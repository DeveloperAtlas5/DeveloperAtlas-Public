const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const rootDir = path.resolve(__dirname, "..");
const shareDir = path.join(rootDir, "output", "share");
const sourcePackageDir = path.join(shareDir, "developer-atlas-mvp-demo");

const fullCopyItems = [
  { from: "output/experience/START_HERE.md", to: "START_HERE.md" },
  { from: "output/experience/first-time-quick-start.md", to: "first-time-quick-start.md" },
  { from: "output/experience/mission-dashboard.html", to: "mission-dashboard.html" },
  { from: "output/experience/ai-prompt-pack.md", to: "ai/ai-prompt-pack.md" },
  { from: "output/experience/canon/hardened", to: "reference/canon/hardened", type: "directory" },
  { from: "output/experience/concepts", to: "concepts", type: "directory" },
  { from: "output/experience/project-start", to: "project-start", type: "directory" },
  { from: "output/experience/beginner-orientation.md", to: "help/beginner-orientation.md" },
  { from: "output/experience/vue-concept-cards.md", to: "help/vue-concept-cards.md" },
  { from: "output/experience/terminal-confidence-guide.md", to: "help/terminal-confidence-guide.md" },
  { from: "output/experience/today-mission-surface.md", to: "mission/today-mission-surface.md" },
  { from: "output/experience/today-mission-surface.vibe.md", to: "mission/today-mission-surface.vibe.md" },
  { from: "output/experience/mission-02-todoitem-surface.md", to: "mission/mission-02-todoitem-surface.md" },
  { from: "output/experience/mission-02-todoitem-surface.vibe.md", to: "mission/mission-02-todoitem-surface.vibe.md" },
  { from: "output/experience/mission-03-todostats-surface.md", to: "mission/mission-03-todostats-surface.md" },
  { from: "output/experience/mission-03-todostats-surface.vibe.md", to: "mission/mission-03-todostats-surface.vibe.md" },
  { from: "output/experience/mission-feedback-template.md", to: "mission/mission-feedback-template.md" },
  { from: "output/experience/tester-feedback-report.md", to: "reviewer/tester-feedback-report.md" },
  { from: "output/experience/tester-handoff-messages.md", to: "reviewer/tester-handoff-messages.md" },
  { from: "output/experience/public-alpha-readiness-report.md", to: "reviewer/public-alpha-readiness-report.md" },
  { from: "output/experience/alpha-focus-lock.md", to: "reviewer/alpha-focus-lock.md" },
  { from: "output/experience/canon-candidate-backlog-report.md", to: "reviewer/canon-candidate-backlog-report.md" },
  { from: "output/experience/alpha-package-final-qa.md", to: "reviewer/alpha-package-final-qa.md" },
  { from: "output/experience/human-ai-readability-audit.md", to: "reviewer/human-ai-readability-audit.md" },
  { from: "output/experience/inherited-warning-burndown-report.md", to: "reviewer/inherited-warning-burndown-report.md" },
  { from: "output/experience/ai-guardrail-evaluation.md", to: "reviewer/ai-guardrail-evaluation.md" },
  { from: "output/experience/ai-guardrail-red-team-pack.md", to: "reviewer/ai-guardrail-red-team-pack.md" },
  { from: "output/experience/ai-red-team-results-template.md", to: "reviewer/ai-red-team-results-template.md" },
  { from: "output/experience/multi-pack-distribution-report.md", to: "reviewer/multi-pack-distribution-report.md" },
  { from: "output/experience/which-pack-should-i-send.md", to: "reviewer/which-pack-should-i-send.md" },
  { from: "output/experience/pack-send-checklist.md", to: "reviewer/pack-send-checklist.md" },
  { from: "output/experience/real-feedback-register.md", to: "reviewer/real-feedback-register.md" },
  { from: "site", to: "reviewer/site", type: "directory" },
  { from: "output/demo/mvp-demo-pack.md", to: "reviewer/demo/mvp-demo-pack.md" },
  { from: "output/demo/demo-walkthrough.md", to: "reviewer/demo/demo-walkthrough.md" },
  { from: "output/demo/ai-demo-brief.md", to: "reviewer/demo/ai-demo-brief.md" },
  { from: "output/mission/today-mission.md", to: "mission/today-mission.md" },
  { from: "output/mission/mission-report.md", to: "reviewer/reports/mission-report.md" },
  { from: "output/mission/mission-experience-report.md", to: "reviewer/reports/mission-experience-report.md" },
  { from: "output/flow/rookie-vue-todo-flow.md", to: "reviewer/flow/rookie-vue-todo-flow.md" },
  { from: "output/flow/flow-report.md", to: "reviewer/reports/flow-report.md" },
  { from: "output/walkthrough/rookie-vue-todo.md", to: "reviewer/walkthrough/rookie-vue-todo.md" },
  { from: "output/canon/canon-report.md", to: "reviewer/reports/canon-report.md" },
  { from: "output/capability/capability-pathway.md", to: "reviewer/reports/capability-pathway.md" },
  { from: "output/setup-advisor/beginner-vue-windows.md", to: "reviewer/advisors/setup-beginner-vue-windows.md" },
  { from: "output/recovery-advisor/npm-install-fails.md", to: "reviewer/advisors/recovery-npm-install-fails.md" },
  { from: "output/ai-context/ai-context-report.md", to: "reviewer/reports/ai-context-report.md" },
  { from: "output/team-context/team-context-quality-report.md", to: "reviewer/reports/team-context-quality-report.md" }
];

const rookieCopyItems = [
  { from: "output/experience/terminal-confidence-guide.md", to: "help/terminal-confidence-guide.md" }
];

const devProjectItems = [
  { from: "tools", to: "tools", type: "directory" },
  { from: "docs", to: "docs", type: "directory" },
  { from: "content", to: "content", type: "directory" },
  { from: "content/concepts", to: "project/concepts-source", type: "directory" },
  { from: "schemas", to: "schemas", type: "directory" },
  { from: "specifications", to: "specifications", type: "directory", optional: true },
  { from: "templates", to: "templates", type: "directory", optional: true },
  { from: "mission", to: "project/mission-source", type: "directory" },
  { from: "canon", to: "project/canon-source", type: "directory" },
  { from: "package.json", to: "package.json" },
  { from: "README.md", to: "README.md", optional: true },
  { from: "package-lock.json", to: "package-lock.json", optional: true },
  { from: "pnpm-lock.yaml", to: "pnpm-lock.yaml", optional: true },
  { from: "output/experience", to: "generated/output/experience", type: "directory" }
];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function removePath(target) {
  if (fs.existsSync(target)) fs.rmSync(target, { recursive: true, force: true });
}

function assertSource(from, optional) {
  const source = path.join(rootDir, from);
  if (!fs.existsSync(source)) {
    if (optional) return null;
    throw new Error(`Missing package source: ${from}`);
  }
  return source;
}

function copyItem(packDir, item) {
  const source = assertSource(item.from, item.optional);
  if (!source) return;
  const destination = path.join(packDir, item.to);
  ensureDir(path.dirname(destination));
  if (item.type === "directory") {
    fs.cpSync(source, destination, {
      recursive: true,
      filter: (entry) => {
        const normalized = entry.replace(/\\/g, "/");
        return !/(^|\/)(node_modules|\.git)(\/|$)/.test(normalized) && !/\.zip$/i.test(normalized);
      }
    });
  } else {
    fs.copyFileSync(source, destination);
  }
}

function countFiles(dir) {
  if (!fs.existsSync(dir)) return 0;
  let count = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const entryPath = path.join(dir, entry.name);
    if (entry.isDirectory()) count += countFiles(entryPath);
    else count += 1;
  }
  return count;
}

function createZip(packDir, zipPath) {
  removePath(zipPath);
  execFileSync(
    "tar",
    [
      "-a",
      "-cf",
      zipPath,
      "-C",
      packDir,
      "."
    ],
    { stdio: "inherit" }
  );
  if (!fs.existsSync(zipPath)) throw new Error(`Zip was not created: ${zipPath}`);
}

function rewriteReviewerSiteLinks(packDir) {
  const indexPath = path.join(packDir, "reviewer", "site", "index.html");
  if (!fs.existsSync(indexPath)) return;
  const replacements = new Map([
    ["../output/experience/today-mission-surface.md", "../../mission/today-mission-surface.md"],
    ["../output/experience/today-mission-surface.vibe.md", "../../mission/today-mission-surface.vibe.md"],
    ["../output/mission/today-mission.md", "../../mission/today-mission.md"],
    ["../output/flow/rookie-vue-todo-flow.md", "../flow/rookie-vue-todo-flow.md"],
    ["../output/walkthrough/rookie-vue-todo.md", "../walkthrough/rookie-vue-todo.md"],
    ["../output/demo/mvp-demo-pack.md", "../demo/mvp-demo-pack.md"]
  ]);
  let html = fs.readFileSync(indexPath, "utf8");
  for (const [source, destination] of replacements) {
    html = html.split(source).join(destination);
  }
  fs.writeFileSync(indexPath, html);
}

function getRookieMissionLines() {
  return [
    "# Mission 1 - Make your to-do list stay saved after you refresh the page",
    "",
    "## Before you start",
    "",
    "This Rookie Pack starts after your basic Vue to-do project already exists.",
    "",
    "You need a basic Vue to-do project already open in VS Code.",
    "",
    "If your Vue project is not created yet, stop here and get the starter project first.",
    "",
    "Atlas is where you read.",
    "",
    "Your Vue project is where you code.",
    "",
    "First action: open your Vue project.",
    "",
    "In normal text, this guide says \"to-do\". In code, you may see `todo` or `todos` as variable names.",
    "",
    "## What you will do",
    "",
    "- Find where your to-do items are stored.",
    "- Save to-do items to `localStorage` when they change.",
    "- Load saved to-do items when the app starts.",
    "- Refresh the browser and check that a to-do item is still there.",
    "",
    "## Where you will code",
    "",
    "You will make the change in your Vue project, not in the Atlas files.",
    "",
    "For many small Vue projects, the first file to check is `src/App.vue`.",
    "",
    "## Step 1 - Open your Vue project",
    "",
    "Open your Vue project.",
    "",
    "Open `src/App.vue`.",
    "",
    "Find where your to-do items are stored. In code, this may look like `ref([])`, `reactive(...)`, or a variable named `todos`.",
    "",
    "Do not move files around for this mission.",
    "",
    "## Step 2 - Save to-do items",
    "",
    "After your app adds, removes, edits, or completes a to-do item, save the current list.",
    "",
    "Use one storage key, for example:",
    "",
    "```js",
    "localStorage.setItem(\"todos\", JSON.stringify(todos.value))",
    "```",
    "",
    "If your code does not use the name `todos`, use your app's actual variable name.",
    "",
    "## Step 3 - Load to-do items after refresh",
    "",
    "When the app starts, read the saved value before showing the list.",
    "",
    "Use a safe fallback so the app still opens when nothing is saved yet.",
    "",
    "```js",
    "const savedTodos = localStorage.getItem(\"todos\")",
    "const todos = ref(savedTodos ? JSON.parse(savedTodos) : [])",
    "```",
    "",
    "Match this to your existing code. The exact line may need to change if your app already creates the list differently.",
    "",
    "## Check your work",
    "",
    "- Run `npm run dev` if the app is not already running.",
    "- Add one to-do item.",
    "- Refresh the browser.",
    "- Confirm the to-do item is still visible.",
    "- Complete or remove a to-do item if your app supports it.",
    "- Refresh again.",
    "",
    "Visible win: your to-do list stays saved after you refresh the page.",
    "",
    "## If you get stuck",
    "",
    "- To-do items disappear after refresh: make sure you load once when the app starts and save again after each list change.",
    "- `[object Object]` appears: use `JSON.stringify()` before saving arrays or objects.",
    "- JSON error: clear the saved value in the browser and try again.",
    "- Terminal feels confusing: open `help/terminal-confidence-guide.md`.",
    "",
    "## Extra context",
    "",
    "Vue state is the data your page is using right now. If the state changes, the page updates.",
    "",
    "For this mission, your to-do items are in Vue state while the page is open. `localStorage` lets them stay saved after refresh.",
    "",
    "`localStorage` is browser storage for small, non-sensitive data.",
    "",
    "Use it here because your to-do items should still be there after refresh.",
    "",
    "Do not store passwords, tokens, secrets, or private personal information in browser storage.",
    ""
  ];
}

function escapeHtml(value) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function inlineCode(text) {
  return escapeHtml(text).replace(/`([^`]+)`/g, "<code>$1</code>");
}

function renderRookieMissionHtml(lines) {
  const html = [];
  let paragraph = [];
  let list = [];
  let code = [];
  let inCode = false;

  function flushParagraph() {
    if (!paragraph.length) return;
    html.push(`<p>${paragraph.map(inlineCode).join(" ")}</p>`);
    paragraph = [];
  }

  function flushList() {
    if (!list.length) return;
    html.push("<ul>");
    for (const item of list) html.push(`<li>${inlineCode(item)}</li>`);
    html.push("</ul>");
    list = [];
  }

  for (const line of lines) {
    if (line.startsWith("```")) {
      if (inCode) {
        html.push(`<pre><code>${escapeHtml(code.join("\n"))}</code></pre>`);
        code = [];
        inCode = false;
      } else {
        flushParagraph();
        flushList();
        inCode = true;
      }
      continue;
    }
    if (inCode) {
      code.push(line);
      continue;
    }
    if (!line.trim()) {
      flushParagraph();
      flushList();
      continue;
    }
    if (line.startsWith("# ")) {
      flushParagraph();
      flushList();
      html.push(`<h2>${inlineCode(line.slice(2))}</h2>`);
      continue;
    }
    if (line.startsWith("## ")) {
      flushParagraph();
      flushList();
      html.push(`<h3>${inlineCode(line.slice(3))}</h3>`);
      continue;
    }
    if (line.startsWith("- ")) {
      flushParagraph();
      list.push(line.slice(2));
      continue;
    }
    flushList();
    paragraph.push(line);
  }
  flushParagraph();
  flushList();
  return html.join("\n");
}

function renderQuickTerms() {
  const terms = [
    ["Vue state", "The data your page is using right now.", "Your to-do items are in state while the page is open. This mission saves them so they come back after refresh."],
    ["ref", "A Vue helper for a value that can change.", "Your app may use `ref([])` to hold the to-do list."],
    ["localStorage", "Small browser storage that can keep simple data after refresh.", "This mission saves the to-do list there."],
    ["App.vue", "A common starting file in small Vue projects.", "This is the first file to check for your to-do list code."],
    ["refresh", "Reloading the browser page.", "The win is that your to-do item is still visible after refresh."],
    ["browser", "The app where you view and test the page.", "Atlas opens in your browser, and your Vue app preview opens there too."],
    ["terminal", "A place to run project commands.", "Use it for `npm run dev` if your Vue app is not already running."]
  ];
  return terms.map(([term, meaning, mission]) => [
    "<details>",
    `<summary>${escapeHtml(term)}</summary>`,
    `<p>${inlineCode(meaning)}</p>`,
    `<p>${inlineCode(mission)}</p>`,
    "</details>"
  ].join("\n")).join("\n");
}

function writeRookieDashboard(packDir) {
  const missionHtml = renderRookieMissionHtml(getRookieMissionLines());
  const quickTermsHtml = renderQuickTerms();
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Developer Atlas Rookie Reader</title>
  <style>
    :root { color-scheme: light; --bg: #efe8da; --page: #fffaf0; --ink: #24201a; --muted: #675f52; --line: #d9cdb8; --accent: #27645b; --code: #f3eadb; --button: #ffffff; --focus: #111827; font-size: 18px; }
    body.contrast { --bg: #0f172a; --page: #ffffff; --ink: #111827; --muted: #374151; --line: #111827; --accent: #0f766e; --code: #f3f4f6; --button: #ffffff; --focus: #f59e0b; }
    body { margin: 0; background: var(--bg); color: var(--ink); font-family: Georgia, "Times New Roman", serif; line-height: 1.78; }
    .topbar { position: sticky; top: 0; z-index: 2; background: var(--page); border-bottom: 1px solid var(--line); }
    .topbar-inner { width: min(100% - 28px, 1120px); margin: 0 auto; display: flex; flex-wrap: wrap; gap: 12px; align-items: center; justify-content: space-between; padding: 12px 0; }
    .brand { font-family: Arial, sans-serif; font-weight: 700; }
    .controls { display: flex; flex-wrap: wrap; gap: 8px; }
    button { border: 1px solid var(--line); border-radius: 6px; padding: 9px 11px; background: var(--button); color: var(--ink); font: 700 0.95rem Arial, sans-serif; cursor: pointer; }
    button:focus, a:focus, summary:focus { outline: 3px solid var(--focus); outline-offset: 3px; }
    .layout { width: min(100% - 28px, 1120px); margin: 0 auto; display: grid; grid-template-columns: minmax(0, 760px) minmax(250px, 1fr); gap: 22px; padding: 24px 0 42px; }
    .page, .side-card { background: var(--page); border: 1px solid var(--line); border-radius: 8px; box-shadow: 0 10px 30px rgba(38, 32, 24, 0.08); }
    .page { padding: clamp(22px, 5vw, 54px); }
    .side { display: grid; gap: 16px; align-content: start; }
    .side-card { padding: 18px; font-family: Arial, sans-serif; line-height: 1.55; }
    h1, h2, h3 { line-height: 1.2; color: var(--ink); }
    h1 { margin: 0 0 8px; font-size: 1.1rem; font-family: Arial, sans-serif; }
    h2 { margin: 0 0 18px; font-size: 2.05rem; }
    h3 { margin: 34px 0 10px; font-size: 1.32rem; border-top: 1px solid var(--line); padding-top: 22px; }
    p, li { font-size: 1rem; }
    .reader-kicker, .note { color: var(--muted); font-family: Arial, sans-serif; }
    .reminder { border-left: 4px solid var(--accent); background: rgba(39, 100, 91, 0.08); padding: 12px 14px; margin: 18px 0 24px; font-family: Arial, sans-serif; }
    code { font-family: Consolas, "Liberation Mono", monospace; background: var(--code); padding: 1px 4px; border-radius: 4px; }
    pre { overflow-x: auto; background: var(--code); padding: 14px; border-radius: 8px; border: 1px solid var(--line); }
    pre code { padding: 0; background: transparent; }
    a { color: var(--accent); font-weight: 700; }
    details { border-top: 1px solid var(--line); padding: 10px 0; }
    summary { cursor: pointer; font-weight: 700; }
    details p { margin: 8px 0 0; font-size: 0.95rem; }
    .reader-content { font-size: var(--reader-size, 1rem); }
    .reader-content p, .reader-content li { font-size: var(--reader-size, 1rem); }
    @media (max-width: 860px) {
      .layout { grid-template-columns: 1fr; }
      .topbar { position: static; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="topbar-inner">
      <h1>Developer Atlas Rookie Reader <span class="note">Mission 1</span></h1>
      <div class="controls" aria-label="Reader controls">
        <button type="button" id="smaller-text">Smaller text</button>
        <button type="button" id="larger-text">Larger text</button>
        <button type="button" id="toggle-theme">High contrast</button>
      </div>
    </div>
  </header>
  <main class="layout">
    <article class="page" aria-labelledby="mission-title">
      <p class="reader-kicker">Atlas Reader - a calm book-style guide</p>
      <h2 id="mission-title">Mission 1 - Make your to-do list stay saved after you refresh the page</h2>
      <div class="reminder">
        <p><strong>Start Mission 1 here.</strong></p>
        <strong>Read in Atlas. Code in your Vue project.</strong>
        <p>You do not need to browse the folders. This page includes the mission so you can read it like a small book in your browser.</p>
      </div>
      <div class="reader-content">
${missionHtml}
      </div>
    </article>
    <aside class="side" aria-label="Reader support">
      <section class="side-card" aria-labelledby="quick-terms">
        <h2 id="quick-terms">Quick Terms</h2>
        <p class="note">Optional. Open a term only when a word feels unfamiliar.</p>
${quickTermsHtml}
      </section>
      <section class="side-card" aria-labelledby="browser-open">
        <h2 id="browser-open">Open in your browser</h2>
        <p>Open <code>mission-dashboard.html</code> from Windows File Explorer.</p>
        <p>If it opens in VS Code, open the extracted folder in Windows File Explorer and double-click <code>mission-dashboard.html</code>.</p>
        <p>This reader works without internet and does not load Markdown from another local file.</p>
      </section>
      <section class="side-card" aria-labelledby="help">
        <h2 id="help">Help if needed</h2>
        <p><a href="help/terminal-confidence-guide.md">Open terminal help</a> only if terminal commands feel confusing.</p>
      </section>
      <section class="side-card" aria-labelledby="read-aloud">
      <h2 id="read-aloud">Read-aloud option</h2>
      <p>Use this optional control if listening helps.</p>
      <button type="button" id="read-dashboard">Read dashboard aloud</button>
      <button type="button" id="stop-reading">Stop reading</button>
      <p id="read-status" aria-live="polite">Read-aloud is ready if your browser supports it.</p>
      </section>
    </aside>
  </main>
  <script>
    let size = 1;
    const readButton = document.getElementById("read-dashboard");
    const stopButton = document.getElementById("stop-reading");
    const status = document.getElementById("read-status");
    const reader = document.querySelector(".reader-content");
    const summary = "Developer Atlas Rookie Reader. Read in Atlas. Code in your Vue project. You do not need to browse folders. Mission 1 makes your to-do list stay saved after refresh.";
    document.getElementById("larger-text").addEventListener("click", () => {
      size = Math.min(1.35, size + 0.1);
      reader.style.setProperty("--reader-size", size + "rem");
    });
    document.getElementById("smaller-text").addEventListener("click", () => {
      size = Math.max(0.95, size - 0.1);
      reader.style.setProperty("--reader-size", size + "rem");
    });
    document.getElementById("toggle-theme").addEventListener("click", () => {
      document.body.classList.toggle("contrast");
    });
    readButton.addEventListener("click", () => {
      if (!("speechSynthesis" in window)) {
        status.textContent = "Read-aloud is not supported in this browser.";
        return;
      }
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(summary);
      status.textContent = "Reading dashboard summary.";
      utterance.onend = () => { status.textContent = "Read-aloud finished."; };
      window.speechSynthesis.speak(utterance);
    });
    stopButton.addEventListener("click", () => {
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
      status.textContent = "Read-aloud stopped.";
    });
  </script>
</body>
</html>
`;
  fs.writeFileSync(path.join(packDir, "mission-dashboard.html"), html);
}

function writeRookieStartHere(packDir) {
  const text = [
    "# Developer Atlas Rookie Pack",
    "Open `mission-dashboard.html` from Windows File Explorer.",
    "It opens Atlas like a small book in your browser.",
    "If it opens in VS Code, open the extracted folder in Windows File Explorer and double-click `mission-dashboard.html`.",
    "This Rookie Pack starts after your basic Vue to-do project already exists.",
    "You need a basic Vue to-do project already open in VS Code.",
    "Read in Atlas.",
    "Code in your Vue project.",
    "You do not need to browse the folders.",
    "If the terminal feels confusing, open `help/terminal-confidence-guide.md`.",
    ""
  ].join("\n");
  fs.writeFileSync(path.join(packDir, "START_HERE.md"), text);
}

function writeRookieMissionSurface(packDir) {
  const text = getRookieMissionLines().join("\n");
  const missionPath = path.join(packDir, "mission", "today-mission-surface.md");
  ensureDir(path.dirname(missionPath));
  fs.writeFileSync(missionPath, text);
}

function writeDevDashboard(packDir) {
  const source = path.join(rootDir, "output", "experience", "mission-dashboard.html");
  const destination = path.join(packDir, "mission-dashboard.html");
  fs.copyFileSync(source, destination);
}

function writeManifest(packDir, config, zipPath) {
  const manifest = {
    pack_name: config.name,
    pack_audience: config.audience,
    manifest_scope: "Primary files and directories only. Nested files are counted by filesystem checks, not listed one by one.",
    generated_at: new Date().toISOString(),
    entry_points: config.entryPoints,
    directories: config.directories,
    notes: config.notes,
    zip_path: path.relative(rootDir, zipPath).replace(/\\/g, "/"),
    actual_file_count: countFiles(packDir)
  };
  fs.writeFileSync(path.join(packDir, "package-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
  return manifest;
}

function writeMultiPackReport(results) {
  const lines = [
    "# Multi-Pack Distribution Report",
    "",
    "## Purpose",
    "",
    "Phase 116 creates three audience-specific packages so different users receive different package weight.",
    "",
    "Use `which-pack-should-i-send.md` to choose a pack, then `pack-send-checklist.md` before sending it.",
    "",
    "Phase 119 simplified the Rookie Pack into a non-AI Mission 1 first-reaction test.",
    "",
    "First tester signal: the Rookie Pack start was clear, but Mission 1 needed better laptop readability.",
    "",
    "Second tester signal: the Rookie Pack assumes the learner already has a basic Vue project. It is not a zero-install or zero-project setup pack.",
    "",
    "Real tester feedback is tracked in `reviewer/real-feedback-register.md`. Keep it separate from simulated feedback.",
    "",
    "## Pack Summary",
    "",
    "| Pack | Audience | Dashboard variant | File count | Manifest entries |",
    "|---|---|---|---:|---:|"
  ];

  for (const result of results) {
    lines.push(`| ${result.name} | ${result.audience} | ${result.dashboardVariant} | ${result.fileCount} | ${result.manifestEntries} |`);
  }

  lines.push(
    "",
    "## Included Folders",
    "",
    "- Rookie Pack: `mission/`, `help/`.",
    "- Full Pack: `mission/`, `help/`, `ai/`, `reference/`, `concepts/`, `project-start/`, `reviewer/`.",
    "- Dev Pack: Full Pack plus `tools/`, `docs/`, `content/`, `schemas/`, source context, generated concept output, and generated experience output.",
    "",
    "## Intentional Exclusions",
    "",
    "- Rookie Pack excludes AI, reference, Concept Library, Project Start Guides, Mission 2, Mission 3, feedback templates, reviewer files, tools, docs, content, and dev material.",
    "- Full Pack keeps reviewer files under `reviewer/` and keeps them out of the default learner path.",
    "- Dev Pack excludes `node_modules/`, `.git/`, and old zip artifacts.",
    "",
    "## Validation Summary",
    "",
    "- Pack manifests clarify that they list primary files and directories, not every nested file.",
    "- Pack-specific dashboards avoid links to files not included in that pack.",
    "- Rookie Pack keeps Mission 1 as the first visible action.",
    "- Full Pack keeps Mission 1 -> Mission 2 -> Mission 3 available.",
    "- Dev Pack includes maintainer context without adding learner scope.",
    "",
    "## Recommended Distribution Usage",
    "",
    "- Send Rookie Pack to complete beginners and first-time testers only when they already have a basic Vue project and you need a Mission 1 first reaction.",
    "- Send Full Pack to normal learners, AI-assisted builders, and learners testing Missions 1-3.",
    "- Send Dev Pack to maintainers, reviewers, contributors, or future AI editing sessions.",
    "- Use `reviewer/real-feedback-register.md` to separate real tester feedback from simulated or internal feedback.",
    "",
    "Future Atlas flow idea: Goal -> Build or Learn -> Solo or AI Help -> Concept Library / Mission Path.",
    ""
  );

  const reportPath = path.join(rootDir, "output", "experience", "multi-pack-distribution-report.md");
  ensureDir(path.dirname(reportPath));
  fs.writeFileSync(reportPath, lines.join("\n"));
}

function writePackSelectorNote() {
  const lines = [
    "# Which Pack Should I Send?",
    "",
    "## Use Rookie Pack when...",
    "",
    "- The tester is a complete beginner.",
    "- The tester may feel overwhelmed by many files.",
    "- You only want feedback on Mission 1.",
    "- You want to test first impression and folder clarity.",
    "- You want the lowest-friction start.",
    "- The learner already has a basic Vue to-do project open.",
    "",
    "Rookie Pack is non-AI and Mission 1 only.",
    "",
    "Rookie Pack is the safest first send for beginners who already have a basic Vue project.",
    "",
    "Rookie Pack is not a zero-install or zero-project setup pack.",
    "",
    "Real feedback about pack fit should be recorded in `reviewer/real-feedback-register.md` after sending.",
    "",
    "## Use Full Pack when...",
    "",
    "- The tester is ready for Missions 1-3.",
    "- The tester may use AI help.",
    "- The tester can handle optional folders.",
    "- You want feedback on the current complete learner experience.",
    "",
    "Use Full Pack for AI-assisted learner testing.",
    "",
    "Send Full Pack when you want AI-assisted testing or Missions 1-3.",
    "",
    "## Use Dev Pack when...",
    "",
    "- The recipient is a maintainer.",
    "- The recipient is reviewing how Atlas is built.",
    "- The recipient needs tools, validators, templates, docs, or content.",
    "- The recipient may contribute to the project.",
    "",
    "Do not send Dev Pack to normal beginners.",
    "",
    "## Default recommendation",
    "",
    "When unsure, send Rookie Pack first only if the learner already has a Vue project. Send Full Pack after the learner is comfortable, ready for AI-assisted testing, or ready for Missions 1-3. Keep Dev Pack for maintainers.",
    "",
    "## Simple decision table",
    "",
    "| Situation | Send |",
    "|---|---|",
    "| Complete beginner with a Vue project | Rookie Pack |",
    "| First-impression test | Rookie Pack |",
    "| Testing Mission 1 only | Rookie Pack |",
    "| Testing Missions 1-3 | Full Pack |",
    "| AI-assisted learner test | Full Pack |",
    "| Mentor/reviewer testing learner flow | Full Pack |",
    "| Maintainer or contributor | Dev Pack |",
    "| Someone asks how Atlas is built | Dev Pack |",
    "",
    "## What not to send",
    "",
    "Do not send Dev Pack to a beginner unless they explicitly need the full project internals.",
    "",
    "Do not send Full Pack when you only need Mission 1 feedback.",
    "",
    "Do not send multiple packs at once to a new tester.",
    "",
    "Multiple zips can create the same decision fatigue Atlas is trying to reduce.",
    "",
    "## After sending a pack",
    "",
    "After choosing a pack, use `pack-send-checklist.md` before sending it.",
    "",
    "After receiving real tester feedback, record it in `reviewer/real-feedback-register.md`.",
    "",
    "Ask only one or two questions after sending a pack.",
    "",
    "For Rookie Pack, ask: \"Was it clear that this starts after your Vue project already exists?\"",
    "",
    "For Full Pack, ask: \"Could you follow the missions without feeling lost?\"",
    "",
    "For Dev Pack, ask: \"Could you find the build, validation, and packaging files?\"",
    ""
  ];
  const notePath = path.join(rootDir, "output", "experience", "which-pack-should-i-send.md");
  ensureDir(path.dirname(notePath));
  fs.writeFileSync(notePath, lines.join("\n"));
}

function writePackSendChecklist() {
  const lines = [
    "# Pack Send Checklist",
    "",
    "## Purpose",
    "",
    "Use this checklist before sending an Atlas pack to a tester.",
    "",
    "This is owner-facing and not required learner reading.",
    "",
    "## Before sending",
    "",
    "- Run `npm run package:packs`.",
    "- Run `npm run validate:packs`.",
    "- Choose one tester goal.",
    "- Choose one pack.",
    "- Do not send multiple packs to a new tester.",
    "",
    "## Pick one pack",
    "",
    "- Complete beginner or first-impression test with a basic Vue project already open: Rookie Pack.",
    "- Rookie Mission 1 non-AI test: Rookie Pack.",
    "- Normal learner, AI-assisted, or Missions 1-3 test: Full Pack.",
    "- Maintainer or contributor: Dev Pack.",
    "- Unsure: Rookie Pack first.",
    "",
    "Use `which-pack-should-i-send.md` if the choice is unclear.",
    "",
    "Use `real-feedback-register.md` after the tester responds.",
    "",
    "## Send one zip",
    "",
    "Send only one zip.",
    "",
    "Tell the tester what to open first.",
    "",
    "For Rookie and Full Pack, tell them to open `mission-dashboard.html` in a browser.",
    "",
    "For Rookie Pack, tell them it starts after their basic Vue to-do project already exists.",
    "",
    "For Rookie Pack, do not mention AI or reference material.",
    "",
    "First tester signal: the Rookie Pack start was clear, but Mission 1 needed better laptop readability.",
    "",
    "Second tester signal: Rookie Pack is not a zero-install or zero-project setup pack.",
    "",
    "Do not explain every folder before they open it.",
    "",
    "## Ask one question",
    "",
    "- Rookie Pack: Was it clear this starts after your Vue project already exists?",
    "- Full Pack: Could you follow the missions without feeling lost?",
    "- Dev Pack: Could you find the build, validation, and packaging files?",
    "",
    "Ask one main question first. Add follow-up questions only after they respond.",
    "",
    "## Record the result",
    "",
    "- Record pack sent.",
    "- Record tester type.",
    "- Record first reaction.",
    "- Record where they got stuck.",
    "- Record the next improvement.",
    "- Record real feedback in `reviewer/real-feedback-register.md`.",
    "",
    "## What not to do",
    "",
    "- Do not send all packs at once.",
    "- Do not send Dev Pack to a beginner.",
    "- Do not explain the whole project before the tester opens the pack.",
    "- Do not ask for too much feedback in the first message.",
    "- Do not add new features before recording the result.",
    "- For Rookie Pack, do not mention AI or reference material.",
    "",
    "## Quick copy/paste messages",
    "",
    "### Rookie Pack message",
    "",
    "Hey, I'm testing the beginner version of Developer Atlas. This starts after you already have a basic Vue to-do project. Please unzip this, open `mission-dashboard.html` in your browser, and tell me one thing first: is that starting point clear?",
    "",
    "### Full Pack message",
    "",
    "Hey, I'm testing the current learner version of Developer Atlas. Please unzip this, open `mission-dashboard.html`, try the mission path, and tell me whether you could follow it without feeling lost.",
    "",
    "### Dev Pack message",
    "",
    "Hey, I'm sharing the maintainer version of Developer Atlas. This includes the build, validation, packaging, docs, and project internals. Please check whether you can find the files needed to understand how the package is built.",
    ""
  ];
  const checklistPath = path.join(rootDir, "output", "experience", "pack-send-checklist.md");
  ensureDir(path.dirname(checklistPath));
  fs.writeFileSync(checklistPath, lines.join("\n"));
}

function buildRookiePack(config) {
  const packDir = path.join(shareDir, config.dirName);
  removePath(packDir);
  ensureDir(packDir);
  for (const item of rookieCopyItems) copyItem(packDir, item);
  writeRookieMissionSurface(packDir);
  writeRookieDashboard(packDir);
  writeRookieStartHere(packDir);
  return packDir;
}

function buildFullPack(config) {
  const packDir = path.join(shareDir, config.dirName);
  removePath(packDir);
  ensureDir(packDir);
  for (const item of fullCopyItems) copyItem(packDir, item);
  rewriteReviewerSiteLinks(packDir);
  return packDir;
}

function buildDevPack(config) {
  const packDir = buildFullPack(config);
  for (const item of devProjectItems) copyItem(packDir, item);
  writeDevDashboard(packDir);
  return packDir;
}

const packConfigs = [
  {
    name: "Rookie Pack",
    dirName: "developer-atlas-rookie-pack",
    zipName: "developer-atlas-rookie-pack.zip",
    audience: "Complete beginners and first-time testers",
    dashboardVariant: "Rookie Mission 1 dashboard",
    entryPoints: ["mission-dashboard.html", "START_HERE.md"],
    directories: ["mission/", "help/"],
    notes: ["Mission 1 only.", "Non-AI by default.", "Reference and reviewer material intentionally excluded."],
    build: buildRookiePack
  },
  {
    name: "Full Pack",
    dirName: "developer-atlas-full-pack",
    zipName: "developer-atlas-full-pack.zip",
    audience: "Normal learners, Rookie-to-Junior learners, and AI-assisted builders",
    dashboardVariant: "Full learner dashboard",
    entryPoints: ["mission-dashboard.html", "first-time-quick-start.md", "START_HERE.md"],
    directories: ["mission/", "help/", "ai/", "reference/", "concepts/", "project-start/", "reviewer/"],
    notes: ["Includes Missions 1-3.", "Project Start Guides are optional.", "Reviewer files remain under reviewer/.", "AI path remains secondary."],
    build: buildFullPack
  },
  {
    name: "Dev Pack",
    dirName: "developer-atlas-dev-pack",
    zipName: "developer-atlas-dev-pack.zip",
    audience: "Maintainers, reviewers, contributors, and future AI editing sessions",
    dashboardVariant: "Full dashboard plus maintainer context",
    entryPoints: ["mission-dashboard.html", "first-time-quick-start.md", "START_HERE.md", "package.json"],
    directories: ["mission/", "help/", "ai/", "reference/", "concepts/", "project-start/", "reviewer/", "tools/", "docs/", "content/", "schemas/", "generated/"],
    notes: ["Includes Full Pack content plus source and validator context.", "Excludes node_modules, .git, and old zips."],
    build: buildDevPack
  }
];

function main() {
  if (!fs.existsSync(sourcePackageDir)) {
    console.log("Existing MVP package not found; building packs from generated outputs.");
  }
  execFileSync("node", ["tools/generate-concept-library.js"], { cwd: rootDir, stdio: "inherit" });
  execFileSync("node", ["tools/generate-project-start-guides.js"], { cwd: rootDir, stdio: "inherit" });
  execFileSync("node", ["tools/generate-real-feedback-register.js"], { cwd: rootDir, stdio: "inherit" });

  const preliminaryResults = packConfigs.map((config) => ({
    name: config.name,
    audience: config.audience,
    dashboardVariant: config.dashboardVariant,
    fileCount: 0,
    manifestEntries: config.entryPoints.length + config.directories.length
  }));
  writePackSelectorNote();
  writePackSendChecklist();
  writeMultiPackReport(preliminaryResults);

  const results = [];
  for (const config of packConfigs) {
    const packDir = config.build(config);
    const zipPath = path.join(shareDir, config.zipName);
    const manifest = writeManifest(packDir, config, zipPath);
    createZip(packDir, zipPath);
    const fileCount = countFiles(packDir);
    results.push({
      name: config.name,
      audience: config.audience,
      dashboardVariant: config.dashboardVariant,
      fileCount,
      manifestEntries: manifest.entry_points.length + manifest.directories.length
    });
    console.log(`${config.name} created: ${path.relative(rootDir, zipPath).replace(/\\/g, "/")} (${fileCount} files)`);
  }

  writeMultiPackReport(results);
  for (const config of packConfigs.filter((item) => item.name !== "Rookie Pack")) {
    const packDir = path.join(shareDir, config.dirName);
    copyItem(packDir, {
      from: "output/experience/multi-pack-distribution-report.md",
      to: "reviewer/multi-pack-distribution-report.md"
    });
    const zipPath = path.join(shareDir, config.zipName);
    const manifestPath = path.join(packDir, "package-manifest.json");
    const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
    manifest.actual_file_count = countFiles(packDir);
    fs.writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
    createZip(packDir, zipPath);
  }
}

main();
