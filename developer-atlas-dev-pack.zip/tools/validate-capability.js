const fs = require("fs");
const path = require("path");
const { readGoals } = require("./goal-utils");
const { readTools } = require("./toolkit-utils");
const { readFrictionNodes } = require("./friction-utils");
const { readWorkloadProfiles } = require("./hardware-utils");
const {
  capabilityDir,
  readCapabilities
} = require("./capability-utils");

const schemaFiles = [
  "capability.schema.json",
  "capability-report.schema.json",
  "project-fit.schema.json"
];

const requiredFields = [
  "capability_id",
  "title",
  "category",
  "description",
  "required_goals",
  "required_canon_nodes",
  "required_tools",
  "required_hardware_workloads",
  "common_friction_nodes",
  "minimum_readiness_score",
  "recommended_readiness_score",
  "estimated_hours",
  "difficulty",
  "output_artifact",
  "success_criteria",
  "avoid_if",
  "beginner_notes",
  "professional_notes",
  "ai_context_prompt"
];

const arrayFields = [
  "required_goals",
  "required_canon_nodes",
  "required_tools",
  "required_hardware_workloads",
  "common_friction_nodes",
  "success_criteria",
  "avoid_if",
  "beginner_notes",
  "professional_notes"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);

  let capabilities = [];
  try {
    capabilities = readCapabilities();
  } catch (error) {
    errors.push(`capability/examples: unable to read capabilities (${error.message})`);
  }

  const knownIds = collectKnownIds();
  validateCapabilities(capabilities, knownIds, errors, warnings);

  console.log("Atlas Capability validation");
  console.log(`Capabilities: ${capabilities.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const schemaPath = path.join(capabilityDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`capability/${fileName}: missing schema file`);
      continue;
    }
    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`capability/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function collectKnownIds() {
  const canonIndex = JSON.parse(fs.readFileSync(path.join(capabilityDir, "..", "canon", "canon-index.json"), "utf8"));
  return {
    goalIds: new Set(readGoals().map((record) => record.goal.goal_id)),
    canonIds: new Set(canonIndex.entries.map((entry) => entry.canon_id)),
    toolIds: new Set(readTools().map((record) => record.data.id)),
    workloadIds: new Set(readWorkloadProfiles().map((record) => record.workload.workload_id)),
    frictionIds: new Set(readFrictionNodes().map((record) => record.node.id))
  };
}

function validateCapabilities(records, knownIds, errors, warnings) {
  const seen = new Set();

  for (const { capability, relativePath } of records) {
    for (const field of requiredFields) {
      if (capability[field] === undefined || capability[field] === null || capability[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }

    if (seen.has(capability.capability_id)) errors.push(`${relativePath}: duplicate capability_id ${capability.capability_id}`);
    seen.add(capability.capability_id);

    for (const field of arrayFields) validateArray(relativePath, capability, field, errors, field === "common_friction_nodes");
    validateRange(relativePath, capability, "minimum_readiness_score", 0, 100, errors);
    validateRange(relativePath, capability, "recommended_readiness_score", 0, 100, errors);
    validateNonNegative(relativePath, capability, "estimated_hours", errors);

    if (capability.minimum_readiness_score > capability.recommended_readiness_score) {
      errors.push(`${relativePath}: minimum_readiness_score cannot exceed recommended_readiness_score`);
    }

    warnUnknown(relativePath, capability.required_goals, knownIds.goalIds, "required_goals", warnings);
    warnUnknown(relativePath, capability.required_canon_nodes, knownIds.canonIds, "required_canon_nodes", warnings);
    warnUnknown(relativePath, capability.required_tools, knownIds.toolIds, "required_tools", warnings);
    warnUnknown(relativePath, capability.required_hardware_workloads, knownIds.workloadIds, "required_hardware_workloads", warnings);
    warnUnknown(relativePath, capability.common_friction_nodes, knownIds.frictionIds, "common_friction_nodes", warnings);
  }
}

function validateArray(relativePath, data, field, errors, allowEmpty = false) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }
  if (!allowEmpty && data[field].length === 0) errors.push(`${relativePath}: ${field} should not be empty`);
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

function validateRange(relativePath, data, field, min, max, errors) {
  if (typeof data[field] !== "number" || data[field] < min || data[field] > max) {
    errors.push(`${relativePath}: ${field} should be a number from ${min} to ${max}`);
  }
}

function validateNonNegative(relativePath, data, field, errors) {
  if (typeof data[field] !== "number" || data[field] < 0) {
    errors.push(`${relativePath}: ${field} should be a non-negative number`);
  }
}

function warnUnknown(relativePath, values = [], knownSet, label, warnings) {
  for (const value of values) {
    if (!knownSet.has(value)) warnings.push(`${relativePath}: ${label} references unknown id ${value}`);
  }
}

main();
