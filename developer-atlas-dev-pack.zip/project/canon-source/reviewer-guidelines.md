# Canon Reviewer Guidelines

Review Canon nodes for developer judgment, not word count.

## Reviewer Duties

- Check technical accuracy against evidence.
- Confirm examples run or are mechanically correct.
- Confirm the node explains trade-offs.
- Confirm beginner and professional explanations differ in depth.
- Confirm AI guidance is specific enough to prevent common bad code.
- Confirm related nodes are real Atlas node IDs where possible.

## Review Tone

Be precise. Do not ask for more prose unless it reduces confusion.

