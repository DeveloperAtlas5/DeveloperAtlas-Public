# Promise.all() vs Promise.allSettled()

## Status Metadata

- Canon ID: CANON-008
- Node ID: canon.javascript.promise.all-vs-allsettled
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript promises
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `Promise.all()` when every async task must succeed for the operation to be useful. Use `Promise.allSettled()` when each task has independent value and you need a complete success/failure report.

The decision is not about which method is newer or safer. It is about failure semantics:

- `Promise.all()` is fail-fast.
- `Promise.allSettled()` is complete-report.
- Neither method limits concurrency by itself.

## What Problem This Solves

Developers often ask "How do I run these promises together?" That question is too broad. The real decision is what should happen when one task fails.

This node solves a common async decision:

- Choose `Promise.all()` when one failure should reject the whole operation.
- Choose `Promise.allSettled()` when partial success is acceptable or expected.
- Choose sequential `await`, a concurrency pool, or a job queue when parallel fan-out is not the right model.

## Mental Model

Think in contracts.

`Promise.all()` is an all-or-nothing contract. If every task succeeds, you get the values. If one task fails, the combined promise rejects.

```js
const [user, permissions] = await Promise.all([
  fetchUser(userId),
  fetchPermissions(userId)
]);
```

`Promise.allSettled()` is an inspection report. It waits until every task is either fulfilled or rejected, then gives you one result record per task.

```js
const results = await Promise.allSettled(files.map(uploadFile));
```

| Question | Better default |
| --- | --- |
| Is one failure enough to fail the whole operation? | `Promise.all()` |
| Do you need all success and failure details? | `Promise.allSettled()` |
| Are tasks optional or independent? | `Promise.allSettled()` |
| Do tasks depend on previous results? | Sequential `await` |
| Do you need a concurrency limit? | Promise pool or queue |

## Beginner Explanation

Use `Promise.all()` when everything has to work.

If a page needs both the current user and their permissions before it can render safely, one failed request means the page cannot continue:

```js
const [user, permissions] = await Promise.all([
  fetchUser(),
  fetchPermissions()
]);
```

Use `Promise.allSettled()` when you want to know what happened to every task.

If you send 100 notifications, maybe 92 succeed and 8 fail. You still need the full report:

```js
const results = await Promise.allSettled(users.map(sendNotification));
```

Beginner rule:

1. If one failure should stop the whole thing, use `Promise.all()`.
2. If you need a per-task report, use `Promise.allSettled()`.
3. If you need to do tasks one after another, use `for...of` with `await`.

## Professional Explanation

`Promise.all()` returns a promise that fulfills with an array of fulfillment values when all input promises fulfill. It rejects when any input promise rejects, using the first rejection reason observed by the aggregate promise. This fail-fast behavior is correct when the operation has no meaningful partial result.

`Promise.allSettled()` returns a promise that fulfills after every input promise settles. Its result array preserves input order and contains records shaped like `{ status: "fulfilled", value }` or `{ status: "rejected", reason }`. This makes it appropriate for partial-failure workflows, batch operations, fan-out reports, and retry planning.

Both methods observe already-created promises. They do not automatically throttle work, cancel remaining work, retry failures, or make side effects safe. If you create 500 network requests and pass them to either method, the concurrency decision already happened.

In code review, ask:

- Is fail-fast correct?
- Is partial success useful?
- Are rejection reasons preserved?
- Is concurrency bounded when needed?
- Are results mapped back to their source items?

## Syntax

```js
const values = await Promise.all([
  taskA(),
  taskB()
]);
```

```js
const results = await Promise.allSettled([
  taskA(),
  taskB()
]);
```

Result shape for `Promise.allSettled()`:

```js
[
  { status: "fulfilled", value: "ok" },
  { status: "rejected", reason: new Error("failed") }
]
```

## Decision Guide

Ask these questions in order:

1. Must every task succeed for the result to be valid?
   Use `Promise.all()`.
2. Do you need to keep successful results even when some tasks fail?
   Use `Promise.allSettled()`.
3. Do you need a complete report of every task?
   Use `Promise.allSettled()`.
4. Do later tasks depend on earlier task results?
   Use sequential `await` or split the workflow into stages.
5. Are there many tasks that could overwhelm an API, database, or browser?
   Use a concurrency pool or queue.
6. Do you need retry behavior?
   Use `allSettled()` for reporting, then retry rejected items intentionally.

## Comparison Table

| Feature | `Promise.all()` | `Promise.allSettled()` |
| --- | --- | --- |
| Main intent | All-or-nothing parallel work | Complete per-task report |
| Failure behavior | Rejects when one input rejects | Fulfills after all settle |
| Success result | Array of values | Array of status records |
| Partial success | Not returned by the aggregate promise | Explicitly represented |
| Output order | Input order | Input order |
| Best for required data | Yes | Sometimes, if optional sections exist |
| Best for bulk jobs | Only if any failure should fail all | Yes |
| Requires result inspection | Less, unless caught | Yes |
| Limits concurrency | No | No |

## When To Use The Primary Option

Use `Promise.all()` when:

- All tasks are required.
- One failure should make the caller handle the whole operation as failed.
- You want direct fulfillment values instead of status records.
- The tasks are independent and safe to start together.
- Partial data would be misleading or unsafe.

```js
const [account, permissions, subscription] = await Promise.all([
  api.fetchAccount(accountId),
  api.fetchPermissions(accountId),
  api.fetchSubscription(accountId)
]);
```

## When To Use The Alternative

Use `Promise.allSettled()` when:

- Each task has independent value.
- You need a complete success/failure report.
- Partial success is acceptable.
- You need to retry only failed items.
- You need to show which optional widgets, uploads, messages, or imports failed.

```js
const uploadResults = await Promise.allSettled(files.map(uploadFile));

const uploaded = uploadResults.filter((result) => result.status === "fulfilled");
const failed = uploadResults.filter((result) => result.status === "rejected");
```

## When Not To Use This Decision

Do not use either method just because you see multiple async tasks.

Avoid both when:

- Tasks must run in order. Use `for...of` with `await`.
- Tasks depend on previous task results. Use staged logic.
- You need concurrency limits. Use a promise pool, queue, or worker system.
- The work should happen in the background. Use a job queue.
- You need cancellation semantics. Use `AbortController` or a library-specific cancellation API.
- You need streaming results as each task finishes. Use a different orchestration pattern.

Sequential example:

```js
for (const invoice of invoices) {
  await sendInvoice(invoice);
}
```

## Alternatives

### Sequential await

Use sequential `await` when order, dependency, or rate limits matter.

```js
for (const customer of customers) {
  await syncCustomer(customer);
}
```

### Promise pool

Use a promise pool when many tasks can run in parallel, but not all at once.

### Job queue

Use a job queue for durable background processing, retries, and observability.

### Promise.race()

Use `Promise.race()` when the first settled promise should determine the result.

### Promise.any()

Use `Promise.any()` when the first successful fulfillment is enough.

## Production Examples

### Required Account Boot Data With Promise.all()

```js
async function loadAccountPage(accountId) {
  const [account, permissions, billingSummary] = await Promise.all([
    api.getAccount(accountId),
    api.getPermissions(accountId),
    api.getBillingSummary(accountId)
  ]);

  return {
    account,
    canManageBilling: permissions.includes("billing:manage"),
    billingSummary
  };
}
```

Why `Promise.all()` fits: the page should not render trusted account controls if account, permissions, or billing data failed to load.

### Bulk Notification Report With Promise.allSettled()

```js
async function sendReleaseNotifications(users, message) {
  const results = await Promise.allSettled(
    users.map((user) => notificationService.send(user.id, message))
  );

  return results.map((result, index) => ({
    userId: users[index].id,
    status: result.status,
    error: result.status === "rejected" ? result.reason.message : ""
  }));
}
```

Why `Promise.allSettled()` fits: one failed notification should not erase the successful deliveries.

### Optional Dashboard Widgets

```js
const widgetResults = await Promise.allSettled([
  loadRevenueWidget(),
  loadUsageWidget(),
  loadSupportWidget()
]);

const widgets = widgetResults.map((result, index) => ({
  key: ["revenue", "usage", "support"][index],
  ready: result.status === "fulfilled",
  data: result.status === "fulfilled" ? result.value : null
}));
```

Why `Promise.allSettled()` fits: one optional widget failure should not blank the entire dashboard.

## Common Mistakes

- Using `Promise.all()` when partial success is acceptable.
- Using `Promise.allSettled()` and forgetting to inspect `status`.
- Assuming `Promise.all()` cancels other promises after one rejects.
- Assuming either method limits concurrency.
- Losing the relationship between each result and its input item.
- Swallowing rejection reasons and returning vague failure messages.
- Using `forEach(async () => ...)` instead of creating promises for `Promise.all()`.
- Starting too many network requests at once.

```js
// Mistake: one failed email rejects the whole batch and hides successes
await Promise.all(users.map((user) => sendEmail(user)));
```

```js
// Better when partial success is acceptable
const results = await Promise.allSettled(users.map((user) => sendEmail(user)));
```

```js
// Mistake: status records are ignored
const results = await Promise.allSettled(tasks);
return results.map((result) => result.value);
```

```js
// Better
return results.map((result) =>
  result.status === "fulfilled"
    ? { ok: true, value: result.value }
    : { ok: false, reason: result.reason.message }
);
```

## Debugging Checklist

- If one failure rejected the whole operation, did you mean `Promise.allSettled()`?
- If errors disappeared, are rejected `allSettled()` results being inspected?
- If successes disappeared after one failure, are you using fail-fast behavior accidentally?
- If API rate limits are hit, did you start too many promises at once?
- If results no longer match inputs, are you preserving input order or IDs?
- If promises are still running after a rejection, did you assume `Promise.all()` cancels them?
- If the code uses `forEach(async ...)`, should it use `map()` plus `Promise.all()` or a sequential `for...of` loop?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-008/`.

Verification command:

```sh
npm run canon:verify:008
```

The verification suite checks:

- `Promise.all()` succeeds when all promises resolve.
- `Promise.all()` rejects when one promise fails.
- `Promise.allSettled()` returns mixed success/failure results.
- The anti-pattern of using `Promise.all()` when partial success is acceptable.

## Performance Notes

Both methods aggregate promises; neither method creates a concurrency limit. The practical performance decision is often made before the call, when promises are created.

For small sets of independent tasks, both are fine. For large batches, use a concurrency pool or queue so the system does not overload network, database, browser, or third-party API limits.

Fail-fast does not mean all other underlying work stops. If you need cancellation, design for it explicitly with `AbortController` or the API's cancellation mechanism.

## AI Coding Guidance

When generating async JavaScript:

- Use `Promise.all()` for required parallel work.
- Use `Promise.allSettled()` when partial success is acceptable.
- Do not claim that `Promise.all()` cancels remaining promises.
- Do not use `Promise.allSettled()` without inspecting `status`.
- Preserve input identity when reporting settled results.
- Use `map()` to create promise arrays; avoid `forEach(async ...)`.
- Use sequential `for...of` when order, dependency, or rate limits matter.
- Mention concurrency limits when generating code for large batches.

Bad AI output:

```js
await Promise.all(users.map(sendEmail));
return "All users were processed";
```

Good AI output when partial success is acceptable:

```js
const results = await Promise.allSettled(users.map(sendEmail));
return results.map((result, index) => ({
  userId: users[index].id,
  status: result.status
}));
```

## Teaching Notes

Teach failure behavior before syntax:

1. Start with two successful promises and `Promise.all()`.
2. Show one rejection and the fail-fast result.
3. Show the same inputs with `Promise.allSettled()`.
4. Inspect `fulfilled` and `rejected` records.
5. Explain that neither method limits concurrency.
6. End with when to use sequential `await`.

Useful teaching phrase:

> `Promise.all()` asks "Did everything work?" `Promise.allSettled()` asks "What happened to each task?"

## Interview Questions

1. What does `Promise.all()` do when one input rejects?
2. Does `Promise.all()` cancel the remaining promises?
3. What does `Promise.allSettled()` return for a rejected input?
4. When is partial success useful?
5. Why is `allSettled()` not enough unless you inspect `status`?
6. How would you preserve which user matched which notification result?
7. What should you use when you need a concurrency limit?
8. Why is `forEach(async () => ...)` usually a warning sign?

## Exercises

### Beginner

Load two required resources with `Promise.all()` and handle failure with `try/catch`.

### Intermediate

Send notifications to several users with `Promise.allSettled()` and return a report of successes and failures.

### Advanced

Refactor a bulk import that uses `Promise.all()` into a partial-success workflow with retry candidates and clear failure reasons.

## Related Atlas Nodes

- `javascript.array.map`
- `javascript.array.foreach`
- `javascript.array.filter`
- `javascript.array.find`
- `javascript.array.reduce`

## Evidence And Sources

- MDN Web Docs: Promise.all(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/all
- MDN Web Docs: Promise.allSettled(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/allSettled
- ECMAScript specification: Promise.all: https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.all
- ECMAScript specification: Promise.allSettled: https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.allsettled

## Proof Of Superiority Summary

Official references explain what `Promise.all()` and `Promise.allSettled()` do. This Canon node explains how to choose between them in production code, why failure semantics matter, how partial success should be reported, how concurrency limits change the architecture, how AI should generate safe async code, and when sequential loops, pools, queues, `Promise.race()`, or `Promise.any()` are better tools.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
