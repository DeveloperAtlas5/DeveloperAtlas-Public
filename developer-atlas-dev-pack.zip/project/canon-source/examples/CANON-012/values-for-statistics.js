const assert = require("assert");

function run() {
  const revenueByPlan = {
    basic: 120000,
    pro: 340000,
    enterprise: 890000
  };

  const values = Object.values(revenueByPlan);
  const totalRevenueCents = values.reduce((sum, cents) => sum + cents, 0);
  const averageRevenueCents = totalRevenueCents / values.length;

  assert.strictEqual(totalRevenueCents, 1350000);
  assert.strictEqual(averageRevenueCents, 450000);
}

module.exports = run;

