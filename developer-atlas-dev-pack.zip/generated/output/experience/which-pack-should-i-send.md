# Which Pack Should I Send?

## Use Rookie Pack when...

- The tester is a complete beginner.
- The tester may feel overwhelmed by many files.
- You only want feedback on Mission 1.
- You want to test first impression and folder clarity.
- You want the lowest-friction start.
- The learner already has a basic Vue to-do project open.

Rookie Pack is non-AI and Mission 1 only.

Rookie Pack is the safest first send for beginners who already have a basic Vue project.

Rookie Pack is not a zero-install or zero-project setup pack.

Real feedback about pack fit should be recorded in `reviewer/real-feedback-register.md` after sending.

## Use Full Pack when...

- The tester is ready for Missions 1-3.
- The tester may use AI help.
- The tester can handle optional folders.
- You want feedback on the current complete learner experience.

Use Full Pack for AI-assisted learner testing.

Send Full Pack when you want AI-assisted testing or Missions 1-3.

## Use Dev Pack when...

- The recipient is a maintainer.
- The recipient is reviewing how Atlas is built.
- The recipient needs tools, validators, templates, docs, or content.
- The recipient may contribute to the project.

Do not send Dev Pack to normal beginners.

## Default recommendation

When unsure, send Rookie Pack first only if the learner already has a Vue project. Send Full Pack after the learner is comfortable, ready for AI-assisted testing, or ready for Missions 1-3. Keep Dev Pack for maintainers.

## Simple decision table

| Situation | Send |
|---|---|
| Complete beginner with a Vue project | Rookie Pack |
| First-impression test | Rookie Pack |
| Testing Mission 1 only | Rookie Pack |
| Testing Missions 1-3 | Full Pack |
| AI-assisted learner test | Full Pack |
| Mentor/reviewer testing learner flow | Full Pack |
| Maintainer or contributor | Dev Pack |
| Someone asks how Atlas is built | Dev Pack |

## What not to send

Do not send Dev Pack to a beginner unless they explicitly need the full project internals.

Do not send Full Pack when you only need Mission 1 feedback.

Do not send multiple packs at once to a new tester.

Multiple zips can create the same decision fatigue Atlas is trying to reduce.

## After sending a pack

After choosing a pack, use `pack-send-checklist.md` before sending it.

After receiving real tester feedback, record it in `reviewer/real-feedback-register.md`.

Ask only one or two questions after sending a pack.

For Rookie Pack, ask: "Was it clear that this starts after your Vue project already exists?"

For Full Pack, ask: "Could you follow the missions without feeling lost?"

For Dev Pack, ask: "Could you find the build, validation, and packaging files?"
