# Start a SQL Project

## What this is for

Use this when you want to write or run database queries.

## What you need first

You need a database, a database file, or an app that connects to a database.

## Required tools

- A database tool or application

## Recommended extensions

- DB Browser for SQLite
- phpMyAdmin
- MySQL Workbench
- A VS Code SQL extension

## Start from zero

- Choose a simple database tool, such as SQLite with DB Browser for SQLite.
- Create a database file or connect to an existing database.
- Create a table before writing queries that read data.

## Open an existing project

- Find where the project stores database settings.
- Common places include Laravel migrations, database clients, MySQL, SQLite, and PostgreSQL tools.
- Open the database tool or the app that connects to the database.

## Run or preview the project

- SQL usually runs inside a database tool or application.
- Write a query in the tool's query editor.
- Run the query and inspect the rows returned.

## Where you usually code

- SQL queries may live in a database client, app code, migrations, seed files, or reports.
- Tables hold data. Rows are records. Columns are the named fields in each row.

## Common first problems

- No table exists yet: create or migrate the table first.
- The query returns no rows: check the table name and filter.
- The app uses a different database: check the connection settings.

## Next Atlas step

After you can run a query, continue with the mission or use the Concept Library for SQL terms.
