const fs = require("fs");
const path = require("path");
const { readEntries } = require("./content-utils");
const { readGoals, readGoalProfiles } = require("./goal-utils");
const { readMachineProfiles } = require("./hardware-utils");
const {
  readinessDir,
  readReadinessProfiles
} = require("./readiness-utils");

const schemaFiles = [
  "readiness-profile.schema.json",
  "readiness-report.schema.json",
  "readiness-score.schema.json"
];

const requiredFields = [
  "readiness_id",
  "profile_id",
  "target_goal_ids",
  "learner_level",
  "known_nodes",
  "completed_practice",
  "machine_profile_id",
  "available_hours_per_week",
  "preferred_stack",
  "constraints",
  "confidence_before",
  "desired_output"
];

const arrayFields = [
  "target_goal_ids",
  "known_nodes",
  "completed_practice",
  "preferred_stack",
  "constraints"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);

  let profiles = [];
  try {
    profiles = readReadinessProfiles();
  } catch (error) {
    errors.push(`readiness/examples: unable to read profiles (${error.message})`);
  }

  const knownIds = collectKnownIds();
  validateProfiles(profiles, knownIds, errors, warnings);

  console.log("Atlas Readiness validation");
  console.log(`Readiness examples: ${profiles.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const schemaPath = path.join(readinessDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`readiness/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`readiness/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function collectKnownIds() {
  return {
    contentIds: new Set(readEntries().map((entry) => entry.frontMatter.id)),
    goalIds: new Set(readGoals().map((record) => record.goal.goal_id)),
    goalProfileIds: new Set(readGoalProfiles().map((record) => record.profile.profile_id)),
    machineProfileIds: new Set(readMachineProfiles().map((record) => record.profile.profile_id))
  };
}

function validateProfiles(records, knownIds, errors, warnings) {
  const seen = new Set();

  for (const { profile, relativePath } of records) {
    for (const field of requiredFields) {
      if (profile[field] === undefined || profile[field] === null || profile[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }

    if (seen.has(profile.readiness_id)) errors.push(`${relativePath}: duplicate readiness_id ${profile.readiness_id}`);
    seen.add(profile.readiness_id);

    for (const field of arrayFields) validateStringArray(relativePath, profile, field, errors, field === "known_nodes" || field === "completed_practice");

    if (typeof profile.available_hours_per_week !== "number" || profile.available_hours_per_week < 1) {
      errors.push(`${relativePath}: available_hours_per_week should be >= 1`);
    }
    if (typeof profile.confidence_before !== "number" || profile.confidence_before < 0 || profile.confidence_before > 1) {
      errors.push(`${relativePath}: confidence_before should be 0 to 1`);
    }

    warnUnknown(relativePath, profile.target_goal_ids, knownIds.goalIds, "target_goal_ids", warnings);
    warnUnknown(relativePath, profile.known_nodes, knownIds.contentIds, "known_nodes", warnings);
    if (!knownIds.goalProfileIds.has(profile.profile_id)) warnings.push(`${relativePath}: profile_id ${profile.profile_id} does not exist`);
    if (!knownIds.machineProfileIds.has(profile.machine_profile_id)) warnings.push(`${relativePath}: machine_profile_id ${profile.machine_profile_id} does not exist`);
  }
}

function validateStringArray(relativePath, data, field, errors, allowEmpty = false) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }
  if (!allowEmpty && data[field].length === 0) errors.push(`${relativePath}: ${field} should not be empty`);
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

function warnUnknown(relativePath, values = [], knownSet, label, warnings) {
  for (const value of values) {
    if (!knownSet.has(value)) warnings.push(`${relativePath}: ${label} references unknown id ${value}`);
  }
}

main();
