# CSS position relative vs absolute vs fixed vs sticky

## Status Metadata

- Canon ID: CANON-020
- Node ID: canon.css.layout.position-relative-absolute-fixed-sticky
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: CSS layout
- Level: rookie/junior/intermediate
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `position: relative` when an element should keep its normal layout space but needs an offset or needs to anchor absolutely positioned children. Use `position: absolute` when an element should leave normal document flow and be placed relative to its nearest positioned ancestor. Use `position: fixed` for viewport-pinned UI, and `position: sticky` for elements that behave normally until a scroll threshold is reached.

The decision is about flow and anchor:

- Normal flow lays elements out naturally.
- `relative` keeps flow space.
- `absolute` leaves flow and uses a containing block.
- `fixed` uses the viewport.
- `sticky` starts in flow, then sticks inside its scroll container.

## What Problem This Solves

Developers often use positioning to fight layout instead of solving the layout model. That creates brittle CSS:

- Badges attach to the page instead of the card.
- Absolute elements overlap content because they left normal flow.
- Fixed headers cover page content.
- Sticky elements do not stick because the scroll container, threshold, or overflow context is wrong.
- AI-generated CSS uses `position: absolute` as a shortcut for spacing.

This node teaches positioning as a deliberate placement decision, not a general layout replacement.

## Mental Model

Start with normal document flow.

Normal flow is the default layout stream: blocks stack, inline content flows, and elements take up space. Positioning changes how an element participates in that stream.

Ask two questions:

1. Does the element keep its normal layout space?
2. What is the element positioned relative to?

| Value | Keeps flow space? | Positioned relative to |
| --- | --- | --- |
| `relative` | Yes | Its own normal position |
| `absolute` | No | Nearest positioned ancestor or initial containing block |
| `fixed` | No | Viewport |
| `sticky` | Yes until stuck | Nearest scroll container plus threshold |

Think:

```text
relative = "move me visually, but keep my seat"
absolute = "place me inside my positioned anchor"
fixed    = "pin me to the viewport"
sticky   = "flow normally, then stick after a scroll threshold"
```

## Beginner Explanation

Most elements should start without `position`. Let normal layout, Flexbox, or Grid do the work.

Use `relative` on a card when a badge should be placed inside that card:

```css
.card {
  position: relative;
}
```

Use `absolute` on the badge:

```css
.badge {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
}
```

Use `fixed` for something pinned to the screen, like a help button.

Use `sticky` for something that scrolls normally, then sticks when it reaches `top: 0`.

Beginner rule:

1. Normal page layout? Use normal flow, Flexbox, or Grid.
2. Need an anchor for a child? Parent gets `relative`.
3. Need a child placed inside that anchor? Child gets `absolute`.
4. Need screen-pinned UI? Use `fixed`.
5. Need scroll-aware sticking? Use `sticky` with a threshold like `top: 0`.

## Professional Explanation

CSS positioning changes formatting behavior, containing blocks, stacking interactions, and scroll behavior. `relative` lays out the element in normal flow, then applies visual offsets without moving surrounding layout. It also creates a containing block for absolutely positioned descendants.

`absolute` removes the element from normal flow. Its inset offsets resolve against the nearest positioned ancestor, which commonly means the nearest ancestor whose `position` is not `static`. If no suitable ancestor exists, positioning can resolve against a higher-level containing block, often producing surprising placement.

`fixed` removes the element from normal flow and pins it relative to the viewport in common cases. It is useful for persistent UI, but it can obscure content, conflict with mobile browser chrome, or interact with transformed ancestors and stacking contexts.

`sticky` participates in normal flow until its scroll container crosses a threshold such as `top: 0`. Sticky failures are usually not because "sticky is broken"; they come from missing thresholds, wrong scroll container assumptions, insufficient scroll range, or ancestor overflow constraints.

In production review, positioning should communicate intent: anchor, overlay, viewport UI, or sticky affordance. If positioning is being used to build a whole layout, Flexbox, Grid, normal flow, or better markup is usually the better first tool.

## Syntax

```css
.offset-note {
  position: relative;
  top: 0.25rem;
}
```

```css
.card {
  position: relative;
}

.card__badge {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
}
```

```css
.help-button {
  position: fixed;
  right: 1rem;
  bottom: 1rem;
}
```

```css
.section-heading {
  position: sticky;
  top: 0;
}
```

## Decision Guide

Ask these questions in order:

1. Can normal flow, margin, padding, Flexbox, or Grid solve the layout?
   Use those first.
2. Should the element keep its original layout space while being visually offset?
   Use `position: relative`.
3. Should a child be placed inside a specific parent or component?
   Put `position: relative` on the parent and `position: absolute` on the child.
4. Should the element stay pinned to the viewport while the page scrolls?
   Use `position: fixed`.
5. Should the element scroll normally until it reaches a threshold?
   Use `position: sticky` with `top`, `right`, `bottom`, or `left`.
6. Is the element overlapping content?
   Check whether it left normal flow or needs reserved space.
7. Is sticky not working?
   Check threshold, scroll container, ancestor overflow, and available scroll distance.

## Comparison Table

| Position | Flow Behavior | Anchor | Best For | Main Risk |
| --- | --- | --- | --- | --- |
| `static` | Normal flow | None | Default document layout | Cannot use inset offsets |
| `relative` | Keeps normal space | Its original position | Small offsets, containing block for children | Visual offset can confuse surrounding layout |
| `absolute` | Removed from flow | Nearest positioned ancestor | Badges, popovers, overlays inside components | Wrong ancestor or overlap |
| `fixed` | Removed from flow | Viewport | Floating actions, persistent headers, banners | Covers content, mobile viewport quirks |
| `sticky` | Keeps flow until stuck | Scroll container and threshold | Section headers, table headers, toolbars | Fails without threshold or scroll context |

## When To Use The Primary Option

Use `position: relative` when:

- An element should keep its layout space.
- You need a small visual offset.
- You need to create an anchor for absolutely positioned children.
- A card, avatar, thumbnail, or list item contains a badge, menu, or overlay.

```css
.product-card {
  position: relative;
}
```

Why it fits: the card remains in layout and becomes the containing block for positioned children.

## When To Use The Alternative

Use `absolute` when the element should be placed inside a positioned anchor:

```css
.product-card__badge {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
}
```

Use `fixed` when the element belongs to the viewport:

```css
.support-button {
  position: fixed;
  right: 1rem;
  bottom: 1rem;
}
```

Use `sticky` when an element should scroll with content and then stick:

```css
.table-header {
  position: sticky;
  top: 0;
  z-index: 1;
}
```

## When Not To Use This Decision

Do not use positioning when the real problem is layout structure.

Avoid positioning when:

- Flexbox or Grid expresses the layout shape better.
- Normal document flow already gives the desired stack.
- You are using `absolute` to fake columns, cards, or page structure.
- You are moving elements visually while harming keyboard or reading order.
- You are hiding spacing problems instead of fixing parent layout.
- The element needs to reserve space but `absolute` or `fixed` removes it.
- A modal, popover, tooltip, or dropdown needs accessibility and focus behavior beyond placement.

## Alternatives

- Normal flow for article content, forms, and simple vertical stacks.
- Margin and padding for spacing.
- Flexbox for one-dimensional alignment.
- Grid for two-dimensional layout.
- Transform for animation and visual movement.
- Dialog/popover patterns for interactive overlays that need focus management.

## Production Examples

### Card Badge With Positioned Anchor

```css
.product-card {
  position: relative;
  padding: 1rem;
}

.product-card__badge {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
}
```

Why this fits: the badge is anchored to the card, not the viewport or page.

### Fixed Support Button

```css
.support-button {
  position: fixed;
  right: 1rem;
  bottom: 1rem;
  z-index: 20;
}
```

Why this fits: the button should stay available while the page scrolls.

### Sticky Table Toolbar

```css
.table-toolbar {
  position: sticky;
  top: 0;
  z-index: 2;
  background: white;
}
```

Why this fits: the toolbar belongs to the table area but should remain visible after reaching the top threshold.

### Relative Offset Without Layout Shift

```css
.notification-dot {
  position: relative;
  top: -0.125rem;
}
```

Why this fits: the dot nudges visually while the surrounding line layout keeps its original space.

## Common Mistakes

- Expecting `absolute` to position relative to the nearest visual parent instead of the nearest positioned ancestor.
- Forgetting that `absolute` and `fixed` leave normal flow.
- Using `relative` offsets for meaningful layout movement, causing confusing empty space.
- Using `fixed` for component-level UI that should stay inside a container.
- Forgetting `top`, `right`, `bottom`, or `left` for `sticky`.
- Expecting sticky to work inside any overflow context without checking the scroll container.
- Using `z-index` without understanding stacking context.
- Using absolute positioning as a substitute for Grid or Flexbox.

## Debugging Checklist

- Start by disabling `position` and checking normal flow.
- Identify whether the element keeps layout space.
- For `absolute`, find the nearest positioned ancestor.
- Add `position: relative` to the intended parent when anchoring a child.
- Check inset properties: `top`, `right`, `bottom`, `left`, or logical equivalents.
- For `fixed`, check whether it covers content and whether safe spacing is reserved.
- For `sticky`, check threshold, scroll container, ancestor `overflow`, and scroll range.
- Check `z-index` only after confirming positioning and stacking context.
- Ask whether Flexbox or Grid would solve the layout more cleanly.

## Mechanical Verification

Deterministic examples live in `canon/examples/CANON-020/`.

Run:

```bash
npm run canon:verify:020
```

Verified examples:

- Relative offset keeps layout space.
- Absolute positioning uses the nearest positioned ancestor.
- Fixed positioning stays viewport-pinned.
- Sticky positioning requires a scroll container and threshold.

## Performance Notes

Positioning is usually a maintainability and correctness decision before it is a performance decision. The practical risks are overlap, layout instability, scroll confusion, and inaccessible visual order.

For animation, prefer transforms for movement where possible. For persistent overlays, manage stacking, focus, and viewport safe areas intentionally.

## AI Coding Guidance

- Start with normal flow, Flexbox, or Grid unless the prompt asks for anchoring, overlay, viewport pinning, or sticky behavior.
- Use `position: relative` on the intended container before generating `position: absolute` on a child.
- Do not generate absolute-positioned full layouts when Grid or Flexbox is the right tool.
- Include a threshold such as `top: 0` when generating sticky examples.
- Warn when `fixed` UI may cover content.
- Add background and `z-index` to sticky headers when overlap is likely.
- Ask what the element should be positioned relative to when the anchor is unclear.

## Teaching Notes

Teach positioning after normal flow, margin/padding, Flexbox, and Grid basics.

Use one card demo:

1. Show the card in normal flow.
2. Add `position: relative` to the card and explain that the card keeps its seat.
3. Add an absolute badge and show that the badge uses the card as its anchor.
4. Show a fixed help button and explain viewport pinning.
5. Show a sticky heading and explain the threshold.

The teaching goal is confidence: learners should stop guessing and start asking "what is the anchor, and does it keep space?"

## Interview Questions

1. What does normal document flow mean?
2. How does `position: relative` affect layout space?
3. What containing block does `position: absolute` use?
4. When should you use `position: fixed`?
5. Why might `position: sticky` fail?
6. When should you use Flexbox or Grid instead of positioning?

## Exercises

### Beginner

Create a card with a badge in the top-right corner using `relative` and `absolute`.

### Intermediate

Build a fixed help button and adjust page spacing so it does not cover important content.

### Advanced

Debug a sticky toolbar that fails because of scroll container or threshold issues.

## Related Atlas Nodes

- `CANON-004`
- `css.property.position`
- `css.property.margin`
- `css.property.padding`
- `css.property.display`

## Evidence And Sources

- MDN position: https://developer.mozilla.org/en-US/docs/Web/CSS/position
- MDN layout and containing block: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_display/Containing_block
- MDN sticky positioning: https://developer.mozilla.org/en-US/docs/Web/CSS/position#sticky_positioning
- CSS Positioned Layout Module Level 3: https://www.w3.org/TR/css-position-3/

## Proof Of Superiority Summary

Official references explain each positioning value. Atlas adds the practical decision model: start from normal flow, identify whether the element keeps space, choose the correct anchor, debug containing blocks and sticky scroll context, and guide AI assistants away from absolute-positioned layouts when Flexbox or Grid is the better tool.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 15 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 2 |
| readability | 2 | 2 |
| Total | 100 | 95 |
