const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const outputDir = path.join(rootDir, "output", "walkthrough");
const examplePath = path.join(rootDir, "walkthrough", "examples", "rookie-vue-todo.json");

function readJson(relativePath, fallback) {
  const fullPath = path.join(rootDir, relativePath);
  if (!fs.existsSync(fullPath)) return fallback;
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function readText(relativePath, fallback = "") {
  const fullPath = path.join(rootDir, relativePath);
  if (!fs.existsSync(fullPath)) return fallback;
  return fs.readFileSync(fullPath, "utf8");
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function findCapability(id) {
  const report = readJson("output/capability/project-fit-report.json", { project_fits: [] });
  return (report.project_fits || []).find((item) => item.capability_id === id) || null;
}

function extractSectionSummary(text, fallback) {
  const lines = text.split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => !line.startsWith("#"));
  return lines.slice(0, 4).join(" ") || fallback;
}

function extractRecoverySummary(text) {
  const safeFix = matchLineAfterHeading(text, "## Safest First Fix");
  const reassurance = matchLineAfterHeading(text, "## Beginner Reassurance");
  const verification = matchLineAfterHeading(text, "## Verification Steps");
  return [
    reassurance || "This is a setup blocker, not a sign that you cannot code.",
    safeFix ? `Safest first fix: ${safeFix}` : "Safest first fix: run the diagnostics in order.",
    verification ? `Verification: ${verification}` : "Verification: npm run dev should print a local URL."
  ].join("\n\n");
}

function matchLineAfterHeading(text, heading) {
  const lines = text.split(/\r?\n/);
  const index = lines.findIndex((line) => line.trim() === heading);
  if (index === -1) return "";

  for (const line of lines.slice(index + 1)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith("## ")) return "";
    return trimmed.replace(/^[-*]\s*/, "").replace(/^\d+\.\s*/, "").replace(/^\[ \]\s*/, "");
  }

  return "";
}

function bulletList(items) {
  if (!Array.isArray(items) || items.length === 0) return "- None";
  return items.map((item) => `- ${item}`).join("\n");
}

function renderMarkdown(model, generated) {
  return [
    `# ${model.title}`,
    "",
    "## 1. Welcome",
    "",
    "You do not need to know everything before you start. This walkthrough gives you one calm path: get set up, build one tiny Vue app, recover if setup breaks, and leave with a visible win.",
    "",
    "## 2. Goal",
    "",
    model.goal,
    "",
    "## 3. Why This Goal Matters",
    "",
    model.why_this_goal_matters,
    "",
    "## 4. Smallest Useful Next Step",
    "",
    model.smallest_useful_next_step,
    "",
    "## 5. Setup Check",
    "",
    model.setup_check,
    "",
    "## 6. What To Install",
    "",
    bulletList(model.what_to_install),
    "",
    "## 7. What Usually Gets In The Way",
    "",
    bulletList(model.what_usually_goes_wrong),
    "",
    "## 8. Recovery Path If It Breaks",
    "",
    "If the dev server does not start, do not panic. Treat it as a normal setup blocker.",
    "",
    generated.recovery_summary,
    "",
    "## 9. What To Learn Now",
    "",
    bulletList(model.what_to_learn_now),
    "",
    "Helpful learning topics:",
    "",
    bulletList((model.canon_nodes || []).map(friendlyLearningTopic)),
    "",
    "## 10. What To Skip For Now",
    "",
    bulletList(model.what_to_skip_for_now),
    "",
    "## 11. Project Task",
    "",
    model.project_task,
    "",
    generated.capability
      ? `${generated.capability.title} is the right size for this walkthrough. Keep the first version small enough to finish.`
      : "Build Vue Todo App is the intended ready-today project.",
    "",
    ...(model.persistence_next_step ? [
      "## 12. Persistence Next Step",
      "",
      model.persistence_next_step,
      "",
      "Storage recovery tips:",
      "",
      "- If the list resets after refresh, check that you save after todo changes and load when the app starts.",
      "- If saved todos load incorrectly, clear the old saved value and reload with an empty-array fallback.",
      "- If todos vanish after closing the tab, check whether you used sessionStorage instead of localStorage.",
      ""
    ] : []),
    "",
    "## 13. AI-Ready Context Pack",
    "",
    "Use this context pack when asking an AI assistant for help. It keeps the answer focused on the next practical step instead of expanding into backend, auth, routing, or state management.",
    "",
    `- ${generated.sources.ai_context}`,
    "",
    "Preview:",
    "",
    generated.ai_context_summary,
    "",
    "## 14. Visible Win",
    "",
    `**${model.visible_win}**`,
    "",
    "That win matters. It proves you can connect input, state, list rendering, filtering, and user interaction in one working app.",
    "",
    "## 15. Next Step After Finishing",
    "",
    model.next_step_after_finishing,
    "",
    "Keep the next step small. The goal is momentum, not proving everything at once.",
    ""
  ].join("\n");
}

function main() {
  ensureDir(outputDir);
  const model = JSON.parse(fs.readFileSync(examplePath, "utf8"));

  const capability = findCapability(model.capability_id);
  const setupPath = `output/setup-advisor/${model.setup_request_id}.md`;
  const recoveryPath = `output/recovery-advisor/${model.recovery_request_id}.md`;
  const backupRecoveryPath = `output/recovery-advisor/${model.backup_recovery_request_id}.md`;
  const aiContextPath = `output/ai-context/${model.ai_context_request_id}.md`;

  const generated = {
    generated_at: new Date().toISOString(),
    walkthrough_id: model.walkthrough_id,
    title: model.title,
    goal: model.goal,
    visible_win: model.visible_win,
    capability,
    sources: {
      setup: setupPath,
      recovery: recoveryPath,
      backup_recovery: backupRecoveryPath,
      ai_context: aiContextPath
    },
    recovery_summary: extractRecoverySummary(readText(recoveryPath)),
    ai_context_summary: extractSectionSummary(
      readText(aiContextPath),
      "Ask for help with the smallest Vue todo app and keep scope limited to the current task."
    ),
    model
  };

  fs.writeFileSync(path.join(outputDir, `${model.walkthrough_id}.json`), `${JSON.stringify(generated, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, `${model.walkthrough_id}.md`), renderMarkdown(model, generated));

  console.log(`Generated output/walkthrough/${model.walkthrough_id}.md.`);
  console.log(`Generated output/walkthrough/${model.walkthrough_id}.json.`);
}

main();

function friendlyLearningTopic(id) {
  const topics = {
    "CANON-003": "Vue reactivity: simple state",
    "CANON-007": "Showing and hiding UI",
    "CANON-009": "Filtering todo items",
    "CANON-013": "Stable keys for todo rows",
    "CANON-022": "Browser storage for remembering todos",
    "CANON-025": "Component communication for splitting the app later"
  };
  return topics[id] || id;
}
