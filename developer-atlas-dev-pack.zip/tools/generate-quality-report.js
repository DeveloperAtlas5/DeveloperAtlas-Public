const fs = require("fs");
const path = require("path");
const { analyzeContent } = require("./quality-utils");
const { rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "reports");
const outputPath = path.join(outputDir, "quality-report.md");

function main() {
  const { results, counts } = analyzeContent();
  const sortedBest = [...results].sort((a, b) => b.score - a.score || a.file.localeCompare(b.file));
  const sortedWeakest = [...results].sort((a, b) => a.score - b.score || a.file.localeCompare(b.file));

  const lines = [
    "# Developer Atlas Quality Report",
    "",
    `Total entries: ${counts.totalEntries}`,
    `Average quality score: ${counts.averageScore}/100`,
    "",
    "## Warning Counts",
    "",
    `- Critical: ${counts.warningLevels.critical}`,
    `- Quality: ${counts.warningLevels.quality}`,
    `- Enrichment: ${counts.warningLevels.enrichment}`,
    `- Future: ${counts.warningLevels.future}`,
    "",
    "## Top 10 Best Entries",
    "",
    "| Score | ID | File |",
    "|---:|---|---|"
  ];

  for (const result of sortedBest.slice(0, 10)) {
    lines.push(`| ${result.score} | ${result.entry.frontMatter.id} | ${result.file} |`);
  }

  lines.push("", "## Bottom 20 Weakest Entries", "", "| Score | ID | File |", "|---:|---|---|");
  for (const result of sortedWeakest.slice(0, 20)) {
    lines.push(`| ${result.score} | ${result.entry.frontMatter.id} | ${result.file} |`);
  }

  lines.push("", "## Missing Fields Summary", "");
  for (const [field, count] of counts.missingFields) lines.push(`- ${field}: ${count}`);

  lines.push("", "## Entries By Technology", "");
  for (const [technology, count] of counts.byTechnology) lines.push(`- ${technology}: ${count}`);

  lines.push("", "## Entries By Type", "");
  for (const [type, count] of counts.byType) lines.push(`- ${type}: ${count}`);

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${lines.join("\n")}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)}.`);
}

main();
