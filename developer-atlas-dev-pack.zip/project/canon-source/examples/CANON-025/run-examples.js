const examples = [
  ["parent passes prop to child", require("./parent-passes-prop-to-child")],
  ["child emits event to parent", require("./child-emits-event-to-parent")],
  ["v-model updates parent state", require("./v-model-updates-parent-state")],
  ["mistake: child mutates prop directly", require("./mistake-child-mutates-prop-directly")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-025 example(s).`);
