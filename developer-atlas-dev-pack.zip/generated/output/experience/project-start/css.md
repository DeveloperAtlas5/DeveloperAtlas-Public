# Start a CSS Project

## What this is for

Use this when you want to add styles to a web page.

## What you need first

You need an HTML file and a CSS file in your project.

## Required tools

- A browser
- VS Code or another text editor

## Recommended extensions

- Live Server

## Start from zero

- Create or open an HTML project.
- Create a file such as `style.css`.
- Link the CSS file from HTML with `<link rel="stylesheet" href="style.css">`.

## Open an existing project

- Open the project folder in VS Code.
- Find a `.css` file, or create one if the project does not have styles yet.
- Check the HTML file to see which CSS file is linked.

## Run or preview the project

- Open the HTML page in your browser.
- Change the CSS file.
- Refresh the browser to see the style change.

## Where you usually code

- Styles usually live in `.css` files.
- Small examples may put styles inside a `<style>` tag, but a CSS file is easier to find.

## Common first problems

- The style does not change: refresh the browser.
- The CSS file is not connected: check the `<link>` path.
- One rule does not apply: check the selector name.

## Next Atlas step

After styles are connected, continue with the mission or look up CSS terms in the Concept Library.
