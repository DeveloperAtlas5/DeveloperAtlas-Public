function createKernelContext(mission, brain, atlasContext, graph, models) {
  const nodeById = new Map(atlasContext.knowledge.map((node) => [node.id, node]));
  return {
    mission,
    brain,
    atlasContext,
    graph,
    models,
    nodeById,
    warnings: []
  };
}

function runIntentEngine(context) {
  const { mission, models } = context;
  const text = `${mission.user_goal} ${mission.expected_output || ""} ${JSON.stringify(mission.context || {})}`.toLowerCase();
  const rules = models.intentDetection?.deterministic_rules || {};
  let category = "Implementation";
  for (const [pattern, intent] of Object.entries(rules)) {
    if (new RegExp(pattern).test(text)) {
      category = intent;
      break;
    }
  }

  const detected = {
    category,
    sub_intent: inferSubIntent(category, text),
    confidence: inferIntentConfidence(text, mission),
    signals: {
      verbs: extractMatches(text, ["choose", "fix", "debug", "optimize", "learn", "migrate", "refactor", "deploy", "secure", "test", "integrate"]),
      technologies: mission.technologies || [],
      constraints: mission.constraints || [],
      desired_outcome: mission.expected_output || "decision"
    }
  };

  return { ...context, detectedIntent: detected };
}

function runConstraintEngine(context) {
  const dimensions = context.models.constraints?.dimensions || {};
  const missionConstraints = context.mission.constraints || [];
  return {
    ...context,
    resolvedConstraints: {
      dimensions_used: Object.keys(dimensions),
      explicit: missionConstraints,
      inferred: inferConstraints(context.mission)
    }
  };
}

function runKnowledgeEngine(context) {
  const requiredNodes = resolveNodes(context.mission.required_node_ids, context, "required");
  const optionalNodes = resolveNodes(context.mission.optional_node_ids, context, "optional");
  const supportingNodeIds = requiredNodes.map((node) => node.id);
  const relatedEdges = context.graph.edges.filter((edge) => supportingNodeIds.includes(edge.source) || supportingNodeIds.includes(edge.target));
  return {
    ...context,
    requiredNodes,
    optionalNodes,
    candidates: [...requiredNodes, ...optionalNodes],
    supportingNodeIds,
    relatedEdges
  };
}

function runPatternEngine(context) {
  const catalog = context.models.patternCatalog?.patterns || [];
  const missionText = `${context.mission.user_goal} ${(context.mission.technologies || []).join(" ")}`.toLowerCase();
  const matchedPatterns = catalog.filter((pattern) =>
    (pattern.applies_to || []).some((signal) => missionText.includes(signal.toLowerCase()))
  );
  return { ...context, matchedPatterns };
}

function runDecisionEngine(context) {
  const recommendation = chooseRecommendation(context.mission, context.requiredNodes);
  const rejectedAlternatives = context.requiredNodes
    .filter((node) => node.id !== recommendation.node_id)
    .map((node) => ({
      node_id: node.id,
      title: node.title,
      reason: first(node.when_not_to_use) || "Not the best fit for this mission's primary goal."
    }));

  return { ...context, recommendation, rejectedAlternatives };
}

function runRecommendationEngine(context) {
  return {
    ...context,
    rankedSolutions: context.candidates.map((node) => ({
      node_id: node.id,
      title: node.title,
      pros: [node.summary].filter(Boolean),
      cons: normalizeList(node.when_not_to_use).slice(0, 2),
      tradeoffs: normalizeList(node.tradeoffs).slice(0, 3),
      confidence: Number(node.confidence || 3),
      evidence_level: node.evidence_level || "context_dependent",
      estimated_learning: inferLearningEstimate(node, context.mission.persona),
      maintenance_impact: inferMaintenanceImpact(node),
      performance_impact: inferPerformanceImpact(node)
    })).sort((a, b) => b.confidence - a.confidence)
  };
}

function runLearningEngine(context) {
  const limit = context.mission.persona === "rookie" ? 3 : 5;
  const next = [];
  for (const edge of context.relatedEdges) {
    const candidate = context.supportingNodeIds.includes(edge.source) ? edge.target : edge.source;
    if (!context.supportingNodeIds.includes(candidate) && !next.includes(candidate)) next.push(candidate);
    if (next.length >= limit) break;
  }
  return {
    ...context,
    nextLearningNodes: next.length ? next : context.supportingNodeIds.slice(0, Math.min(limit, context.supportingNodeIds.length))
  };
}

function createKernelOutput(context) {
  const confidence = aggregateConfidence(context.requiredNodes);
  const evidenceLevel = aggregateEvidence(context.requiredNodes);
  const decisionRecord = {
    decision_id: `decision.${context.mission.mission_id}`,
    mission_id: context.mission.mission_id,
    user_goal: context.mission.user_goal,
    detected_intent: `${context.detectedIntent.category}: ${context.detectedIntent.sub_intent}`,
    context_summary: summarizeContext(context.mission),
    candidates: context.candidates.map(toCandidate),
    recommendation: context.recommendation,
    rejected_alternatives: context.rejectedAlternatives,
    tradeoffs: collectTradeoffs(context.requiredNodes, context.mission),
    confidence,
    evidence_level: evidenceLevel,
    supporting_nodes: context.supportingNodeIds,
    risks: collectRisks(context.requiredNodes),
    verification_steps: verificationSteps(context.mission),
    beginner_explanation: beginnerExplanation(context.mission, context.recommendation, context.requiredNodes),
    professional_summary: professionalSummary(context.mission, context.recommendation),
    ai_coding_guidance: aiCodingGuidance(context.mission, context.recommendation, context.requiredNodes),
    next_learning_nodes: context.nextLearningNodes
  };

  return {
    metadata: {
      kernel: "Atlas Kernel",
      version: "0.2",
      generated_at: new Date().toISOString(),
      deterministic: true,
      pipeline: ["Intent Engine", "Constraint Engine", "Knowledge Engine", "Pattern Engine", "Decision Engine", "Recommendation Engine", "Learning Engine", "Output Engine"]
    },
    mission: context.mission,
    reasoning_trace: createReasoningTrace(context, decisionRecord),
    decision_record: decisionRecord,
    recommended_nodes: [context.recommendation.node_id].filter(Boolean),
    learning_path: context.nextLearningNodes,
    ranked_solutions: context.rankedSolutions,
    matched_patterns: context.matchedPatterns,
    warnings: context.warnings
  };
}

function resolveNodes(ids, context, level) {
  const nodes = [];
  for (const id of ids || []) {
    const node = context.nodeById.get(id);
    if (node) nodes.push(node);
    else context.warnings.push(`${level} node not found: ${id}`);
  }
  return nodes;
}

function chooseRecommendation(mission, nodes) {
  if (mission.mission_id === "choose-array-loop-method") {
    return {
      node_id: "javascript.array.map",
      title: "Choose by output shape",
      reason: "No single array method is universally best; map() is the default only when the goal is a new transformed array."
    };
  }
  if (mission.mission_id === "vue-reactivity-not-updating") {
    return {
      node_id: "vue.reactivity.ref",
      title: "Start by checking the reactive source",
      reason: "Most beginner Vue update issues start with state not being declared, read, or bound reactively."
    };
  }
  const best = [...nodes].sort((a, b) => (b.importance || 0) - (a.importance || 0) || (b.confidence || 0) - (a.confidence || 0))[0];
  return { node_id: best?.id || "", title: best?.title || "", reason: best?.summary || "" };
}

function createReasoningTrace(context, decisionRecord) {
  return [
    ["Intent", context.mission.user_goal, context.detectedIntent],
    ["Constraints", context.mission.constraints, context.resolvedConstraints],
    ["Knowledge Nodes", context.mission.required_node_ids, context.supportingNodeIds],
    ["Patterns", context.models.patternCatalog?.patterns?.length || 0, context.matchedPatterns],
    ["Recipes", context.supportingNodeIds, "No recipe node required for this deterministic mission."],
    ["Alternatives", context.candidates.map((node) => node.id), decisionRecord.rejected_alternatives],
    ["Tradeoffs", context.requiredNodes.map((node) => node.id), decisionRecord.tradeoffs],
    ["Recommendation", context.rankedSolutions, decisionRecord.recommendation],
    ["Verification", decisionRecord.recommendation, decisionRecord.verification_steps],
    ["Learning Next", context.relatedEdges.length, decisionRecord.next_learning_nodes],
    ["Confidence", context.requiredNodes.map((node) => node.confidence), { confidence: decisionRecord.confidence, evidence_level: decisionRecord.evidence_level }]
  ].map(([stage, input, output]) => ({ stage, input, output }));
}

function aggregateConfidence(nodes) {
  const values = nodes.map((node) => Number(node.confidence || 3)).filter(Boolean);
  return values.length ? Math.min(...values) : 3;
}

function aggregateEvidence(nodes) {
  const levels = nodes.map((node) => node.evidence_level).filter(Boolean);
  if (levels.includes("official")) return "official";
  if (levels.includes("specification")) return "specification";
  if (levels.includes("industry_standard")) return "industry_standard";
  return "context_dependent";
}

function collectTradeoffs(nodes, mission) {
  if (mission.mission_id === "choose-array-loop-method") {
    return [
      "Choose array methods by desired output shape.",
      "forEach() is clear for side effects but returns undefined.",
      "reduce() is powerful for aggregation but can reduce readability for beginners."
    ];
  }
  if (mission.mission_id === "vue-reactivity-not-updating") {
    return [
      "ref() is simple for single values but requires .value in script code.",
      "reactive() is useful for objects but can be confusing if destructured incorrectly.",
      "computed() should derive values, while watch() should handle side effects."
    ];
  }
  return nodes.flatMap((node) => normalizeList(node.tradeoffs)).slice(0, 5);
}

function collectRisks(nodes) {
  return nodes.flatMap((node) => normalizeList(node.when_not_to_use)).slice(0, 5);
}

function verificationSteps(mission) {
  if (mission.mission_id === "vue-reactivity-not-updating") {
    return [
      "Confirm the state is declared with ref() or reactive().",
      "If using ref() in script code, confirm reads and writes use .value.",
      "Confirm the template is bound to reactive state, not a stale copy.",
      "Check v-for keys when list rendering behaves unexpectedly."
    ];
  }
  return [
    "Identify the desired output shape.",
    "Choose the matching array method.",
    "Run the code with an empty array and at least one realistic item."
  ];
}

function beginnerExplanation(mission, recommendation, nodes) {
  if (mission.mission_id === "vue-reactivity-not-updating") {
    return "Start by asking: is the value reactive, and is the template reading that reactive value? Use ref() for simple values, reactive() for objects, computed() for derived values, and watch() for side effects.";
  }
  if (mission.mission_id === "choose-array-loop-method") {
    return "Ask what result you want: new array means map, smaller array means filter, one item means find, one value means reduce, yes/no any means some, yes/no all means every, and side effects mean forEach.";
  }
  return first(nodes.map((node) => node.summary)) || recommendation.reason;
}

function professionalSummary(mission, recommendation) {
  if (mission.mission_id === "vue-reactivity-not-updating") {
    return "Debug Vue update issues by tracing the reactive source, derived state, side effects, bindings, and keyed rendering path.";
  }
  if (mission.mission_id === "choose-array-loop-method") {
    return "Select the method by output shape and intent; reserve forEach for side effects and reduce for true aggregation.";
  }
  return recommendation.reason;
}

function aiCodingGuidance(mission, recommendation, nodes) {
  if (mission.mission_id === "vue-reactivity-not-updating") {
    return "Generate Vue fixes by preserving reactive declarations, using .value in script for refs, avoiding side effects in computed(), and adding stable keys to v-for lists.";
  }
  if (mission.mission_id === "choose-array-loop-method") {
    return "Generate the array method matching the desired output shape; avoid forEach for transformations and use an explicit initial value with reduce.";
  }
  return nodes.map((node) => node.code_generation_notes).filter(Boolean)[0] || recommendation.reason;
}

function summarizeContext(mission) {
  return `${mission.persona} mission for ${(mission.technologies || []).join(", ")} at ${mission.difficulty} difficulty. Constraints: ${(mission.constraints || []).join("; ")}.`;
}

function toCandidate(node) {
  return {
    node_id: node.id,
    title: node.title,
    summary: node.summary,
    confidence: node.confidence,
    evidence_level: node.evidence_level
  };
}

function inferSubIntent(category, text) {
  if (category === "Debugging" && /not updating|reactivity|state/.test(text)) return "State Not Updating";
  if (category === "Architecture" && /choose|between|vs|decision/.test(text)) return "Technology Choice";
  if (category === "Learning") return "Mental Model";
  return "General";
}

function inferIntentConfidence(text, mission) {
  let score = 2;
  if (mission.technologies?.length) score += 1;
  if (mission.constraints?.length) score += 1;
  if (/choose|fix|debug|learn|optimize|migrate|refactor|test/.test(text)) score += 1;
  return Math.min(score, 5);
}

function extractMatches(text, words) {
  return words.filter((word) => text.includes(word));
}

function inferConstraints(mission) {
  const inferred = [];
  if (mission.persona === "rookie") inferred.push("prefer beginner explanations");
  if ((mission.constraints || []).some((item) => item.toLowerCase().includes("production"))) inferred.push("avoid high-risk recommendations");
  return inferred;
}

function inferLearningEstimate(node, persona) {
  if (persona === "rookie" && Number(node.difficulty || 1) >= 3) return "medium";
  return "low";
}

function inferMaintenanceImpact(node) {
  return Number(node.importance || 0) >= 4 ? "positive" : "neutral";
}

function inferPerformanceImpact(node) {
  const text = `${node.summary || ""} ${node.performance || ""}`.toLowerCase();
  if (text.includes("performance")) return "context_dependent";
  return "neutral";
}

function normalizeList(value) {
  if (Array.isArray(value)) return value;
  if (value) return [value];
  return [];
}

function first(value) {
  return Array.isArray(value) ? value[0] : value;
}

module.exports = {
  createKernelContext,
  runIntentEngine,
  runConstraintEngine,
  runKnowledgeEngine,
  runPatternEngine,
  runDecisionEngine,
  runRecommendationEngine,
  runLearningEngine,
  createKernelOutput
};
