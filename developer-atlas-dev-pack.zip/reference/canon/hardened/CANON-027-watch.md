# CANON-027 - watch()

Status: Hardened

## Core idea

watch reacts to state changes.

Use it for side effects such as saving to localStorage.

Use deep watch for arrays or objects when needed.

## Use this when

Use this when Mission 1 saves todos after they change.

## Basic pattern

Watch the state, then run a small side effect.

## Common friction

Array and object changes may need deep watching.

## Small example

```js
watch(todos, () => {
  localStorage.setItem("todos", JSON.stringify(todos.value));
}, { deep: true });
```

## Check yourself

- Is watch doing a side effect?
- Does it stay focused on saving?

## Related Canon nodes

- CANON-022
- CANON-023
