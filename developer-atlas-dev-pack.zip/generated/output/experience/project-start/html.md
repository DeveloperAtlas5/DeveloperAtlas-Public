# Start a HTML Project

## What this is for

Use this when you want to start a simple web page.

## What you need first

You need a folder for the project and a text editor such as VS Code.

## Required tools

- A browser
- VS Code or another text editor

## Recommended extensions

- Live Server

## Start from zero

- Create a new folder for the project.
- Create a file named `index.html` inside that folder.
- Add a small HTML page.
- Open `index.html` in your browser.

## Open an existing project

- Open the project folder in VS Code.
- Find `index.html` or another `.html` file.
- Open the HTML file in your browser.

## Run or preview the project

- Double-click `index.html` to open it in the browser.
- If you use Live Server, right-click the HTML file and choose Open with Live Server.
- Refresh the browser after changes if Live Server is not running.

## Where you usually code

- HTML usually lives in `.html` files.
- CSS can connect later with a `<link>` tag.
- JavaScript can connect later with a `<script>` tag.

## Common first problems

- The browser still shows the old page: refresh the browser.
- The page is blank: check that you opened the right `index.html` file.
- Styles or scripts do not load: check the file path.

## Next Atlas step

After the page opens, continue with the mission or the Concept Library.
