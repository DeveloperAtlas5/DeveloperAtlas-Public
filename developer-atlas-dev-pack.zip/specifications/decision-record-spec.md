# Decision Record Specification

Decision records are deterministic outputs from Atlas Kernel.

## Purpose

A decision record captures what Atlas recommended, why it recommended it, what alternatives were rejected, what evidence supports it, and what the developer should verify or learn next.

## Required Fields

- `decision_id`
- `mission_id`
- `user_goal`
- `detected_intent`
- `context_summary`
- `candidates`
- `recommendation`
- `rejected_alternatives`
- `tradeoffs`
- `confidence`
- `evidence_level`
- `supporting_nodes`
- `risks`
- `verification_steps`
- `beginner_explanation`
- `professional_summary`
- `ai_coding_guidance`
- `next_learning_nodes`

## Rules

- Recommendations must reference supporting node ids.
- Alternatives should include rejection reasons.
- Trade-offs are required.
- Confidence and evidence level must be explicit.
- Verification steps are required when code or troubleshooting is involved.
