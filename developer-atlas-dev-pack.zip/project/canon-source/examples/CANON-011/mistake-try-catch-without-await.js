function failingPromise() {
  return Promise.reject(new Error("network unavailable"));
}

async function catchWithoutAwait() {
  try {
    const promise = failingPromise();
    promise.catch(() => {});
    return "not caught locally";
  } catch (error) {
    return `caught: ${error.message}`;
  }
}

async function catchWithAwait() {
  try {
    await failingPromise();
    return "not reached";
  } catch (error) {
    return `caught: ${error.message}`;
  }
}

module.exports = async function runMistakeTryCatchWithoutAwait() {
  const unhandled = failingPromise().catch((error) => error.message);
  const withoutAwait = await catchWithoutAwait();
  const withAwait = await catchWithAwait();
  const rejectionMessage = await unhandled;

  if (withoutAwait !== "not caught locally") {
    throw new Error("try/catch without await should not catch the rejection locally.");
  }

  if (withAwait !== "caught: network unavailable") {
    throw new Error("try/catch with await should catch the rejection.");
  }

  if (rejectionMessage !== "network unavailable") {
    throw new Error("Rejected promise should remain catchable at the promise boundary.");
  }

  return { withoutAwait, withAwait };
};
