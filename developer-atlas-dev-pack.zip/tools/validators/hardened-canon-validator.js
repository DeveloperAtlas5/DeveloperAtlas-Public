const {
  fs,
  path,
  hardenedCanonOutputDir,
  packagedDemoDir,
  packagedHardenedCanonDir,
  validateNoHypeLanguage,
  validateNoShameLanguage,
  validateSectionsInOrder
} = require("./shared-validator-utils");

const expectedFiles = [
  "CANON-022-localstorage-vue-state.md",
  "CANON-023-json-stringify-parse.md",
  "CANON-024-ref.md",
  "CANON-025-computed.md",
  "CANON-027-watch.md",
  "CANON-028-v-model.md",
  "CANON-029-v-for-key.md",
  "CANON-030-props-emits.md",
  "CANON-031-avoid-prop-mutation.md"
];

const expectedTopics = [
  [/CANON-022[\s\S]*localStorage \+ Vue state[\s\S]*localStorage saves strings[\s\S]*Vue state drives the screen[\s\S]*JSON\.stringify[\s\S]*JSON\.parse[\s\S]*App\.vue[\s\S]*localStorage is for persistence, not app logic/i, "localStorage + Vue state"],
  [/CANON-023[\s\S]*JSON\.stringify vs JSON\.parse[\s\S]*JSON\.stringify turns data into a string[\s\S]*JSON\.parse turns saved strings back into usable data[\s\S]*invalid saved data/i, "JSON stringify parse"],
  [/CANON-024[\s\S]*ref\(\)[\s\S]*ref holds reactive values[\s\S]*Use `\.value` in script[\s\S]*Templates unwrap refs automatically/i, "ref"],
  [/CANON-025[\s\S]*computed\(\)[\s\S]*computed is for derived display values[\s\S]*totals[\s\S]*completed count[\s\S]*remaining count[\s\S]*Do not use computed for side effects/i, "computed"],
  [/CANON-027[\s\S]*watch\(\)[\s\S]*watch reacts to state changes[\s\S]*saving to localStorage[\s\S]*deep watch for arrays or objects/i, "watch"],
  [/CANON-028[\s\S]*v-model[\s\S]*v-model connects form input to state[\s\S]*todo input text/i, "v-model"],
  [/CANON-029[\s\S]*v-for \+ :key[\s\S]*v-for renders lists[\s\S]*:key helps Vue track items predictably[\s\S]*stable id[\s\S]*unpredictable updates/i, "v-for key"],
  [/CANON-030[\s\S]*props \+ emits[\s\S]*Props go down[\s\S]*Events go up[\s\S]*Parent owns shared state[\s\S]*Child asks for changes[\s\S]*Mission 2/i, "props emits"],
  [/CANON-031[\s\S]*avoid prop mutation[\s\S]*Do not directly change props[\s\S]*Emit an event[\s\S]*parent update the state/i, "avoid prop mutation"]
];

function validateHardenedCanon(errors, warnings) {
  validateHardenedCanonDir(
    hardenedCanonOutputDir,
    "output/experience/canon/hardened",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateHardenedCanonDir(
    packagedHardenedCanonDir,
    "output/share/developer-atlas-mvp-demo/reference/canon/hardened",
    errors,
    warnings,
    true
  );
}

function validateHardenedCanonDir(dirPath, label, errors, warnings, required) {
  if (!fs.existsSync(dirPath)) {
    const message = `${label}: missing hardened Canon folder`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const files = fs.readdirSync(dirPath).filter((entry) => entry.endsWith(".md")).sort();
  if (files.length !== 9) {
    errors.push(`${label}: expected exactly 9 hardened Canon files, found ${files.length}`);
  }

  for (const expectedFile of expectedFiles) {
    if (!files.includes(expectedFile)) {
      errors.push(`${label}/${expectedFile}: missing expected hardened Canon file`);
    }
  }

  for (const file of files) {
    if (!expectedFiles.includes(file)) {
      errors.push(`${label}/${file}: hardened Canon file is outside the current Rookie Vue path set`);
    }
  }

  const allText = files
    .map((file) => fs.readFileSync(path.join(dirPath, file), "utf8"))
    .join("\n\n");

  validateNoHypeLanguage(allText, label, errors);
  validateNoShameLanguage(allText, label, errors);

  const forbiddenPatterns = [
    /Gold Candidate/i,
    /scorecard/i,
    /benchmark/i,
    /\bproof\b/i,
    /deterministic architecture/i,
    /Mission Intelligence/i,
    /Flow Engine/i,
    /Capability Intelligence/i
  ];

  for (const pattern of forbiddenPatterns) {
    if (pattern.test(allText)) {
      errors.push(`${label}: contains forbidden internal wording (${pattern})`);
    }
  }

  if (/bad data/i.test(allText)) {
    errors.push(`${label}: use "invalid saved data" instead of "bad data"`);
  }

  if ((allText.match(/CANON-022/g) || []).length < 1) {
    errors.push(`${label}: localStorage Canon should preserve CANON-022`);
  }

  const vModelPath = path.join(dirPath, "CANON-028-v-model.md");
  if (fs.existsSync(vModelPath)) {
    const vModelText = fs.readFileSync(vModelPath, "utf8");
    if (!/^# CANON-028 - v-model/m.test(vModelText)) {
      errors.push(`${label}/CANON-028-v-model.md: v-model should use unique CANON-028 ID`);
    }
  }

  const headingIds = files
    .map((file) => {
      const text = fs.readFileSync(path.join(dirPath, file), "utf8");
      const match = text.match(/^# (CANON-\d+)/m);
      return match ? match[1] : null;
    })
    .filter(Boolean);
  const uniqueIds = new Set(headingIds);
  if (uniqueIds.size !== headingIds.length) {
    errors.push(`${label}: Canon IDs must be unique`);
  }

  for (const file of files) {
    validateHardenedCanonFile(path.join(dirPath, file), `${label}/${file}`, errors);
  }

  for (const [pattern, topic] of expectedTopics) {
    if (!pattern.test(allText)) {
      errors.push(`${label}: missing required hardened Canon topic (${topic})`);
    }
  }
}

function validateHardenedCanonFile(filePath, label, errors) {
  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# CANON-",
    "Status: Hardened",
    "## Core idea",
    "## Use this when",
    "## Basic pattern",
    "## Common friction",
    "## Small example",
    "## Check yourself",
    "## Related Canon nodes"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  if (!/^# CANON-\d+ - .+/m.test(text)) {
    errors.push(`${label}: missing Canon heading`);
  }

  if (!/Status: Hardened/i.test(text)) {
    errors.push(`${label}: missing hardened status`);
  }
}

module.exports = {
  validateHardenedCanon
};
