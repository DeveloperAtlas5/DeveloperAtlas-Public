# AI Concept Check Standard

Technology: AI Standard

## Simple meaning

AI should identify relevant Atlas concepts before answering with code.

## Why it exists

Concept checks keep answers aligned with the project map instead of random tool choices.

## What AI should do

- Identify which Atlas concepts apply before answering.
- Use relevant concept nodes to explain the choice.
- Connect the code change to the concept.
- For Laravel categories and items, check Model, Migration, Relationship, Seeder, and Factory.
- For Vue saved to-do items, check Vue state, ref, localStorage, and App.vue.

## What AI should avoid

- Using framework terms without explaining them.
- Choosing tools without saying why.
- Mixing concepts from different stacks without warning.

## Before changing code

Name the concept nodes that guide the answer.

## While writing code

Use those concepts to keep code and explanation aligned.

## After the change

Point back to the concept that explains why the change works.

## Human check

The human should see which idea the code is practicing.

## Related Atlas nodes

- Vue ref
- Vue watch
- Laravel Model
- Laravel Migration
- AI Explain-Before-Change Standard
