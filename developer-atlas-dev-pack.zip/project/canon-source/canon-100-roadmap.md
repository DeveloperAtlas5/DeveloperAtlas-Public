# Canon 100 Roadmap

This roadmap lists the next Canon candidates after Batch 01. It is a planning document, not a publication claim. Candidates should be hardened one at a time using the Batch 01, Batch 02, and Batch 03 quality bar.

## Batch 02 Release Candidate

- CANON-006: computed() vs watch() - Batch 02 Gold Candidate
- CANON-007: v-if vs v-show - Batch 02 Gold Candidate
- CANON-008: Promise.all() vs Promise.allSettled() - Batch 02 Gold Candidate
- CANON-009: Array.prototype.filter() Decision Guide - Batch 02 Gold Candidate
- CANON-010: Array.prototype.find() Decision Guide - Batch 02 Gold Candidate

## Batch 03 Release Candidate

- CANON-011: async vs await vs Promise.then() - Batch 03 Gold Candidate
- CANON-012: Object.keys() vs Object.values() vs Object.entries() - Batch 03 Gold Candidate
- CANON-013: v-for keys decision guide - Batch 03 Gold Candidate
- CANON-014: Laravel validation - Batch 03 Gold Candidate
- CANON-015: SQL WHERE vs HAVING - Batch 03 Gold Candidate

## Batch 04 Release Candidate

Batch 04 exists to broaden MVP demo coverage across development levels: rookies, juniors, intermediate developers, professional developers, and AI assistants. These nodes are frozen as Gold Candidates, pending named reviewer sign-off before final Gold.

- CANON-016: `try/catch` vs `.catch()` - Batch 04 Gold Candidate, junior/intermediate JavaScript error handling
- CANON-017: `JSON.parse()` vs `JSON.stringify()` - Batch 04 Gold Candidate, rookie/junior JavaScript data exchange
- CANON-018: Laravel `Controller` vs `Form Request` vs `Service` - Batch 04 Gold Candidate, intermediate/professional Laravel architecture
- CANON-019: SQL `INNER JOIN` vs `LEFT JOIN` - Batch 04 Gold Candidate, junior/intermediate SQL relational thinking
- CANON-020: CSS `position: relative` vs `absolute` vs `fixed` vs `sticky` - Batch 04 Gold Candidate, rookie/junior/intermediate CSS layout

## Batch 05 Candidates

Batch 05 broadens MVP demo coverage across CSS, JavaScript, Laravel, SQL, and Vue. These are candidate nodes only and should not be treated as Gold until hardened.

- CANON-021: CSS `display: block` vs `inline` vs `inline-block` - Batch 05 Candidate
- CANON-022: JavaScript `localStorage` vs `sessionStorage` - Batch 05 Candidate
- CANON-023: Laravel migration vs model vs factory vs seeder - Batch 05 Candidate
- CANON-024: SQL `GROUP BY` decision guide - Batch 05 Candidate
- CANON-025: Vue props vs emits vs model - Batch 05 Candidate

## Batch 06 Candidates

Batch 06 broadens practical engineering foundations across Git, package management, API architecture, SQL relationships, and the CSS box model. These are candidate nodes only and should not be treated as Gold until hardened.

- CANON-026: Git commit vs branch vs merge - Batch 06 Candidate
- CANON-027: npm vs pnpm vs yarn - Batch 06 Candidate
- CANON-028: REST API route vs controller vs service - Batch 06 Candidate
- CANON-029: SQL primary key vs foreign key - Batch 06 Candidate
- CANON-030: CSS margin vs padding - Batch 06 Candidate

## JavaScript

1. Promise.all() vs Promise.allSettled() - Batch 02 Gold Candidate: CANON-008
2. async vs await vs Promise.then() - Batch 03 Gold Candidate: CANON-011
3. try/catch vs .catch() - Batch 04 Gold Candidate: CANON-016
4. JSON.parse() vs JSON.stringify() - Batch 04 Gold Candidate: CANON-017
5. localStorage vs sessionStorage - Batch 05 Candidate: CANON-022
6. optional chaining vs defensive checks
7. nullish coalescing vs logical OR
8. Array.prototype.filter() - Batch 02 Gold Candidate: CANON-009
9. Array.prototype.find() - Batch 02 Gold Candidate: CANON-010
10. Array.prototype.some() vs every()
11. Array.prototype.sort()
12. Object.keys() vs Object.values() vs Object.entries() - Batch 03 Gold Candidate: CANON-012
13. Map vs plain object
14. Set for uniqueness
15. shallow copy vs deep copy
16. debounce vs throttle
17. modules: default export vs named export
18. Date handling pitfalls

## Vue

1. computed() vs watch() - Batch 02 Gold Candidate: CANON-006
2. v-if vs v-show - Batch 02 Gold Candidate: CANON-007
3. props vs emits vs model - Batch 05 Candidate: CANON-025
4. v-model component contract
5. composables vs components
6. provide/inject
7. watchers for side effects
8. v-for keys decision guide - Batch 03 Gold Candidate: CANON-013
9. lifecycle hooks in Composition API
10. Pinia store vs local state
11. route params with useRoute()
12. navigation with useRouter()
13. slots vs props

## CSS

1. position relative vs absolute vs fixed vs sticky - Batch 04 Gold Candidate: CANON-020
2. margin vs padding - Batch 06 Candidate: CANON-030
3. gap vs margins
4. rem vs px
5. min-width vs width
6. media queries vs container queries
7. z-index stacking context
8. display block vs inline vs inline-block - Batch 05 Candidate: CANON-021
9. CSS custom properties
10. responsive image sizing
11. overflow handling
12. BEM vs utility classes

## SQL

1. WHERE vs HAVING - Batch 03 Gold Candidate: CANON-015
2. INNER JOIN vs LEFT JOIN - Batch 04 Gold Candidate: CANON-019
3. GROUP BY - Batch 05 Candidate: CANON-024
4. ORDER BY
5. COUNT(*) vs COUNT(column)
6. EXISTS vs IN
7. indexes for lookup queries
8. aggregate queries
9. subquery vs JOIN
10. transaction basics
11. NULL handling
12. primary key vs foreign key - Batch 06 Candidate: CANON-029

## HTML

1. button vs anchor
2. label and input association
3. form submission basics
4. select vs radio group
5. semantic sectioning
6. img alt text
7. table semantics
8. meta viewport
9. script loading attributes
10. accessible navigation landmarks

## PHP/Laravel

1. Laravel validation - Batch 03 Gold Candidate: CANON-014
2. Controller vs Form Request vs Service - Batch 04 Gold Candidate: CANON-018
3. Eloquent model relationships
4. migration design - Batch 05 Candidate: CANON-023
5. route model binding
6. request classes
7. collections map/filter/reduce
8. config vs env
9. queues for background work
10. policies vs gates

## Architecture

1. layered architecture
2. repository pattern trade-offs
3. service layer boundaries
4. DTO vs array payload
5. monolith vs microservices
6. caching strategy
7. event-driven design
8. API versioning
9. idempotency
10. feature flags

## Git And Workflow

1. commit vs branch vs merge - Batch 06 Candidate: CANON-026
2. pull vs fetch
3. rebase vs merge
4. stash vs commit
5. pull request review basics

## Package Management

1. npm vs pnpm vs yarn - Batch 06 Candidate: CANON-027
2. lockfile basics
3. dependencies vs devDependencies
4. semantic version ranges
5. clean install debugging

## Backend/API

1. REST API route vs controller vs service - Batch 06 Candidate: CANON-028
2. request validation boundaries
3. response shape design
4. API pagination
5. error response contracts

## Security

1. authentication vs authorization
2. password hashing
3. CSRF protection
4. XSS prevention
5. SQL injection prevention
6. secure cookies
7. rate limiting
8. secrets management
9. input validation vs output escaping
10. least privilege

## Testing/Debugging

1. unit vs integration tests
2. test pyramid
3. mocking external APIs
4. snapshot testing trade-offs
5. debugging async JavaScript
6. browser network debugging
7. database query debugging
8. regression test writing
9. flaky test triage
10. logging vs tracing

## AI Engineering

1. prompt contracts
2. retrieval vs model memory
3. structured outputs
4. eval design
5. hallucination risk controls
6. tool calling boundaries
7. context window budgeting
8. source citation policy
9. deterministic fallback behavior
10. AI code review checklists
11. agent handoff records
12. confidence scoring
