# Vue Store / Pinia

Technology: Vue

## Simple meaning

A store keeps shared frontend state outside one component.

## Why it exists

It helps multiple components use and update the same browser-side data.

## Where you use it

In Pinia store files or a shared state module.

## When to use it

Use a store when several distant components need the same state and passing props becomes noisy.

## Tiny example

`const todoStore = useTodoStore();`

## Common beginner confusion

A store is not a database. Refreshing the page can still lose data unless you also persist or reload it.

## Related concepts

- Component
- ref
- reactive

## Similar idea in another technology

Laravel stores long-term data in a database through models; Pinia stores current frontend state in the browser.
