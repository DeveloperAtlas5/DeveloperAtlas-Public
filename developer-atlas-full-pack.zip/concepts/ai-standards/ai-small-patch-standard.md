# AI Small Patch Standard

Technology: AI Standard

## Simple meaning

AI should make the smallest useful change for the current goal.

## Why it exists

Small patches are easier to review, test, undo, and learn from.

## What AI should do

- Touch only files needed for the goal.
- Do not rewrite working areas without reason.
- Prefer patch-sized help over project redesign.
- Say why each changed file is needed.

## What AI should avoid

- Large rewrites.
- New dependencies.
- New architecture.
- Formatting unrelated files.
- Fixing unrelated problems unless asked.

## Before changing code

Name the goal and decide the smallest file set that can satisfy it.

## While writing code

Keep the patch focused and leave unrelated code alone.

## After the change

List the changed files and the exact verification step.

## Human check

The human should see that the patch maps directly to the requested goal.

## Related Atlas nodes

- AI No-Scope-Creep Standard
- AI Explain-Before-Change Standard
