# Mission Feedback Template

Each mission ends with a short reflection. Atlas uses this shape to understand confidence, completion, recovery, and remaining confusion.

## What Atlas Measures

- Confidence before and after the mission.
- Whether the visible win was completed.
- Whether recovery guidance helped.
- What still feels unclear.
- For AI-assisted builders, whether the AI stayed inside the mission scope.
- For AI-assisted builders, whether unnecessary AI changes were rejected or undone.

## Default Learner Questions

Before you started, how confident did you feel?

1 2 3 4 5

After finishing or stopping, how confident do you feel now?

1 2 3 4 5

Did you complete the visible win?

- Yes
- Partly
- Not yet

Did Atlas help you recover from a blocker?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.

## AI-Assisted Builder Questions

Before you asked AI, how confident did you feel?

1 2 3 4 5

After testing the AI-assisted change, how confident do you feel now?

1 2 3 4 5

Did the AI change stay inside the mission scope?

- Yes
- Mostly
- No, it changed too much

Did you reject or undo any unnecessary AI changes?

- Yes
- No
- Not needed

Did Atlas help you recover when AI broke or over-expanded the code?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.
