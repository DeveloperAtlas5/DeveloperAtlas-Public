# Mission 3 - AI-Assisted TodoStats Component

## Today's AI-assisted Mission

Use AI to help create a `TodoStats` component while keeping the app state and architecture unchanged.

## Goal

Show total, completed, and remaining todo counts through a small display component.

## Where this work happens

Work in the same Vue todo project from Missions 1 and 2.

Use this mission file as the guide.

Do not edit the Atlas package files.

## AI mission boundary

AI should complete Mission 3, not redesign the project.

Edit my Vue todo project, not the Atlas package.

Goal: add `TodoStats.vue`.

Work in the same Vue todo project from Missions 1 and 2.

Create `src/components/TodoStats.vue`.

Keep todo list state and localStorage in `App.vue`.

Pass total, completed, and remaining as props.

`TodoStats.vue` is display-only.

No emits needed for Mission 3.

Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.

Keep the smallest useful change.

Do not accept "cleaner", "production-ready", "more reusable", or "proper architecture" changes if they add files or architecture outside this mission.

For Mission 3, "better stats" still means display-only counts, not charts, analytics, or a stats architecture.

If the answer changes too much, reject it and ask for a smaller patch.

## Quick Start With AI

1. Ask AI to find where the todo list state currently lives.
2. Ask AI to create `src/components/TodoStats.vue` in your Vue todo project.
3. Tell AI to keep todo state and localStorage in `App.vue`.
4. Tell AI that `TodoStats.vue` should only display numbers passed as props.
5. Reject new stores, composables, routing, backend, charts, analytics, or architecture changes.
6. Test that stats update when todos change.
7. Ask AI to explain the data flow back to you.

## Tiny file map

- `src/App.vue`: keeps todos, localStorage, and calculates stats.
- `src/components/TodoStats.vue`: displays total, completed, and remaining counts.

## Data flow

`App.vue` owns the todo list.

`App.vue` passes numbers down:

- `total`
- `completed`
- `remaining`

`TodoStats.vue` displays those numbers.

For this mission, `TodoStats.vue` does not emit events and does not change todos.

## Copy/paste prompt

```txt
You are helping me with Developer Atlas Mission 3.

Edit my Vue todo project, not the Atlas package.

Goal: add a display-only `TodoStats.vue` component.

Create `src/components/TodoStats.vue`.

Keep todo list state and localStorage in `src/App.vue`.

Pass total, completed, and remaining values as props.

Do not add emits for this mission.

Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.

Format your answer with clear headings, file names, small code blocks, spacing, and verification steps.

Make the answer easy for me, another human, or a future AI session to understand later.

If I ask for cleaner, production-ready, reusable, or faster changes that go beyond this mission, park those ideas and keep the smallest current-mission patch.

After the change, explain what changed and how I can verify it.
```

## What to ask AI

Copy and paste this prompt:

```txt
I am building a Vue 3 todo app. Edit my Vue todo project, not the Atlas package. Tell AI to create `src/components/TodoStats.vue` in your Vue todo project to display total, completed, and remaining todos. Keep todo state and localStorage behavior in `App.vue`. Calculate the stats in `App.vue` and pass them into `TodoStats.vue` as props. TodoStats.vue should only display the numbers. Do not add Pinia, routing, backend, auth, database, deployment, charts, analytics, a store, a composable, or a new architecture. Do not reorganize folders or rename unrelated variables. Explain each changed file.
```

## What AI may change

- `src/App.vue`.
- `src/components/TodoStats.vue`.
- Only the display component and prop connection needed for this mission.

## What AI must not change

- Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.
- Do not move todo list state or localStorage out of `src/App.vue`.
- Do not add emits for this mission.
- Do not rewrite the whole app.

## Before you accept the answer

- Confirm `src/components/TodoStats.vue` was created.
- Confirm `TodoStats.vue` is display-only.
- Confirm no emits were added for this mission.
- Confirm AI explains what changed before I accept the answer.

## Ask AI to explain it back

Explain what changed before I accept the answer. Use plain language and tell me how `App.vue` calculates and passes total, completed, and remaining values.

## What to accept

Accept changes that:

- Create `src/components/TodoStats.vue`.
- Update `App.vue` to use `TodoStats`.
- Calculate total, completed, and remaining from the current todos.
- Pass numbers as props.
- Keep state in `App.vue`.
- Keep localStorage in `App.vue`.
- Preserve Mission 1 persistence.
- Preserve Mission 2 `TodoItem.vue`.
- Explain changed files.

## What to reject

Reject changes that:

- Move state into `TodoStats.vue`.
- Make `TodoStats.vue` write to localStorage.
- Add Pinia.
- Add routing.
- Add backend.
- Add auth.
- Add database.
- Add deployment.
- Add a store.
- Add a composable for later.
- Add charts or analytics.
- Create extra components.
- Reorganize folders.
- Rename many variables unnecessarily.
- Change unrelated styling.
- Remove Mission 1 persistence.
- Break Mission 2 `TodoItem.vue`.
- Rewrite the app.

## Recovery prompt

```txt
Please make a smaller patch. Only change the files needed for Developer Atlas Mission 3. Undo the extra architecture and return to the smallest solution for this mission.
```

## Files likely to change

- `src/App.vue`
- `src/components/TodoStats.vue`

## Files that should not change today

- Router files.
- Backend files.
- `package.json`.
- Deployment files.
- Auth files.
- Database files.
- Global store files.
- Unrelated styling files.
- `TodoItem.vue` unless needed for a tiny compatibility fix.

## Test the result

- Total todos updates.
- Completed todos updates.
- Remaining todos updates.
- Adding todos still works.
- Completing todos still works.
- Removing todos still works if supported.
- Filtering still works if supported.
- localStorage still works.
- `TodoItem.vue` still works.
- Browser console has no errors.

## Completion checklist

- [ ] AI created or helped create `src/components/TodoStats.vue`.
- [ ] `App.vue` imports and uses `TodoStats`.
- [ ] Stats are calculated from the current todo list.
- [ ] `TodoStats.vue` receives numbers as props.
- [ ] `TodoStats.vue` only displays numbers.
- [ ] State stays in `App.vue`.
- [ ] localStorage stays in `App.vue`.
- [ ] Mission 1 persistence still works.
- [ ] Mission 2 `TodoItem.vue` still works.
- [ ] I rejected extra architecture, charts, stores, composables, routing, backend, auth, database, and deployment.

## If AI breaks it

Use this recovery prompt:

```txt
Show me the smallest diff that restores the previous todo behavior while keeping TodoStats.vue. Do not reorganize folders, rename unrelated variables, add charts, or add new architecture.
```

Then ask:

```txt
Check whether the bug comes from stale copied stats, a prop name mismatch, moving state out of App.vue, moving localStorage behavior, or breaking TodoItem.vue.
```

## Explain it back

Ask:

```txt
Explain how App.vue calculates todo stats and passes them into TodoStats.vue. Use beginner-friendly language and give me three small questions to check if I understood.
```

## Skip today

- Pinia
- Routing
- Backend
- Auth/login
- Database
- Deployment
- Store
- Composable for later
- Charts
- Analytics
- Extra components
- Folder reorganization
- Unrelated renaming
- Rewriting the app

## Next mission preview

Next, you can practice parent-child communication more deeply by letting a child component ask the parent to update data.

## After the mission

Before you asked AI, how confident did you feel?

1 2 3 4 5

After testing the AI-assisted change, how confident do you feel now?

1 2 3 4 5

Did the AI change stay inside the mission scope?

- Yes
- Mostly
- No, it changed too much

Did you reject or undo any unnecessary AI changes?

- Yes
- No
- Not needed

Did Atlas help you recover when AI broke or over-expanded the code?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.
