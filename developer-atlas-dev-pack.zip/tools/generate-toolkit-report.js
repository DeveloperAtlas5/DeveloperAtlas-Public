const fs = require("fs");
const path = require("path");
const {
  toolkitOutputDir,
  ensureToolkitOutputDir,
  readTools,
  readSetupProfiles,
  countBy
} = require("./toolkit-utils");

function main() {
  const tools = readTools().map((record) => record.data);
  const profiles = readSetupProfiles().map((record) => record.data);

  ensureToolkitOutputDir();
  fs.writeFileSync(
    path.join(toolkitOutputDir, "toolkit-index.json"),
    `${JSON.stringify({ tools, setup_profiles: profiles }, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(toolkitOutputDir, "toolkit-report.md"),
    toReport(tools, profiles)
  );

  console.log(`Generated output/toolkit/toolkit-index.json with ${tools.length} tool(s) and ${profiles.length} setup profile(s).`);
  console.log("Generated output/toolkit/toolkit-report.md.");
}

function toReport(tools, profiles) {
  const linkedToFriction = tools.filter((tool) => tool.related_friction_nodes.length);
  const topBeginner = [...tools].sort((a, b) => b.beginner_fit - a.beginner_fit || a.name.localeCompare(b.name)).slice(0, 8);
  const topFriction = [...tools].sort((a, b) => b.friction_reduction_score - a.friction_reduction_score || a.name.localeCompare(b.name)).slice(0, 8);

  const lines = [
    "# Atlas Toolkit Report",
    "",
    `Total tools: ${tools.length}`,
    `Setup profiles: ${profiles.length}`,
    `Tools linked to friction nodes: ${linkedToFriction.length}`,
    "",
    "## Tools By Category",
    "",
    ...formatCounts(countBy(tools, "category")),
    "",
    "## Top Beginner Tools",
    "",
    ...topBeginner.map((tool) => `- ${tool.name}: ${tool.beginner_fit}/100`),
    "",
    "## Top Friction-Reducing Tools",
    "",
    ...topFriction.map((tool) => `- ${tool.name}: ${tool.friction_reduction_score}/100`),
    "",
    "## Setup Profiles",
    "",
    ...profiles.map((profile) => `- ${profile.profile_id}: ${profile.audience} (${profile.operating_system})`),
    "",
    "## Tools Linked To Friction Nodes",
    ""
  ];

  for (const tool of linkedToFriction.sort((a, b) => a.name.localeCompare(b.name))) {
    lines.push(`- ${tool.name}: ${tool.related_friction_nodes.join(", ")}`);
  }

  lines.push("", "## Recommended Missing Tools Or Extensions", "");
  lines.push("- Node version manager for cross-project runtime switching.");
  lines.push("- Database GUI for SQL and Laravel learners.");
  lines.push("- HTTPie or curl profile for CLI-first API testing.");
  lines.push("- Windows terminal profile guidance.");
  lines.push("- Docker Compose profile for Laravel plus database services.");

  return `${lines.join("\n")}\n`;
}

function formatCounts(items) {
  return items.length
    ? items.map((item) => `- ${item.value}: ${item.count}`)
    : ["- None"];
}

main();
