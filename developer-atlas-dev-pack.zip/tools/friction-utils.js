const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const frictionDir = path.join(rootDir, "friction");
const frictionExamplesDir = path.join(frictionDir, "examples");
const frictionOutputDir = path.join(rootDir, "output", "friction");

function ensureFrictionOutputDir() {
  fs.mkdirSync(frictionOutputDir, { recursive: true });
}

function findFrictionExampleFiles() {
  if (!fs.existsSync(frictionExamplesDir)) return [];

  return fs.readdirSync(frictionExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => path.join(frictionExamplesDir, fileName));
}

function readFrictionNodes() {
  return findFrictionExampleFiles().map((file) => {
    return {
      file,
      relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
      node: JSON.parse(fs.readFileSync(file, "utf8"))
    };
  });
}

function countValues(nodes, field) {
  const counts = new Map();

  for (const { node } of nodes) {
    for (const value of node[field] || []) {
      counts.set(value, (counts.get(value) || 0) + 1);
    }
  }

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

module.exports = {
  frictionDir,
  frictionExamplesDir,
  frictionOutputDir,
  ensureFrictionOutputDir,
  findFrictionExampleFiles,
  readFrictionNodes,
  countValues
};
