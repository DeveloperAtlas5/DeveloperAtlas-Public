const fs = require("fs");
const path = require("path");
const { readEntries, compareEntries, rootDir } = require("./content-utils");
const {
  STRUCTURED_NODE_TYPES,
  RECOMMENDATION_FIELDS,
  buildGraph,
  recommendationCompleteness
} = require("./graph-utils");

const outputDir = path.join(rootDir, "output", "reports");
const outputPath = path.join(outputDir, "recommendation-report.md");

function main() {
  const entries = readEntries().sort(compareEntries);
  const graph = buildGraph(entries);
  const recommendationResults = entries.map((entry) => ({
    id: entry.frontMatter.id,
    type: entry.frontMatter.type,
    technology: entry.frontMatter.technology,
    ...recommendationCompleteness(entry.frontMatter)
  }));
  const missingRecommendationNodes = recommendationResults.filter((result) => result.missing.length > 0);

  const lines = [
    "# Developer Atlas Recommendation Report",
    "",
    `Total nodes: ${entries.length}`,
    `Nodes missing recommendation metadata: ${missingRecommendationNodes.length}`,
    "",
    "## Structured Node Coverage",
    ""
  ];

  for (const type of STRUCTURED_NODE_TYPES) {
    lines.push(`- ${type}: ${graph.statistics.structured_node_counts[type]}`);
  }

  lines.push("", "## Recommendation Metadata Fields", "");
  for (const field of RECOMMENDATION_FIELDS) {
    const missing = recommendationResults.filter((result) => result.missing.includes(field)).length;
    lines.push(`- ${field}: missing from ${missing} node(s)`);
  }

  lines.push("", "## Nodes Missing Recommendation Metadata", "", "| Score | ID | Missing Fields |", "|---:|---|---|");
  for (const result of missingRecommendationNodes.slice(0, 40)) {
    lines.push(`| ${result.score} | ${result.id} | ${result.missing.join(", ")} |`);
  }

  lines.push("", "## Relationship Gaps", "");
  lines.push(`- Missing relationship targets: ${graph.missingEdges.length}`);
  lines.push(`- Nodes without outgoing graph edges: ${entries.filter((entry) => !graph.edges.some((edge) => edge.source === entry.frontMatter.id)).length}`);
  lines.push(`- Nodes without incoming graph edges: ${entries.filter((entry) => !graph.edges.some((edge) => edge.target === entry.frontMatter.id)).length}`);

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${lines.join("\n")}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)}.`);
}

main();
