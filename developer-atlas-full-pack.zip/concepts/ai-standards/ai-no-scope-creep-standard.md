# AI No-Scope-Creep Standard

Technology: AI Standard

## Simple meaning

AI should stay inside the current goal and park future ideas.

## Why it exists

Extra features make learning, review, and verification harder.

## What AI should do

- Stay inside the current goal.
- Do not add features because they seem useful.
- Park future ideas instead of building them immediately.
- Say what is out of scope.

## What AI should avoid

- Adding auth.
- Adding backend.
- Adding routing.
- Adding stores.
- Adding dependencies.
- Adding extra UI systems.
- Adding production architecture unless the mission explicitly asks for it.

## Before changing code

Write down what the current mission asks for and what it does not ask for.

## While writing code

Reject changes that do not serve the current goal.

## After the change

Mention any future idea as parked, not implemented.

## Human check

The human should be able to verify only the requested behavior changed.

## Related Atlas nodes

- AI Small Patch Standard
- AI Human Review Standard
