const examples = [
  ["Object.keys() for dynamic form fields", require("./dynamic-form-fields")],
  ["Object.values() for totals/statistics", require("./values-for-statistics")],
  ["Object.entries() for rendering label/value pairs", require("./entries-for-label-value-pairs")],
  ["mistake: assuming these include inherited properties", require("./mistake-inherited-properties")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-012 example(s).`);

