const fs = require("fs");
const path = require("path");
const { readEntries } = require("./content-utils");
const { readFrictionNodes } = require("./friction-utils");
const { readTools } = require("./toolkit-utils");
const {
  readinessDir,
  readReadinessProfiles,
  readReadinessDeltas
} = require("./readiness-utils");

const requiredFields = [
  "delta_id",
  "readiness_id",
  "before_score",
  "after_score",
  "completed_nodes",
  "completed_practice",
  "resolved_friction_nodes",
  "added_tools",
  "improved_machine_profile",
  "confidence_before",
  "confidence_after",
  "time_spent_minutes",
  "visible_wins",
  "remaining_gaps",
  "next_best_step"
];

const arrayFields = [
  "completed_nodes",
  "completed_practice",
  "resolved_friction_nodes",
  "added_tools",
  "improved_machine_profile",
  "visible_wins",
  "remaining_gaps"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchema(errors);

  let deltas = [];
  try {
    deltas = readReadinessDeltas();
  } catch (error) {
    errors.push(`readiness/deltas: unable to read deltas (${error.message})`);
  }

  const knownIds = collectKnownIds();
  validateDeltas(deltas, knownIds, errors, warnings);

  console.log("Atlas Readiness Delta validation");
  console.log(`Readiness deltas: ${deltas.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchema(errors) {
  const schemaPath = path.join(readinessDir, "readiness-delta.schema.json");
  if (!fs.existsSync(schemaPath)) {
    errors.push("readiness/readiness-delta.schema.json: missing schema file");
    return;
  }

  try {
    JSON.parse(fs.readFileSync(schemaPath, "utf8"));
  } catch (error) {
    errors.push(`readiness/readiness-delta.schema.json: invalid JSON (${error.message})`);
  }
}

function collectKnownIds() {
  return {
    readinessIds: new Set(readReadinessProfiles().map((record) => record.profile.readiness_id)),
    contentIds: new Set(readEntries().map((entry) => entry.frontMatter.id)),
    frictionIds: new Set(readFrictionNodes().map((record) => record.node.id)),
    toolIds: new Set(readTools().map((record) => record.data.id))
  };
}

function validateDeltas(records, knownIds, errors, warnings) {
  const seen = new Set();

  for (const { delta, relativePath } of records) {
    for (const field of requiredFields) {
      if (delta[field] === undefined || delta[field] === null || delta[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }

    if (seen.has(delta.delta_id)) errors.push(`${relativePath}: duplicate delta_id ${delta.delta_id}`);
    seen.add(delta.delta_id);

    if (!knownIds.readinessIds.has(delta.readiness_id)) {
      warnings.push(`${relativePath}: readiness_id ${delta.readiness_id} does not exist`);
    }

    validateRange(relativePath, delta, "before_score", 0, 100, errors);
    validateRange(relativePath, delta, "after_score", 0, 100, errors);
    validateRange(relativePath, delta, "confidence_before", 0, 1, errors);
    validateRange(relativePath, delta, "confidence_after", 0, 1, errors);
    validateNonNegative(relativePath, delta, "time_spent_minutes", errors);

    for (const field of arrayFields) validateStringArray(relativePath, delta, field, errors);
    warnUnknown(relativePath, delta.completed_nodes, knownIds.contentIds, "completed_nodes", warnings);
    warnUnknown(relativePath, delta.resolved_friction_nodes, knownIds.frictionIds, "resolved_friction_nodes", warnings);
    warnUnknown(relativePath, delta.added_tools, knownIds.toolIds, "added_tools", warnings);

    if (delta.after_score < delta.before_score) warnings.push(`${relativePath}: after_score is lower than before_score`);
    if (delta.confidence_after < delta.confidence_before) warnings.push(`${relativePath}: confidence decreased`);
  }
}

function validateStringArray(relativePath, data, field, errors) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

function validateRange(relativePath, data, field, min, max, errors) {
  if (typeof data[field] !== "number" || data[field] < min || data[field] > max) {
    errors.push(`${relativePath}: ${field} should be a number from ${min} to ${max}`);
  }
}

function validateNonNegative(relativePath, data, field, errors) {
  if (typeof data[field] !== "number" || data[field] < 0) {
    errors.push(`${relativePath}: ${field} should be a non-negative number`);
  }
}

function warnUnknown(relativePath, values = [], knownSet, label, warnings) {
  for (const value of values) {
    if (!knownSet.has(value)) warnings.push(`${relativePath}: ${label} references unknown id ${value}`);
  }
}

main();

