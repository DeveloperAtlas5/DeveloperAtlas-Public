const assert = require("node:assert/strict");

function run() {
  const users = [
    { id: 1, name: "Ada" },
    { id: 2, name: "Grace" }
  ];
  const logged = [];

  const badResult = users.map((user) => {
    logged.push(`Visited ${user.name}`);
  });

  assert.deepEqual(logged, ["Visited Ada", "Visited Grace"]);
  assert.deepEqual(badResult, [undefined, undefined]);

  const goodResult = users.map((user) => user.name);

  assert.deepEqual(goodResult, ["Ada", "Grace"]);

  return { badResult, goodResult };
}

module.exports = run;

if (require.main === module) run();
