const assert = require("node:assert/strict");
const { innerJoin, leftJoin, users, orders, userMatchesOrder, userOrderProjection } = require("./join-sim");

function run() {
  const innerRows = innerJoin(users, orders, userMatchesOrder, userOrderProjection);
  const leftRows = leftJoin(users, orders, userMatchesOrder, userOrderProjection);

  const innerUserIds = new Set(innerRows.map((row) => row.user_id));
  const leftUserIds = new Set(leftRows.map((row) => row.user_id));

  assert.equal(innerUserIds.has(3), false);
  assert.equal(leftUserIds.has(3), true);

  const linus = leftRows.find((row) => row.user_id === 3);
  assert.deepEqual(linus, {
    user_id: 3,
    email: "linus@example.com",
    order_id: null,
    total_cents: null
  });

  return { innerUserIds: [...innerUserIds], leftUserIds: [...leftUserIds] };
}

module.exports = run;

if (require.main === module) run();
