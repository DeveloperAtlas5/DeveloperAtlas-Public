const examples = [
  ["simple controller stays simple", require("./simple-controller-stays-simple")],
  ["Form Request extracts validation/authorization", require("./form-request-validation-authorization")],
  ["service extracts reusable business workflow", require("./service-reusable-business-workflow")],
  ["mistake: creating a service for one line of code", require("./mistake-service-for-one-line")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-018 example(s).`);
