const examples = [
  ["try/catch catches synchronous error", require("./try-catch-sync-error")],
  ["try/catch catches awaited rejection", require("./try-catch-awaited-rejection")],
  ["Promise.catch() handles promise chain rejection", require("./promise-catch-chain-rejection")],
  ["mistake: swallowing errors without logging/rethrowing", require("./mistake-swallowing-errors")]
];

(async () => {
  for (const [name, run] of examples) {
    await run();
    console.log(`PASS ${name}`);
  }

  console.log(`Verified ${examples.length} CANON-016 example(s).`);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
