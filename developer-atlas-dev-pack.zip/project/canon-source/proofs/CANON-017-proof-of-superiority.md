# CANON-017 Proof Of Superiority

Canon ID: CANON-017
Node ID: canon.javascript.json.parse-vs-stringify
Title: JSON.parse() vs JSON.stringify()

## What Official Docs Explain Well

MDN and the ECMAScript specification explain `JSON.parse()`, `JSON.stringify()`, the JSON namespace, parsing behavior, stringification behavior, replacers, revivers, exceptions, and return values.

## What Developers Still Struggle With

Developers rarely fail because they cannot remember the method names. They fail because the data boundary is unclear:

- Is the current value JSON text or already a JavaScript value?
- Should this boundary parse incoming data or stringify outgoing data?
- Why did invalid JSON throw?
- Why did `undefined`, functions, or symbols disappear?
- Why did circular data fail?
- Why did the API receive an object-shaped string instead of a JSON request body?
- Why is parsed data still unsafe without validation?

These mistakes show up in production as broken API requests, corrupted localStorage, confusing debug output, invalid AI context payloads, and runtime parsing errors.

## How Atlas Improves The Explanation

Atlas turns the topic into a boundary decision:

- Use `JSON.parse()` when JSON text enters the program.
- Use `JSON.stringify()` when JavaScript values leave the program as JSON text.
- Keep business logic working with validated JavaScript values.
- Do not use JSON conversion as a generic cloning or validation strategy.

This gives rookies a direction model and gives professionals a review model for API, storage, logging, and AI context boundaries.

## What Decision Support Atlas Adds

The node asks whether the current value is text or a runtime value before recommending a method. It also names when neither method is the right answer: validation, cloning complex values, preserving prototypes, handling circular references, or processing very large payloads.

## What Production Guidance Atlas Adds

The node includes realistic examples for API response parsing, API payload stringification, localStorage round trips, and AI context serialization. It also covers invalid JSON, double parsing, double stringifying, unsupported values, and validation after parsing.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct generation rules:

- Ask whether the input is JSON text or a JavaScript value.
- Generate `JSON.parse()` only for strings.
- Generate `JSON.stringify()` at JSON output boundaries.
- Add `Content-Type: application/json` for JSON request bodies.
- Validate parsed untrusted data.
- Avoid JSON round-tripping as a default deep clone.

## Why This Deserves Gold Candidate Status

CANON-017 deserves Gold Candidate status because it converts a beginner-looking API topic into a practical engineering boundary model with official evidence, deterministic examples, production guidance, debugging checks, and AI generation guardrails. It still needs named reviewer sign-off before final Gold approval.
