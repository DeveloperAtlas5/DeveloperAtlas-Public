const fs = require("fs");
const path = require("path");
const { readEntries, compareEntries, rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "ai");
const outputPath = path.join(outputDir, "atlas-ai-dataset.json");

const NODE_FIELDS = [
  "id",
  "slug",
  "title",
  "technology",
  "category",
  "type",
  "difficulty",
  "importance",
  "frequency",
  "confidence",
  "evidence_level",
  "summary",
  "problem",
  "solution",
  "syntax",
  "when_to_use",
  "when_not_to_use",
  "examples",
  "common_mistakes",
  "best_practices",
  "alternatives",
  "related",
  "relationships",
  "recommended_for",
  "avoid_for",
  "best_alternative",
  "tradeoffs",
  "industry_usage",
  "beginner_score",
  "professional_score",
  "interview_score",
  "production_score",
  "learning_priority",
  "tags",
  "ai_notes",
  "teaching_notes",
  "code_generation_notes",
  "troubleshooting_notes",
  "sources"
];

function main() {
  const nodes = readEntries()
    .sort(compareEntries)
    .map((entry) => {
      const node = {};
      for (const field of NODE_FIELDS) node[field] = entry.frontMatter[field] ?? null;
      node.raw_markdown_excerpt = entry.markdown.replace(/^---\r?\n[\s\S]*?\r?\n---(?:\r?\n|$)/, "").trim().slice(0, 1200);
      return node;
    });

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${JSON.stringify({ generated_at: new Date().toISOString(), total_nodes: nodes.length, nodes }, null, 2)}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)} with ${nodes.length} nodes.`);
}

main();
