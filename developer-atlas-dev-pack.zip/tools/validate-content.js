const { analyzeContent } = require("./quality-utils");

const mode = process.argv.includes("--strict")
  ? "strict"
  : process.argv.includes("--quiet")
    ? "quiet"
    : "default";

const IMPORTANT_LEVELS = new Set(["critical", "quality"]);

function visibleWarnings(warnings) {
  if (mode === "quiet") return [];
  if (mode === "strict") return warnings;
  return warnings.filter((warning) => IMPORTANT_LEVELS.has(warning.level));
}

function main() {
  const { results, counts } = analyzeContent();
  const failed = results.filter((result) => result.errors.length > 0);

  console.log("Developer Atlas content validation");
  console.log(`Mode: ${mode}`);
  console.log(`Total entries: ${counts.totalEntries}`);
  console.log("");

  if (mode !== "quiet") {
    for (const result of results) {
      const warnings = visibleWarnings(result.warnings);
      const label = result.errors.length > 0 ? "FAIL" : warnings.length > 0 ? "WARN" : "PASS";
      console.log(`${label} ${result.file} (quality ${result.score}/100)`);
      for (const error of result.errors) console.log(`  - ERROR: ${error}`);
      for (const warning of warnings.slice(0, 6)) {
        console.log(`  - ${warning.level.toUpperCase()}: ${warning.message}`);
      }
      if (warnings.length > 6) console.log(`  - ${warnings.length - 6} more warning(s)`);
    }
    console.log("");
  }

  console.log(`Errors: ${counts.errorCount}`);
  console.log(`Warnings: ${counts.warningCount}`);
  console.log(`Inherited content warnings: ${counts.warningCount}`);
  if (counts.warningCount > 0) {
    console.log("See output/experience/inherited-warning-burndown-report.md");
  }
  printWarningLevels(counts.warningLevels);
  console.log(`Average quality score: ${counts.averageScore}/100`);
  console.log("");
  printCounts("Entries by technology", counts.byTechnology);
  printCounts("Entries by type", counts.byType);
  printCounts("Top missing fields", counts.missingFields.slice(0, 10));
  console.log("");

  if (failed.length > 0) {
    console.log(`Validation failed: ${failed.length} file(s) need attention.`);
    process.exitCode = 1;
  } else {
    console.log("Validation passed: all entries are structurally valid.");
  }
}

function printWarningLevels(levels) {
  console.log("Warnings by level:");
  console.log(`  - critical: ${levels.critical}`);
  console.log(`  - quality: ${levels.quality}`);
  console.log(`  - enrichment: ${levels.enrichment}`);
  console.log(`  - future: ${levels.future}`);
}

function printCounts(title, counts) {
  console.log(`${title}:`);
  for (const [name, count] of counts) console.log(`  - ${name}: ${count}`);
}

main();
