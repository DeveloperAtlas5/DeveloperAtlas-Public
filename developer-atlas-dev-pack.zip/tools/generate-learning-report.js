const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  buildLearningGraph,
  getLearning,
  sumLearning
} = require("./learning-utils");

function main() {
  const entries = readCanonIndex().entries || [];
  const graph = buildLearningGraph(entries);
  const withLearning = entries.filter((entry) => entry.learning);
  const misconceptions = new Map();
  for (const entry of withLearning) {
    for (const item of getLearning(entry).misconceptions || []) {
      misconceptions.set(item, (misconceptions.get(item) || 0) + 1);
    }
  }
  const topMisconceptions = [...misconceptions.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, 10)
    .map(([text]) => text);

  const lines = [
    "# Atlas Learning Report",
    "",
    `Total Canon nodes with learning metadata: ${withLearning.length}`,
    `Total prerequisites: ${withLearning.reduce((sum, entry) => sum + (getLearning(entry).prerequisites || []).length, 0)}`,
    `Total unlocks: ${withLearning.reduce((sum, entry) => sum + (getLearning(entry).unlocks || []).length, 0)}`,
    `Dependency edges: ${graph.edges.length}`,
    `Cycles detected: ${graph.cycles_detected.length}`,
    `Total estimated learning minutes: ${sumLearning(withLearning, "estimated_learning_minutes")}`,
    `Total estimated practice minutes: ${sumLearning(withLearning, "estimated_practice_minutes")}`,
    "",
    "## Root Nodes",
    ""
  ];

  lines.push(...formatList(graph.root_nodes));
  lines.push("", "## Terminal Nodes", "");
  lines.push(...formatList(graph.terminal_nodes));
  lines.push("", "## Top Misconceptions", "");
  lines.push(...formatList(topMisconceptions));
  lines.push("", "## Recommended Next Learning Metadata Improvements", "");
  lines.push("- Add learner-level variants for practice tasks.");
  lines.push("- Add misconception corrections as structured objects after the first metadata pass stabilizes.");
  lines.push("- Add readiness rubrics for certification checkpoints.");
  lines.push("- Connect future Canon nodes only after they exist in canon-index.json.");

  if (graph.missing_references.length) {
    lines.push("", "## Missing References", "");
    lines.push(...formatList(graph.missing_references));
  }

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "learning-report.md"), `${lines.join("\n")}\n`);
  console.log("Generated output/learning/learning-report.md.");
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
