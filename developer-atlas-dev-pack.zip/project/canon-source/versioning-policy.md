# Canon Versioning Policy

Canon versions use calendar-aligned versions such as `2026.1`.

## Version Changes

Increment the version when:

- Technical guidance changes.
- Evidence changes.
- Examples are replaced.
- Score changes.
- The node moves to a new publication stage.

## Review Cadence

Gold Canon nodes should be reviewed at least once per calendar year or when official platform behavior changes.

