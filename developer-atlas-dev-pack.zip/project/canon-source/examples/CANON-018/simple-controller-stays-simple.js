const assert = require("node:assert/strict");
const { classifyEndpoint, shouldAvoidService } = require("./architecture-rules");

module.exports = function runSimpleControllerStaysSimpleExample() {
  const endpoint = {
    validationRules: 1,
    hasAuthorization: false,
    hasCustomMessages: false,
    routeAwareValidation: false,
    reusedWorkflow: false,
    modelOperations: 1,
    needsTransaction: false,
    hasExternalSideEffects: false,
    usedOutsideHttp: false
  };

  assert.deepEqual(classifyEndpoint(endpoint), ["controller"]);
  assert.equal(shouldAvoidService(endpoint), true);
};
