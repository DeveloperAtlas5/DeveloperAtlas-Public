const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const toolkitDir = path.join(rootDir, "toolkit");
const toolkitExamplesDir = path.join(toolkitDir, "examples");
const toolkitProfilesDir = path.join(toolkitDir, "setup-profiles");
const toolkitOutputDir = path.join(rootDir, "output", "toolkit");

function ensureToolkitOutputDir() {
  fs.mkdirSync(toolkitOutputDir, { recursive: true });
}

function readJsonFiles(dir) {
  if (!fs.existsSync(dir)) return [];

  return fs.readdirSync(dir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(dir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        data: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function readTools() {
  return readJsonFiles(toolkitExamplesDir);
}

function readSetupProfiles() {
  return readJsonFiles(toolkitProfilesDir);
}

function countBy(items, field) {
  const counts = new Map();

  for (const item of items) {
    const value = item[field];
    counts.set(value, (counts.get(value) || 0) + 1);
  }

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

module.exports = {
  toolkitDir,
  toolkitExamplesDir,
  toolkitProfilesDir,
  toolkitOutputDir,
  ensureToolkitOutputDir,
  readTools,
  readSetupProfiles,
  countBy
};
