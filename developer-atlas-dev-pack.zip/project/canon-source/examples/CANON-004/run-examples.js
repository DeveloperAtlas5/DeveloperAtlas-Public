const examples = [
  ["navbar with Flexbox", require("./navbar-flexbox")],
  ["card grid with CSS Grid", require("./card-grid-css-grid")],
  ["mistake: using Flexbox for a true 2D layout", require("./mistake-flexbox-for-2d-layout")],
  ["mistake: using Grid for simple inline alignment", require("./mistake-grid-for-inline-alignment")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-004 example(s).`);
