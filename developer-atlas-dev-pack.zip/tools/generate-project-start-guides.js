const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const sourcePath = path.join(rootDir, "content", "project-start-guides", "guides.json");
const outputDir = path.join(rootDir, "output", "experience", "project-start");

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeFile(relativePath, content) {
  const target = path.join(outputDir, relativePath);
  ensureDir(path.dirname(target));
  fs.writeFileSync(target, `${content.trim()}\n`);
}

function list(items) {
  return items.map((item) => `- ${item}`).join("\n");
}

function renderGuide(guide) {
  return [
    `# Start a ${guide.technology} Project`,
    "",
    "## What this is for",
    "",
    guide.what_this_is_for,
    "",
    "## What you need first",
    "",
    guide.what_you_need_first,
    "",
    "## Required tools",
    "",
    list(guide.required_tools),
    "",
    "## Recommended extensions",
    "",
    list(guide.recommended_extensions),
    "",
    "## Start from zero",
    "",
    list(guide.start_from_zero),
    "",
    "## Open an existing project",
    "",
    list(guide.open_existing_project),
    "",
    "## Run or preview the project",
    "",
    list(guide.run_or_preview),
    "",
    "## Where you usually code",
    "",
    list(guide.where_you_code),
    "",
    "## Common first problems",
    "",
    list(guide.common_first_problems),
    "",
    "## Next Atlas step",
    "",
    guide.next_atlas_step
  ].join("\n");
}

function renderIndex(guides) {
  const bySlug = new Map(guides.map((guide) => [guide.slug, guide]));
  const link = (slug) => `- [${bySlug.get(slug).technology}](${slug}.md)`;
  return [
    "# Project Start Guides",
    "",
    "Use this when you do not know how to start or open a project yet.",
    "",
    "Not knowing how to start a project is normal. These guides exist so you do not have to guess.",
    "",
    "## Web basics",
    "",
    ["html", "css", "javascript"].map(link).join("\n"),
    "",
    "## Frameworks",
    "",
    ["vue", "laravel"].map(link).join("\n"),
    "",
    "## Backend / database",
    "",
    ["php", "sql", "java"].map(link).join("\n"),
    "",
    "## How to use these guides",
    "",
    "Pick the project type, follow the first setup steps, then continue with the mission or Concept Library."
  ].join("\n");
}

function main() {
  const data = JSON.parse(fs.readFileSync(sourcePath, "utf8"));
  if (fs.existsSync(outputDir)) fs.rmSync(outputDir, { recursive: true, force: true });
  ensureDir(outputDir);

  for (const guide of data.guides) {
    writeFile(`${guide.slug}.md`, renderGuide(guide));
  }
  writeFile("index.md", renderIndex(data.guides));

  console.log(`Generated output/experience/project-start with ${data.guides.length} guide(s).`);
}

main();
