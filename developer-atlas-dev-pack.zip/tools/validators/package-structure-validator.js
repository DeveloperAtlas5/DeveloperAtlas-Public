const {
  fs,
  path,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionThreeSurfacePath,
  vibeMissionThreeSurfacePath,
  missionDashboardPath,
  startHerePath,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedFirstTimeQuickStartPath,
  packagedMissionDashboardPath,
  packagedHardenedCanonDir,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  packagedAiGuardrailEvaluationPath,
  packagedAiGuardrailRedTeamPackPath,
  packagedAiRedTeamResultsTemplatePath,
  packagedMissionThreeSurfacePath,
  packagedVibeMissionThreeSurfacePath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange
} = require("./shared-validator-utils");

function validatePackagedDemoStructure(errors, warnings) {
  if (!fs.existsSync(packagedDemoDir)) {
    warnings.push("output/share/developer-atlas-mvp-demo has not been packaged yet");
    return;
  }

  const requiredPackageFiles = [
    "START_HERE.md",
    "first-time-quick-start.md",
    "mission-dashboard.html",
    "package-manifest.json",
    "ai/ai-prompt-pack.md",
    "reference/canon/hardened/CANON-022-localstorage-vue-state.md",
    "reference/canon/hardened/CANON-023-json-stringify-parse.md",
    "reference/canon/hardened/CANON-024-ref.md",
    "reference/canon/hardened/CANON-025-computed.md",
    "reference/canon/hardened/CANON-027-watch.md",
    "reference/canon/hardened/CANON-028-v-model.md",
    "reference/canon/hardened/CANON-029-v-for-key.md",
    "reference/canon/hardened/CANON-030-props-emits.md",
    "reference/canon/hardened/CANON-031-avoid-prop-mutation.md",
    "mission/today-mission-surface.md",
    "mission/today-mission-surface.vibe.md",
    "mission/mission-02-todoitem-surface.md",
    "mission/mission-02-todoitem-surface.vibe.md",
    "mission/mission-03-todostats-surface.md",
    "mission/mission-03-todostats-surface.vibe.md",
    "mission/mission-feedback-template.md",
    "help/beginner-orientation.md",
    "help/vue-concept-cards.md",
    "help/terminal-confidence-guide.md",
    "reviewer/tester-feedback-report.md",
    "reviewer/tester-handoff-messages.md",
    "reviewer/public-alpha-readiness-report.md",
    "reviewer/alpha-focus-lock.md",
    "reviewer/canon-candidate-backlog-report.md",
    "reviewer/alpha-package-final-qa.md",
    "reviewer/human-ai-readability-audit.md",
    "reviewer/inherited-warning-burndown-report.md",
    "reviewer/ai-guardrail-evaluation.md",
    "reviewer/ai-guardrail-red-team-pack.md",
    "reviewer/ai-red-team-results-template.md"
  ];

  for (const relativePath of requiredPackageFiles) {
    if (!fs.existsSync(path.join(packagedDemoDir, relativePath))) {
      errors.push(`output/share/developer-atlas-mvp-demo/${relativePath}: missing required packaged file`);
    }
  }

  const forbiddenRootEntries = [
    "README.md",
    "ai-prompt-pack.md",
    "canon",
    "feedback",
    "site",
    "demo",
    "reports",
    "flow",
    "walkthrough",
    "advisors",
    "beginner-orientation.md",
    "vue-concept-cards.md",
    "terminal-confidence-guide.md"
  ];

  for (const relativePath of forbiddenRootEntries) {
    if (fs.existsSync(path.join(packagedDemoDir, relativePath))) {
      errors.push(`output/share/developer-atlas-mvp-demo/${relativePath}: should not be in the learner-first package root`);
    }
  }

  const expectedRootEntries = new Set([
    "START_HERE.md",
    "first-time-quick-start.md",
    "mission-dashboard.html",
    "package-manifest.json",
    "mission",
    "help",
    "ai",
    "reference",
    "reviewer"
  ]);
  const actualRootEntries = fs.readdirSync(packagedDemoDir);
  for (const entry of actualRootEntries) {
    if (!expectedRootEntries.has(entry)) {
      errors.push(`output/share/developer-atlas-mvp-demo/${entry}: unexpected root entry`);
    }
  }
  for (const entry of expectedRootEntries) {
    if (!actualRootEntries.includes(entry)) {
      errors.push(`output/share/developer-atlas-mvp-demo/${entry}: missing learner-first root entry`);
    }
  }

  const expectedHelpFiles = new Set([
    "beginner-orientation.md",
    "vue-concept-cards.md",
    "terminal-confidence-guide.md"
  ]);
  const packagedHelpDir = path.join(packagedDemoDir, "help");
  if (fs.existsSync(packagedHelpDir)) {
    const actualHelpFiles = fs
      .readdirSync(packagedHelpDir)
      .filter((entry) => entry.endsWith(".md"));
    for (const helpFile of actualHelpFiles) {
      if (!expectedHelpFiles.has(helpFile)) {
        errors.push(`output/share/developer-atlas-mvp-demo/help/${helpFile}: unexpected learner-facing support guide`);
      }
    }
  }

  if (!fs.existsSync(packagedFirstTimeQuickStartPath)) {
    errors.push("output/share/developer-atlas-mvp-demo/first-time-quick-start.md: missing root quick-start file");
  }

  if (!fs.existsSync(packagedHardenedCanonDir)) {
    errors.push("output/share/developer-atlas-mvp-demo/reference/canon/hardened: missing hardened Canon folder");
  }

  const manifestPath = path.join(packagedDemoDir, "package-manifest.json");
  if (!fs.existsSync(manifestPath)) {
    errors.push("output/share/developer-atlas-mvp-demo/package-manifest.json: missing package manifest");
  } else {
    const manifest = parseJson(manifestPath, "output/share/developer-atlas-mvp-demo/package-manifest.json", errors);
    if (manifest && !/Primary package entries and directory groups/i.test(manifest.manifest_scope || "")) {
      errors.push("output/share/developer-atlas-mvp-demo/package-manifest.json: missing manifest scope clarification");
    }
    if (manifest) {
      const manifestText = JSON.stringify(manifest);
      for (const requiredEntry of ["mission-dashboard.html", "first-time-quick-start.md", "START_HERE.md", "mission/", "help/", "ai/", "reference/", "reviewer/"]) {
        if (!manifestText.includes(requiredEntry)) {
          errors.push(`output/share/developer-atlas-mvp-demo/package-manifest.json: missing manifest entry ${requiredEntry}`);
        }
      }
      const manifestEntries = Array.isArray(manifest.files_included) ? manifest.files_included : [];
      for (const forbiddenEntry of ["README.md", "ai-prompt-pack.md", "canon/hardened", "feedback/"]) {
        if (manifestEntries.includes(forbiddenEntry)) {
          errors.push(`output/share/developer-atlas-mvp-demo/package-manifest.json: old package path still listed (${forbiddenEntry})`);
        }
      }
    }
  }
}

function validatePublicAlphaScopeNotExpanded(errors) {
  const learnerMissionFiles = [
    ["output/experience/today-mission-surface.md", missionSurfacePath],
    ["output/experience/today-mission-surface.vibe.md", vibeMissionSurfacePath],
    ["output/experience/mission-02-todoitem-surface.md", missionTwoSurfacePath],
    ["output/experience/mission-02-todoitem-surface.vibe.md", vibeMissionTwoSurfacePath],
    ["output/experience/mission-03-todostats-surface.md", missionThreeSurfacePath],
    ["output/experience/mission-03-todostats-surface.vibe.md", vibeMissionThreeSurfacePath],
    ["output/share/developer-atlas-mvp-demo/mission/today-mission-surface.md", path.join(packagedDemoDir, "mission", "today-mission-surface.md")],
    ["output/share/developer-atlas-mvp-demo/mission/today-mission-surface.vibe.md", path.join(packagedDemoDir, "mission", "today-mission-surface.vibe.md")],
    ["output/share/developer-atlas-mvp-demo/mission/mission-02-todoitem-surface.md", path.join(packagedDemoDir, "mission", "mission-02-todoitem-surface.md")],
    ["output/share/developer-atlas-mvp-demo/mission/mission-02-todoitem-surface.vibe.md", path.join(packagedDemoDir, "mission", "mission-02-todoitem-surface.vibe.md")],
    ["output/share/developer-atlas-mvp-demo/mission/mission-03-todostats-surface.md", packagedMissionThreeSurfacePath],
    ["output/share/developer-atlas-mvp-demo/mission/mission-03-todostats-surface.vibe.md", packagedVibeMissionThreeSurfacePath],
    ["output/share/developer-atlas-mvp-demo/START_HERE.md", packagedStartHerePath],
    ["output/share/developer-atlas-mvp-demo/ai/ai-prompt-pack.md", path.join(packagedDemoDir, "ai", "ai-prompt-pack.md")]
  ];

  for (const [label, filePath] of learnerMissionFiles) {
    if (!fs.existsSync(filePath)) continue;
    const text = fs.readFileSync(filePath, "utf8");
    if (phase93CandidateIdPattern.test(text)) {
      errors.push(`${label}: public alpha learner path references Phase 93 candidate backlog IDs`);
    }
  }
}

module.exports = {
  validatePackagedDemoStructure,
  validatePublicAlphaScopeNotExpanded
};
