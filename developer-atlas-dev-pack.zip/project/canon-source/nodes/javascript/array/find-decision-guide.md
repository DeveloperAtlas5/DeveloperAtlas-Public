# Array.prototype.find() Decision Guide

## Status Metadata

- Canon ID: CANON-010
- Node ID: canon.javascript.array.find-decision-guide
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript arrays
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `find()` when you need the first item in an array that matches a condition.

The decision is about first-match retrieval:

- `find()` returns one matching item or `undefined`.
- `filter()` returns all matching items.
- `some()` answers whether at least one match exists.
- `includes()` checks whether a known value exists.
- `reduce()` builds summaries, groups, or lookups.

## What Problem This Solves

Developers often use array methods that work but hide the real intent:

- `filter()[0]` when they need only the first match.
- `filter()` when duplicates matter and all matches should be shown.
- `some()` when the actual item is needed.
- Repeated `find()` calls when a lookup object or `Map` would be clearer and faster.

This node solves a daily JavaScript decision: choose `find()` when the desired result is one item from the array.

## Mental Model

Start with the result shape.

Think of `find()` as a search party that stops at the first match. Each item is inspected in order. When the callback returns a truthy value, `find()` returns that item and stops searching.

```js
const selectedUser = users.find((user) => user.id === selectedUserId);
```

The method contract is:

> I am looking for the first item that matches this condition.

| Desired result | Best fit |
| --- | --- |
| First matching item | `find()` |
| All matching items | `filter()` |
| Boolean: at least one match | `some()` |
| Known primitive/object reference exists | `includes()` |
| New array with transformed items | `map()` |
| One summary, group, lookup, or total | `reduce()` |

## Beginner Explanation

Use `find()` when you want one thing.

If you have users and want the user with ID `42`, use `find()`:

```js
const user = users.find((user) => user.id === 42);
```

If no user matches, the result is `undefined`.

Beginner rule:

1. If you want one matching item, use `find()`.
2. If you want every matching item, use `filter()`.
3. If you only need yes/no, use `some()` or `includes()`.
4. Always handle the case where no item is found.

## Professional Explanation

`Array.prototype.find()` returns the first element for which the predicate returns a truthy value. It visits array elements in order and stops once a match is found. If no element matches, it returns `undefined`.

In production code, `find()` is strongest for local, readable first-match lookup:

- selected records
- active route options
- first validation error
- matching configuration entry
- a single item from a small in-memory array

The key review question is not "Can this locate the value?" It is "Is first-match behavior the correct domain rule?"

If duplicate matches are meaningful, use `filter()`. If repeated key-based lookup happens in a loop or hot path, precompute a `Map` or lookup object. If the array contains primitive values and you already know the target value, `includes()` may express the intent better.

Sparse-array note: `find()` visits indexes in ascending order and follows the specification's array access behavior. For normal dense arrays, think of it as checking each item until the first match.

## Syntax

```js
const result = array.find((item, index, array) => {
  return isMatchingItem;
});
```

Common forms:

```js
const user = users.find((user) => user.id === targetId);
```

```js
const firstInvalidField = fields.find((field) => field.error);
```

Callback arguments:

| Argument | Meaning |
| --- | --- |
| `item` | The current array item |
| `index` | The current item index |
| `array` | The original array |
| callback return | Truthy returns the item and stops searching |

## Decision Guide

Ask these questions in order:

1. Do I need one matching item from the array?
   Use `find()`.
2. Do I need all matching items?
   Use `filter()`.
3. Do I only need to know whether any item matches?
   Use `some()`.
4. Do I already have the exact primitive value or object reference?
   Use `includes()`.
5. Do I need repeated lookup by ID, slug, or key?
   Build a `Map` or lookup object.
6. Do I need a grouped result, count, or summary?
   Use `reduce()`.
7. Is `undefined` a valid outcome?
   Handle it explicitly.

Use `find()` when the sentence sounds like:

- "Get the selected product."
- "Find the first invalid field."
- "Find the current route option."
- "Get the matching configuration entry."

Avoid it when the sentence sounds like:

- "Show all active users." Use `filter()`.
- "Check whether this role exists." Use `includes()` or `some()`.
- "Build a user lookup by ID." Use `reduce()`, `Object.fromEntries()`, or `Map`.

## Comparison Table

| Choice | Best For | Returns | Trade-Off |
| --- | --- | --- | --- |
| `find()` | First matching item | Item or `undefined` | Wrong when all matches matter |
| `filter()` | All matching items | New array | More work and wrong shape for one item |
| `some()` | Existence check by predicate | Boolean | Does not return the item |
| `includes()` | Known value/reference membership | Boolean | No predicate logic |
| `reduce()` | Lookup, grouping, summary | Any value | Too heavy for simple first match |
| `Map#get()` | Repeated key lookup | Value or `undefined` | Requires building the map |

## When To Use The Primary Option

Use `find()` when:

- The output should be one item.
- First match is the correct domain behavior.
- The array is local or small enough for a linear scan to be clear.
- The missing case can be represented as `undefined`.
- The predicate is easy to read.

```js
const selectedProduct = products.find((product) => product.slug === selectedSlug);
```

## When To Use The Alternative

Use `filter()` when all matches matter:

```js
const activeUsers = users.filter((user) => user.status === "active");
```

Use `some()` when you only need yes/no:

```js
const hasAdmin = users.some((user) => user.role === "admin");
```

Use `includes()` when checking a known value:

```js
const canEdit = user.permissions.includes("posts:edit");
```

Use a lookup for repeated key access:

```js
const productsBySlug = new Map(products.map((product) => [product.slug, product]));
const selectedProduct = productsBySlug.get(selectedSlug);
```

## When Not To Use This Decision

Do not use `find()` when:

- You need every matching item. Use `filter()`.
- You only need a boolean. Use `some()` or `includes()`.
- You need to transform item shape. Use `map()`.
- You need a grouped or indexed structure. Use `reduce()`, `Object.fromEntries()`, or `Map`.
- You are doing repeated lookup inside a loop.
- Duplicate matches are an error that should be detected explicitly.
- The missing case is not handled.

## Alternatives

### filter()

Use `filter()` for all matching items.

```js
const paidOrders = orders.filter((order) => order.status === "paid");
```

### some()

Use `some()` for yes/no predicate checks.

```js
const hasFailedJob = jobs.some((job) => job.status === "failed");
```

### includes()

Use `includes()` for known values.

```js
const isAllowed = allowedStatuses.includes(order.status);
```

### reduce()

Use `reduce()` for lookup objects or summaries.

```js
const usersById = users.reduce((lookup, user) => {
  lookup[user.id] = user;
  return lookup;
}, {});
```

### Map

Use `Map` for repeated key-based lookup.

```js
const usersById = new Map(users.map((user) => [user.id, user]));
```

## Production Examples

### Selected Product By Slug

```js
const selectedProduct = products.find((product) => product.slug === route.params.slug);

if (!selectedProduct) {
  throw new Error("Product not found");
}
```

Why `find()` fits: the route should resolve to one product, and the missing case is handled.

### First Invalid Form Field

```js
const firstInvalidField = fields.find((field) => field.errorMessage);

if (firstInvalidField) {
  focusField(firstInvalidField.name);
}
```

Why `find()` fits: the UI only needs the first field that should receive attention.

### Matching Feature Flag

```js
const checkoutFlag = featureFlags.find((flag) => flag.key === "checkout_v2");
const checkoutEnabled = checkoutFlag?.enabled === true;
```

Why `find()` fits: the code needs one configuration entry and handles the missing flag.

### Repeated Lookup Refactor

```js
const productsById = new Map(products.map((product) => [product.id, product]));

const orderRows = orders.map((order) => ({
  id: order.id,
  productName: productsById.get(order.productId)?.name ?? "Unknown product"
}));
```

Why `Map` fits better: repeated `find()` inside `map()` would rescan the products array for every order.

## Common Mistakes

- Forgetting that `find()` can return `undefined`.
- Using `filter()[0]` instead of `find()`.
- Expecting `find()` to return every match.
- Using `find()` for boolean checks instead of `some()` or `includes()`.
- Repeating `find()` inside loops for key-based lookup.
- Ignoring duplicate matches when duplicates should be impossible.
- Using a broad predicate that returns the wrong first match.

```js
// Mistake: selectedUser may be undefined
const selectedUser = users.find((user) => user.id === selectedId);
console.log(selectedUser.name);
```

```js
// Better
const selectedUser = users.find((user) => user.id === selectedId);
if (!selectedUser) {
  throw new Error("User not found");
}
console.log(selectedUser.name);
```

```js
// Mistake: wrong result shape for one item
const selectedProduct = products.filter((product) => product.slug === slug)[0];
```

```js
// Better
const selectedProduct = products.find((product) => product.slug === slug);
```

## Debugging Checklist

- If the result is `undefined`, is the predicate correct?
- If the wrong item is returned, are there earlier matching items?
- If all matches are needed, should this be `filter()`?
- If only yes/no is needed, should this be `some()` or `includes()`?
- If lookup is repeated, should the array be indexed first?
- If a property read crashes, did you handle the missing case?
- If IDs do not match, are you comparing the same type, such as string versus number?
- If duplicates are invalid, should you validate uniqueness before calling `find()`?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-010/`.

Verification command:

```sh
npm run canon:verify:010
```

The verification suite checks:

- Finding a user by ID.
- Finding a product by slug.
- The anti-pattern of using `filter()[0]` instead of `find()`.
- The anti-pattern of expecting `find()` to return all matches.

## Performance Notes

`find()` stops when it finds the first match, so it can avoid scanning the rest of the array. That is useful when first-match behavior is correct.

For repeated key-based lookup, `find()` can become inefficient because it rescans the array each time. Build a `Map`, lookup object, or indexed data structure when repeated lookup is part of the workflow.

Choose clarity first for small local arrays. Reach for indexing when repeated lookup, large data sets, or profiling justify it.

## AI Coding Guidance

When generating code:

- Use `find()` only when the result should be one matching item.
- Always handle the possible `undefined` result.
- Prefer `filter()` when all matches should be returned.
- Prefer `some()` when only a boolean answer is needed.
- Prefer `includes()` when checking a known primitive value or object reference.
- Prefer `Map` or lookup objects for repeated key-based lookup.
- Do not generate `filter()[0]` for first-match retrieval.
- Explain the choice using output shape: "one item or undefined."

Bad AI output:

```js
const selectedUser = users.filter((user) => user.id === selectedId)[0];
```

Good AI output:

```js
const selectedUser = users.find((user) => user.id === selectedId);
if (!selectedUser) {
  throw new Error("User not found");
}
```

## Teaching Notes

Teach `find()` as a result-shape decision:

1. Start with "first matching item."
2. Show the `undefined` missing case.
3. Compare with `filter()` for all matches.
4. Compare with `some()` for yes/no.
5. Compare with `includes()` for known values.
6. End with repeated lookup and why `Map` can be better.

Useful teaching phrase:

> `find()` gives you one item, not a list.

## Interview Questions

1. What does `find()` return when nothing matches?
2. How is `find()` different from `filter()`?
3. How is `find()` different from `some()`?
4. When is `includes()` clearer than `find()`?
5. Why is `filter()[0]` usually weaker than `find()`?
6. When would repeated `find()` calls become a problem?
7. How would you find the first invalid form field?
8. How should you handle duplicate matches?

## Exercises

### Beginner

Find a user by ID and handle the missing-user case.

### Intermediate

Find a product by slug from route data, then show a fallback when it is missing.

### Advanced

Refactor code that calls `find()` inside a loop into a `Map`-based lookup, and explain the readability and performance trade-off.

## Related Atlas Nodes

- `javascript.array.find`
- `javascript.array.filter`
- `javascript.array.some`
- `javascript.array.includes`
- `javascript.array.map`
- `javascript.array.reduce`
- `javascript.object.keys`

## Evidence And Sources

- MDN Web Docs: Array.prototype.find(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/find
- ECMAScript specification: Array.prototype.find: https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array.prototype.find

## Proof Of Superiority Summary

Official references explain how `find()` executes. This Canon node explains when to choose it, when to reject it, how to handle `undefined`, how it compares with `filter()`, `some()`, `includes()`, and `reduce()`, what production first-match retrieval looks like, and how AI assistants should generate safe lookup code.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
