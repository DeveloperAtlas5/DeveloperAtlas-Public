# Welcome back

Today is one small, useful mission. No full roadmap. No extra systems to inspect. Just make the next visible improvement.

## Today's Mission

Make your Vue todo app remember tasks after refresh.

## Why this matters

A real app should not forget everything when the page reloads. Browser storage is a small but important step toward making the app feel real.

- `localStorage` is useful for non-sensitive data that should survive refresh and browser restart.
- `sessionStorage` can survive refresh, but it is scoped to the current tab/session.
- Neither should be used for sensitive data.
- Vue state controls what is visible now.
- Browser storage controls what can be restored later.

## Where this work happens

Work in your Vue todo project.

Use this mission file as the guide.

Do not edit the Atlas package files.

## Quick Start

1. Open your Vue project.
2. Open `src/App.vue`.
3. Find where your todo list state is created.
4. Add loading from `localStorage` when the app starts.
5. Add saving to `localStorage` when todos change.
6. Run `npm run dev`.
7. Add a todo, refresh the page, and confirm the todo is still there.

## Estimated time

45-60 minutes

## Difficulty

Guided

## Start here

Optional help: `help/vue-concept-cards.md` for Vue words like `ref()`, `v-for`, or `:key`.

Open help files only when a word or step feels unclear.

1. Find where your todos are stored in Vue state.
2. Load saved todos when the app starts.
3. Save todos to `localStorage` when they change.
4. Refresh the page.
5. Confirm the todos are still visible.
6. Check the browser console for errors.

## Where this change belongs

Optional help: `help/beginner-orientation.md` if you are unsure where your Vue files live.

Optional help: `help/terminal-confidence-guide.md` if `npm install` or `npm run dev` feels unclear.

In a small Vue todo app, this change usually belongs near the todo list state. If your todos are created in `App.vue`, start there.

The code changes belong in your todo app, usually in `src/App.vue` for this mission.

- Load saved todos when the app starts.
- Save todos where todos change, such as add, edit, complete, or delete actions.
- If the app already has a todo component or composable, place the storage logic near the existing todo state.
- This mission usually does not require router, backend, database, auth, deployment, or build config changes.

## Check your result

- You can add a todo.
- You can refresh the page.
- The todo is still visible.
- Completed states still work if the app supports them.
- There are no console errors.

Visible win: You can refresh the page and your non-sensitive todo tasks are still there.

## Completion checklist

- [ ] I can add a todo.
- [ ] I can refresh the page.
- [ ] The todo is still visible after refresh.
- [ ] Completed todo state still works if my app supports it.
- [ ] I do not see browser console errors.
- [ ] I understand why `localStorage` fits this mission better than `sessionStorage`.
- [ ] I did not add backend, login, database, routing, or deployment changes.

## If you get stuck

- Todos disappear after refresh: confirm you load saved todos when the app starts and save again after each todo change.
- `[object Object]` appears: save arrays and objects with `JSON.stringify()` before putting them in storage.
- JSON parse error: clear the old saved value, then load with a safe fallback like an empty array.
- Storage choice mismatch: use `localStorage` for non-sensitive todos that should survive browser restart; use `sessionStorage` only for tab-scoped temporary drafts.
- Key mismatch: make sure the key you save with is the same key you load with.
- Sensitive data by mistake: remove it from storage and do not store secrets, passwords, tokens, or private personal information in browser storage.

## Ask AI for help

Copy and paste this prompt:

```txt
I am building a Vue 3 todo app. Today's mission is to make todos persist after refresh using localStorage. Please help me debug one step at a time. Do not add backend, auth, Pinia, routing, database, or advanced architecture.
```

## Skip today

- Backend
- Login/auth
- Database
- Cloud sync
- Pinia
- Routing
- Encryption/security architecture
- Deployment

## Next mission preview

After this, you can learn how to extract the todo item into a reusable component.

## After the mission

Before you started, how confident did you feel?

1 2 3 4 5

After finishing or stopping, how confident do you feel now?

1 2 3 4 5

Did you complete the visible win?

- Yes
- Partly
- Not yet

Did Atlas help you recover from a blocker?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.
