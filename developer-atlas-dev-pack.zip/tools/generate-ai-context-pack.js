const fs = require("fs");
const path = require("path");
const { readEntries, compareEntries, rootDir } = require("./content-utils");
const { buildGraph, recommendationCompleteness } = require("./graph-utils");
const { readGoals } = require("./goal-utils");
const { readTools } = require("./toolkit-utils");
const {
  aiContextOutputDir,
  ensureAiContextOutputDir,
  readAiContextRequests,
  readJsonIfExists,
  unique
} = require("./ai-context-utils");

const outputDir = path.join(rootDir, "output", "ai");
const outputPath = path.join(outputDir, "atlas-context-pack.json");

function pick(data, fields) {
  const output = {};
  for (const field of fields) output[field] = data[field] ?? null;
  return output;
}

function main() {
  if (process.argv.includes("--assistant-packs")) {
    generateAssistantContextPacks();
    return;
  }

  const entries = readEntries().sort(compareEntries);
  const graph = buildGraph(entries);
  const nodes = entries.map((entry) => entry.frontMatter);

  const knowledge = nodes.map((data) => ({
    ...pick(data, [
      "id",
      "title",
      "technology",
      "category",
      "type",
      "difficulty",
      "importance",
      "frequency",
      "confidence",
      "evidence_level",
      "summary",
      "problem",
      "solution",
      "syntax",
      "when_to_use",
      "when_not_to_use",
      "common_mistakes",
      "best_practices",
      "sources"
    ]),
    recommendation_score: recommendationCompleteness(data).score
  }));

  const contextPack = {
    generated_at: new Date().toISOString(),
    knowledge,
    relationships: graph.edges,
    recommendations: nodes.map((data) => ({
      id: data.id,
      recommended_for: data.recommended_for ?? [],
      avoid_for: data.avoid_for ?? [],
      best_alternative: data.best_alternative ?? null,
      tradeoffs: data.tradeoffs ?? [],
      industry_usage: data.industry_usage ?? null,
      beginner_score: data.beginner_score ?? null,
      professional_score: data.professional_score ?? null,
      interview_score: data.interview_score ?? null,
      production_score: data.production_score ?? null,
      learning_priority: data.learning_priority ?? null
    })),
    comparisons: nodes.filter((data) => data.type === "comparison"),
    decision_trees: nodes.filter((data) => data.type === "decision_guide"),
    recipes: nodes.filter((data) => data.type === "recipe"),
    problems: nodes.filter((data) => data.type === "problem"),
    learning_paths: nodes.filter((data) => data.type === "learning_path")
  };

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${JSON.stringify(contextPack, null, 2)}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)}.`);
}

function generateAssistantContextPacks() {
  const requests = readAiContextRequests().map((record) => record.request);
  const context = readAssistantContext();
  const packs = requests.map((request) => buildAssistantPack(request, context));

  ensureAiContextOutputDir();
  for (const pack of packs) {
    fs.writeFileSync(
      path.join(aiContextOutputDir, `${pack.request_id}.json`),
      `${JSON.stringify(pack, null, 2)}\n`
    );
    fs.writeFileSync(
      path.join(aiContextOutputDir, `${pack.request_id}.md`),
      assistantPackToMarkdown(pack)
    );
  }

  const report = buildAssistantContextReport(packs);
  fs.writeFileSync(
    path.join(aiContextOutputDir, "ai-context-report.md"),
    contextReportToMarkdown(report)
  );

  console.log(`Generated ${packs.length} AI context pack(s).`);
  console.log("Generated output/ai-context/ai-context-report.md.");
}

function readAssistantContext() {
  return {
    goalsById: new Map(readGoals().map((record) => [record.goal.goal_id, record.goal])),
    readinessReport: readJsonIfExists(path.join(rootDir, "output", "readiness", "readiness-report.json"), { reports: [] }),
    readinessDetails: readReadinessDetails(),
    capabilityPathway: readJsonIfExists(path.join(rootDir, "output", "capability", "capability-pathway.json"), { weeks: [] }),
    explainabilityReport: readJsonIfExists(path.join(rootDir, "output", "explainability", "explainability-report.json"), {}),
    whyRoadmap: readJsonIfExists(path.join(rootDir, "output", "explainability", "why-this-roadmap.json"), {}),
    setupReportText: readTextIfExists(path.join(rootDir, "output", "setup-advisor", "setup-advisor-report.md")),
    recoveryReportText: readTextIfExists(path.join(rootDir, "output", "recovery-advisor", "recovery-advisor-report.md")),
    toolkitIndex: readJsonIfExists(path.join(rootDir, "output", "toolkit", "toolkit-index.json"), { tools: [] }),
    hardwareReport: readJsonIfExists(path.join(rootDir, "output", "hardware", "hardware-index.json"), { hardware_nodes: [] }),
    learnerProfiles: readLearnerProfiles()
  };
}

function readReadinessDetails() {
  const dir = path.join(rootDir, "output", "readiness");
  const details = new Map();
  if (!fs.existsSync(dir)) return details;

  for (const fileName of fs.readdirSync(dir).filter((name) => name.endsWith(".json") && !name.includes("report"))) {
    const report = JSON.parse(fs.readFileSync(path.join(dir, fileName), "utf8"));
    if (report.profile_summary?.readiness_id) details.set(report.profile_summary.readiness_id, report);
  }
  return details;
}

function readLearnerProfiles() {
  const dir = path.join(rootDir, "learning", "profiles");
  const profiles = new Map();
  if (!fs.existsSync(dir)) return profiles;

  for (const fileName of fs.readdirSync(dir).filter((name) => name.endsWith(".json"))) {
    const profile = JSON.parse(fs.readFileSync(path.join(dir, fileName), "utf8"));
    profiles.set(profile.profile_id, profile);
  }
  return profiles;
}

function buildAssistantPack(request, context) {
  const profile = context.learnerProfiles.get(request.profile_id);
  const readiness = bestReadinessForRequest(request, context);
  const readinessDetail = context.readinessDetails.get(readiness?.readiness_id);
  const pathwayWeeks = relevantPathwayWeeks(request, context);
  const roadmapJustifications = relevantRoadmapJustifications(request, context);
  const toolingConstraints = toolingConstraintsFor(readinessDetail, context);
  const hardwareConstraints = hardwareConstraintsFor(readinessDetail, context);
  const nextSteps = nextStepsFor(request, readinessDetail, pathwayWeeks);
  const shortestPath = shortestPathFor(request, context, pathwayWeeks);

  const pack = {
    request_id: request.request_id,
    generated_at: new Date().toISOString(),
    ai_role_instruction: `Act as a ${request.desired_ai_role}. Use Atlas context first, stay vendor-neutral, and help with the next practical step.`,
    user_goal_summary: summarizeGoals(request.goals, context),
    current_readiness: {
      readiness_id: readiness?.readiness_id || "unknown",
      score: readiness?.score || readinessDetail?.readiness_score || 0,
      status: readiness?.status || readinessDetail?.readiness_status || "unknown",
      weakest_areas: readiness?.weakest_areas || readinessDetail?.weakest_areas || [],
      strongest_areas: readiness?.strongest_areas || readinessDetail?.strongest_areas || []
    },
    current_task: request.current_task,
    known_knowledge: profile?.known_nodes || [],
    missing_knowledge: unique([
      ...(readinessDetail?.missing_knowledge || []),
      ...pathwayWeeks.flatMap((week) => week.required_knowledge || [])
    ]).slice(0, 12),
    hardware_tooling_constraints: unique([
      ...request.known_constraints,
      ...toolingConstraints,
      ...hardwareConstraints
    ]).slice(0, 12),
    what_to_help_with_now: helpNowFor(request, pathwayWeeks, roadmapJustifications),
    what_not_to_overcomplicate: whatNotToOvercomplicate(request, readinessDetail, context),
    shortest_acceptable_path: shortestPath,
    next_3_steps: nextSteps,
    clarification_rules: clarificationRulesFor(request),
    preferred_explanation_style: `${request.preferred_tone}; learner level: ${request.learner_level}`,
    estimated_length: 0
  };

  pack.estimated_length = assistantPackToMarkdown(pack).length;
  return trimPackToLength(pack, request.max_length);
}

function bestReadinessForRequest(request, context) {
  const goalText = request.goals.join(" ");
  return [...(context.readinessReport.reports || [])].sort((a, b) => {
    const aScore = readinessMatchScore(a, goalText);
    const bScore = readinessMatchScore(b, goalText);
    return bScore - aScore || b.score - a.score;
  })[0];
}

function readinessMatchScore(readiness, goalText) {
  const text = `${readiness.readiness_id} ${(readiness.weakest_areas || []).join(" ")}`.toLowerCase();
  return goalText.toLowerCase().split(/[\W_]+/).filter((word) => word.length > 3 && text.includes(word)).length * 10 + readiness.score;
}

function relevantPathwayWeeks(request, context) {
  const weeks = context.capabilityPathway.weeks || [];
  const taskText = `${request.current_task} ${request.goals.join(" ")}`.toLowerCase();
  const matches = weeks.filter((week) => {
    const text = `${week.project?.title || ""} ${(week.required_knowledge || []).join(" ")} ${(week.friction_risks || []).join(" ")}`.toLowerCase();
    return taskText.split(/[\W_]+/).some((word) => word.length > 4 && text.includes(word));
  });
  return matches.length ? matches : weeks.slice(0, 2);
}

function relevantRoadmapJustifications(request, context) {
  const justifications = context.whyRoadmap.roadmap_justifications || [];
  const taskText = `${request.current_task} ${request.goals.join(" ")}`.toLowerCase();
  return justifications.filter((item) => {
    const text = `${item.project} ${(item.supports_goals || []).join(" ")} ${(item.what_depends_on_it || []).join(" ")}`.toLowerCase();
    return taskText.split(/[\W_]+/).some((word) => word.length > 4 && text.includes(word));
  }).slice(0, 3);
}

function summarizeGoals(goalIds, context) {
  return goalIds.map((goalId) => {
    const goal = context.goalsById.get(goalId);
    return goal ? `${goal.title} (${goal.category})` : goalId;
  }).join("; ");
}

function toolingConstraintsFor(readinessDetail, context) {
  const toolNames = new Map((context.toolkitIndex.tools || []).map((tool) => [tool.id, tool.name || tool.id]));
  return (readinessDetail?.tooling_gaps || []).map((tool) => `Tooling gap: ${toolNames.get(tool) || tool}`);
}

function hardwareConstraintsFor(readinessDetail) {
  return readinessDetail?.hardware_concerns || [];
}

function helpNowFor(request, pathwayWeeks, roadmapJustifications) {
  const help = [`Help with current task: ${request.current_task}`];
  for (const week of pathwayWeeks.slice(0, 2)) help.push(`Keep project scope near: ${week.project.title}`);
  for (const item of roadmapJustifications.slice(0, 2)) help.push(`Explain why: ${item.why_this_project}`);
  return unique(help).slice(0, 6);
}

function whatNotToOvercomplicate(request, readinessDetail, context) {
  const avoid = [...request.known_constraints];
  avoid.push(...(readinessDetail?.what_to_skip_for_now || []));
  avoid.push(...(context.whyRoadmap.safe_to_defer || []).map((item) => item.recommendation));
  if (request.learner_level === "rookie") avoid.push("Do not introduce advanced architecture until the smallest project works.");
  return unique(avoid).slice(0, 8);
}

function shortestPathFor(request, context, pathwayWeeks) {
  const roadmapPaths = context.whyRoadmap.shortest_acceptable_path || [];
  const relevant = roadmapPaths.filter((pathText) => {
    const text = `${request.current_task} ${pathwayWeeks.map((week) => week.project.title).join(" ")}`.toLowerCase();
    return text.split(/[\W_]+/).some((word) => word.length > 4 && pathText.toLowerCase().includes(word));
  });

  return (relevant.length ? relevant : roadmapPaths).slice(0, 4);
}

function nextStepsFor(request, readinessDetail, pathwayWeeks) {
  const steps = [
    ...(readinessDetail?.recommended_next_3_steps || []),
    ...pathwayWeeks.flatMap((week) => week.prep_tasks || [])
  ];
  if (!steps.length) steps.push(`Start with: ${request.current_task}`);
  return unique(steps).slice(0, 3);
}

function clarificationRulesFor(request) {
  const rules = [
    "Ask clarifying questions only when the next action depends on missing facts.",
    "If setup or commands fail, ask for OS, versions, exact command, and exact error.",
    "If the request grows in scope, suggest the smallest finishable version first."
  ];
  if (request.include_sections.includes("hardware")) {
    rules.push("Before hardware advice, ask for CPU, RAM, GPU/VRAM, storage, OS, and workload.");
  }
  return rules;
}

function trimPackToLength(pack, maxLength) {
  let current = { ...pack };
  while (assistantPackToMarkdown(current).length > maxLength && current.missing_knowledge.length > 6) {
    current.missing_knowledge = current.missing_knowledge.slice(0, -1);
  }
  while (assistantPackToMarkdown(current).length > maxLength && current.hardware_tooling_constraints.length > 5) {
    current.hardware_tooling_constraints = current.hardware_tooling_constraints.slice(0, -1);
  }
  while (assistantPackToMarkdown(current).length > maxLength && current.what_not_to_overcomplicate.length > 4) {
    current.what_not_to_overcomplicate = current.what_not_to_overcomplicate.slice(0, -1);
  }
  while (assistantPackToMarkdown(current).length > maxLength && current.what_to_help_with_now.length > 3) {
    current.what_to_help_with_now = current.what_to_help_with_now.slice(0, -1);
  }
  while (assistantPackToMarkdown(current).length > maxLength && current.shortest_acceptable_path.length > 2) {
    current.shortest_acceptable_path = current.shortest_acceptable_path.slice(0, -1);
  }
  while (assistantPackToMarkdown(current).length > maxLength && current.clarification_rules.length > 2) {
    current.clarification_rules = current.clarification_rules.slice(0, -1);
  }
  if (assistantPackToMarkdown(current).length > maxLength) {
    current.known_knowledge = current.known_knowledge.slice(0, 3);
    current.missing_knowledge = current.missing_knowledge.slice(0, 4);
    current.hardware_tooling_constraints = current.hardware_tooling_constraints.slice(0, 3);
    current.what_to_help_with_now = current.what_to_help_with_now.slice(0, 2);
    current.what_not_to_overcomplicate = current.what_not_to_overcomplicate.slice(0, 2);
    current.shortest_acceptable_path = current.shortest_acceptable_path.slice(0, 1);
    current.next_3_steps = current.next_3_steps.slice(0, 3);
    current.clarification_rules = current.clarification_rules.slice(0, 2);
  }
  if (assistantPackToMarkdown(current).length > maxLength) {
    current.ai_role_instruction = truncateText(current.ai_role_instruction, 180);
    current.user_goal_summary = truncateText(current.user_goal_summary, 180);
    current.current_task = truncateText(current.current_task, 180);
    current.preferred_explanation_style = truncateText(current.preferred_explanation_style, 120);
  }
  if (assistantPackToMarkdown(current).length > maxLength) {
    current.missing_knowledge = current.missing_knowledge.slice(0, 3);
    current.hardware_tooling_constraints = current.hardware_tooling_constraints.slice(0, 2);
    current.what_to_help_with_now = current.what_to_help_with_now.slice(0, 1);
    current.what_not_to_overcomplicate = current.what_not_to_overcomplicate.slice(0, 1);
    current.next_3_steps = current.next_3_steps.slice(0, 2);
    current.ai_role_instruction = truncateText(current.ai_role_instruction, 140);
    current.user_goal_summary = truncateText(current.user_goal_summary, 140);
    current.current_task = truncateText(current.current_task, 140);
  }
  current.estimated_length = assistantPackToMarkdown(current).length;
  return current;
}

function buildAssistantContextReport(packs) {
  const sortedByLength = [...packs].sort((a, b) => a.estimated_length - b.estimated_length);
  const sortedByCompleteness = [...packs].sort((a, b) => completenessScore(b) - completenessScore(a));
  return {
    packs_generated: packs.length,
    shortest_pack: sortedByLength[0],
    most_complete_pack: sortedByCompleteness[0],
    generated_files: packs.flatMap((pack) => [
      `output/ai-context/${pack.request_id}.json`,
      `output/ai-context/${pack.request_id}.md`
    ])
  };
}

function completenessScore(pack) {
  return [
    pack.known_knowledge.length,
    pack.missing_knowledge.length,
    pack.hardware_tooling_constraints.length,
    pack.what_to_help_with_now.length,
    pack.what_not_to_overcomplicate.length,
    pack.shortest_acceptable_path.length,
    pack.next_3_steps.length
  ].reduce((total, value) => total + value, 0);
}

function assistantPackToMarkdown(pack) {
  const lines = [
    `# Atlas AI Context Pack: ${pack.request_id}`,
    `AI role: ${pack.ai_role_instruction}`,
    `Goals: ${pack.user_goal_summary}`,
    `Readiness: ${pack.current_readiness.status}; keep the next step small and guided.`,
    `Current task: ${humanizeText(pack.current_task)}`,
    `Known knowledge: ${friendlyInlineList(pack.known_knowledge)}`,
    `Missing knowledge: ${friendlyInlineList(pack.missing_knowledge)}`,
    `Hardware/tooling constraints: ${friendlyTextList(pack.hardware_tooling_constraints)}`,
    `Help with now: ${friendlyTextList(pack.what_to_help_with_now)}`,
    `Do not overcomplicate: ${friendlyTextList(pack.what_not_to_overcomplicate)}`,
    `Shortest acceptable path: ${friendlyTextList(pack.shortest_acceptable_path)}`,
    `Next 3 steps: ${friendlyTextList(pack.next_3_steps)}`,
    `Clarification rules: ${inlineList(pack.clarification_rules)}`,
    `Preferred explanation style: ${pack.preferred_explanation_style}`
  ];

  return `${lines.join("\n")}\n`;
}

function contextReportToMarkdown(report) {
  return [
    "# Atlas AI Context Report",
    "",
    `Context packs generated: ${report.packs_generated}`,
    "",
    "## Shortest Pack",
    "",
    report.shortest_pack ? `- ${report.shortest_pack.request_id}: ${report.shortest_pack.estimated_length} characters` : "- None",
    "",
    "## Most Complete Pack",
    "",
    report.most_complete_pack ? `- ${report.most_complete_pack.request_id}: ${completenessScore(report.most_complete_pack)} context points` : "- None",
    "",
    "## Generated Files",
    "",
    ...formatList(report.generated_files)
  ].join("\n") + "\n";
}

function formatList(items) {
  return items?.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function inlineList(items) {
  return items?.length ? items.join("; ") : "None";
}

function friendlyInlineList(items) {
  return inlineList((items || []).map(friendlyKnowledge));
}

function friendlyTextList(items) {
  return inlineList((items || []).map(humanizeText));
}

function humanizeText(value) {
  if (!value) return value;
  const replacements = {
    "javascript.array.filter": "JavaScript array filtering",
    "javascript.function.fetch": "fetching data with JavaScript",
    "vue.reactivity.ref": "Vue ref() state",
    "vue.reactivity.reactive": "Vue reactive() state",
    "extension.vue-official": "the Vue Official editor extension",
    "friction.javascript.npm.install_fails": "npm install problems",
    "friction.javascript.vite.not_starting": "Vite dev server problems"
  };
  return Object.entries(replacements).reduce(
    (text, [from, to]) => text.replaceAll(from, to),
    value
  );
}

function friendlyKnowledge(id) {
  const labels = {
    "CANON-003": "Vue reactivity: choosing simple state",
    "CANON-007": "Vue conditional display",
    "CANON-009": "Filtering visible items",
    "CANON-013": "Stable keys for list rows",
    "CANON-022": "Browser storage: localStorage vs sessionStorage",
    "CANON-025": "Component communication: props, emits, and model"
  };
  return labels[id] || id;
}

function readTextIfExists(file) {
  return fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
}

function truncateText(value, maxLength) {
  if (!value || value.length <= maxLength) return value;
  return `${value.slice(0, maxLength - 3).trim()}...`;
}

main();
