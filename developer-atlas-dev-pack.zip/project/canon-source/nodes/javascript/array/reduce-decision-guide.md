# Array.prototype.reduce() Decision Guide

## Status Metadata

- Canon ID: CANON-002
- Node ID: canon.javascript.array.reduce-decision-guide
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript arrays
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `reduce()` when an array should be collapsed into one final value: a number, object, map, grouped collection, lookup table, or combined result.

Do not use `reduce()` just because it is powerful. Use it when the accumulator has a clear name, a stable shape, and a final result that is easier to understand than a loop or a chain of simpler array methods.

## What Problem This Solves

Developers often learn `reduce()` as "the hard array method." That creates two problems:

- They avoid it when it is the cleanest tool for aggregation.
- They overuse it for clever one-liners that hide intent.

This node solves a daily JavaScript decision:

- Use `reduce()` for many-to-one accumulation.
- Use `map()` for one output per input.
- Use `filter()` for keeping some items.
- Use `forEach()` for side effects.
- Use `for...of` when step-by-step control is clearer.

## Mental Model

Start with the final answer, then choose the loop.

Think of `reduce()` as a running notebook passed from item to item. Each array item gets one chance to update the notebook. At the end, the notebook is the result.

- The notebook is the accumulator.
- The first page is the `initialValue`.
- Each callback returns the updated notebook.
- The final notebook is the value returned by `reduce()`.

The method contract is:

> I am turning many items into one result by carrying an accumulator through the list.

| Desired result | Best fit |
| --- | --- |
| One number, object, map, group, or lookup | `reduce()` |
| New array with same length | `map()` |
| New array with fewer items | `filter()` |
| Side effect for each item | `forEach()` |
| First matching item | `find()` |
| Yes/no answer | `some()` or `every()` |
| Early exit, `break`, `continue`, or sequential `await` | `for...of` |

## Beginner Explanation

`reduce()` keeps a running answer.

If you want the total price of a cart, the running answer starts at `0`. Each item adds its price. After the last item, the running answer is the total.

```js
const total = cart.reduce((sum, item) => {
  return sum + item.price;
}, 0);
```

Read it as:

1. Start with `sum = 0`.
2. Visit each item.
3. Return the next value of `sum`.
4. After the array ends, return the final `sum`.

The most important beginner rule:

> If you cannot clearly name the accumulator, pause before using `reduce()`.

Good accumulator names include `total`, `groups`, `lookup`, `counts`, `result`, and `byId`. Weak names like `acc`, `x`, or `obj` can be fine in tiny examples, but they are often a warning sign in production code.

## Professional Explanation

`Array.prototype.reduce()` executes a reducer callback for each visited element and returns a single accumulated value. The accumulator may be any type: primitive, object, array, `Map`, or domain-specific structure.

In professional code, `reduce()` is strongest when it expresses a stable accumulator invariant:

- `total` is always a number.
- `groups` is always an object keyed by status.
- `byId` is always a lookup object keyed by ID.
- `stats` is always an object with known counters.

The key review question is not "Can this be written with `reduce()`?" It is "Does `reduce()` make the accumulator and final result easier to reason about?"

Use an explicit `initialValue` by default. It makes empty arrays predictable, keeps accumulator type stable, and prevents the first array item from becoming the implicit accumulator. Omitting `initialValue` is only reasonable when the array is guaranteed non-empty and the first item is truly the correct starting accumulator.

Sparse-array note: `reduce()` skips empty slots in sparse arrays, like other callback-based array methods. This matters for arrays with holes such as `new Array(3)`, but it should not dominate everyday decision-making.

## Syntax

```js
const result = array.reduce((accumulator, item, index, array) => {
  return nextAccumulator;
}, initialValue);
```

Common forms:

```js
const total = numbers.reduce((sum, number) => sum + number, 0);
```

```js
const byId = users.reduce((lookup, user) => {
  lookup[user.id] = user;
  return lookup;
}, {});
```

Callback arguments:

| Argument | Meaning |
| --- | --- |
| `accumulator` | The running value returned from the previous callback |
| `item` | The current array item |
| `index` | The current item index |
| `array` | The original array |
| `initialValue` | The starting accumulator value |

## Decision Guide

Ask these questions in order:

1. Do many items become one final value?
   Use `reduce()`.
2. Is the final value an array with one output per input?
   Use `map()`.
3. Is the final value an array with only matching items?
   Use `filter()`.
4. Is the goal only to perform an action for each item?
   Use `forEach()`.
5. Do you need early exit, `break`, `continue`, or sequential `await`?
   Use `for...of`.
6. Is the reducer doing more than one job?
   Split the work into named steps or use a loop.
7. Is the accumulator hard to name?
   Do not use `reduce()` yet. Clarify the result shape first.

Use `reduce()` when the sentence sounds like:

- "Calculate the total."
- "Group these records."
- "Build a lookup."
- "Count occurrences."
- "Combine rows into one summary."

Avoid it when the sentence sounds like:

- "Change every item into another item." Use `map()`.
- "Keep only some items." Use `filter()`.
- "Log or send something for each item." Use `forEach()` or `for...of`.

## Comparison Table

| Choice | Best For | Returns | Trade-Off |
| --- | --- | --- | --- |
| `reduce()` | Many items into one result | Any value | Powerful, but can hide intent |
| `map()` | One transformed output per input | New array | Wrong for totals, groups, and side effects |
| `filter()` | Keeping matching items | New array | Wrong for transformation or aggregation alone |
| `forEach()` | Side effects | `undefined` | Not chainable and not for returned results |
| `for...of` | Explicit control flow | Whatever you build | More lines, often clearer for complex logic |
| `Object.fromEntries()` | Entries into object | Object | Requires key/value pairs first |

## When To Use The Primary Option

Use `reduce()` when:

- You need one final value.
- The accumulator has a clear type and purpose.
- You can provide a safe `initialValue`.
- Each callback step is small and predictable.
- The result would otherwise require external mutation.
- The operation is aggregation, grouping, counting, indexing, or summarizing.

Good examples:

```js
const totalCents = lineItems.reduce((sum, item) => {
  return sum + item.quantity * item.unitPriceCents;
}, 0);
```

```js
const ordersByStatus = orders.reduce((groups, order) => {
  groups[order.status] ??= [];
  groups[order.status].push(order);
  return groups;
}, {});
```

## When To Use The Alternative

Use `map()` when the output should have one item for each input:

```js
const names = users.map((user) => user.name);
```

Use `filter()` when you are keeping only matching items:

```js
const activeUsers = users.filter((user) => user.active);
```

Use `forEach()` when you only need side effects:

```js
errors.forEach((error) => {
  logger.warn("Validation failed", { field: error.field });
});
```

Use `for...of` when the logic needs early exit, multiple branches, mutation that should be obvious, or sequential async work:

```js
for (const order of orders) {
  if (order.status === "blocked") break;
  await syncOrder(order);
}
```

## When Not To Use This Decision

Do not use `reduce()` when:

- The result is just a transformed array. Use `map()`.
- The result is a subset. Use `filter()`.
- The code is mostly side effects. Use `forEach()` or `for...of`.
- The reducer has hidden branching, nested mutation, and multiple responsibilities.
- The accumulator changes type during the reducer.
- The team will struggle to maintain it compared with a named loop.
- You need early exit. `reduce()` will keep iterating unless you throw, which is usually the wrong control flow.

Also avoid forcing `reduce()` into business workflows that deserve named steps. A few clear lines are better than a dense reducer that nobody wants to debug.

## Alternatives

### map()

Use `map()` for one-to-one transformation.

```js
const productNames = products.map((product) => product.name);
```

### filter()

Use `filter()` for subsets.

```js
const paidOrders = orders.filter((order) => order.status === "paid");
```

### forEach()

Use `forEach()` for side effects.

```js
events.forEach((event) => analytics.track(event.name, event.properties));
```

### for...of

Use `for...of` for clarity, early exit, or sequential async work.

```js
const totals = {};

for (const order of orders) {
  if (!order.customerId) continue;
  totals[order.customerId] ??= 0;
  totals[order.customerId] += order.totalCents;
}
```

### Object.fromEntries()

Use `Object.fromEntries()` when you already have key/value pairs.

```js
const byId = Object.fromEntries(users.map((user) => [user.id, user]));
```

## Production Examples

### Invoice Summary

```js
const invoiceSummary = invoice.lines.reduce(
  (summary, line) => {
    const lineSubtotal = line.quantity * line.unitPriceCents;
    const lineTax = Math.round(lineSubtotal * line.taxRate);

    return {
      subtotalCents: summary.subtotalCents + lineSubtotal,
      taxCents: summary.taxCents + lineTax,
      totalCents: summary.totalCents + lineSubtotal + lineTax
    };
  },
  {
    subtotalCents: 0,
    taxCents: 0,
    totalCents: 0
  }
);
```

Why `reduce()` fits: many invoice lines become one summary object with stable numeric fields.

### Group Orders By Status

```js
const ordersByStatus = orders.reduce((groups, order) => {
  groups[order.status] ??= [];
  groups[order.status].push({
    id: order.id,
    customerName: order.customer.name,
    totalCents: order.totalCents,
    placedAt: order.placedAt
  });
  return groups;
}, {});
```

Why `reduce()` fits: the UI needs one object keyed by status, not one output item per input.

### Build A Lookup For Fast Reads

```js
const productsBySku = products.reduce((lookup, product) => {
  lookup[product.sku] = {
    id: product.id,
    name: product.name,
    priceCents: product.priceCents,
    inStock: product.inventoryCount > 0
  };
  return lookup;
}, {});
```

Why `reduce()` fits: repeated SKU lookups become direct property reads instead of repeated array searches.

### Vue-Ready Derived Data

```js
import { computed } from "vue";

const totalsByCustomer = computed(() =>
  orders.value.reduce((totals, order) => {
    totals[order.customerId] ??= {
      customerId: order.customerId,
      orderCount: 0,
      totalCents: 0
    };

    totals[order.customerId].orderCount += 1;
    totals[order.customerId].totalCents += order.totalCents;
    return totals;
  }, {})
);
```

Why `reduce()` fits: a reactive list of orders becomes one lookup object that the template or component logic can read efficiently.

## Common Mistakes

- Omitting `initialValue` and crashing on empty arrays.
- Letting the accumulator change type.
- Forgetting to return the accumulator.
- Using `reduce()` to imitate `map()` or `filter()`.
- Hiding too many business rules inside one callback.
- Mutating an external variable instead of returning the accumulator.
- Naming the accumulator `acc` in complex production code.
- Returning a new object sometimes and mutating the old object other times.

```js
// Mistake: TypeError on an empty array
const total = numbers.reduce((sum, number) => sum + number);
```

```js
// Better: explicit initial value
const total = numbers.reduce((sum, number) => sum + number, 0);
```

```js
// Mistake: reduce used as a confusing map()
const names = users.reduce((result, user) => {
  result.push(user.name);
  return result;
}, []);
```

```js
// Better
const names = users.map((user) => user.name);
```

## Debugging Checklist

- If the result is wrong for empty arrays, did you provide `initialValue`?
- If the result becomes `undefined`, does every branch return the accumulator?
- If the result has a strange type, does the accumulator keep the same shape every iteration?
- If grouping fails, did you initialize the group before pushing?
- If keys are missing, are the object keys unique and defined?
- If totals are wrong, are numeric fields stored in cents or floats?
- If code review is slow, would a named `for...of` loop communicate the business rule better?
- If the reducer is hard to test, should the callback become a named function?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-002/`.

Verification command:

```sh
npm run canon:verify:002
```

The verification suite checks:

- Summing numbers with an explicit `initialValue`.
- Grouping orders by status.
- Converting an array to a lookup object.
- The anti-pattern of using `reduce()` where `map()` or `filter()` is clearer.

## Performance Notes

Choose `reduce()` for intent before micro-performance. It can avoid intermediate arrays, but that only helps when the reducer stays readable.

For hot paths, measure. A `for...of` loop can be faster and clearer when combining filtering, transformation, early exit, and aggregation. In normal application code, the bigger performance risk is developer confusion: dense reducers cause slower reviews and more bugs.

## AI Coding Guidance

When generating code:

- Use `reduce()` only when many items become one final value.
- Always include `initialValue` unless there is a specific reason not to.
- Give the accumulator a meaningful name in non-trivial code.
- Keep the accumulator type stable.
- Prefer `map()` for one-to-one transformation.
- Prefer `filter()` for subsets.
- Prefer `for...of` for early exit, sequential `await`, or complex branching.
- Do not generate clever nested reducers for beginner-facing code.
- Explain the accumulator shape before showing advanced reducer syntax.
- If generating object lookups, make key collision behavior explicit when relevant.

Bad AI output:

```js
const names = users.reduce((acc, user) => {
  acc.push(user.name);
  return acc;
}, []);
```

Good AI output:

```js
const names = users.map((user) => user.name);
```

Good `reduce()` output:

```js
const usersById = users.reduce((lookup, user) => {
  lookup[user.id] = user;
  return lookup;
}, {});
```

## Teaching Notes

Teach `reduce()` as a decision about result shape, not as a clever trick.

Good teaching progression:

1. Start with a running total.
2. Name the accumulator.
3. Add `initialValue`.
4. Show that each callback returns the next accumulator.
5. Move from number accumulation to object accumulation.
6. Compare with `map()` and `filter()` so learners know when not to use it.
7. End with a refactor from confusing `reduce()` to clearer code.

Useful teaching phrase:

> The accumulator is the answer so far.

## Interview Questions

1. What does `reduce()` return?
2. What is the accumulator?
3. Why is `initialValue` important?
4. What happens when `reduce()` is called on an empty array without `initialValue`?
5. When is `map()` clearer than `reduce()`?
6. When is `filter()` clearer than `reduce()`?
7. How would you group orders by status?
8. How would you build a lookup object by ID?
9. Why can a dense reducer be risky in production code?
10. What would you use if you need early exit?

## Exercises

### Beginner

Sum an array of prices using `reduce()` with an explicit `initialValue`.

### Intermediate

Group support tickets by status and explain the accumulator shape.

### Advanced

Refactor a reducer that filters, maps, and groups in one callback into clearer named steps. Explain what readability improves and what trade-off you made.

## Related Atlas Nodes

- `javascript.array.reduce`
- `javascript.array.map`
- `javascript.array.filter`
- `javascript.array.foreach`
- `javascript.array.find`
- `javascript.array.some`
- `javascript.array.every`
- `javascript.object.keys`
- `vue.reactivity.computed`

## Evidence And Sources

- MDN Web Docs: Array.prototype.reduce(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce
- ECMAScript specification: Array.prototype.reduce: https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array.prototype.reduce
- Industry reference pattern: production JavaScript commonly uses `reduce()` for totals, grouping, and lookup construction when the accumulator has a clear invariant.

## Proof Of Superiority Summary

Official references explain how `reduce()` executes. This Canon node explains when to choose it, when to reject it, how to reason about the accumulator, why `initialValue` matters, how it compares with `map()`, `filter()`, `forEach()`, and `for...of`, and how AI assistants should generate maintainable reducer code.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
