const examples = [
  ["sum numbers with initialValue", require("./sum-numbers-initial-value")],
  ["group orders by status", require("./group-orders-by-status")],
  ["convert array to lookup object", require("./array-to-lookup-object")],
  ["anti-pattern: reduce where map/filter is clearer", require("./anti-pattern-reduce-where-map-filter-clearer")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-002 example(s).`);
