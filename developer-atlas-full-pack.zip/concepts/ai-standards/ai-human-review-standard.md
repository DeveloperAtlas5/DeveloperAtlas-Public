# AI Human Review Standard

Technology: AI Standard

## Simple meaning

The human stays in control of AI-assisted code changes.

## Why it exists

AI help should make code easier to review, not harder to trust.

## What AI should do

- Make changes reviewable.
- Show what changed and how to check it.
- Help the human understand before moving on.
- Name any risk or uncertainty plainly.

## What AI should avoid

- Taking over the mission.
- Skipping explanation.
- Hiding risk.
- Asking the human to trust a large change blindly.

## Before changing code

Ask for missing context if the safe change is unclear.

## While writing code

Keep the human's current goal visible.

## After the change

Give a short review summary and verification checklist.

## Human check

The human should be able to approve, reject, or ask for a smaller patch.

## Related Atlas nodes

- AI Explain-Before-Change Standard
- AI Small Patch Standard
