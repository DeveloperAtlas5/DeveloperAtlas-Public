const { assertUniqueKeys } = require("./keyed-patch-simulator");

module.exports = function runMistakeDuplicateKeys() {
  const rows = [
    { id: "user-1", email: "shared@example.com" },
    { id: "user-2", email: "shared@example.com" }
  ];

  let duplicateDetected = false;

  try {
    assertUniqueKeys(rows, (row) => row.email);
  } catch (error) {
    duplicateDetected = error.message.includes("Duplicate key detected");
  }

  if (!duplicateDetected) {
    throw new Error("Duplicate key example should detect non-unique sibling keys.");
  }

  assertUniqueKeys(rows, (row) => row.id);

  return true;
};
