# Database Relationships vs Frontend Data Relationships

## Shared idea

Both describe how pieces of data connect.

## Laravel side

Laravel relationships such as `hasMany` and `belongsTo` describe how database-backed models connect.

## Vue side

Frontend data relationships are often nested objects, arrays, props, or IDs used to display connected data.

## Main difference

Database relationships define stored records and queries. Frontend relationships define how loaded data is displayed or passed through components.

## Related concepts

Model, Eloquent, Props, Component, API Resource
