module.exports = function runGroupOrdersByStatus() {
  const orders = [
    { id: "ord_1", status: "paid", totalCents: 2400 },
    { id: "ord_2", status: "pending", totalCents: 1200 },
    { id: "ord_3", status: "paid", totalCents: 800 }
  ];

  const byStatus = orders.reduce((groups, order) => {
    groups[order.status] ??= [];
    groups[order.status].push(order);
    return groups;
  }, {});

  if (byStatus.paid.length !== 2) {
    throw new Error(`Expected 2 paid orders, got ${byStatus.paid.length}`);
  }

  if (byStatus.pending[0].id !== "ord_2") {
    throw new Error("Expected pending group to include ord_2");
  }
};
