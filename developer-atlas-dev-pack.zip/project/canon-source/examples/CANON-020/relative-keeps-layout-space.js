const assert = require("node:assert/strict");
const { relativeOffset } = require("./layout-simulator");

module.exports = function runRelativeKeepsLayoutSpaceExample() {
  const result = relativeOffset({
    normalTop: 100,
    height: 40,
    offsetTop: -10
  });

  assert.equal(result.keepsLayoutSpace, true);
  assert.equal(result.flowTop, 100);
  assert.equal(result.flowBottom, 140);
  assert.equal(result.visualTop, 90);
  assert.equal(result.visualBottom, 130);
};
