# SQL WHERE vs HAVING

## Status Metadata

- Canon ID: CANON-015
- Node ID: canon.sql.command.where-vs-having
- Status: Gold Candidate
- Score: 95
- Version: 2026.1
- Source family: SQL Fundamentals
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `WHERE` to filter individual rows before grouping and aggregation. Use `HAVING` to filter grouped results after `GROUP BY` and aggregate functions such as `COUNT()`, `SUM()`, or `AVG()`. Use both when you need to narrow raw rows first and then keep only groups that pass an aggregate condition.

## What Problem This Solves

Developers often remember that both clauses "filter," then place a condition wherever the query happens to run. That creates wrong reports, slow queries, and syntax errors like trying to use `COUNT(*)` inside `WHERE`.

This node answers:

- Does the condition apply to raw rows?
- Does the condition apply to grouped aggregate results?
- Should the query use both?
- When is a join, subquery, window function, or application filter the better tool?

## Mental Model

Think of a warehouse line.

`WHERE` is the door before items enter the counting machine. It decides which raw rows are allowed in.

`GROUP BY` is the counting machine. It bundles rows by customer, product, date, status, or another grouping key.

`HAVING` is the inspector after counting. It keeps or rejects whole groups based on aggregate facts.

```sql
SELECT customer_id, COUNT(*) AS order_count
FROM orders
WHERE status = 'paid'
GROUP BY customer_id
HAVING COUNT(*) > 1;
```

Read it as: "From paid order rows, group by customer, then keep customers with more than one paid order."

## Beginner Explanation

Use `WHERE` when the condition can be checked on one row at a time.

```sql
WHERE status = 'paid'
```

Use `HAVING` when the condition needs a group calculation.

```sql
HAVING COUNT(*) > 1
```

Beginner rule:

1. Can you decide before `GROUP BY`? Use `WHERE`.
2. Do you need `COUNT()`, `SUM()`, `AVG()`, `MIN()`, or `MAX()`? Use `HAVING`.
3. Need both row filtering and group filtering? Use both.

## Professional Explanation

SQL query processing is logical, not written-order intuitive. `WHERE` filters rows produced by `FROM` and joins before grouping. `GROUP BY` forms groups and computes aggregate values. `HAVING` filters those groups after aggregation.

This distinction matters for correctness and performance. Put row-level predicates in `WHERE` so the database can reduce the input before aggregation and often use indexes. Put aggregate predicates in `HAVING` because aggregate values do not exist until after grouping.

In production review, a `HAVING` clause should usually mention an aggregate expression or a grouped column. If `HAVING` only repeats a row-level predicate, move it to `WHERE` unless there is a dialect-specific reason. If a query needs both detailed rows and group-level filters, consider a subquery, CTE, or window function.

## Syntax

```sql
SELECT customer_id, COUNT(*) AS order_count
FROM orders
WHERE status = 'paid'
GROUP BY customer_id
HAVING COUNT(*) > 1;
```

General shape:

```sql
SELECT group_column, aggregate_function(*)
FROM table_name
WHERE row_condition
GROUP BY group_column
HAVING aggregate_condition;
```

## Decision Guide

1. Is the condition about a single row, such as status, date, country, account, or active flag?
   Use `WHERE`.
2. Is the condition about a group result, such as `COUNT(*) > 1` or `SUM(total) >= 1000`?
   Use `HAVING`.
3. Do you need to exclude irrelevant rows before grouping and then filter aggregate results?
   Use both.
4. Do you need to show individual rows while filtering by aggregate facts?
   Use a subquery, CTE, or window function.
5. Are you filtering after data is returned to application code?
   Prefer SQL filtering unless the condition truly depends on application-only state.

## Comparison Table

| Clause | Filters | Runs Logically | Best For | Main Mistake |
| --- | --- | --- | --- | --- |
| `WHERE` | Raw rows | Before `GROUP BY` | Row-level conditions | Trying to use aggregate functions there. |
| `HAVING` | Groups | After `GROUP BY` and aggregation | Aggregate conditions | Using it for ordinary row filters. |
| Both | Rows, then groups | Before and after grouping | Reports with row constraints and group thresholds | Putting all conditions in `HAVING`. |
| Subquery / CTE | Intermediate result sets | Depends on query shape | Complex staged filtering | Making a simple report harder than needed. |

## When To Use The Primary Option

Use `WHERE` when the database can decide from each row before grouping.

- Active orders only.
- Orders in the last 30 days.
- Customers from one region.
- Products in a category.
- Rows with `deleted_at IS NULL`.
- Tenant/account scoping.

## When To Use WHERE

```sql
SELECT customer_id, COUNT(*) AS paid_orders
FROM orders
WHERE status = 'paid'
GROUP BY customer_id;
```

Why `WHERE` fits: `status = 'paid'` is true or false for each order row before grouping.

## When To Use The Alternative

Use `HAVING` when the condition depends on grouped aggregate values.

- Customers with more than one order.
- Products with total sales over a threshold.
- Teams with average score above a target.
- Categories where `COUNT(DISTINCT user_id)` exceeds a limit.
- Groups whose latest date or minimum price passes a threshold.

## When To Use HAVING

```sql
SELECT customer_id, COUNT(*) AS order_count
FROM orders
GROUP BY customer_id
HAVING COUNT(*) > 1;
```

Why `HAVING` fits: `COUNT(*)` exists only after rows have been grouped by customer.

## When To Use Both

Use both when the business question has a row-level filter and a group-level filter.

```sql
SELECT customer_id, COUNT(*) AS paid_orders
FROM orders
WHERE status = 'paid'
GROUP BY customer_id
HAVING COUNT(*) > 1;
```

Why both fit: `WHERE` removes unpaid orders before grouping; `HAVING` keeps only customer groups with more than one paid order.

## When Not To Use This Decision

- Do not use `HAVING` just because a query has `GROUP BY`; row-level conditions still belong in `WHERE`.
- Do not use `WHERE` for aggregate expressions such as `COUNT(*) > 1`.
- Do not use either clause to replace join conditions. Join relationships belong in `JOIN ... ON`.
- Do not use either clause when a window function is needed to filter detail rows by group-level metrics.
- Do not filter large result sets in application code when SQL can express the condition clearly.
- Do not hide tenant or authorization scoping in `HAVING`; put row-level boundaries in `WHERE` or joins.

## Alternatives

- `JOIN ... ON` for table relationship conditions.
- CTEs for staged aggregate queries.
- Subqueries for filtering one query by another result.
- Window functions for retaining detail rows while calculating group metrics.
- `FILTER` clauses in databases that support aggregate-specific filtering.
- Application filtering only when the condition cannot be expressed in SQL or depends on external state.

## Production Examples

### Active Paid Orders Before Grouping

```sql
SELECT customer_id, COUNT(*) AS paid_order_count
FROM orders
WHERE status = 'paid'
  AND deleted_at IS NULL
GROUP BY customer_id;
```

Why `WHERE` fits: both `status` and `deleted_at` are row-level conditions. Filtering them before grouping makes the report correct and usually cheaper.

### Customers With Repeat Orders

```sql
SELECT customer_id, COUNT(*) AS order_count
FROM orders
GROUP BY customer_id
HAVING COUNT(*) > 1;
```

Why `HAVING` fits: the report only wants groups where the grouped count is greater than one.

### Monthly Revenue Report With Both

```sql
SELECT customer_id, SUM(total_cents) AS paid_revenue_cents
FROM orders
WHERE status = 'paid'
  AND placed_at >= DATE '2026-01-01'
GROUP BY customer_id
HAVING SUM(total_cents) >= 100000;
```

Why both fit: `WHERE` chooses paid 2026 rows; `HAVING` keeps customers whose paid revenue reaches the threshold.

### Detail Rows By Aggregate Fact

```sql
WITH repeat_customers AS (
  SELECT customer_id
  FROM orders
  GROUP BY customer_id
  HAVING COUNT(*) > 1
)
SELECT orders.*
FROM orders
JOIN repeat_customers
  ON repeat_customers.customer_id = orders.customer_id;
```

Why a CTE fits: the final output needs detail rows, not just grouped rows.

## Common Mistakes

- Writing `WHERE COUNT(*) > 1`.
- Using `HAVING status = 'paid'` instead of `WHERE status = 'paid'`.
- Putting tenant/account filters in `HAVING` and aggregating too much data.
- Expecting an aggregate alias to work in every database's `HAVING` clause.
- Forgetting that `HAVING` filters groups, so non-grouped columns can be invalid or nondeterministic.
- Using application code to remove groups after fetching a large aggregate result.
- Confusing `JOIN ... ON` filters with row filters in `WHERE`.

## Debugging Checklist

- Does the condition mention an aggregate function? It probably belongs in `HAVING`.
- Can the condition be evaluated for one row? It probably belongs in `WHERE`.
- Are row filters reducing data before grouping?
- Is every non-aggregate selected column included in `GROUP BY` or functionally valid for the database?
- Is a `HAVING` predicate really a row predicate in disguise?
- Are you accidentally filtering detail rows when you meant to filter groups?
- Would a CTE make a staged aggregate query easier to read?
- Are tenant, account, and permission boundaries applied before aggregation?

## Mechanical Verification

Runnable deterministic examples live in `canon/examples/CANON-015/`.

Run:

```bash
npm run canon:verify:015
```

The examples verify:

- `WHERE` filters active paid orders before grouping.
- `HAVING` filters customer groups with `COUNT(*) > 1`.
- `WHERE` and `HAVING` work together for row and group conditions.
- Using `WHERE` with aggregate `COUNT(*)` is a mistake.

## Performance Notes

Correct placement often helps performance.

- `WHERE` can reduce rows before aggregation and may use indexes.
- `HAVING` operates after grouping, so it should be used for aggregate conditions.
- Moving a row-level condition from `HAVING` to `WHERE` can reduce the amount of work before grouping.
- For large reports, inspect query plans and indexes after the semantics are correct.

## AI Coding Guidance

When generating SQL:

- Put row-level filters in `WHERE`.
- Put aggregate filters in `HAVING`.
- Use both when a report needs row constraints and group thresholds.
- Do not generate `WHERE COUNT(*) > ...`.
- Do not put tenant, account, or active/deleted filters in `HAVING`.
- Use a CTE or subquery when the user needs detail rows filtered by aggregate facts.
- Explain the query in logical order: `FROM`, `WHERE`, `GROUP BY`, `HAVING`, `SELECT`.

## Teaching Notes

Teach `WHERE` and `HAVING` with the same dataset so the difference is visible.

Progression:

1. Filter paid rows with `WHERE`.
2. Group by customer.
3. Filter customer groups with `HAVING`.
4. Combine both.
5. Show why `WHERE COUNT(*) > 1` fails.

Useful teaching phrase:

> `WHERE` filters before the count; `HAVING` filters after the count.

## Interview Questions

1. What does `WHERE` filter in a grouped query?
2. What does `HAVING` filter?
3. Why is `WHERE COUNT(*) > 1` invalid?
4. When would you use both `WHERE` and `HAVING`?
5. Why can moving row-level filters from `HAVING` to `WHERE` improve a query?
6. What should you use if you need detail rows from groups that pass an aggregate condition?
7. How would tenant scoping affect a grouped report?

## Exercises

### Beginner

Write a query that counts paid orders per customer using `WHERE status = 'paid'`.

### Intermediate

Write a query that returns only customers with at least three paid orders by using both `WHERE` and `HAVING`.

### Advanced

Build a report that returns detail rows for customers whose total paid revenue exceeds a threshold. Use a CTE or subquery and explain why plain `HAVING` alone is not enough.

## Related Atlas Nodes

- `sql.command.where`
- `sql.command.select`
- `sql.command.join`
- `CANON-005`

## Evidence And Sources

- PostgreSQL SELECT docs - https://www.postgresql.org/docs/current/sql-select.html
- PostgreSQL table expressions pipeline - https://www.postgresql.org/docs/current/queries-table-expressions.html
- MySQL SELECT statement and HAVING - https://dev.mysql.com/doc/en/select.html
- MySQL GROUP BY handling - https://dev.mysql.com/doc/refman/8.4/en/group-by-handling.html
- SQLite SELECT docs - https://sqlite.org/lang_select.html

## Proof Of Superiority Summary

Official SQL database docs explain clause syntax and query behavior. This Canon node explains the production decision: `WHERE` for row filtering before grouping, `HAVING` for aggregate group filtering after grouping, both for staged report constraints, CTEs for detail rows by aggregate facts, performance implications, deterministic examples, and AI-safe SQL generation rules.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
