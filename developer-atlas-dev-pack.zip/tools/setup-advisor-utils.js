const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const setupAdvisorDir = path.join(rootDir, "setup-advisor");
const setupAdvisorExamplesDir = path.join(setupAdvisorDir, "examples");
const setupAdvisorOutputDir = path.join(rootDir, "output", "setup-advisor");

function ensureSetupAdvisorOutputDir() {
  fs.mkdirSync(setupAdvisorOutputDir, { recursive: true });
}

function readSetupRequests() {
  if (!fs.existsSync(setupAdvisorExamplesDir)) return [];

  return fs.readdirSync(setupAdvisorExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(setupAdvisorExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        request: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

module.exports = {
  setupAdvisorDir,
  setupAdvisorExamplesDir,
  setupAdvisorOutputDir,
  ensureSetupAdvisorOutputDir,
  readSetupRequests
};
