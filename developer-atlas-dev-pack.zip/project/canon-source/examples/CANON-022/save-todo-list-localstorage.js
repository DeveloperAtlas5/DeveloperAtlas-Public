const assert = require("assert");
const { MemoryStorage } = require("./storage-fake");

module.exports = function saveTodoListToLocalStorage() {
  const localStorage = new MemoryStorage("localStorage");
  const todos = [
    { id: 1, text: "Persist todos", done: false },
    { id: 2, text: "Refresh safely", done: true }
  ];

  localStorage.setItem("todos", JSON.stringify(todos));

  const stored = localStorage.getItem("todos");
  assert.strictEqual(typeof stored, "string");
  assert.ok(stored.includes("Persist todos"));
  assert.notStrictEqual(stored, "[object Object]");
};
