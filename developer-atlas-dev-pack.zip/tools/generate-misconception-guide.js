const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getLearning
} = require("./learning-utils");

function main() {
  const entries = readCanonIndex().entries || [];
  const lines = ["# Atlas Misconception Guide", ""];
  let count = 0;

  for (const entry of entries) {
    const corrections = getLearning(entry).misconception_corrections || [];
    for (const item of corrections) {
      count += 1;
      lines.push(`## ${entry.canon_id}: ${entry.title}`);
      lines.push("");
      lines.push(`- Misconception: ${item.misconception}`);
      lines.push(`- Correction: ${item.correction}`);
      lines.push(`- Affected Canon node: ${entry.canon_id}`);
      lines.push(`- Explanation: ${item.explanation}`);
      lines.push(`- Practice task: ${item.practice_task}`);
      lines.push("");
    }
  }

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "misconception-guide.md"), `${lines.join("\n").trim()}\n`);
  console.log(`Generated output/learning/misconception-guide.md with ${count} misconception corrections.`);
}

main();

