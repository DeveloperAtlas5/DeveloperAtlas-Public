const fs = require("fs");
const path = require("path");
const {
  hardwareOutputDir,
  ensureHardwareOutputDir,
  readContextualHardwareHints,
  countValues
} = require("./hardware-utils");

function main() {
  const hints = readContextualHardwareHints().map((record) => record.hint);
  const report = buildReport(hints);

  ensureHardwareOutputDir();
  fs.writeFileSync(
    path.join(hardwareOutputDir, "contextual-hardware-hints.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(hardwareOutputDir, "contextual-hardware-hints.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/hardware/contextual-hardware-hints.json with ${hints.length} hint(s).`);
  console.log("Generated output/hardware/contextual-hardware-hints.md.");
}

function buildReport(hints) {
  return {
    total_contextual_hints: hints.length,
    hints_by_workload: countValues(hints.flatMap((hint) => hint.related_workloads)),
    hints_by_severity: countValues(hints.map((hint) => hint.severity)),
    hints: hints.map((hint) => ({
      hint_id: hint.hint_id,
      severity: hint.severity,
      related_workloads: hint.related_workloads,
      trigger_topics: hint.trigger_topics,
      condition: hint.condition,
      message_rookie: hint.message_rookie,
      message_professional: hint.message_professional,
      hardware_reason: hint.hardware_reason,
      suggested_check: hint.suggested_check,
      related_machine_profile_fields: hint.related_machine_profile_fields
    }))
  };
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Contextual Hardware Hints",
    "",
    `Total contextual hints: ${report.total_contextual_hints}`,
    "",
    "## Hints by Workload",
    "",
    ...formatCounts(report.hints_by_workload),
    "",
    "## Hints by Severity",
    "",
    ...formatCounts(report.hints_by_severity),
    "",
    "## Hint Catalog"
  ];

  for (const hint of report.hints) {
    lines.push(
      "",
      `### ${hint.hint_id}`,
      "",
      `Severity: ${hint.severity}`,
      `Workloads: ${hint.related_workloads.join(", ")}`,
      `Trigger topics: ${hint.trigger_topics.join(", ")}`,
      "",
      `Condition: ${hint.condition}`,
      "",
      `Rookie: ${hint.message_rookie}`,
      "",
      `Professional: ${hint.message_professional}`,
      "",
      `Reason: ${hint.hardware_reason}`,
      "",
      `Suggested check: ${hint.suggested_check}`,
      "",
      `Machine fields: ${hint.related_machine_profile_fields.join(", ")}`
    );
  }

  return `${lines.join("\n")}\n`;
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

main();
