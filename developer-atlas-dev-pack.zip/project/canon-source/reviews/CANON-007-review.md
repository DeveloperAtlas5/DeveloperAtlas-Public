# Canon Review Template

Canon ID: CANON-007
Node ID: canon.vue.directive.v-if-vs-v-show
Reviewer: Pending Gold Review Panel
Date: 2026-07-02
Stage: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Gold-candidate draft aligns with Vue docs for conditional rendering, `v-if`, and `v-show`.
- Edge cases: Covers DOM presence, lifecycle recreation, state preservation, permission-gated content, accessibility cautions, and alternative tools.
- Version concerns: Guidance targets Vue 3 template behavior.
- Evidence quality: Direct official Vue URLs are included.

## Educational Review

- Beginner clarity: Strong existence-versus-visibility mental model.
- Mental model: Door/light-switch framing is practical and memorable.
- Exercise quality: Beginner, intermediate, and advanced exercises are present.
- Common mistake coverage: Covers state reset, hidden DOM, expensive initial render, and overusing directives for styling/routing.

## AI Review

- Structured enough for retrieval: Yes.
- Code generation guidance: Strong and specific.
- Ambiguity risks: AI should still distinguish visual hiding from true authorization.
- Related node quality: Related IDs align with existing Vue nodes.

## Engineering Review

- Decision support: Strong.
- Production realism: Permission panel, filter drawer, chart, and tab examples are practical.
- Trade-offs: Good coverage of initial cost, toggle cost, DOM existence, and state preservation.
- Anti-pattern coverage: Strong enough for Gold-candidate review.

## Decision

- Approved stage: Gold Candidate
- Required changes: Add named reviewer sign-off before Gold approval.
- Score: 95
