const fs = require("fs");
const path = require("path");
const {
  readinessOutputDir,
  ensureReadinessOutputDir,
  readReadinessDeltas,
  average,
  round,
  unique
} = require("./readiness-utils");

function main() {
  const deltas = readReadinessDeltas().map((record) => record.delta);
  const report = buildReport(deltas);

  ensureReadinessOutputDir();
  fs.writeFileSync(
    path.join(readinessOutputDir, "readiness-delta-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(readinessOutputDir, "readiness-delta-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/readiness/readiness-delta-report.json for ${deltas.length} delta(s).`);
  console.log("Generated output/readiness/readiness-delta-report.md.");
}

function buildReport(deltas) {
  const scored = deltas.map((delta) => ({
    ...delta,
    score_improvement: round(delta.after_score - delta.before_score),
    confidence_improvement: round(delta.confidence_after - delta.confidence_before)
  }));

  return {
    deltas_processed: deltas.length,
    average_score_improvement: round(average(scored.map((delta) => delta.score_improvement))),
    average_confidence_improvement: round(average(scored.map((delta) => delta.confidence_improvement))),
    total_time_spent_minutes: scored.reduce((total, delta) => total + delta.time_spent_minutes, 0),
    visible_wins: unique(scored.flatMap((delta) => delta.visible_wins)),
    most_improved_category: inferMostImprovedCategory(scored),
    remaining_biggest_gap: mostCommonGap(scored),
    next_recommended_actions: unique(scored.map((delta) => delta.next_best_step)),
    deltas: scored.map((delta) => ({
      delta_id: delta.delta_id,
      readiness_id: delta.readiness_id,
      before_score: delta.before_score,
      after_score: delta.after_score,
      score_improvement: delta.score_improvement,
      confidence_improvement: delta.confidence_improvement,
      time_spent_minutes: delta.time_spent_minutes,
      visible_wins: delta.visible_wins,
      remaining_gaps: delta.remaining_gaps,
      next_best_step: delta.next_best_step
    }))
  };
}

function inferMostImprovedCategory(deltas) {
  const totals = {
    knowledge: 0,
    practice: 0,
    tooling: 0,
    friction: 0,
    hardware: 0,
    momentum: 0
  };

  for (const delta of deltas) {
    totals.knowledge += delta.completed_nodes.length * 2;
    totals.practice += delta.completed_practice.length * 2;
    totals.tooling += delta.added_tools.length * 2;
    totals.friction += delta.resolved_friction_nodes.length * 3;
    totals.hardware += delta.improved_machine_profile.length;
    totals.momentum += Math.max(0, delta.confidence_after - delta.confidence_before) * 10;
  }

  const [category, score] = Object.entries(totals)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0];
  return { category, signal_score: round(score) };
}

function mostCommonGap(deltas) {
  const counts = new Map();
  for (const gap of deltas.flatMap((delta) => delta.remaining_gaps)) {
    const normalized = normalizeGap(gap);
    counts.set(normalized, (counts.get(normalized) || 0) + 1);
  }

  const [gap, count] = [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0] || ["None", 0];
  return { gap, count };
}

function normalizeGap(gap) {
  const lower = gap.toLowerCase();
  if (lower.includes("vue")) return "Vue component and reactivity practice";
  if (lower.includes("laravel") || lower.includes("database")) return "Laravel database and backend practice";
  if (lower.includes("terminal") || lower.includes("setup")) return "Setup and terminal confidence";
  return gap;
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Readiness Delta Report",
    "",
    `Deltas processed: ${report.deltas_processed}`,
    `Average score improvement: ${report.average_score_improvement}`,
    `Average confidence improvement: ${report.average_confidence_improvement}`,
    `Total time spent: ${report.total_time_spent_minutes} minutes`,
    `Most improved category: ${report.most_improved_category.category} (${report.most_improved_category.signal_score})`,
    `Remaining biggest gap: ${report.remaining_biggest_gap.gap} (${report.remaining_biggest_gap.count})`,
    "",
    "## Visible Wins",
    "",
    ...formatList(report.visible_wins),
    "",
    "## Next Recommended Actions",
    "",
    ...formatList(report.next_recommended_actions),
    "",
    "## Delta Details",
    ""
  ];

  for (const delta of report.deltas) {
    lines.push(
      `### ${delta.delta_id}`,
      "",
      `Readiness: ${delta.readiness_id}`,
      `Score: ${delta.before_score} -> ${delta.after_score} (+${delta.score_improvement})`,
      `Confidence improvement: +${delta.confidence_improvement}`,
      `Time spent: ${delta.time_spent_minutes} minutes`,
      "",
      "Visible wins:",
      ...formatList(delta.visible_wins),
      "",
      "Remaining gaps:",
      ...formatList(delta.remaining_gaps),
      "",
      `Next best step: ${delta.next_best_step}`,
      ""
    );
  }

  return `${lines.join("\n")}\n`;
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
