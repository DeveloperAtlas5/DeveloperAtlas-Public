const examples = [
  ["INNER JOIN users/orders", require("./inner-join-users-orders")],
  ["LEFT JOIN users/orders", require("./left-join-users-orders")],
  ["mistake: duplicate rows from one-to-many joins", require("./duplicate-rows-one-to-many")],
  ["debugging missing rows caused by INNER JOIN", require("./missing-rows-inner-join")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-005 example(s).`);
