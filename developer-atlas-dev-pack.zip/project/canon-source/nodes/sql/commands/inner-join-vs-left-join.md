# SQL INNER JOIN vs LEFT JOIN

## Status Metadata

- Canon ID: CANON-019
- Node ID: canon.sql.command.inner-join-vs-left-join
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: SQL relational thinking
- Level: junior/intermediate
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `INNER JOIN` when the answer should include only rows that have a match in both tables. Use `LEFT JOIN` when the left table is the main list and its rows must stay visible even when the right table has no match.

The decision is about row preservation:

- `INNER JOIN` means only matching rows.
- `LEFT JOIN` means keep all left-side rows.
- One-to-many relationships can multiply rows with either join type.

## What Problem This Solves

Developers often understand join syntax before they understand result shape. That causes real reporting bugs:

- Users disappear because `INNER JOIN` removed users with no orders.
- A `LEFT JOIN` accidentally acts like an `INNER JOIN` because a right-table filter is placed in `WHERE`.
- Counts are inflated because one user matches many orders.
- AI-generated SQL chooses a plausible join type without knowing whether unmatched rows should remain.

This node teaches the practical question: should missing related data remove the left row or stay visible as `NULL`?

## Mental Model

Start with the table whose rows define the report.

If `users` is the main list:

- `INNER JOIN orders` keeps only users with matching orders.
- `LEFT JOIN orders` keeps every user, and fills order columns with `NULL` when no order exists.

Think of `INNER JOIN` as an intersection and `LEFT JOIN` as a preserve-left report.

```text
INNER JOIN: keep only left rows with right matches
LEFT JOIN:  keep every left row, attach right matches when present
```

The key review question is:

> Should unmatched left-side rows survive?

## Beginner Explanation

Imagine these tables:

`users`

| id | name |
| --- | --- |
| 1 | Ada |
| 2 | Grace |
| 3 | Linus |

`orders`

| id | user_id | total |
| --- | --- | --- |
| 101 | 1 | 50 |
| 102 | 2 | 75 |

`INNER JOIN` returns Ada and Grace because they have orders. Linus disappears.

`LEFT JOIN` returns Ada, Grace, and Linus. Linus stays, but the order columns are `NULL`.

Beginner rule:

1. Want only rows with matches? Use `INNER JOIN`.
2. Want every row from the left table? Use `LEFT JOIN`.
3. Missing rows? Check whether `INNER JOIN` removed them.
4. Too many rows? Check whether one left row has many matches.

## Professional Explanation

Join type encodes null-preservation. `INNER JOIN` is correct when the relationship is required for the result. `LEFT JOIN` is correct when the relationship is optional but the left-side entity remains part of the answer.

In production SQL, the join choice must be reviewed with cardinality and filter placement:

- A one-to-one join enriches one row with related columns.
- A many-to-one join attaches a parent or lookup.
- A one-to-many join expands the result and may require aggregation.
- A `LEFT JOIN` introduces `NULL` for missing right-side rows.
- A right-table condition in `WHERE` can remove those `NULL` rows and make the result behave like an inner join.

The professional signal is not "LEFT JOIN is safer." It is "Does this query preserve the entities the business question says must remain visible?"

## Syntax

```sql
SELECT users.id, users.name, orders.id AS order_id
FROM users
INNER JOIN orders
  ON orders.user_id = users.id;
```

```sql
SELECT users.id, users.name, orders.id AS order_id
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id;
```

## Decision Guide

Ask these questions in order:

1. What is the main table whose rows define the answer?
   Put that table first when using `LEFT JOIN`.
2. Should rows without matching related data disappear?
   Use `INNER JOIN`.
3. Should rows without matching related data remain visible?
   Use `LEFT JOIN`.
4. Can one left row match many right rows?
   Expect duplicate-looking left data or aggregate first.
5. Are you filtering right-side rows after a `LEFT JOIN`?
   Use the `ON` clause when unmatched left rows must still survive.
6. Do you only need to test existence?
   Consider `EXISTS` or `NOT EXISTS`.
7. Do you need one row per left entity with counts or totals?
   Join and aggregate, or aggregate first and then join.

## Comparison Table

| Choice | Row Preservation | Best For | Main Risk |
| --- | --- | --- | --- |
| `INNER JOIN` | Keeps only matching rows | Required relationships, matched-only reports | Missing rows when related data is optional |
| `LEFT JOIN` | Keeps all left-side rows | Optional relationships, zero-activity reports, audits | `NULL` handling and accidental filtering in `WHERE` |
| `LEFT JOIN ... IS NULL` | Keeps left rows with no match | Finding missing related records | Can be less clear than `NOT EXISTS` in some queries |
| `EXISTS` | Does not duplicate rows | Existence checks | Does not return right-table columns |
| Aggregated join | One row per grouped entity | Counts and totals | Wrong counts if cardinality is ignored |

## When To Use The Primary Option

Use `INNER JOIN` when:

- Both records must exist for the answer to be valid.
- The business question says "users with orders" or "orders with customers."
- Missing related records should be excluded.
- You need columns from both tables and only matched pairs matter.

```sql
SELECT users.id, users.email, orders.id AS order_id
FROM users
INNER JOIN orders
  ON orders.user_id = users.id;
```

Why `INNER JOIN` fits: users without orders are not part of a "users with orders" report.

## When To Use The Alternative

Use `LEFT JOIN` when:

- The left table is the main list.
- Related rows are optional.
- You need zero-activity rows to remain visible.
- You are auditing missing relationships.
- The report says "all users, with orders if they exist."

```sql
SELECT users.id, users.email, orders.id AS order_id
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id;
```

Why `LEFT JOIN` fits: users without orders remain visible with `NULL` order columns.

## When Not To Use This Decision

Do not choose between `INNER JOIN` and `LEFT JOIN` when a join is not the right tool.

Avoid either join when:

- You only need to ask whether related rows exist. Use `EXISTS`.
- You need to find rows with no match and `NOT EXISTS` is clearer.
- You need counts or totals but not right-table details. Aggregate first or use `GROUP BY`.
- The join would cause row explosion and the output needs one row per entity.
- The relationship is unclear or missing a trustworthy key.
- Application authorization, tenant scoping, or soft-delete filters are not yet defined.

## Alternatives

### EXISTS

Use `EXISTS` when you need matched existence without duplicating left rows.

```sql
SELECT users.id, users.email
FROM users
WHERE EXISTS (
  SELECT 1
  FROM orders
  WHERE orders.user_id = users.id
);
```

### NOT EXISTS

Use `NOT EXISTS` to find left rows without related rows.

```sql
SELECT users.id, users.email
FROM users
WHERE NOT EXISTS (
  SELECT 1
  FROM orders
  WHERE orders.user_id = users.id
);
```

### Aggregation

Use aggregation when one row per parent is required.

```sql
SELECT users.id, users.email, COUNT(orders.id) AS order_count
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id
GROUP BY users.id, users.email;
```

## Production Examples

### Users With Orders

```sql
SELECT users.id, users.email, orders.id AS order_id, orders.total_cents
FROM users
INNER JOIN orders
  ON orders.user_id = users.id
ORDER BY users.id, orders.id;
```

This is a matched-only report. Users with no orders should not appear.

### All Users Including Users Without Orders

```sql
SELECT users.id, users.email, orders.id AS order_id, orders.total_cents
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id
ORDER BY users.id, orders.id;
```

This is a preserve-left report. Users with no orders appear with `NULL` order columns.

### Find Users With No Orders

```sql
SELECT users.id, users.email
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id
WHERE orders.id IS NULL;
```

This works because unmatched right-side rows produce `NULL`.

### Keep All Users While Filtering Paid Orders

```sql
SELECT users.id, users.email, orders.id AS paid_order_id
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id
 AND orders.status = 'paid';
```

The paid-order filter belongs in `ON` when users without paid orders must remain visible.

## Common Mistakes

- Using `INNER JOIN` and wondering why users without orders disappeared.
- Using `LEFT JOIN` but placing `orders.status = 'paid'` in `WHERE`, removing unmatched users.
- Treating `LEFT JOIN` as always safer than `INNER JOIN`.
- Forgetting that one user can match many orders, producing multiple rows per user.
- Counting rows after a one-to-many join without checking duplicates.
- Joining on the wrong key.
- Selecting `id` without qualifying which table owns it.
- Using `SELECT *` in production join queries.

## Debugging Checklist

### Missing Row Debugging

- Count rows from the left table before the join.
- Switch an `INNER JOIN` to `LEFT JOIN` temporarily and inspect `NULL` right-side columns.
- Check whether a `WHERE` clause references right-side columns after a `LEFT JOIN`.
- Verify the join keys with a small sample.
- Check soft-delete, tenant, status, and date filters.

### Duplicate Row Debugging

- Check whether one left row matches many right rows.
- Select only join keys first.
- Count matches per left key.
- Decide whether the output should show detail rows or grouped rows.
- Add `GROUP BY`, aggregate first, or use `EXISTS` when detail rows are not needed.

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-019/`.

Run:

```bash
npm run canon:verify:019
```

Verified examples:

- `INNER JOIN` returns users with orders.
- `LEFT JOIN` returns all users including those without orders.
- `INNER JOIN` does not keep unmatched users.
- Filtering a `LEFT JOIN` in `WHERE` can make it behave like `INNER JOIN`.

## Performance Notes

Correct result shape comes first. After correctness, inspect indexes, join cardinality, and query plans.

Practical performance checks:

- Join keys should usually be indexed.
- Filters that reduce raw rows should happen as early as correctness allows.
- One-to-many joins can expand results significantly.
- `EXISTS` can be clearer and efficient for existence checks.
- Aggregating before joining can avoid row explosion in reports.

## AI Coding Guidance

- Ask whether unmatched left-side rows should remain visible.
- Ask which table is the main entity list.
- Generate `INNER JOIN` only when missing related rows should be excluded.
- Generate `LEFT JOIN` when preserving all left rows is required.
- Put optional right-side filters in `ON` when unmatched left rows must remain.
- Warn when a `WHERE` condition on the right table after a `LEFT JOIN` removes `NULL` rows.
- Warn about one-to-many duplicates and suggest aggregation or `EXISTS` when appropriate.
- Avoid `SELECT *` in generated join examples.

## Teaching Notes

Teach with three users and two orders. Make the missing user visible.

1. Show `INNER JOIN`: the user without orders disappears.
2. Show `LEFT JOIN`: the user without orders remains.
3. Add a `WHERE orders.status = 'paid'` filter and show how it removes `NULL` rows.
4. Move the filter into `ON` and show that all users remain.

The goal is not to memorize syntax. The goal is to predict row survival.

## Interview Questions

1. What rows does `INNER JOIN` keep?
2. What rows does `LEFT JOIN` preserve?
3. Why can a `WHERE` clause after `LEFT JOIN` remove unmatched rows?
4. How do one-to-many joins create duplicate-looking parent rows?
5. When would `EXISTS` be better than a join?
6. How would you find users with no orders?

## Exercises

### Beginner

Run `INNER JOIN` and `LEFT JOIN` against small users/orders tables and write down which users appear.

### Intermediate

Find all users with no orders using `LEFT JOIN ... IS NULL`, then rewrite the query with `NOT EXISTS`.

### Advanced

Debug a report where paid-order filtering accidentally hides users with no paid orders.

## Related Atlas Nodes

- `CANON-005`
- `CANON-015`
- `sql.command.join`
- `sql.command.where`
- `sql.command.select`

## Evidence And Sources

- PostgreSQL joined tables: https://www.postgresql.org/docs/current/queries-table-expressions.html
- MySQL JOIN syntax: https://dev.mysql.com/doc/refman/8.4/en/join.html
- SQLite SELECT and join syntax: https://www.sqlite.org/lang_select.html

## Proof Of Superiority Summary

Official documentation explains join syntax. Atlas adds the practical decision model: choose based on row preservation, debug missing rows by checking join type and filter placement, debug duplicate rows by checking cardinality, and guide AI assistants away from plausible but wrong joins.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 10 |
| evidence | 5 | 5 |
| relationships | 5 | 5 |
| exercises | 3 | 2 |
| readability | 2 | 1 |
| Total | 100 | 95 |
