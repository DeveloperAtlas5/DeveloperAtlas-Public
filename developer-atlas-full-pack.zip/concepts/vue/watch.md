# Vue watch

Technology: Vue

## Simple meaning

`watch` runs code when reactive data changes.

## Why it exists

It lets the app react to a state change with a side effect.

## Where you use it

Inside Vue setup code.

## When to use it

Use `watch` for side effects such as saving to localStorage or reacting to a route parameter change.

## Tiny example

`watch(todos, saveTodos, { deep: true })`

## Common beginner confusion

Use `computed` for values you display. Use `watch` when something needs to happen because data changed.

## Related concepts

- ref
- computed
- localStorage

## Similar idea in another technology

A Laravel event listener reacts after something happens on the server; Vue watch reacts after browser state changes.
