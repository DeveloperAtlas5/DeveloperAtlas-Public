module.exports = function runFindUserById() {
  const users = [
    { id: "u1", name: "Ada" },
    { id: "u2", name: "Grace" },
    { id: "u3", name: "Lin" }
  ];

  const user = users.find((item) => item.id === "u2");
  const missingUser = users.find((item) => item.id === "u9");

  if (!user || user.name !== "Grace") {
    throw new Error("Expected find() to return Grace by ID");
  }

  if (missingUser !== undefined) {
    throw new Error("Expected find() to return undefined for a missing user");
  }
};
