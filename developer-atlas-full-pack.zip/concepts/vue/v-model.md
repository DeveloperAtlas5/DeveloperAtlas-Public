# Vue v-model

Technology: Vue

## Simple meaning

`v-model` connects form input value and Vue state.

## Why it exists

It keeps what the user types and what Vue remembers in sync.

## Where you use it

On inputs, textareas, selects, and components designed to support it.

## When to use it

Use `v-model` when form input should update reactive state.

## Tiny example

`<input v-model="newTodo">`

## Common beginner confusion

`v-model` is not storage. It updates current browser state, not the database or localStorage by itself.

## Related concepts

- ref
- reactive
- Props
- Emits

## Similar idea in another technology

Laravel validation reads submitted form values later; Vue `v-model` tracks input while the user is typing.
