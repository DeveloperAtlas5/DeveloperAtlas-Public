const assert = require("node:assert/strict");

module.exports = function runMistakeParseAlreadyParsedObjectExample() {
  const alreadyParsed = { id: 7, title: "Atlas" };

  assert.equal(typeof alreadyParsed, "object");
  assert.throws(() => {
    JSON.parse(alreadyParsed);
  }, SyntaxError);

  const correctValue = alreadyParsed;
  assert.equal(correctValue.title, "Atlas");
};
