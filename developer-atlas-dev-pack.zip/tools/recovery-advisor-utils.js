const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const recoveryAdvisorDir = path.join(rootDir, "recovery-advisor");
const recoveryAdvisorExamplesDir = path.join(recoveryAdvisorDir, "examples");
const recoveryAdvisorOutputDir = path.join(rootDir, "output", "recovery-advisor");

function ensureRecoveryAdvisorOutputDir() {
  fs.mkdirSync(recoveryAdvisorOutputDir, { recursive: true });
}

function readRecoveryRequests() {
  if (!fs.existsSync(recoveryAdvisorExamplesDir)) return [];

  return fs.readdirSync(recoveryAdvisorExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(recoveryAdvisorExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        request: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

module.exports = {
  recoveryAdvisorDir,
  recoveryAdvisorExamplesDir,
  recoveryAdvisorOutputDir,
  ensureRecoveryAdvisorOutputDir,
  readRecoveryRequests
};
