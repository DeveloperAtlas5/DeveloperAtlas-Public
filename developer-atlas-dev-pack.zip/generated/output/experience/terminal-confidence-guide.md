# Terminal Confidence Guide

## How to use this file

This file is optional. Open this only if terminal commands or project folders feel unclear.

You do not need to become a terminal expert today. This guide is just enough to help with the Rookie Vue mission.

## What the terminal is

The terminal is a place where you type commands for your computer or project.

For this mission, you only need a couple of npm commands.

## What folder should I be in?

Commands should usually run inside the root folder of the Vue project.

The root folder is usually the folder that contains `package.json`.

If you run commands from another folder, npm may not find the project scripts yet.

## How to recognize the project folder

You are probably in the right project folder if it contains:

- `package.json`.
- `src/`.
- `vite.config.js`.
- `node_modules/` after install.
- `index.html`.

If you see `package.json`, you are probably near the right place to run npm commands.

## Common commands for this mission

```bash
npm install
npm run dev
```

`npm install` downloads the project packages.

`npm run dev` starts the local development server.

The terminal may show a local address like `http://localhost:5173`. That address is where the app usually opens in the browser.

## If a command does not work

Try these calm checks:

1. Are you in the folder that contains `package.json`?
2. Did you already run `npm install`?
3. Did the terminal show a missing script message?
4. Is another dev server already using the port?
5. Did the command output include a useful error line?

The message is information. It does not mean you cannot do this.

## What messages are normal?

These messages are often normal:

- Package install progress.
- Warnings.
- A local server URL.
- Port changed because another port is busy.

Warnings are not always blockers. Atlas cares about whether the app starts and whether the mission visible win works.

## What to copy when asking for help

Copy:

- The command you ran.
- The folder path shown in the terminal.
- The last 10-20 lines of the terminal output.
- What you expected to happen.
- What happened instead.

Copy and paste this help prompt:

```txt
I am working on a Vue beginner project. I am trying to run the mission, but the terminal command did not work as expected. Here is the command I ran, the folder I was in, and the last part of the terminal output. Please help me one step at a time and do not add new project features.
```

## What to remember today

- Run Vue project commands from the folder that contains `package.json`.
- `npm install` gets the project packages.
- `npm run dev` starts the local app.
- Warnings are not always blockers.
- Copy the command, folder path, and last terminal lines when asking for help.
