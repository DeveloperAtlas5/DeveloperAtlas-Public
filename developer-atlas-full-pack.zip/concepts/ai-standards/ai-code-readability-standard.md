# AI Code Readability Standard

Technology: AI Standard

## Simple meaning

AI should write code humans can read without guessing.

## Why it exists

Readable code is easier for a learner or teammate to review, change, and trust.

## What AI should do

- Use clear names.
- Use consistent indentation and spacing.
- Avoid clever shortcuts.
- Keep related logic close together.
- Comment the why, not the line-by-line mechanics.
- Prefer readable code over impressive code.

## What AI should avoid

- Dense code dumps.
- Unexplained abstractions.
- Over-commenting lines that already explain themselves.
- Renaming everything for style.

## Before changing code

Find the current goal, the file in scope, and the surrounding code style.

## While writing code

Write the clearest small version that fits the existing code.

## After the change

Explain the important lines and name any tradeoff.

## Human check

The human should be able to read the changed file and explain what each changed block does.

## Related Atlas nodes

- AI Small Patch Standard
- AI Human Review Standard
- Vue ref
- Laravel Controller
