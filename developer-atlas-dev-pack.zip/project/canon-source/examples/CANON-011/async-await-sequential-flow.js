async function findCustomer(customerId) {
  return { id: customerId, email: "  ADA@EXAMPLE.COM " };
}

async function saveCustomerEmail(customerId, email) {
  return { customerId, email, saved: true };
}

function normalizeEmail(email) {
  return email.trim().toLowerCase();
}

module.exports = async function runAsyncAwaitSequentialFlow() {
  const customer = await findCustomer(42);
  const normalizedEmail = normalizeEmail(customer.email);
  const saved = await saveCustomerEmail(customer.id, normalizedEmail);

  if (saved.email !== "ada@example.com") {
    throw new Error("async/await sequence did not preserve the transformed email.");
  }

  return saved;
};
