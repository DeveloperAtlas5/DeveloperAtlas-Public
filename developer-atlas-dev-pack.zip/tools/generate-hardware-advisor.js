const fs = require("fs");
const path = require("path");
const {
  hardwareOutputDir,
  ensureHardwareOutputDir,
  readHardwareNodes,
  readWorkloadProfiles
} = require("./hardware-utils");

function main() {
  const nodes = readHardwareNodes().map((record) => record.node);
  const workloads = readWorkloadProfiles().map((record) => record.workload);
  const advice = buildAdvice(nodes, workloads);

  ensureHardwareOutputDir();
  fs.writeFileSync(
    path.join(hardwareOutputDir, "workload-advice.md"),
    toMarkdown(advice)
  );

  console.log(`Generated output/hardware/workload-advice.md for ${workloads.length} workload profile(s).`);
}

function buildAdvice(nodes, workloads) {
  return workloads
    .sort((a, b) => b.estimated_risk_of_wrong_purchase - a.estimated_risk_of_wrong_purchase)
    .map((workload) => {
      const relatedNodes = nodes
        .filter((node) => (node.related_workloads || []).includes(workload.workload_id))
        .sort((a, b) => b.upgrade_priority - a.upgrade_priority || a.title.localeCompare(b.title));

      return {
        workload_id: workload.workload_id,
        goal: workload.goal,
        audience: workload.audience,
        risk: workload.estimated_risk_of_wrong_purchase,
        priority_order: workload.priority_order,
        local_vs_cloud_guidance: workload.local_vs_cloud_guidance,
        recommended_hardware_nodes: relatedNodes.map((node) => ({
          id: node.id,
          title: node.title,
          upgrade_priority: node.upgrade_priority,
          tradeoffs: node.tradeoffs.slice(0, 2)
        })),
        upgrade_path: workload.upgrade_path,
        common_mistakes: workload.common_mistakes
      };
    });
}

function toMarkdown(advice) {
  const lines = [
    "# Atlas Hardware Workload Advice",
    "",
    "Hardware advice is workload-based and avoids specific current prices, stores, or hype-driven product picks."
  ];

  for (const workload of advice) {
    lines.push(
      "",
      `## ${workload.workload_id}`,
      "",
      `Goal: ${workload.goal}`,
      `Audience: ${workload.audience}`,
      `Wrong-purchase risk: ${workload.risk}/100`,
      "",
      "### Priority Order",
      "",
      ...workload.priority_order.map((item) => `- ${item}`),
      "",
      "### Recommended Hardware Nodes",
      "",
      ...formatHardwareNodes(workload.recommended_hardware_nodes),
      "",
      "### Local vs Cloud",
      "",
      workload.local_vs_cloud_guidance,
      "",
      "### Upgrade Path",
      "",
      ...workload.upgrade_path.map((item) => `- ${item}`),
      "",
      "### Common Mistakes",
      "",
      ...workload.common_mistakes.map((item) => `- ${item}`)
    );
  }

  return `${lines.join("\n")}\n`;
}

function formatHardwareNodes(nodes) {
  if (!nodes.length) return ["- No related hardware nodes yet."];

  return nodes.map((node) => {
    return `- ${node.id} (${node.title}, priority ${node.upgrade_priority}/5): ${node.tradeoffs.join(" ")}`;
  });
}

main();
