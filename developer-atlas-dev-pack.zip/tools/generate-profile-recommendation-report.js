const fs = require("fs");
const path = require("path");
const {
  rootDir
} = require("./content-utils");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getSkillArea
} = require("./learning-utils");

const profilesDir = path.join(rootDir, "learning", "profiles");
const personalizedDir = path.join(learningOutputDir, "personalized");

const gapRecommendations = {
  "JavaScript Arrays": [
    "CANON-012: Object.keys() vs Object.values() vs Object.entries()",
    "CANON-011: async vs await vs Promise.then()"
  ],
  "Vue Reactivity": [
    "CANON-013: v-for keys decision guide",
    "CANON-011: async vs await vs Promise.then()"
  ],
  "Vue Directives": [
    "CANON-013: v-for keys decision guide"
  ],
  "JavaScript Async": [
    "CANON-011: async vs await vs Promise.then()"
  ],
  "CSS Layout": [
    "CSS margin vs padding decision guide",
    "CSS position relative vs absolute"
  ],
  "SQL Fundamentals": [
    "CANON-015: SQL WHERE vs HAVING"
  ]
};

function main() {
  const profiles = readProfiles();
  const plans = readPlans();
  const entries = readCanonIndex().entries || [];
  const entriesByCanonId = new Map(entries.map((entry) => [entry.canon_id, entry]));

  const recommendedCounts = new Map();
  const weakCounts = new Map();
  const knownCounts = new Map();
  const skippedCounts = new Map();
  const skillCoverage = new Map();

  for (const profile of profiles) {
    incrementSkill(skillCoverage, profile.target_skill_area, "target_profiles");
    for (const node of profile.weak_nodes || []) increment(weakCounts, node);
    for (const node of profile.known_nodes || []) increment(knownCounts, node);
  }

  for (const plan of plans) {
    for (const item of plan.recommended_next_nodes || []) {
      increment(recommendedCounts, item.canon_id);
      incrementSkill(skillCoverage, item.skill_area, "recommended_nodes");
    }
    for (const item of plan.skipped_known_nodes || []) {
      increment(skippedCounts, item.canon_id);
      const entry = entriesByCanonId.get(item.canon_id);
      if (entry) incrementSkill(skillCoverage, getSkillArea(entry), "skipped_nodes");
    }
  }

  const averageAvailableMinutes = profiles.length
    ? profiles.reduce((sum, profile) => sum + Number(profile.available_minutes || 0), 0) / profiles.length
    : 0;

  const report = {
    generated_at: new Date().toISOString(),
    profiles_processed: profiles.length,
    plans_processed: plans.length,
    most_common_recommended_nodes: toRankedNodes(recommendedCounts, entriesByCanonId),
    most_common_weak_nodes: toRankedNodes(weakCounts, entriesByCanonId),
    most_common_known_nodes: toRankedNodes(knownCounts, entriesByCanonId),
    most_common_skipped_nodes: toRankedNodes(skippedCounts, entriesByCanonId),
    coverage_by_skill_area: toSkillCoverage(skillCoverage),
    average_available_minutes: Number(averageAvailableMinutes.toFixed(1)),
    recommended_next_canon_nodes_to_create: recommendNextCanonNodes(skillCoverage, recommendedCounts, weakCounts),
    recommended_learning_improvements: [
      "Add profile-level prerequisites so plans can explain why a node was not selected yet.",
      "Add deterministic plan difficulty scoring across selected practice tasks.",
      "Add more profiles for SQL, CSS layout, and JavaScript async learners.",
      "Track completed mastery proofs separately from completed practice tasks."
    ]
  };

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "profile-recommendation-report.json"), `${JSON.stringify(report, null, 2)}\n`);
  fs.writeFileSync(path.join(learningOutputDir, "profile-recommendation-report.md"), toMarkdown(report));

  console.log(`Generated output/learning/profile-recommendation-report.json and output/learning/profile-recommendation-report.md for ${profiles.length} profiles.`);
}

function readProfiles() {
  if (!fs.existsSync(profilesDir)) return [];
  return fs.readdirSync(profilesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => JSON.parse(fs.readFileSync(path.join(profilesDir, fileName), "utf8")));
}

function readPlans() {
  if (!fs.existsSync(personalizedDir)) return [];
  return fs.readdirSync(personalizedDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => JSON.parse(fs.readFileSync(path.join(personalizedDir, fileName), "utf8")));
}

function increment(map, key) {
  map.set(key, (map.get(key) || 0) + 1);
}

function incrementSkill(map, skillArea, field) {
  if (!map.has(skillArea)) {
    map.set(skillArea, {
      skill_area: skillArea,
      target_profiles: 0,
      recommended_nodes: 0,
      skipped_nodes: 0
    });
  }
  map.get(skillArea)[field] += 1;
}

function toRankedNodes(counts, entriesByCanonId) {
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([canon_id, count]) => {
      const entry = entriesByCanonId.get(canon_id);
      return {
        canon_id,
        title: entry?.title || canon_id,
        skill_area: entry ? getSkillArea(entry) : "Unknown",
        count
      };
    });
}

function toSkillCoverage(skillCoverage) {
  return [...skillCoverage.values()].sort((a, b) => a.skill_area.localeCompare(b.skill_area));
}

function recommendNextCanonNodes(skillCoverage, recommendedCounts, weakCounts) {
  const pressure = [...skillCoverage.values()]
    .map((skill) => ({
      skill_area: skill.skill_area,
      pressure: skill.target_profiles + skill.recommended_nodes + skill.skipped_nodes
    }))
    .sort((a, b) => b.pressure - a.pressure || a.skill_area.localeCompare(b.skill_area));

  const recommendations = [];
  for (const item of pressure) {
    for (const candidate of gapRecommendations[item.skill_area] || []) {
      if (!recommendations.includes(candidate)) recommendations.push(candidate);
      if (recommendations.length >= 5) return recommendations;
    }
  }

  if (recommendedCounts.size || weakCounts.size) {
    for (const fallback of ["CANON-011: async vs await vs Promise.then()", "CANON-012: Object.keys() vs Object.values() vs Object.entries()", "CANON-013: v-for keys decision guide"]) {
      if (!recommendations.includes(fallback)) recommendations.push(fallback);
      if (recommendations.length >= 5) break;
    }
  }

  return recommendations;
}

function toMarkdown(report) {
  const lines = [
    "# Profile Recommendation Report",
    "",
    `Profiles processed: ${report.profiles_processed}`,
    `Personalized plans processed: ${report.plans_processed}`,
    `Average available minutes: ${report.average_available_minutes}`,
    "",
    "## Most Common Recommended Nodes",
    ""
  ];

  lines.push(...formatRanked(report.most_common_recommended_nodes));
  lines.push("", "## Most Common Weak Nodes", "");
  lines.push(...formatRanked(report.most_common_weak_nodes));
  lines.push("", "## Most Common Known Nodes", "");
  lines.push(...formatRanked(report.most_common_known_nodes));
  lines.push("", "## Most Common Skipped Nodes", "");
  lines.push(...formatRanked(report.most_common_skipped_nodes));
  lines.push("", "## Coverage By Skill Area", "");
  lines.push("| Skill Area | Target Profiles | Recommended Nodes | Skipped Nodes |");
  lines.push("| --- | ---: | ---: | ---: |");
  for (const item of report.coverage_by_skill_area) {
    lines.push(`| ${item.skill_area} | ${item.target_profiles} | ${item.recommended_nodes} | ${item.skipped_nodes} |`);
  }
  lines.push("", "## Recommended Next Canon Nodes To Create", "");
  lines.push(...formatList(report.recommended_next_canon_nodes_to_create));
  lines.push("", "## Recommended Learning Improvements", "");
  lines.push(...formatList(report.recommended_learning_improvements));

  return `${lines.join("\n")}\n`;
}

function formatRanked(items) {
  return items.length
    ? items.map((item) => `- ${item.canon_id}: ${item.title} (${item.skill_area}) - ${item.count}`)
    : ["- None"];
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();

