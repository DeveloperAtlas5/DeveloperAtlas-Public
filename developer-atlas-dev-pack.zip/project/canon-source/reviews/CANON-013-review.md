# CANON-013 Review

Canon ID: CANON-013
Node ID: canon.vue.directive.v-for-keys
Title: v-for keys decision guide
Status: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Explains Vue key identity, stable keys, index-key risks, duplicate keys, and key placement for `<template v-for>`.
- Edge cases: Covers sortable/filterable lists, stateful child components, inputs, random keys, duplicate keys, and static-list exceptions.
- Evidence: Uses official Vue list rendering and key attribute documentation.
- Verification: Four deterministic examples pass.

## Educational Review

- Mental model: Strong "name tag" and "item, not current seat" framing.
- Beginner clarity: Gives direct rules for IDs, dynamic lists, stateful rows, and static exceptions.
- Progression: Moves from identity to stable keys, index risks, debugging, and production review.
- Exercises: Covers beginner, intermediate, and advanced practice.

## AI Readiness Review

- Code generation guidance: Strong defaults for `item.id`, warnings for dynamic index keys, duplicate keys, and random keys.
- Machine readability: Stable Canon headings and scorecard structure.
- Relationship quality: Connects to `v-for`, `v-if`, `v-model`, and Vue reactivity Canon nodes.

## Engineering Review

- Production examples: Includes editable rows, transitions, static policy lists, and template loops.
- Debugging support: Checklist maps directly to identity drift and remount problems.
- Trade-offs: Clear distinction between correctness, patching behavior, and acceptable static index usage.

## Remaining Gold Gaps

- Named human reviewer sign-off is still required before final Gold status.
