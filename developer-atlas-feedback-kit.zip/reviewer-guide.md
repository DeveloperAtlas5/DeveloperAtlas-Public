# Developer Atlas Reviewer Guide

Thank you for reviewing the Developer Atlas MVP demo.

## Start Here

1. Open the demo package folder if you received it:
   `../developer-atlas-mvp-demo/site/index.html`
2. If you received the zip, unzip `developer-atlas-mvp-demo.zip` first.
3. Spend 10 to 20 minutes reviewing the landing page and two or three demo files.
4. Fill out the form that best matches your perspective.

## Recommended Forms

- General tester: `tester-feedback-form.md`
- Mentor, advisor, or collaborator: `mentor-review-form.md`
- Working developer: `developer-review-form.md`
- AI assistant workflow tester: `ai-context-test-form.md`

## What To Focus On

- Can you understand the product in 30 seconds?
- Does the demo feel credible?
- Which part feels most valuable?
- Which part is confusing or too broad?
- Would Setup/Recovery, AI Context, or Roadmaps solve a real problem for you?
- What is missing before you would use or recommend it?

## How To Return Feedback

Fill in the Markdown file directly and send it back, or paste your answers into a message. Short, specific notes are more useful than polished essays.
