const {
  fs,
  path,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionDashboardPath,
  startHerePath,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  inheritedWarningBurnDownReportPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedMissionDashboardPath,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  packagedInheritedWarningBurnDownReportPath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange
} = require("./shared-validator-utils");
const { analyzeContent } = require("../quality-utils");

function validateBeginnerOrientation(errors, warnings) {
  validateBeginnerOrientationFile(
    beginnerOrientationPath,
    "output/experience/beginner-orientation.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateBeginnerOrientationFile(
    packagedBeginnerOrientationPath,
    "output/share/developer-atlas-mvp-demo/help/beginner-orientation.md",
    errors,
    warnings,
    true
  );
}

function validateBeginnerOrientationFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing beginner orientation`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Beginner Orientation",
    "## What this package is",
    "## Where to start",
    "## Where the mission lives",
    "## Where your app code usually lives",
    "## What App.vue means",
    "## Where to run terminal commands",
    "## What package.json means",
    "## What to ignore for now",
    "## Tiny glossary"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/public alpha demo of Developer Atlas/i, "public alpha demo explanation"],
    [/mission[\s\S]*recovery guidance[\s\S]*completion checklist[\s\S]*AI-assisted builder view[\s\S]*feedback flow/i, "package review targets"],
    [/This package explains the mission[\s\S]*actual Vue app files may live in your own Vue project folder|Atlas package = read, guide, and reference[\s\S]*Vue todo project = code and workspace/i, "guidance files versus actual app folder"],
    [/Atlas package = read, guide, and reference[\s\S]*Vue todo project = code and workspace[\s\S]*Do not edit files inside the Atlas package unless a mission explicitly tells you to/i, "workspace boundary explanation"],
    [/START_HERE\.md[\s\S]*Start there first[\s\S]*which mission file to open/i, "START_HERE pointer"],
    [/main learner-facing mission[\s\S]*mission\/today-mission-surface\.md|mission\/today-mission-surface\.md[\s\S]*main learner-facing mission/i, "mission surface pointer"],
    [/optional AI-assisted builder view[\s\S]*mission\/today-mission-surface\.vibe\.md|mission\/today-mission-surface\.vibe\.md[\s\S]*optional AI-assisted builder view/i, "optional vibe pointer"],
    [/src\/App\.vue[\s\S]*src\/components\//i, "Vue app code locations"],
    [/first likely file to edit[\s\S]*src\/App\.vue/i, "first likely file"],
    [/If your project is very small, App\.vue may contain most of the todo app/i, "small App.vue guidance"],
    [/If your project already has components, the todo item may live in src\/components\//i, "components guidance"],
    [/App\.vue is usually the main Vue component[\s\S]*main app layout and state/i, "App.vue explanation"],
    [/App\.vue is the first place to check[\s\S]*todo list state often starts there/i, "App.vue mission relevance"],
    [/Terminal commands should usually be run from the root folder of the Vue project/i, "terminal root folder guidance"],
    [/npm install[\s\S]*npm run dev/i, "npm command examples"],
    [/folder that contains:[\s\S]*package\.json/i, "package.json command folder"],
    [/cannot find a script or package file[\s\S]*may not be inside the project folder yet/i, "calm terminal folder guidance"],
    [/package\.json is the file that tells Node\/npm what scripts and packages the project uses/i, "package.json explanation"],
    [/see package\.json in the folder[\s\S]*right place to run npm commands/i, "package.json location hint"],
    [/Feedback reports[\s\S]*Technical reports[\s\S]*Validation files[\s\S]*Source scripts[\s\S]*Package generation scripts[\s\S]*Internal project-owner notes/i, "ignore-for-now list"],
    [/START_HERE\.md[\s\S]*mission\/today-mission-surface\.md[\s\S]*completion checklist[\s\S]*after-mission reflection/i, "only need list"],
    [/help\/terminal-confidence-guide\.md/i, "terminal confidence guide pointer"],
    [/help\/vue-concept-cards\.md/i, "Vue concept cards pointer"],
    [/\*\*Vue\*\*[\s\S]*\*\*App\.vue\*\*[\s\S]*\*\*Component\*\*[\s\S]*\*\*Vue state\*\*[\s\S]*\*\*localStorage\*\*[\s\S]*\*\*sessionStorage\*\*[\s\S]*\*\*Terminal\*\*[\s\S]*\*\*Project folder\*\*[\s\S]*\*\*package\.json\*\*[\s\S]*\*\*npm\*\*/i, "tiny glossary terms"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateVueConceptCards(errors, warnings) {
  validateVueConceptCardsFile(
    vueConceptCardsPath,
    "output/experience/vue-concept-cards.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateVueConceptCardsFile(
    packagedVueConceptCardsPath,
    "output/share/developer-atlas-mvp-demo/help/vue-concept-cards.md",
    errors,
    warnings,
    true
  );
}

function validateVueConceptCardsFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing Vue concept cards`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Vue Concept Cards",
    "## How to use this file",
    "## Vue state",
    "## ref()",
    "## reactive()",
    "## v-model",
    "## v-for",
    "## :key",
    "## computed",
    "## localStorage and Vue state",
    "## What to remember today"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/This file is optional[\s\S]*Open this only if the mission uses a Vue word that feels unclear/i, "optional usage guidance"],
    [/You do not need to memorize everything today/i, "no-memorization guidance"],
    [/Vue state is the data your app is using right now[\s\S]*current todo list[\s\S]*text typed into an input/i, "Vue state explanation"],
    [/State changes when the user interacts[\s\S]*screen updates when state changes[\s\S]*Browser storage is separate from Vue state/i, "state behavior and storage separation"],
    [/`ref\(\)` is often used for one reactive value[\s\S]*input text[\s\S]*filter value[\s\S]*boolean toggle[\s\S]*`ref\(\[\]\)`[\s\S]*`\.value`[\s\S]*const newTodo = ref\(''\)/i, "ref explanation"],
    [/`reactive\(\)` is often used for an object with multiple related fields[\s\S]*form object[\s\S]*settings object[\s\S]*directly, not with `\.value`[\s\S]*const form = reactive\(\{ title: '', done: false \}\)[\s\S]*may not need both `ref\(\)` and `reactive\(\)`/i, "reactive explanation"],
    [/`v-model` connects an input to Vue state[\s\S]*When the user types, the state updates[\s\S]*<input v-model="newTodo">/i, "v-model explanation"],
    [/`v-for` repeats part of the template for each item in a list[\s\S]*one row per todo[\s\S]*<li v-for="todo in todos">/i, "v-for explanation"],
    [/`:key` gives Vue a stable identity[\s\S]*update the right item[\s\S]*stable id[\s\S]*array index[\s\S]*reordered or deleted[\s\S]*:key="todo\.id"/i, ":key explanation"],
    [/`computed` creates a derived value from existing state[\s\S]*filtered todos[\s\S]*completed count[\s\S]*remaining count[\s\S]*computed\(\(\) => todos\.value\.filter/i, "computed explanation"],
    [/Vue state controls what the app shows now[\s\S]*localStorage remembers simple non-sensitive data after refresh[\s\S]*save the state to localStorage[\s\S]*Load from localStorage[\s\S]*JSON\.stringify\(\)[\s\S]*JSON\.parse\(\)/i, "localStorage and Vue state explanation"],
    [/Do not store sensitive data in localStorage or sessionStorage/i, "sensitive data warning"],
    [/Vue state is the app's current data[\s\S]*`ref\(\)` is common for one value[\s\S]*`reactive\(\)` is common for an object[\s\S]*`v-model` connects inputs to state[\s\S]*`v-for` shows lists[\s\S]*`:key` helps Vue track list items[\s\S]*`computed` calculates values from state[\s\S]*localStorage can restore non-sensitive todo data/i, "what to remember summary"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateTerminalConfidenceGuide(errors, warnings) {
  validateTerminalConfidenceGuideFile(
    terminalConfidenceGuidePath,
    "output/experience/terminal-confidence-guide.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateTerminalConfidenceGuideFile(
    packagedTerminalConfidenceGuidePath,
    "output/share/developer-atlas-mvp-demo/help/terminal-confidence-guide.md",
    errors,
    warnings,
    true
  );
}

function validateTerminalConfidenceGuideFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing terminal confidence guide`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Terminal Confidence Guide",
    "## How to use this file",
    "## What the terminal is",
    "## What folder should I be in?",
    "## How to recognize the project folder",
    "## Common commands for this mission",
    "## If a command does not work",
    "## What messages are normal?",
    "## What to copy when asking for help",
    "## What to remember today"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/This file is optional[\s\S]*Open this only if terminal commands or project folders feel unclear/i, "optional usage guidance"],
    [/You do not need to become a terminal expert today/i, "terminal confidence framing"],
    [/terminal is a place where you type commands for your computer or project/i, "terminal explanation"],
    [/Commands should usually run inside the root folder of the Vue project[\s\S]*folder that contains `package\.json`[\s\S]*npm may not find the project scripts yet/i, "project folder command guidance"],
    [/contains:[\s\S]*`package\.json`[\s\S]*`src\/`[\s\S]*`vite\.config\.js`[\s\S]*`node_modules\/`[\s\S]*`index\.html`/i, "project folder recognition"],
    [/If you see `package\.json`, you are probably near the right place to run npm commands/i, "package.json folder hint"],
    [/npm install[\s\S]*npm run dev/i, "common npm commands"],
    [/`npm install` downloads the project packages/i, "npm install explanation"],
    [/`npm run dev` starts the local development server/i, "npm run dev explanation"],
    [/local address like `http:\/\/localhost:5173`[\s\S]*where the app usually opens in the browser/i, "local server URL behavior"],
    [/Are you in the folder that contains `package\.json`[\s\S]*already run `npm install`[\s\S]*missing script message[\s\S]*another dev server already using the port[\s\S]*useful error line/i, "calm recovery checks"],
    [/The message is information[\s\S]*does not mean you cannot do this/i, "calm terminal reassurance"],
    [/Package install progress[\s\S]*Warnings[\s\S]*local server URL[\s\S]*Port changed because another port is busy/i, "normal messages"],
    [/Warnings are not always blockers[\s\S]*app starts[\s\S]*mission visible win works/i, "warnings are not always blockers"],
    [/command you ran[\s\S]*folder path shown in the terminal[\s\S]*last 10-20 lines[\s\S]*expected to happen[\s\S]*happened instead/i, "what to copy for help"],
    [/I am working on a Vue beginner project[\s\S]*terminal command did not work as expected[\s\S]*command I ran[\s\S]*folder I was in[\s\S]*last part of the terminal output[\s\S]*one step at a time[\s\S]*do not add new project features/i, "copy-paste help prompt"],
    [/Run Vue project commands from the folder that contains `package\.json`[\s\S]*`npm install` gets the project packages[\s\S]*`npm run dev` starts the local app[\s\S]*Warnings are not always blockers[\s\S]*Copy the command, folder path, and last terminal lines/i, "what to remember summary"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateAlphaFocusLock(errors, warnings) {
  validateAlphaFocusLockFile(
    alphaFocusLockPath,
    "output/experience/alpha-focus-lock.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateAlphaFocusLockFile(
    packagedAlphaFocusLockPath,
    "output/share/developer-atlas-mvp-demo/reviewer/alpha-focus-lock.md",
    errors,
    warnings,
    true
  );
}

function validateAlphaFocusLockFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing alpha focus lock`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Developer Atlas Alpha Focus Lock",
    "## Summary",
    "## Core Alpha Bet",
    "## Current Winning Slice",
    "## Build Now",
    "## Build Next",
    "## Not Yet",
    "## Do Not Build Before Feedback",
    "## Product Risks",
    "## Content Strategy",
    "## UX Strategy",
    "## Business Strategy",
    "## Alpha Success Metrics",
    "## Expansion Triggers",
    "## Next Action"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/protect Atlas from becoming too broad before the first real tester loop/i, "focus-lock purpose"],
    [/Atlas can help rookie-to-junior developers and AI-assisted builders make progress without getting lost/i, "core alpha bet"],
    [/Rookie Vue Todo \+ browser storage persistence \+ recovery \+ AI-scoped mission guidance/i, "current winning slice"],
    [/visible win[\s\S]*beginner-friendly[\s\S]*AI-assisted builders[\s\S]*mission, recovery, placement, checklist, and reflection[\s\S]*narrow enough to validate/i, "winning-slice rationale"],
    [/Build Now[\s\S]*beginner setup orientation[\s\S]*Vue concept clarity for the current Rookie Vue slice[\s\S]*terminal confidence for the current Rookie Vue slice[\s\S]*package simplification and navigation clarity[\s\S]*mission dashboard \/ package lightness[\s\S]*beginner setup clarity[\s\S]*file\/folder orientation[\s\S]*terminal command clarity[\s\S]*ref\(\)[\s\S]*reactive\(\)[\s\S]*:key[\s\S]*mission surface polish[\s\S]*internal terminology cleanup[\s\S]*real tester feedback[\s\S]*Rookie Vue path/i, "build-now list"],
    [/Build Now[\s\S]*mission scannability and redundancy polish/i, "mission scannability build-now item"],
    [/Build Now[\s\S]*dashboard filtering for the user's current goal/i, "goal-based dashboard filtering build-now item"],
    [/Build Now[\s\S]*recommended first action appears before optional paths/i, "dashboard simplification build-now item"],
    [/Build Now[\s\S]*smallest first-time quick start[\s\S]*Harden only Canon nodes used by Missions 1-3/i, "quick-start and hardened Canon build-now items"],
    [/Build Now[\s\S]*Clarify where learners read and where they code/i, "workspace clarity build-now item"],
    [/Build Now[\s\S]*Harden the AI-assisted path for Missions 1-3 without adding product scope/i, "AI-assisted hardening build-now item"],
    [/Mission 2 clarity polish is allowed because it improves the current Rookie Vue progression path without adding a new product line/i, "Mission 2 clarity polish focus-lock note"],
    [/Mission 2 visual bridge and stricter AI guardrails are allowed because they improve the current Rookie Vue progression path without adding a new product line/i, "Mission 2 visual bridge focus-lock note"],
    [/Mission 3 is allowed because it extends the current Rookie Vue Todo path and tests progression without adding a new product line/i, "Mission 3 focus-lock note"],
    [/Goal-based dashboard filtering is allowed because it reduces friction in the current Rookie Vue path without adding a new product line[\s\S]*Progressive visibility: show only what helps the user's current goal/i, "goal-based dashboard filtering focus-lock note"],
    [/Dashboard simplification is allowed because it reduces choice pressure in the current Rookie Vue path without adding a new product line[\s\S]*The first screen should show the next useful action, not the whole product/i, "dashboard simplification focus-lock note"],
    [/Quick-start and hardened Canon integration is allowed because it supports the current Rookie Vue path without adding a new product line[\s\S]*Harden only Canon nodes used by Missions 1-3 before expanding the backlog/i, "quick-start and hardened Canon focus-lock note"],
    [/Accessibility foundation work is allowed because it improves the current Rookie Vue learner experience without adding a new product line/i, "accessibility foundation focus-lock note"],
    [/Workspace clarity is allowed because it reduces friction in the current Rookie Vue path without adding scope/i, "workspace clarity focus-lock note"],
    [/AI-assisted path hardening is allowed because it supports the current Rookie Vue path without adding new product scope/i, "AI-assisted hardening focus-lock note"],
    [/Learner-first package structure is allowed because it reduces first-impression file overwhelm without adding learner scope/i, "learner-first package structure focus-lock note"],
    [/Build Next[\s\S]*Next Rookie Vue mission[\s\S]*concept clarity cards[\s\S]*site preview flow[\s\S]*code placement examples[\s\S]*feedback triage[\s\S]*additional stack/i, "build-next list"],
    [/Not Yet[\s\S]*Enterprise\/team plans[\s\S]*Private Canon[\s\S]*Marketplace[\s\S]*Certifications[\s\S]*University partnerships[\s\S]*Full IDE extension[\s\S]*CLI[\s\S]*API\/data licensing[\s\S]*Public Canon contribution system[\s\S]*Multi-stack expansion[\s\S]*Dashboards\/accounts[\s\S]*Analytics infrastructure/i, "not-yet list"],
    [/Do not build these before testing with 3-5 real users[\s\S]*New product lines[\s\S]*New intelligence systems[\s\S]*Large roadmaps[\s\S]*Enterprise features[\s\S]*Certification[\s\S]*Marketplace[\s\S]*Full IDE extension[\s\S]*Big UI redesign[\s\S]*Large Canon expansion/i, "do-not-build-before-feedback list"],
    [/updated feedback supports beginner orientation as the next narrow fix[\s\S]*does not justify expanding into new product lines yet/i, "beginner-orientation narrow-fix note"],
    [/latest simulated feedback supports terminal confidence as the next narrow fix[\s\S]*does not justify starting IDE extension work yet/i, "terminal-confidence narrow-fix note"],
    [/After adding beginner, Vue concept, and terminal support[\s\S]*reduce package navigation friction[\s\S]*rather than adding more guidance files/i, "package simplification narrow-fix note"],
    [/50-tester simulation supports a lighter package entry point[\s\S]*before adding more Canon or new product lines/i, "dashboard package-lightness note"],
    [/After the dashboard and package simplification improvements[\s\S]*next step is real tester evidence[\s\S]*not more support files/i, "real tester evidence next-step note"],
    [/Latest feedback supports polishing the current alpha flow, not adding more content or product lines/i, "latest feedback polish note"],
    [/Product Risks[\s\S]*Scope creep[\s\S]*Content bottleneck[\s\S]*Document-heavy UX[\s\S]*Internal terminology leakage[\s\S]*Maintenance burden[\s\S]*Unclear distribution[\s\S]*Too much architecture before usage proof/i, "product risks"],
    [/Canon quality matters more than Canon quantity[\s\S]*Do not chase node count[\s\S]*Add Canon only when a mission needs it[\s\S]*one high-quality mission loop[\s\S]*tester confusion/i, "content strategy"],
    [/The user should see one clear mission[\s\S]*Internal systems should stay invisible[\s\S]*Supporting files should be optional[\s\S]*Reduce document heaviness[\s\S]*mission surface should become the future product surface/i, "UX strategy"],
    [/Do not optimize for fundraising yet[\s\S]*Do not build enterprise before usage proof[\s\S]*individual learners and AI-assisted builders[\s\S]*Pro and small team plans[\s\S]*small tester loops[\s\S]*learning communities[\s\S]*developer Discords/i, "business strategy"],
    [/tester knows what to open first[\s\S]*tester knows what to do next[\s\S]*visible win[\s\S]*confidence delta increases[\s\S]*Recovery section helps[\s\S]*Vibe-coder view prevents AI over-expansion[\s\S]*Tester would use Atlas again[\s\S]*Repeated confusion decreases/i, "alpha success metrics"],
    [/Only expand beyond Rookie Vue when[\s\S]*5-10 real testers complete the loop[\s\S]*understand the mission without explanation[\s\S]*60-70% report confidence improvement[\s\S]*beginner confusion is addressed[\s\S]*accept\/reject guidance is useful[\s\S]*no longer feels too document-heavy/i, "expansion triggers"],
    [/Send the current package to 3-5 real testers before adding new product lines/i, "tester-first next action"],
    [/Use real feedback to choose between beginner orientation, Vue concept clarity, or mission surface simplification/i, "feedback-based next fix"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validatePublicAlphaReadinessReport(errors, warnings) {
  validatePublicAlphaReadinessReportFile(
    publicAlphaReadinessReportPath,
    "output/experience/public-alpha-readiness-report.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validatePublicAlphaReadinessReportFile(
    packagedPublicAlphaReadinessReportPath,
    "output/share/developer-atlas-mvp-demo/reviewer/public-alpha-readiness-report.md",
    errors,
    warnings,
    true
  );
}

function validatePublicAlphaReadinessReportFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing public alpha readiness report`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Developer Atlas Public Alpha Readiness Report",
    "## Summary",
    "## Release Decision",
    "## Package Entry Point",
    "## Primary Tester Path",
    "## Optional Vibe-Coder Path",
    "## Feedback Loop",
    "## Handoff Readiness",
    "## Package Clarity Check",
    "## Risk List",
    "## Recommended Tester Group",
    "## What To Send",
    "## Next Action"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/ready_for_small_alpha/i, "release decision"],
    [/3-5 testers/i, "small alpha tester count"],
    [/START_HERE\.md/i, "START_HERE entry point"],
    [/mission\/[\s\S]*help\/[\s\S]*reviewer\//i, "grouped package structure"],
    [/mission-dashboard\.html[\s\S]*optional visual overview/i, "mission dashboard overview"],
    [/START_HERE\.md -> mission\/today-mission-surface\.md -> after-mission reflection/i, "primary tester path"],
    [/START_HERE\.md -> mission\/today-mission-surface\.vibe\.md -> after-mission reflection/i, "optional vibe-coder path"],
    [/After-mission reflection[\s\S]*mission\/mission-feedback-template\.md[\s\S]*reviewer\/tester-feedback-report\.md/i, "feedback loop"],
    [/reviewer\/tester-handoff-messages\.md/i, "handoff messages"],
    [/alpha-focus-lock\.md/i, "alpha focus lock mention"],
    [/terminal and folder orientation/i, "beginner terminal/folder orientation gap"],
    [/terminal confidence/i, "terminal confidence support gap"],
    [/Vue concept clarity/i, "Vue concept clarity gap"],
    [/\[x\] Tester has one clear start file[\s\S]*\[x\] Project owner has a way to turn feedback into fixes/i, "package clarity checklist"],
    [/Risk List[\s\S]*markdown demo[\s\S]*code examples[\s\S]*tool-specific prompts[\s\S]*supporting files[\s\S]*Real tester data has not been collected yet/i, "risk list"],
    [/complete beginner[\s\S]*Rookie Vue learner[\s\S]*AI-assisted builder[\s\S]*mentor or technical reviewer[\s\S]*junior developer/i, "recommended tester group"],
    [/developer-atlas-mvp-demo\.zip[\s\S]*tester-handoff-messages\.md[\s\S]*START_HERE\.md/i, "what to send"],
    [/Send the demo to 3-5 testers and collect feedback before adding more features/i, "next action"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateTesterHandoffMessages(errors, warnings) {
  validateTesterHandoffMessagesFile(
    testerHandoffMessagesPath,
    "output/experience/tester-handoff-messages.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateTesterHandoffMessagesFile(
    packagedTesterHandoffMessagesPath,
    "output/share/developer-atlas-mvp-demo/reviewer/tester-handoff-messages.md",
    errors,
    warnings,
    true
  );
}

function validateTesterHandoffMessagesFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing tester handoff messages`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Developer Atlas Tester Handoff Messages",
    "## Purpose",
    "## Short invite message",
    "## Longer invite message",
    "## Message for complete beginners",
    "## Message for Rookie Vue learners",
    "## Message for AI-assisted builders",
    "## Message for mentors or technical reviewers",
    "## Follow-up message after testing",
    "## What feedback to ask for"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/START_HERE\.md/i, "START_HERE guidance"],
    [/10 minutes|10-minute/i, "short review time"],
    [/Short invite message[\s\S]*clear[\s\S]*confusing/i, "short invite content"],
    [/Longer invite message[\s\S]*default learner view[\s\S]*AI-assisted builder view[\s\S]*10-minute[\s\S]*30 minutes/i, "longer invite content"],
    [/complete beginners[\s\S]*where to start[\s\S]*words felt confusing[\s\S]*checklist/i, "complete beginner message"],
    [/Rookie Vue learners[\s\S]*doable[\s\S]*placement guidance[\s\S]*browser storage/i, "Rookie Vue learner message"],
    [/AI-assisted builders[\s\S]*AI prompt[\s\S]*accept\/reject[\s\S]*file-scope[\s\S]*explain-it-back/i, "AI-assisted builder message"],
    [/mentors or technical reviewers[\s\S]*easy to test[\s\S]*one calm mission[\s\S]*product fixes[\s\S]*internal machinery/i, "mentor or technical reviewer message"],
    [/Follow-up message after testing[\s\S]*one thing that felt clear[\s\S]*one thing that felt confusing[\s\S]*use Atlas again[\s\S]*more useful/i, "follow-up message"],
    [/What feedback to ask for[\s\S]*Did you know what to do next[\s\S]*placement guidance[\s\S]*completion checklist[\s\S]*vibe-coder view/i, "useful feedback questions"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateTesterFeedbackReport(errors, warnings) {
  validateTesterFeedbackReportFile(
    testerFeedbackReportPath,
    "output/experience/tester-feedback-report.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateTesterFeedbackReportFile(
    packagedTesterFeedbackReportPath,
    "output/share/developer-atlas-mvp-demo/reviewer/tester-feedback-report.md",
    errors,
    warnings,
    true
  );
}

function validateTesterFeedbackReportFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing tester feedback report`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Developer Atlas Tester Feedback Report",
    "## Summary",
    "## Updated Simulated Alpha Feedback Summary",
    "## Latest Feedback-Driven Polish Target",
    "## Mission 2 Clarity Feedback",
    "## Mission 2 Visual Bridge Feedback",
    "## Mission 3 Progression Hypothesis",
    "## Goal-Based Dashboard Feedback",
    "## Dashboard Simplification Feedback",
    "## Quick Start Feedback",
    "## Hardened Canon Feedback",
    "## Workspace Clarity Feedback",
    "## AI-Assisted Path Feedback",
    "## Package Structure Feedback",
    "## Accessibility Feedback",
    "## Tester Profiles",
    "## Confidence Delta",
    "## Mission Completion",
    "## Recovery Usefulness",
    "## Clarity Findings",
    "## AI-Assisted Builder Findings",
    "## Repeated Confusions",
    "## Suggested Fixes",
    "## Priority Fix List",
    "## Next Phase Recommendation"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/No real tester data has been collected yet/i, "no-real-data disclaimer"],
    [/10 simulated tester reports reviewed[\s\S]*Simulated feedback only[\s\S]*Replace this section after real tester feedback is collected[\s\S]*Simulated feedback should be replaced with real tester feedback after the first tester round/i, "simulated alpha feedback disclaimer"],
    [/Overall sentiment was strongly positive[\s\S]*START_HERE\.md` was clear[\s\S]*Placement guidance was strongly positive[\s\S]*Completion checklist was strongly positive[\s\S]*Recovery guidance was positive[\s\S]*Vibe-coder view was strongly positive[\s\S]*terminal commands and folder navigation[\s\S]*terminal confidence gap[\s\S]*Vue concept clarity[\s\S]*visual entry point/i, "updated simulated alpha trends"],
    [/Latest Feedback-Driven Polish Target[\s\S]*Users like the content[\s\S]*scan speed and reduced document weight[\s\S]*Quick Start was added[\s\S]*Vibe reject rules were strengthened/i, "latest feedback-driven polish target"],
    [/Mission 2 Clarity Feedback[\s\S]*Mission 2 felt natural for many testers[\s\S]*Complete beginners found it slightly advanced[\s\S]*Props\/emits clicked for many Rookie Vue learners[\s\S]*AI-assisted builders still saw AI attempt over-engineering[\s\S]*tiny file map, beginner-safe path, stronger placement guidance, and stricter AI reject rules[\s\S]*not broad market evidence/i, "Mission 2 clarity feedback"],
    [/Mission 2 Visual Bridge Feedback[\s\S]*Testers liked Mission 2[\s\S]*Complete beginners still found it a bigger jump[\s\S]*tiny parent-child diagram and clearer props-down\/events-up phrase[\s\S]*strengthen rejection of extra components, folder restructuring, stores, composables, styling side quests, and unrelated renaming[\s\S]*not broad market evidence/i, "Mission 2 visual bridge feedback"],
    [/Mission 3 Progression Hypothesis[\s\S]*learners can continue from component extraction into a small display component[\s\S]*reinforce props without adding new architecture[\s\S]*natural next step after Mission 2[\s\S]*TodoStats make props clearer[\s\S]*app feel more useful[\s\S]*too easy, too hard, or just right[\s\S]*charts, stores, or extra architecture[\s\S]*not broad market evidence/i, "Mission 3 progression hypothesis"],
    [/Goal-Based Dashboard Feedback[\s\S]*goal-based dashboard panels reduce choice pressure[\s\S]*choosing a goal make the package feel easier[\s\S]*too much, too little, or the right amount[\s\S]*which path was for you[\s\S]*pressure to open every file[\s\S]*What almost made you stop/i, "goal-based dashboard feedback"],
    [/Dashboard Simplification Feedback[\s\S]*simplified dashboard lowers choice pressure[\s\S]*recommended first step easy to see[\s\S]*goal buttons feel helpful or still overwhelming[\s\S]*reviewer files are not required for learners[\s\S]*too much, too little, or the right amount[\s\S]*anything almost make you stop/i, "dashboard simplification feedback"],
    [/Quick Start Feedback[\s\S]*first-time-quick-start\.md[\s\S]*easier to begin[\s\S]*read everything[\s\S]*first visible win[\s\S]*almost make you stop/i, "quick start feedback"],
    [/Hardened Canon Feedback[\s\S]*Canon references clarify the mission concepts[\s\S]*optional enough[\s\S]*extra reading pressure/i, "hardened Canon feedback"],
    [/Workspace Clarity Feedback[\s\S]*where to read and where to code[\s\S]*edit the Atlas package or your own Vue project[\s\S]*Atlas is the guide, your Vue project is where you code[\s\S]*almost make you stop/i, "workspace clarity feedback"],
    [/AI-Assisted Path Feedback[\s\S]*AI prompt keep the answer inside the current mission[\s\S]*AI try to add extra architecture[\s\S]*accept\/reject guidance help[\s\S]*explain-it-back step help you understand the change[\s\S]*anything almost make you stop/i, "AI-assisted path feedback"],
    [/Package Structure Feedback[\s\S]*extracted folder feel lighter[\s\S]*mission-dashboard\.html` was the main entry point[\s\S]*which folders were optional[\s\S]*`reviewer\/` feel clearly not required for learners[\s\S]*folder structure almost make you stop/i, "package structure feedback questions"],
    [/Accessibility Feedback[\s\S]*dashboard read-aloud option[\s\S]*clear headings[\s\S]*keyboard-friendly links[\s\S]*audio support[\s\S]*screen readers[\s\S]*zoom[\s\S]*keyboard navigation[\s\S]*future feedback prompt, not broad accessibility validation yet/i, "accessibility feedback tracking"],
    [/Tester liked the package but felt there were many files[\s\S]*main mission to be easier to scan[\s\S]*Add Quick Start sections[\s\S]*label help files as optional[\s\S]*strengthen dashboard hierarchy[\s\S]*main mission and vibe mission must include Quick Start sections[\s\S]*normal testers must still be told they do not need to read every file/i, "Phase 95 suggested fix"],
    [/Before[\s\S]*After[\s\S]*Delta/i, "confidence delta tracking"],
    [/Real Tester Feedback Record[\s\S]*Tester role:[\s\S]*Time spent:[\s\S]*Started from:[\s\S]*Mission clarity:[\s\S]*Help used:[\s\S]*Blocker:[\s\S]*Confidence before:[\s\S]*Confidence after:[\s\S]*Would use again:[\s\S]*Most useful part:[\s\S]*Most confusing part:[\s\S]*Suggested next fix:/i, "real tester feedback record format"],
    [/Tester role[\s\S]*Complete beginner[\s\S]*Rookie Vue learner[\s\S]*AI-assisted builder \/ vibe coder[\s\S]*Mentor or technical reviewer/i, "role-based tester grouping"],
    [/Completed visible win[\s\S]*Partly completed[\s\S]*Not yet completed/i, "mission completion tracking"],
    [/Recovery used[\s\S]*Recovery not needed[\s\S]*Recovery did not help yet/i, "recovery usefulness tracking"],
    [/what to ask AI/i, "AI-assisted builder prompt tracking"],
    [/what changes to accept/i, "AI-assisted builder accept tracking"],
    [/what changes to reject/i, "AI-assisted builder reject tracking"],
    [/Product Fix/i, "suggested product fixes"],
    [/Validation Check/i, "validation check format"],
    [/P0[\s\S]*P1[\s\S]*P2/i, "priority fix list"],
    [/completion checklist/i, "completion checklist findings"],
    [/mission completion checklist/i, "completion checklist suggested fix"],
    [/Code placement confusion/i, "code placement confusion theme"],
    [/terminal command anxiety/i, "terminal command anxiety theme"],
    [/not knowing whether they are in the right folder/i, "right folder uncertainty theme"],
    [/Uncertainty around `npm install`/i, "npm install uncertainty theme"],
    [/Uncertainty around `npm run dev`/i, "npm run dev uncertainty theme"],
    [/folder navigation confusion/i, "folder navigation confusion theme"],
    [/Where real Vue app files live/i, "real Vue file location theme"],
    [/What `App\.vue` means/i, "App.vue confusion theme"],
    [/What `package\.json` means/i, "package.json confusion theme"],
    [/ref\(\)[\s\S]*reactive\(\)[\s\S]*:key/i, "minor Vue concept confusion theme"],
    [/`ref\(\)` vs `reactive\(\)`/i, "ref versus reactive confusion theme"],
    [/`v-for`/i, "v-for confusion theme"],
    [/`:key`/i, ":key confusion theme"],
    [/Vue state meaning/i, "Vue state meaning confusion theme"],
    [/Where this change belongs/i, "placement suggested fix"],
    [/package feels document-heavy/i, "document-heavy package theme"],
    [/Beginners understood the mission but were unsure where files live and where terminal commands should run[\s\S]*Add `help\/beginner-orientation\.md`[\s\S]*project folders[\s\S]*`App\.vue`[\s\S]*terminal commands[\s\S]*`package\.json`[\s\S]*files to ignore[\s\S]*demo package must include beginner orientation[\s\S]*`START_HERE\.md` must point beginners to it/i, "beginner orientation suggested fix"],
    [/Learners could complete the mission but were unsure what `ref\(\)`, `reactive\(\)`, `v-for`, or `:key` meant[\s\S]*Add `help\/vue-concept-cards\.md`[\s\S]*Rookie Vue Todo mission[\s\S]*demo package must include Vue concept cards[\s\S]*main mission surface must point to them/i, "Vue concept cards suggested fix"],
    [/Beginners understood the mission but still felt unsure about terminal commands and whether they were in the right project folder[\s\S]*Add `help\/terminal-confidence-guide\.md`[\s\S]*recognizing the project folder[\s\S]*running `npm install`[\s\S]*running `npm run dev`[\s\S]*copying useful terminal output[\s\S]*demo package must include the terminal confidence guide[\s\S]*`START_HERE\.md` must point beginners to it/i, "terminal confidence suggested fix"],
    [/Tester saw many support files and was unsure which ones were required[\s\S]*Group optional support files under `help\/`[\s\S]*mission files under `mission\/`[\s\S]*reviewer\/project-owner files under `reviewer\/`[\s\S]*package root must contain `START_HERE\.md`[\s\S]*normal testers must be told they only need the start file and main mission/i, "package simplification suggested fix"],
    [/Some testers felt the package contained many markdown files and wanted a clearer visual entry point[\s\S]*Add `mission-dashboard\.html` as an optional visual overview[\s\S]*main mission[\s\S]*optional help files[\s\S]*AI-assisted builder view[\s\S]*feedback path[\s\S]*dashboard must keep `START_HERE\.md` and the main mission as the primary path/i, "mission dashboard suggested fix"],
    [/Phase 83 - Code Placement Guidance/i, "next phase recommendation"],
    [/next narrow fix[\s\S]*not to justify broad expansion/i, "narrow-fix feedback guidance"],
    [/If feedback points in many directions, prioritize the confusion that blocks the current Rookie Vue mission/i, "current-mission blocker priority"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateCanonCandidateBacklogReport(errors, warnings) {
  validateCanonCandidateBacklogReportFile(
    canonCandidateBacklogReportPath,
    "output/experience/canon-candidate-backlog-report.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateCanonCandidateBacklogReportFile(
    packagedCanonCandidateBacklogReportPath,
    "output/share/developer-atlas-mvp-demo/reviewer/canon-candidate-backlog-report.md",
    errors,
    warnings,
    true
  );
}

function validateCanonCandidateBacklogReportFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing Canon candidate backlog report`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Canon Candidate Backlog Report",
    "## Summary",
    "## Why This Exists",
    "## Candidate Groups",
    "## Candidate Rule",
    "## When To Harden",
    "## Product Owner Check"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/20 Canon candidate nodes were added/i, "20 candidate node summary"],
    [/not Gold Candidate/i, "not Gold Candidate statement"],
    [/not integrated into the current public alpha mission/i, "not integrated into public alpha mission"],
    [/future Rookie-to-Junior frontend growth/i, "future frontend growth purpose"],
    [/real tester feedback justifies them/i, "tester feedback hardening trigger"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateAlphaPackageFinalQa(errors, warnings) {
  validateAlphaPackageFinalQaFile(
    alphaPackageFinalQaPath,
    "output/experience/alpha-package-final-qa.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateAlphaPackageFinalQaFile(
    packagedAlphaPackageFinalQaPath,
    "output/share/developer-atlas-mvp-demo/reviewer/alpha-package-final-qa.md",
    errors,
    warnings,
    true
  );
}

function validateAlphaPackageFinalQaFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing alpha package final QA report`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Alpha Package Final QA",
    "## Summary",
    "## Release Decision",
    "## Package Structure Check",
    "## Dashboard Check",
    "## Accessibility Check",
    "## START_HERE Check",
    "## Quick Start Check",
    "## Workspace Clarity Check",
    "## AI-Assisted Path Check",
    "## Hardened Canon Check",
    "## Mission Path Check",
    "## Optional Help Check",
    "## Feedback Capture Check",
    "## Real tester feedback record",
    "## Canon Backlog Isolation Check",
    "## Package Manifest Check",
    "## Remaining Risks",
    "## Send-To-Testers Checklist",
    "## Next Action"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/ready_to_send_to_real_testers/i, "release decision"],
    [/ready for 3-5 real testers[\s\S]*not a public launch/i, "real tester scope"],
    [/Rookie Vue slice/i, "Rookie Vue focus"],
    [/START_HERE\.md[\s\S]*first-time-quick-start\.md[\s\S]*mission-dashboard\.html[\s\S]*mission\/[\s\S]*help\/[\s\S]*ai\/[\s\S]*reference\/canon\/hardened\/[\s\S]*reviewer\//i, "package structure"],
    [/package root contains only entry points and manifest[\s\S]*mission-dashboard\.html is the main entry point[\s\S]*ai-prompt-pack\.md lives under ai\/[\s\S]*hardened Canon lives under reference\/[\s\S]*reviewer-facing reports live under reviewer\/[\s\S]*dashboard links updated paths[\s\S]*reviewer files are only linked from Review path/i, "learner-first package structure checks"],
    [/mission-dashboard\.html[\s\S]*START_HERE\.md[\s\S]*first-time-quick-start\.md[\s\S]*mission\/today-mission-surface\.md[\s\S]*mission\/today-mission-surface\.vibe\.md[\s\S]*mission\/mission-03-todostats-surface\.md[\s\S]*mission\/mission-03-todostats-surface\.vibe\.md[\s\S]*help\/beginner-orientation\.md[\s\S]*help\/vue-concept-cards\.md[\s\S]*help\/terminal-confidence-guide\.md[\s\S]*mission\/mission-feedback-template\.md[\s\S]*reference\/canon\/hardened\//i, "dashboard paths"],
    [/Dashboard Check[\s\S]*Choose your goal[\s\S]*starting[\s\S]*continuing[\s\S]*AI-assisted building[\s\S]*getting unstuck[\s\S]*reviewing Atlas/i, "dashboard goal chooser check"],
    [/Dashboard Check[\s\S]*Recommended first step[\s\S]*Mission 1 as the first action[\s\S]*Goal selection is secondary[\s\S]*simplified labels: Start, Continue, Use AI, I'm stuck, and Review/i, "dashboard simplification summary"],
    [/Starting path[\s\S]*Continuing path[\s\S]*AI-assisted path[\s\S]*I am stuck path[\s\S]*Reviewer path[\s\S]*Only the starting panel is visible by default[\s\S]*other panels stay hidden until selected/i, "dashboard goal panel visibility check"],
    [/starting panel is short[\s\S]*continuing panel shows Mission 1 -> Mission 2 -> Mission 3[\s\S]*reviewer panel says it is for reviewers, mentors, or the project owner/i, "dashboard panel simplification check"],
    [/Mission 1 remains primary[\s\S]*Mission 2 appears after Mission 1[\s\S]*Mission 3 appears after Mission 2/i, "dashboard mission order check"],
    [/Dashboard Check[\s\S]*Fastest path/i, "dashboard fastest path check"],
    [/quick-start link is light[\s\S]*does not replace Mission 1/i, "dashboard quick-start link check"],
    [/Accessibility Check[\s\S]*semantic `header`, `main`, `section`, `nav`, and `footer` landmarks[\s\S]*keyboard reachable[\s\S]*clear action labels[\s\S]*visible focus states[\s\S]*does not rely on color alone[\s\S]*optional read-aloud controls[\s\S]*Read-aloud does not autoplay[\s\S]*`START_HERE\.md` includes a short accessibility note/i, "accessibility QA checklist"],
    [/START_HERE\.md[\s\S]*What the folders mean[\s\S]*mission\/[\s\S]*help\/[\s\S]*ai\/[\s\S]*reference\/[\s\S]*reviewer\//i, "START_HERE paths"],
    [/Quick Start Check[\s\S]*first-time-quick-start\.md` exists[\s\S]*linked from START_HERE[\s\S]*linked lightly from dashboard[\s\S]*does not replace Mission 1[\s\S]*Mission 1 remains first visible action/i, "quick-start QA checks"],
    [/Quick Start Check[\s\S]*Quick start explains where to work/i, "quick-start workspace check"],
    [/Workspace Clarity Check[\s\S]*Dashboard explains read here\/code there[\s\S]*START_HERE explains read here\/code there[\s\S]*Mission 1 says code changes belong in the learner's Vue todo project[\s\S]*Mission 2 says TodoItem\.vue belongs in the learner's Vue todo project[\s\S]*Mission 3 says TodoStats\.vue belongs in the learner's Vue todo project[\s\S]*Vibe versions tell AI to edit the learner's Vue todo project/i, "workspace clarity QA checks"],
    [/AI-Assisted Path Check[\s\S]*AI path gives one mission at a time[\s\S]*Vibe files tell AI to edit the learner's Vue todo project[\s\S]*Vibe files reject architecture expansion[\s\S]*Vibe files include explain-it-back guidance[\s\S]*AI prompt pack exists[\s\S]*AI prompt pack is optional[\s\S]*Mission 1 remains first visible action/i, "AI-assisted path QA checks"],
    [/Hardened Canon Check[\s\S]*Hardened Canon folder exists[\s\S]*Only current mission Canon nodes are hardened[\s\S]*Canon IDs are unique[\s\S]*Forbidden learner-facing\/internal terms are absent[\s\S]*Hype terms are absent[\s\S]*Shame terms are absent/i, "hardened Canon QA checks"],
    [/START_HERE\.md -> mission\/today-mission-surface\.md -> completion checklist -> after-mission reflection/i, "primary mission path"],
    [/START_HERE\.md -> mission\/mission-02-todoitem-surface\.md -> mission\/mission-03-todostats-surface\.md/i, "Mission 3 progression path"],
    [/START_HERE\.md -> mission\/today-mission-surface\.vibe\.md/i, "optional vibe path"],
    [/Main mission includes `## Quick Start`/i, "main mission Quick Start check"],
    [/Vibe mission includes `## Quick Start With AI`/i, "vibe mission Quick Start With AI check"],
    [/Dashboard includes Fastest Path/i, "dashboard includes Fastest Path check"],
    [/Help files are clearly optional/i, "help optionality check"],
    [/Vibe reject rules block structural rewrites and new architecture/i, "vibe structural rewrite rejection check"],
    [/Mission 2 includes a tiny file map[\s\S]*Mission 2 includes a beginner-safe path[\s\S]*Mission 2 includes a parent-child communication explanation[\s\S]*Mission 2 includes a shape-only example[\s\S]*Mission 2 vibe includes a tiny file map[\s\S]*Mission 2 vibe rejects multiple new components[\s\S]*Mission 2 vibe rejects moving state out of `App\.vue`[\s\S]*Mission 2 remains after Mission 1/i, "Mission 2 clarity QA checks"],
    [/Mission 2 includes tiny parent-child diagram[\s\S]*Mission 2 includes props go down, events go up[\s\S]*Mission 2 vibe includes tiny parent-child diagram[\s\S]*Mission 2 vibe rejects extra components[\s\S]*Mission 2 vibe rejects folder restructuring[\s\S]*Mission 2 vibe rejects styling side quests[\s\S]*Mission 2 vibe rejects unrelated renaming[\s\S]*Mission 2 keeps Mission 1 -> Mission 2 progression clear/i, "Mission 2 visual bridge QA checks"],
    [/Mission 3 exists[\s\S]*Mission 3 default and vibe surfaces are packaged[\s\S]*Mission 3 is clearly after Mission 2[\s\S]*Mission 1 remains primary[\s\S]*Mission 2 remains after Mission 1[\s\S]*Mission 3 keeps state in `App\.vue`[\s\S]*Mission 3 keeps localStorage in `App\.vue`[\s\S]*Mission 3 creates `TodoStats\.vue`[\s\S]*backend, routing, Pinia, auth, database, deployment, and new architecture[\s\S]*Dashboard and START_HERE reference Mission 3 correctly/i, "Mission 3 QA checks"],
    [/Dashboard includes Choose your goal[\s\S]*Dashboard includes Recommended first step[\s\S]*Dashboard points clearly to Mission 1 as first action[\s\S]*Dashboard keeps goal selection secondary[\s\S]*Dashboard uses simplified goal labels[\s\S]*Dashboard keeps the starting panel short[\s\S]*Dashboard continuing panel shows Mission 1 -> Mission 2 -> Mission 3[\s\S]*Dashboard reviewer panel says it is for reviewers, mentors, or the project owner[\s\S]*Dashboard includes Starting path[\s\S]*Dashboard includes Continuing path[\s\S]*Dashboard includes AI-assisted path[\s\S]*Dashboard includes I am stuck path[\s\S]*Dashboard includes Reviewer path[\s\S]*Dashboard keeps only one panel visible by default[\s\S]*Dashboard keeps Mission 1 primary, Mission 2 after Mission 1, and Mission 3 after Mission 2[\s\S]*Dashboard keeps accessibility and read-aloud support working/i, "dashboard goal-based QA checks"],
    [/Help files are optional[\s\S]*help\/[\s\S]*Beginner orientation[\s\S]*Vue concept cards[\s\S]*Terminal confidence guide/i, "optional help grouping"],
    [/Mission 3 default and vibe surfaces are the only new learner-facing mission files in this phase/i, "Mission 3 learner-facing files check"],
    [/After-mission reflection[\s\S]*mission\/mission-feedback-template\.md[\s\S]*reviewer\/tester-feedback-report\.md/i, "feedback capture path"],
    [/Tester role:[\s\S]*Time spent:[\s\S]*Started from:[\s\S]*Mission clarity:[\s\S]*Help used:[\s\S]*Blocker:[\s\S]*Confidence before:[\s\S]*Confidence after:[\s\S]*Would use again:[\s\S]*Most useful part:[\s\S]*Most confusing part:[\s\S]*Suggested next fix:/i, "real tester feedback record format"],
    [/20 new Canon candidate nodes[\s\S]*not part of the normal learner path[\s\S]*Candidate backlog supports future work but should not distract alpha testers/i, "Canon backlog isolation"],
    [/package-manifest\.json[\s\S]*mission-dashboard\.html[\s\S]*grouped mission files[\s\S]*grouped help files[\s\S]*ai\/[\s\S]*reference\/[\s\S]*reviewer\//i, "package manifest check"],
    [/Package may still feel large[\s\S]*Markdown may still feel less product-like[\s\S]*Real user behavior may differ[\s\S]*live help with setup[\s\S]*No paid conversion data yet/i, "remaining risks"],
    [/\[ \] Zip file refreshed[\s\S]*\[ \] Opened package root[\s\S]*\[ \] Opened `mission-dashboard\.html`[\s\S]*\[ \] Opened `START_HERE\.md`[\s\S]*\[ \] Opened main mission[\s\S]*\[ \] Confirmed optional help links[\s\S]*\[ \] Confirmed feedback template[\s\S]*\[ \] Sent to 3-5 testers/i, "send-to-testers checklist"],
    [/Send the refreshed demo package to 3-5 real testers before adding more features/i, "next action"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateHumanAiReadabilityAudit(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing human and AI readability audit`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Human and AI Readability Audit",
    "## Summary",
    "## Overall Readability Score",
    "## Human Maintainer Readability",
    "## Beginner Tester Readability",
    "## AI Assistant Readability",
    "## Package Structure Findings",
    "## Learner-Facing Text Findings",
    "## AI Context Findings",
    "## Generator Code Findings",
    "## Canon Findings",
    "## Validation Findings",
    "## File Growth Risks",
    "## Highest-Impact Fixes",
    "## Safe Quick Wins Applied",
    "## Do Not Change Yet",
    "## Recommended Next Phase"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  const requiredMeanings = [
    [/Overall readability score:\s*4\/5/i, "overall readability score"],
    [/Human maintainer readability score:\s*4\/5/i, "human maintainer readability score"],
    [/Beginner tester readability score:\s*4\/5/i, "beginner tester readability score"],
    [/AI assistant readability score:\s*4\/5/i, "AI assistant readability score"],
    [/Generator maintainability score:\s*4\/5/i, "generator maintainability score"],
    [/Package navigation score:\s*4\/5/i, "package navigation score"],
    [/Phase 99 split large generated text templates out of `tools\/generate-mission-experience-report\.js`[\s\S]*`tools\/templates\/`/i, "Phase 99 template split summary"],
    [/dashboard now includes optional read-aloud support and stronger semantic structure[\s\S]*not a full accessibility certification[\s\S]*practical foundation pass/i, "accessibility foundation audit note"],
    [/Phase 102 split mission validation by concern into `tools\/validators\/`[\s\S]*`tools\/validate-mission\.js` as an orchestrator[\s\S]*validation maintainability[\s\S]*future Mission 3 safety/i, "Phase 102 validator split summary"],
    [/Phase 103 added Mission 3 as a focused progression step[\s\S]*Mission 3 adds product momentum while preserving the current Rookie Vue scope/i, "Phase 103 Mission 3 readability summary"],
    [/Phase 104 added goal-based dashboard visibility to reduce choice pressure[\s\S]*first step toward an app\/window-style Atlas experience without leaving the static package format/i, "Phase 104 goal-based dashboard summary"],
    [/Phase 105 simplified the dashboard by making the recommended first step visible before goal selection[\s\S]*keeps goal-based navigation while reducing first-screen choice pressure/i, "Phase 105 dashboard simplification summary"],
    [/Phase 107 added a smallest beginner entry point and hardened only the Canon nodes used by the current Rookie Vue path[\s\S]*quick start reduces first-read weight without replacing the mission files/i, "Phase 107 quick-start and hardened Canon summary"],
    [/Phase 108 clarified the distinction between Atlas as the guide and the learner's Vue project as the coding workspace/i, "Phase 108 workspace clarity summary"],
    [/Phase 109 hardened the AI-assisted path so AI is guided toward small, scoped, explainable changes/i, "Phase 109 AI-assisted path summary"],
    [/Validation maintainability score:\s*5\/5/i, "validation maintainability score"],
    [/Phase 100 improves Mission 2 visual readability[\s\S]*parent-child communication clarity[\s\S]*props-down\/events-up memory phrase[\s\S]*AI rejection specificity/i, "Phase 100 readability note"],
    [/Phase 103 adds a TodoStats component mission[\s\S]*practice props with a small display component after extracting TodoItem/i, "Phase 103 TodoStats readability note"],
    [/Phase 104 adds goal-based dashboard panels[\s\S]*starting, continuing, AI-assisted, stuck, and reviewer paths are separated without adding new package files/i, "Phase 104 dashboard panels readability note"],
    [/Phase 105 keeps goal-based navigation while reducing first-screen choice pressure/i, "Phase 105 dashboard readability note"],
    [/Phase 107 keeps the package mission-first[\s\S]*short first-time quick start[\s\S]*optional hardened Canon reference notes for current mission concepts only/i, "Phase 107 mission-first readability note"],
    [/Phase 108 reduces workspace confusion[\s\S]*Atlas is where learners read[\s\S]*Vue todo project is where they code/i, "Phase 108 workspace readability note"],
    [/Phase 109 makes AI-assisted builder guidance easier to accept or reject[\s\S]*one mission[\s\S]*small patches[\s\S]*explain-it-back verification/i, "Phase 109 AI readability note"],
    [/understandable despite 30\+ files because dashboard and `START_HERE\.md` guide the flow/i, "package still understandable finding"],
    [/dashboard reduces perceived document weight[\s\S]*optional read-aloud support[\s\S]*clearer link labels[\s\S]*progressive visibility[\s\S]*selected goal path is shown/i, "dashboard progressive visibility finding"],
    [/Mission 1 remains the primary path[\s\S]*Mission 2 is positioned after Mission 1/i, "Mission 1 and Mission 2 momentum finding"],
    [/help files are clearly optional/i, "optional help finding"],
    [/AI-assisted builder guidance is strong/i, "AI-assisted builder guidance finding"],
    [/Validation editability is stronger after the Phase 102 split[\s\S]*mission-content-validator\.js[\s\S]*dashboard-accessibility-validator\.js[\s\S]*package-structure-validator\.js[\s\S]*report-validator\.js[\s\S]*maintainer-docs-validator\.js[\s\S]*language-safety-validator\.js[\s\S]*file-growth-validator\.js/i, "Phase 102 validator editability finding"],
    [/source-of-truth and generated outputs are clearly documented|future assistants can identify whether a change belongs in `start-here-template\.js`, `dashboard-template\.js`, `mission-templates\.js`, or `report-templates\.js`/i, "AI editability template finding"],
    [/Phase 98 improves AI editability and learner readability by clarifying parent-child file boundaries[\s\S]*making AI reject rules more specific[\s\S]*reducing ambiguity around where state belongs[\s\S]*improving Mission 2 scan clarity without adding new files/i, "Phase 98 readability note"],
    [/mission experience generator is now a smaller orchestrator/i, "generator split finding"],
    [/After Phase 102, `tools\/validate-mission\.js` should stay small[\s\S]*validator growth risk now lives in the concern modules under `tools\/validators\/`/i, "validator module future growth finding"],
    [/source-of-truth and generated outputs are clearly documented/i, "AI editability documentation finding"],
    [/Validation[\s\S]*must continue to prove claimed features/i, "validation proves claims finding"],
    [/Phase 102 improves validation maintainability[\s\S]*tools\/validators\/[\s\S]*report-validator\.js[\s\S]*tools\/validate-mission\.js`? as an orchestrator/i, "Phase 102 validation maintainability finding"],
    [/Split validator by concern later[\s\S]*Keep maintainer map updated[\s\S]*Keep AI editing rules updated[\s\S]*file-size or line-count warnings[\s\S]*every new feature has validation[\s\S]*template modules named by editing intent[\s\S]*accessibility foundation checks[\s\S]*validator modules named by validation concern[\s\S]*progressive visibility/i, "highest-impact fixes"],
    [/tools\/templates\/start-here-template\.js[\s\S]*tools\/templates\/dashboard-template\.js[\s\S]*tools\/templates\/mission-templates\.js[\s\S]*tools\/templates\/report-templates\.js[\s\S]*docs\/maintainer-map\.md[\s\S]*docs\/ai-editing-rules\.md[\s\S]*human-ai-readability-audit\.md/i, "safe quick wins applied"],
    [/goal-based dashboard visibility/i, "goal-based dashboard quick win"],
    [/first-time quick start[\s\S]*hardened Canon notes for Missions 1-3/i, "Phase 107 quick wins"],
    [/docs\/accessibility-principle\.md/i, "accessibility principle quick win"],
    [/tools\/validators\//i, "validator split quick win"],
    [/Do not add new stacks[\s\S]*Do not add more support files[\s\S]*Do not build IDE extension yet[\s\S]*Do not harden all Canon candidates[\s\S]*Do not split everything into modules/i, "do-not-change-yet guidance"],
    [/Send the package to real testers or run a small real feedback round before adding another mission/i, "recommended next phase"],
    [/Test Mission 1 -> Mission 2 -> Mission 3 momentum with 3-5 users/i, "Mission 1 to Mission 3 testing recommendation"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateInheritedWarningBurnDownReport(errors, warnings) {
  const counts = analyzeContent().counts;
  if (counts.warningCount >= 1546) {
    errors.push(`content warnings: expected inherited warning count below 1546, found ${counts.warningCount}`);
  }

  validateInheritedWarningBurnDownReportFile(
    inheritedWarningBurnDownReportPath,
    "output/experience/inherited-warning-burndown-report.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateInheritedWarningBurnDownReportFile(
    packagedInheritedWarningBurnDownReportPath,
    "output/share/developer-atlas-mvp-demo/reviewer/inherited-warning-burndown-report.md",
    errors,
    warnings,
    true
  );
}

function validateInheritedWarningBurnDownReportFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing inherited warning burn-down report`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Inherited Warning Burn-Down Report",
    "## Summary",
    "## What changed",
    "## Warning categories",
    "## Top warning sources before cleanup",
    "## Warning count by file",
    "## Warning count by term/rule",
    "## Files fixed",
    "## Files regenerated",
    "## Files removed",
    "## Scan-scope decisions",
    "## Remaining warnings",
    "## Why any warnings remain",
    "## Manifest decision",
    "## Next recommendation"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  const requiredMeanings = [
    [/Before:\s*1546 inherited content warnings/i, "before warning count"],
    [/After:\s*0 inherited content warnings/i, "after warning count"],
    [/Inherited warnings reached 0/i, "zero warning summary"],
    [/Valid warning fixed at source[\s\S]*1546[\s\S]*0/i, "category count"],
    [/76 content entries were missing shared future metadata fields/i, "top repeated warning source"],
    [/46 content files had 26 warnings each[\s\S]*10 content files had 14 warnings each[\s\S]*20 content files had 12 warnings each/i, "warning count by file"],
    [/critical:\s*0[\s\S]*quality:\s*0[\s\S]*enrichment:\s*0[\s\S]*future:\s*0/i, "warning count by term"],
    [/76 files under `content\/` were enriched at the source/i, "files fixed"],
    [/output\/experience\/inherited-warning-burndown-report\.md/i, "files regenerated"],
    [/Files removed[\s\S]*None/i, "files removed"],
    [/Scan scope did not change[\s\S]*No learner-facing or package-facing files were excluded[\s\S]*node_modules`? was not scanned/i, "scan-scope decision"],
    [/Remaining warnings[\s\S]*None/i, "remaining warnings"],
    [/No inherited content warnings remain/i, "why no warnings remain"],
    [/manifest lists primary package entries and directory groups/i, "manifest scope decision"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

module.exports = {
  validateBeginnerOrientation,
  validateVueConceptCards,
  validateTerminalConfidenceGuide,
  validateAlphaFocusLock,
  validatePublicAlphaReadinessReport,
  validateTesterHandoffMessages,
  validateTesterFeedbackReport,
  validateCanonCandidateBacklogReport,
  validateAlphaPackageFinalQa,
  validateHumanAiReadabilityAudit,
  validateInheritedWarningBurnDownReport
};
