const assert = require("node:assert/strict");

function toVueReadyProducts(products) {
  return products.map((product) => ({
    id: product.id,
    name: product.name,
    priceLabel: new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD"
    }).format(product.priceCents / 100),
    stockLabel: product.stock > 0 ? `${product.stock} in stock` : "Out of stock",
    route: {
      name: "product-details",
      params: { id: product.id }
    }
  }));
}

function run() {
  const apiProducts = [
    { id: "sku-100", name: "Keyboard", priceCents: 12999, stock: 12 },
    { id: "sku-200", name: "Mouse", priceCents: 4999, stock: 0 }
  ];

  const products = toVueReadyProducts(apiProducts);

  assert.deepEqual(products, [
    {
      id: "sku-100",
      name: "Keyboard",
      priceLabel: "$129.99",
      stockLabel: "12 in stock",
      route: { name: "product-details", params: { id: "sku-100" } }
    },
    {
      id: "sku-200",
      name: "Mouse",
      priceLabel: "$49.99",
      stockLabel: "Out of stock",
      route: { name: "product-details", params: { id: "sku-200" } }
    }
  ]);

  return products;
}

module.exports = run;

if (require.main === module) run();
