# Developer Atlas Specifications

This directory is the source of truth for Developer Atlas architecture.

From this point forward, contributors should implement these specifications rather than redesigning the system ad hoc. If the architecture needs to change, update the relevant specification first, then update schemas, tools, generated outputs, and validation to match.

## Rule

Specifications define the system.

Schemas validate the system.

Tools generate from the system.

Reports measure the system.

AI agents do not invent replacement architecture during implementation.

## Specifications

- `knowledge-node-spec.md`
- `relationship-spec.md`
- `intent-spec.md`
- `constraint-spec.md`
- `decision-record-spec.md`
- `kernel-spec.md`
- `brain-pack-spec.md`
