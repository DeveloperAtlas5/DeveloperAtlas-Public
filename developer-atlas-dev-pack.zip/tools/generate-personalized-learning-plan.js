const fs = require("fs");
const path = require("path");
const {
  rootDir
} = require("./content-utils");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getLearning,
  getSkillArea,
  unique
} = require("./learning-utils");

const profilesDir = path.join(rootDir, "learning", "profiles");
const skillTreePath = path.join(learningOutputDir, "skill-tree.json");
const practicePackPath = path.join(learningOutputDir, "practice-pack.json");
const personalizedDir = path.join(learningOutputDir, "personalized");

function main() {
  const profileArg = process.argv[2];
  const profiles = readProfiles().filter((profile) => !profileArg || profile.profile_id === profileArg);
  const index = readCanonIndex();
  const entries = index.entries || [];
  const skillTree = readJson(skillTreePath, { skills: [] });
  const practicePack = readJson(practicePackPath, { levels: { rookie: [], junior: [], professional: [] } });

  fs.mkdirSync(personalizedDir, { recursive: true });

  const plans = profiles.map((profile) => buildPlan(profile, entries, skillTree, practicePack));
  for (const plan of plans) {
    fs.writeFileSync(path.join(personalizedDir, `${plan.profile.profile_id}.json`), `${JSON.stringify(plan, null, 2)}\n`);
    fs.writeFileSync(path.join(personalizedDir, `${plan.profile.profile_id}.md`), toMarkdown(plan));
  }

  console.log(`Generated ${plans.length} personalized learning plan${plans.length === 1 ? "" : "s"}.`);
}

function readProfiles() {
  if (!fs.existsSync(profilesDir)) return [];
  return fs.readdirSync(profilesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => JSON.parse(fs.readFileSync(path.join(profilesDir, fileName), "utf8")));
}

function readJson(filePath, fallback) {
  if (!fs.existsSync(filePath)) return fallback;
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function buildPlan(profile, entries, skillTree, practicePack) {
  const entriesByCanonId = new Map(entries.map((entry) => [entry.canon_id, entry]));
  const skill = skillTree.skills.find((item) => item.skill_area === profile.target_skill_area);
  const targetNodeIds = skill ? skill.nodes : entries.map((entry) => entry.canon_id);
  const known = new Set(profile.known_nodes || []);
  const weak = new Set(profile.weak_nodes || []);
  const selectedPracticeLevel = profile.level === "ai_tutor" ? "junior" : profile.level;
  const practiceByCanon = new Map((practicePack.levels[selectedPracticeLevel] || []).map((task) => [task.canon_id, task]));

  const candidates = targetNodeIds
    .map((canonId) => entriesByCanonId.get(canonId))
    .filter(Boolean)
    .map((entry) => scoreEntry(entry, profile, known, weak))
    .sort((a, b) => b.priority - a.priority || a.entry.canon_id.localeCompare(b.entry.canon_id));

  const skippedKnownNodes = candidates
    .filter((candidate) => candidate.isKnown && !candidate.isWeak)
    .map((candidate) => summarizeNode(candidate.entry));

  const recommended = [];
  let estimatedTime = 0;
  for (const candidate of candidates) {
    if (candidate.isKnown && !candidate.isWeak) continue;
    const task = practiceByCanon.get(candidate.entry.canon_id);
    const taskTime = task?.estimated_minutes || Math.min(getLearning(candidate.entry).estimated_practice_minutes || 30, 45);
    if (recommended.length && estimatedTime + taskTime > profile.available_minutes) continue;
    recommended.push(toRecommendation(candidate, task, profile));
    estimatedTime += taskTime;
    if (recommended.length >= 3) break;
  }

  if (!recommended.length) {
    const fallback = candidates.find((candidate) => !candidate.isKnown) || candidates[0];
    if (fallback) {
      const task = practiceByCanon.get(fallback.entry.canon_id);
      recommended.push(toRecommendation(fallback, task, profile));
      estimatedTime += task?.estimated_minutes || 30;
    }
  }

  const weakReinforcement = recommended
    .filter((item) => weak.has(item.canon_id) || weak.has(item.node_id))
    .map((item) => ({
      canon_id: item.canon_id,
      title: item.title,
      reason: "Listed as a weak node in the learner profile.",
      practice: item.practice
    }));

  const masteryCheckpoint = recommended[0]?.mastery_proof || "Complete the selected practice task and explain the decision trade-off.";

  return {
    generated_at: new Date().toISOString(),
    profile,
    learner_summary: {
      level: profile.level,
      preferred_style: profile.preferred_style,
      target_skill_area: profile.target_skill_area,
      available_minutes: profile.available_minutes,
      goals: profile.goals
    },
    selected_practice_level: selectedPracticeLevel,
    recommended_next_nodes: recommended,
    skipped_known_nodes: skippedKnownNodes,
    weak_node_reinforcement: weakReinforcement,
    estimated_time_minutes: estimatedTime,
    mastery_checkpoint: masteryCheckpoint,
    next_3_steps: buildNextSteps(recommended, profile),
    source_inputs: {
      canon_index: "canon/canon-index.json",
      skill_tree: "output/learning/skill-tree.json",
      practice_pack: "output/learning/practice-pack.json"
    }
  };
}

function scoreEntry(entry, profile, known, weak) {
  const learning = getLearning(entry);
  const confidence = profile.confidence_by_node?.[entry.canon_id] ?? profile.confidence_by_node?.[entry.node_id] ?? 0;
  const threshold = learning.confidence_threshold || 0.85;
  const isKnown = known.has(entry.canon_id) || known.has(entry.node_id);
  const isWeak = weak.has(entry.canon_id) || weak.has(entry.node_id);
  let priority = 0;
  if (isWeak) priority += 100;
  if (confidence < threshold) priority += Math.round((threshold - confidence) * 50);
  if (!isKnown) priority += 10;
  return { entry, confidence, threshold, isKnown, isWeak, priority };
}

function toRecommendation(candidate, task, profile) {
  const learning = getLearning(candidate.entry);
  return {
    canon_id: candidate.entry.canon_id,
    node_id: candidate.entry.node_id,
    title: candidate.entry.title,
    skill_area: getSkillArea(candidate.entry),
    confidence: candidate.confidence,
    confidence_threshold: candidate.threshold,
    reason: reasonFor(candidate),
    explanation_style: explanationStyle(profile, candidate.entry),
    practice: buildPractice(),
    mastery_proof: learning.mastery_proof?.proof || "",
    ai_tutor_guidance: profile.level === "ai_tutor" ? learning.ai_tutor_guidance || [] : []
  };

  function buildPractice() {
    return task
      ? {
          title: task.task_title,
          task: task.task,
          estimated_minutes: task.estimated_minutes,
          success_criteria: task.success_criteria
        }
      : {
          title: "Practice mastery criteria",
          task: (learning.mastery_criteria || []).join(" "),
          estimated_minutes: Math.min(learning.estimated_practice_minutes || 30, 45),
          success_criteria: "Can explain and apply the node without relying on syntax memory alone."
        };
  }
}

function reasonFor(candidate) {
  if (candidate.isWeak) return "Weak-node reinforcement has highest priority.";
  if (candidate.confidence < candidate.threshold) return "Confidence is below the node threshold.";
  if (!candidate.isKnown) return "Next unlearned node in the target skill area.";
  return "Refresh node selected from the target skill area.";
}

function explanationStyle(profile, entry) {
  if (profile.level === "rookie") return `Use ${profile.preferred_style}: define the mental model first, then show one small example.`;
  if (profile.level === "junior") return `Use ${profile.preferred_style}: lead with the decision rule and one realistic practice task.`;
  if (profile.level === "professional") return `Use ${profile.preferred_style}: be compact, focus on trade-offs and failure modes.`;
  return `Use ${profile.preferred_style}: cite ${entry.canon_id} internally, ask only necessary clarifying questions, and use AI tutor guidance.`;
}

function summarizeNode(entry) {
  return {
    canon_id: entry.canon_id,
    node_id: entry.node_id,
    title: entry.title
  };
}

function buildNextSteps(recommended, profile) {
  const first = recommended[0];
  if (!first) return ["Review the target skill area.", "Pick one weak node.", "Complete one practice task."];
  return [
    `Study ${first.canon_id}: ${first.title} using the ${profile.preferred_style} style.`,
    `Complete practice: ${first.practice.title}.`,
    "Write a one-paragraph decision explanation and compare it to the mastery proof."
  ];
}

function toMarkdown(plan) {
  const lines = [
    `# Personalized Learning Plan: ${plan.profile.profile_id}`,
    "",
    "## Learner Summary",
    "",
    `- Level: ${plan.learner_summary.level}`,
    `- Preferred style: ${plan.learner_summary.preferred_style}`,
    `- Target skill area: ${plan.learner_summary.target_skill_area}`,
    `- Available minutes: ${plan.learner_summary.available_minutes}`,
    `- Selected practice level: ${plan.selected_practice_level}`,
    "",
    "## Goals",
    ""
  ];
  for (const goal of plan.learner_summary.goals) lines.push(`- ${goal}`);

  lines.push("", "## Recommended Next Nodes", "");
  for (const item of plan.recommended_next_nodes) {
    lines.push(`### ${item.canon_id}: ${item.title}`);
    lines.push("");
    lines.push(`- Reason: ${item.reason}`);
    lines.push(`- Confidence: ${item.confidence}`);
    lines.push(`- Threshold: ${item.confidence_threshold}`);
    lines.push(`- Explanation style: ${item.explanation_style}`);
    lines.push(`- Practice: ${item.practice.title} (${item.practice.estimated_minutes} minutes)`);
    lines.push(`- Practice task: ${item.practice.task}`);
    lines.push(`- Success criteria: ${item.practice.success_criteria}`);
    if (item.ai_tutor_guidance.length) {
      lines.push("- AI tutor guidance:");
      for (const guidance of item.ai_tutor_guidance) lines.push(`  - ${guidance}`);
    }
    lines.push("");
  }

  lines.push("## Skipped Known Nodes", "");
  lines.push(...formatNodes(plan.skipped_known_nodes));
  lines.push("", "## Weak-Node Reinforcement", "");
  if (plan.weak_node_reinforcement.length) {
    for (const item of plan.weak_node_reinforcement) lines.push(`- ${item.canon_id}: ${item.title} - ${item.reason}`);
  } else {
    lines.push("- None selected in this plan.");
  }
  lines.push("", "## Estimated Time", "");
  lines.push(`${plan.estimated_time_minutes} minutes`);
  lines.push("", "## Mastery Checkpoint", "");
  lines.push(plan.mastery_checkpoint);
  lines.push("", "## Next 3 Steps", "");
  for (const step of plan.next_3_steps) lines.push(`- ${step}`);

  return `${lines.join("\n")}\n`;
}

function formatNodes(nodes) {
  return nodes.length ? nodes.map((node) => `- ${node.canon_id}: ${node.title}`) : ["- None"];
}

main();
