# Developer Atlas Rookie Pack
Open `mission-dashboard.html` from Windows File Explorer.
It opens Atlas like a small book in your browser.
If it opens in VS Code, open the extracted folder in Windows File Explorer and double-click `mission-dashboard.html`.
This Rookie Pack starts after your basic Vue to-do project already exists.
You need a basic Vue to-do project already open in VS Code.
Read in Atlas.
Code in your Vue project.
You do not need to browse the folders.
If the terminal feels confusing, open `help/terminal-confidence-guide.md`.
