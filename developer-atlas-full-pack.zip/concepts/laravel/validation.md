# Laravel Validation

Technology: Laravel

## Simple meaning

Validation checks incoming data before the app trusts or saves it.

## Why it exists

It protects the app from missing, malformed, or unsafe input.

## Where you use it

In controllers, Form Request classes, or request validation calls.

## When to use it

Use validation before creating or updating records from user input.

## Tiny example

`$request->validate(['email' => 'required|email']);`

## Common beginner confusion

Validation is not the same as saving. It checks data first, then your app can decide what to do next.

## Related concepts

- Request
- Controller
- Model

## Similar idea in another technology

Vue form validation can guide the user in the browser, while Laravel validation protects the server.
