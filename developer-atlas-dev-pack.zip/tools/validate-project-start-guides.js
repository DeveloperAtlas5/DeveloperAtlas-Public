const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const outputDir = path.join(rootDir, "output", "experience", "project-start");

const requiredSections = [
  "## What this is for",
  "## What you need first",
  "## Required tools",
  "## Recommended extensions",
  "## Start from zero",
  "## Open an existing project",
  "## Run or preview the project",
  "## Where you usually code",
  "## Common first problems",
  "## Next Atlas step"
];

const requiredGuides = ["html", "css", "javascript", "vue", "php", "laravel", "sql", "java"];

function read(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

function requireExists(filePath, label, errors) {
  if (!fs.existsSync(filePath)) errors.push(`${label}: missing`);
}

function requirePattern(text, pattern, label, errors) {
  if (!pattern.test(text)) errors.push(`${label}: missing required content`);
}

function requireAll(text, patterns, label, errors) {
  for (const pattern of patterns) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${pattern}`);
      return;
    }
  }
}

function validateGuide(slug, errors) {
  const guidePath = path.join(outputDir, `${slug}.md`);
  requireExists(guidePath, `Project Start Guide ${slug}`, errors);
  if (!fs.existsSync(guidePath)) return;
  const text = read(guidePath);
  for (const section of requiredSections) {
    if (!text.includes(section)) errors.push(`Project Start Guide ${slug}: missing ${section}`);
  }
}

function main() {
  const errors = [];
  const indexPath = path.join(outputDir, "index.md");
  requireExists(indexPath, "Project Start Guide index", errors);
  if (fs.existsSync(indexPath)) {
    const index = read(indexPath);
    for (const heading of ["# Project Start Guides", "## Web basics", "## Frameworks", "## Backend / database"]) {
      if (!index.includes(heading)) errors.push(`Project Start Guide index: missing ${heading}`);
    }
    requirePattern(index, /Not knowing how to start a project is normal/i, "Project Start Guide index normalizing note", errors);
    for (const slug of requiredGuides) {
      requirePattern(index, new RegExp(`\\(${slug}\\.md\\)`, "i"), `Project Start Guide index link ${slug}`, errors);
    }
  }

  for (const slug of requiredGuides) validateGuide(slug, errors);

  const html = fs.existsSync(path.join(outputDir, "html.md")) ? read(path.join(outputDir, "html.md")) : "";
  requirePattern(html, /index\.html[\s\S]*browser/i, "HTML guide index and browser", errors);

  const js = fs.existsSync(path.join(outputDir, "javascript.md")) ? read(path.join(outputDir, "javascript.md")) : "";
  requireAll(js, [/\.js/i, /<script/i, /browser console/i, /JavaScript language features are built into VS Code/i], "JavaScript guide basics", errors);

  const vue = fs.existsSync(path.join(outputDir, "vue.md")) ? read(path.join(outputDir, "vue.md")) : "";
  requireAll(vue, [/Node\.js/i, /Vite/i, /npm install/i, /npm run dev/i, /src\/App\.vue/i, /Vue - Official/i], "Vue guide required details", errors);

  const php = fs.existsSync(path.join(outputDir, "php.md")) ? read(path.join(outputDir, "php.md")) : "";
  requireAll(php, [/\.php/i, /PHP installed/i, /php -S localhost:8000/i, /PHP Intelephense/i], "PHP guide required details", errors);

  const laravel = fs.existsSync(path.join(outputDir, "laravel.md")) ? read(path.join(outputDir, "laravel.md")) : "";
  requireAll(laravel, [/PHP/i, /Composer/i, /php artisan serve/i, /routes/i, /Controllers/i, /Models/i, /Migrations/i], "Laravel guide required details", errors);

  const sql = fs.existsSync(path.join(outputDir, "sql.md")) ? read(path.join(outputDir, "sql.md")) : "";
  requireAll(sql, [/SQL usually runs inside a database tool or application/i, /Tables/i, /Rows/i, /Columns/i], "SQL guide required details", errors);

  const java = fs.existsSync(path.join(outputDir, "java.md")) ? read(path.join(outputDir, "java.md")) : "";
  requireAll(java, [/JDK/i, /\.java/i, /javac/i, /java Main/i, /Extension Pack for Java/i], "Java guide required details", errors);

  console.log("Atlas Project Start Guides validation");
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  if (errors.length) process.exitCode = 1;
}

main();
