const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const rootDir = path.resolve(__dirname, "..");
const packageDir = path.join(rootDir, "output", "share", "developer-atlas-mvp-demo");
const zipPath = path.join(rootDir, "output", "share", "developer-atlas-mvp-demo.zip");

const filesToCopy = [
  { from: "output/experience/START_HERE.md", to: "START_HERE.md" },
  { from: "output/experience/first-time-quick-start.md", to: "first-time-quick-start.md" },
  { from: "output/experience/ai-prompt-pack.md", to: "ai/ai-prompt-pack.md" },
  { from: "output/experience/mission-dashboard.html", to: "mission-dashboard.html" },
  { from: "output/experience/canon/hardened", to: "reference/canon/hardened", type: "directory" },
  { from: "output/experience/beginner-orientation.md", to: "help/beginner-orientation.md" },
  { from: "output/experience/vue-concept-cards.md", to: "help/vue-concept-cards.md" },
  { from: "output/experience/terminal-confidence-guide.md", to: "help/terminal-confidence-guide.md" },
  { from: "output/experience/today-mission-surface.md", to: "mission/today-mission-surface.md" },
  { from: "output/experience/today-mission-surface.vibe.md", to: "mission/today-mission-surface.vibe.md" },
  { from: "output/experience/mission-02-todoitem-surface.md", to: "mission/mission-02-todoitem-surface.md" },
  { from: "output/experience/mission-02-todoitem-surface.vibe.md", to: "mission/mission-02-todoitem-surface.vibe.md" },
  { from: "output/experience/mission-03-todostats-surface.md", to: "mission/mission-03-todostats-surface.md" },
  { from: "output/experience/mission-03-todostats-surface.vibe.md", to: "mission/mission-03-todostats-surface.vibe.md" },
  { from: "output/experience/mission-feedback-template.md", to: "mission/mission-feedback-template.md" },
  { from: "output/experience/tester-feedback-report.md", to: "reviewer/tester-feedback-report.md" },
  { from: "output/experience/tester-handoff-messages.md", to: "reviewer/tester-handoff-messages.md" },
  { from: "output/experience/public-alpha-readiness-report.md", to: "reviewer/public-alpha-readiness-report.md" },
  { from: "output/experience/alpha-focus-lock.md", to: "reviewer/alpha-focus-lock.md" },
  { from: "output/experience/canon-candidate-backlog-report.md", to: "reviewer/canon-candidate-backlog-report.md" },
  { from: "output/experience/alpha-package-final-qa.md", to: "reviewer/alpha-package-final-qa.md" },
  { from: "output/experience/human-ai-readability-audit.md", to: "reviewer/human-ai-readability-audit.md" },
  { from: "output/experience/inherited-warning-burndown-report.md", to: "reviewer/inherited-warning-burndown-report.md" },
  { from: "output/experience/ai-guardrail-evaluation.md", to: "reviewer/ai-guardrail-evaluation.md" },
  { from: "output/experience/ai-guardrail-red-team-pack.md", to: "reviewer/ai-guardrail-red-team-pack.md" },
  { from: "output/experience/ai-red-team-results-template.md", to: "reviewer/ai-red-team-results-template.md" },
  { from: "site", to: "reviewer/site", type: "directory" },
  { from: "output/demo/mvp-demo-pack.md", to: "reviewer/demo/mvp-demo-pack.md" },
  { from: "output/demo/demo-walkthrough.md", to: "reviewer/demo/demo-walkthrough.md" },
  { from: "output/demo/ai-demo-brief.md", to: "reviewer/demo/ai-demo-brief.md" },
  { from: "output/mission/today-mission.md", to: "mission/today-mission.md" },
  { from: "output/mission/mission-report.md", to: "reviewer/reports/mission-report.md" },
  { from: "output/mission/mission-experience-report.md", to: "reviewer/reports/mission-experience-report.md" },
  { from: "output/flow/rookie-vue-todo-flow.md", to: "reviewer/flow/rookie-vue-todo-flow.md" },
  { from: "output/flow/flow-report.md", to: "reviewer/reports/flow-report.md" },
  { from: "output/walkthrough/rookie-vue-todo.md", to: "reviewer/walkthrough/rookie-vue-todo.md" },
  { from: "output/canon/canon-report.md", to: "reviewer/reports/canon-report.md" },
  { from: "output/capability/capability-pathway.md", to: "reviewer/reports/capability-pathway.md" },
  { from: "output/setup-advisor/beginner-vue-windows.md", to: "reviewer/advisors/setup-beginner-vue-windows.md" },
  { from: "output/recovery-advisor/npm-install-fails.md", to: "reviewer/advisors/recovery-npm-install-fails.md" },
  { from: "output/ai-context/ai-context-report.md", to: "reviewer/reports/ai-context-report.md" },
  { from: "output/team-context/team-context-quality-report.md", to: "reviewer/reports/team-context-quality-report.md" }
];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function removePath(target) {
  if (fs.existsSync(target)) {
    fs.rmSync(target, { recursive: true, force: true });
  }
}

function copyFile(from, to) {
  const source = path.join(rootDir, from);
  const destination = path.join(packageDir, to);
  if (!fs.existsSync(source)) {
    throw new Error(`Missing package source: ${from}`);
  }
  ensureDir(path.dirname(destination));
  fs.copyFileSync(source, destination);
}

function copyDirectory(from, to) {
  const source = path.join(rootDir, from);
  const destination = path.join(packageDir, to);
  if (!fs.existsSync(source)) {
    throw new Error(`Missing package source: ${from}`);
  }
  fs.cpSync(source, destination, { recursive: true });
}

function rewritePackagedSiteLinks() {
  const indexPath = path.join(packageDir, "reviewer", "site", "index.html");
  if (!fs.existsSync(indexPath)) {
    throw new Error("Missing packaged site/index.html");
  }

  const replacements = new Map([
    ["../output/experience/today-mission-surface.md", "../mission/today-mission-surface.md"],
    ["../output/experience/today-mission-surface.vibe.md", "../mission/today-mission-surface.vibe.md"],
    ["../output/mission/today-mission.md", "../mission/today-mission.md"],
    ["../output/flow/rookie-vue-todo-flow.md", "../flow/rookie-vue-todo-flow.md"],
    ["../output/walkthrough/rookie-vue-todo.md", "../walkthrough/rookie-vue-todo.md"],
    ["../output/demo/mvp-demo-pack.md", "../demo/mvp-demo-pack.md"]
  ]);

  let html = fs.readFileSync(indexPath, "utf8");
  for (const [source, destination] of replacements) {
    html = html.split(source).join(destination);
  }
  fs.writeFileSync(indexPath, html);
}

function writeReadme() {
  const readme = [
    "# Developer Atlas MVP Demo",
    "",
    "Developer Atlas is an Engineering Progress Platform. It helps developers go from idea to production with more confidence by connecting learning, setup, recovery, tooling, hardware context, AI-ready prompts, and personal roadmaps.",
    "",
    "This package is a small shareable demo for testers, mentors, potential collaborators, and early supporters. It is intentionally file-based so the current MVP can be inspected without a server, account, or product install.",
    "",
    "Unzip the package first. Open `first-time-quick-start.md` if you want the smallest path. Open `START_HERE.md` if you want the short package map.",
    "",
    "Prefer a visual overview first? Open `mission-dashboard.html`. It is an optional visual entry point for the public alpha package.",
    "",
    "`START_HERE.md` includes a short role guide so beginners, Rookie Vue learners, AI-assisted builders, and technical reviewers know what feedback is most useful.",
    "",
    "If you use AI while coding, `ai/ai-prompt-pack.md` is optional. It keeps AI on one mission at a time.",
    "",
    "The package groups files into `mission/`, `help/`, `ai/`, `reference/`, and `reviewer/` so testers can start without reading everything.",
    "Optional hardened Canon reference notes live under `reference/canon/hardened/`. Normal learners do not need them to start Mission 1.",
    "",
    "Optional help files live under `help/`: beginner orientation, Vue concept cards, and terminal confidence.",
    "",
    "If you are a normal tester, you only need `START_HERE.md` and `mission/today-mission-surface.md`.",
    "",
    "The package also includes tester handoff messages for inviting beginners, Rookie Vue learners, AI-assisted builders, and reviewers.",
    "The package includes a public alpha readiness report for checking whether the demo is ready to send to a small tester group.",
    "The package includes an alpha focus lock to keep the public alpha narrow before adding new product lines.",
    "The package includes an inherited warning burn-down report for owner/reviewer validation cleanup notes.",
    "The package includes an AI guardrail evaluation report for owner/reviewer checks of AI-assisted answers.",
    "The package includes an AI guardrail red-team pack for owner/reviewer stress tests.",
    "The package includes an AI red-team results template for owner/reviewer result capture.",
    "",
    "The landing page uses package-local links, so the main demo links should work inside the unzipped folder.",
    "",
    "Mission surfaces include a short placement hint so testers can see where the change usually belongs.",
    "They also include a short completion checklist so testers know when the visible win is working.",
    "",
    "## Open The Landing Page",
    "",
    "Open:",
    "",
    "```text",
    "site/index.html",
    "```",
    "",
    "No build step or dev server is required.",
    "",
    "If your browser blocks Markdown links from a local HTML file, open the listed Markdown files manually from the unzipped folder.",
    "",
    "## Read These First",
    "",
    "1. `START_HERE.md` for the public alpha testing path.",
    "2. `first-time-quick-start.md` for the smallest first-time path.",
    "3. Optional visual overview: `mission-dashboard.html`.",
    "4. Optional for AI-assisted builders: `ai/ai-prompt-pack.md`.",
    "5. `mission/today-mission-surface.md` for the primary learner-facing demo: one calm mission.",
    "6. Optional for beginners: `help/beginner-orientation.md` if folders, `App.vue`, terminal commands, or `package.json` feel unclear.",
    "7. Optional for Vue learners: `help/vue-concept-cards.md` if `ref()`, `reactive()`, `v-for`, `:key`, or Vue state feel unclear.",
    "8. Optional for terminal confidence: `help/terminal-confidence-guide.md` if `npm install`, `npm run dev`, or project folders feel unclear.",
    "9. `site/index.html` for the 30-second overview.",
    "10. Optional: `mission/today-mission-surface.vibe.md` for the AI-assisted builder view.",
    "11. After Mission 2: `mission/mission-03-todostats-surface.md` for the next small Rookie Vue component step.",
    "12. Optional after Mission 2: `mission/mission-03-todostats-surface.vibe.md` for the AI-assisted Mission 3 view.",
    "13. Optional: `mission/mission-feedback-template.md` for the reusable reflection shape.",
    "14. Optional for project owners: `reviewer/tester-feedback-report.md` for grouping tester notes into fixes.",
    "15. Optional for project owners: `reviewer/tester-handoff-messages.md` for inviting testers.",
    "16. Optional for project owners: `reviewer/public-alpha-readiness-report.md` before sending the package.",
    "17. Optional for project owners: `reviewer/alpha-focus-lock.md` before deciding what to build next.",
    "18. Optional for project owners: `reviewer/canon-candidate-backlog-report.md` to review future Canon backlog without expanding the alpha mission.",
    "19. Optional for project owners: `reviewer/alpha-package-final-qa.md` before sending the package to real testers.",
    "20. Optional for project owners: `reviewer/human-ai-readability-audit.md` for maintainer and AI editability findings.",
    "21. Optional for project owners: `reviewer/inherited-warning-burndown-report.md` for validation warning cleanup notes.",
    "22. Optional for project owners: `reviewer/ai-guardrail-evaluation.md` for checking AI-assisted answers against mission scope.",
    "23. Optional for project owners: `reviewer/ai-guardrail-red-team-pack.md` for stress-testing AI guardrails.",
    "24. Optional for project owners: `reviewer/ai-red-team-results-template.md` for recording red-team results.",
    "25. `mission/today-mission.md` for the fuller mission output.",
    "26. `flow/rookie-vue-todo-flow.md` for the full journey behind the mission.",
    "27. `walkthrough/rookie-vue-todo.md` for the calm rookie path from goal to visible win.",
    "28. `demo/mvp-demo-pack.md` for the main MVP story and demo metrics.",
    "29. `advisors/setup-beginner-vue-windows.md` and `advisors/recovery-npm-install-fails.md` for setup and recovery examples.",
    "30. `reports/ai-context-report.md` for AI Context Pack output.",
    "31. `reports/team-context-quality-report.md` to see how Atlas evaluates shared team context.",
    "",
    "## What Is Included",
    "",
    "- A static landing page.",
    "- START_HERE public alpha guide.",
    "- First-time quick start.",
    "- Optional AI prompt pack.",
    "- `mission-dashboard.html` optional visual entry point.",
    "- Optional hardened Canon reference notes for concepts used in Missions 1-3.",
    "- `help/beginner-orientation.md` for folders, App.vue, terminal commands, and package.json.",
    "- `help/vue-concept-cards.md` for the few Vue words used in the mission.",
    "- `help/terminal-confidence-guide.md` for npm commands and project-folder checks.",
    "- Today's learner-facing mission surface.",
    "- Optional AI-assisted builder mission surface.",
    "- Mission 2 and Mission 3 progression surfaces.",
    "- Reusable mission feedback template.",
    "- Optional tester feedback report template for turning notes into fixes.",
    "- Optional tester handoff messages for inviting reviewers.",
    "- Optional public alpha readiness report for deciding whether to send the demo.",
    "- Optional alpha focus lock for keeping the next build decision narrow.",
    "- Optional Canon candidate backlog report for project-owner planning.",
    "- Optional final QA report for checking the alpha handoff.",
    "- Optional human and AI readability audit for project-owner planning.",
    "- Optional inherited warning burn-down report for owner/reviewer validation cleanup.",
    "- Optional AI guardrail evaluation report for owner/reviewer review.",
    "- Optional AI guardrail red-team pack for owner/reviewer stress tests.",
    "- Optional AI red-team results template for owner/reviewer result capture.",
    "- Today's fuller Mission and mission experience report.",
    "- MVP demo narrative and walkthrough files.",
    "- Atlas Flow journey and Flow report.",
    "- Rookie walkthrough.",
    "- Canon quality report.",
    "- Capability pathway report.",
    "- Setup and recovery advisor examples.",
    "- AI context report.",
    "- Team context quality report.",
    "",
    "## Intentionally Not Included Yet",
    "",
    "- No full app.",
    "- No routing.",
    "- No backend.",
    "- No authentication.",
    "- No database.",
    "- No live LLM or API calls.",
    "- No waitlist submission.",
    "",
    "## How To Give Feedback",
    "",
    "Please focus feedback on:",
    "",
    "- Is the 30-second landing page message clear?",
    "- Which demo file best explains the product?",
    "- Which part feels most valuable: learning, setup, recovery, AI context, team context, or roadmaps?",
    "- What feels confusing or too abstract?",
    "- What would you need to see before trusting Atlas with a real developer workflow?",
    "",
    "Short, concrete notes are best. Example: `The recovery advisor example made the product click, but the Canon report needs a plainer intro.`",
    ""
  ].join("\n");

  ensureDir(path.join(packageDir, "reviewer"));
  fs.writeFileSync(path.join(packageDir, "reviewer", "package-notes.md"), readme);
}

function writeManifest(zipCreated) {
  const manifest = {
    generated_at: new Date().toISOString(),
    package_name: "developer-atlas-mvp-demo",
    package_path: path.relative(rootDir, packageDir).replace(/\\/g, "/"),
    zip_path: zipCreated ? path.relative(rootDir, zipPath).replace(/\\/g, "/") : null,
    manifest_scope: "Primary package entries and directory groups. Nested files inside grouped directories are counted by filesystem checks, not individually listed here.",
    files_included: [
      "mission-dashboard.html",
      "first-time-quick-start.md",
      "START_HERE.md",
      "package-manifest.json",
      "mission/",
      "help/",
      "ai/",
      "reference/",
      "reviewer/"
    ]
  };

  fs.writeFileSync(path.join(packageDir, "package-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
  return manifest;
}

function createZip() {
  removePath(zipPath);
  try {
    execFileSync(
      "tar",
      [
        "-a",
        "-cf",
        zipPath,
        "-C",
        packageDir,
        "."
      ],
      { stdio: "ignore" }
    );
    return fs.existsSync(zipPath);
  } catch (error) {
    return false;
  }
}

function main() {
  removePath(packageDir);
  ensureDir(packageDir);

  for (const item of filesToCopy) {
    if (item.type === "directory") {
      copyDirectory(item.from, item.to);
    } else {
      copyFile(item.from, item.to);
    }
  }

  rewritePackagedSiteLinks();
  writeReadme();
  let manifest = writeManifest(true);
  const zipCreated = createZip();
  if (!zipCreated) manifest = writeManifest(false);

  console.log(`Packaged MVP demo at ${manifest.package_path}.`);
  console.log(`Files included: ${manifest.files_included.length}.`);
  console.log(zipCreated ? `Created ${manifest.zip_path}.` : "Zip was not created.");
}

main();
