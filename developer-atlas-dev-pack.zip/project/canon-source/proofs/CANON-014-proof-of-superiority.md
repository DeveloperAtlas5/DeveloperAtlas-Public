# CANON-014 Proof Of Superiority

Canon ID: CANON-014
Node ID: canon.laravel.validation.validation
Title: Laravel validation

## What Official Docs Explain Well

Official Laravel documentation explains validation rules, inline `$request->validate()`, Form Request validation, custom rules, JSON validation errors, and rule syntax such as `unique`.

## What Developers Still Struggle With

Developers often know the rule syntax but miss the architectural boundary:

- They trust frontend validation.
- They save `$request->all()` instead of validated data.
- They mix validation and authorization.
- They keep large request contracts inside controllers.
- They write unscoped `unique` rules for tenant-scoped data.
- They misunderstand `nullable`, `required`, and conditional presence.

## How Atlas Improves The Explanation

Atlas frames Laravel validation as a request boundary. That explains why backend validation exists, why controllers should receive trusted data, and why Form Requests are not just ceremony.

## What Decision Support Atlas Adds

The node gives a practical choice:

- Inline validation for small local request contracts.
- Form Requests for named, reusable, authorized, customized, or route-aware contracts.
- Custom rules, policies, database constraints, and frontend validation as related but distinct tools.

## What Production Guidance Atlas Adds

The node includes controller validation, Form Request authorization, scoped uniqueness, JSON `422` behavior, frontend-bypass examples, debugging checks, and database-integrity warnings.

## What AI-Readable Structure Atlas Adds

The node tells AI assistants to validate server-side, use validated data, choose Form Requests for larger contracts, avoid `$request->all()`, handle scoped uniqueness, and explain where validation stops.

## Why This Deserves Gold Candidate Status

CANON-014 deserves Gold Candidate status because it turns Laravel validation from rule memorization into a production request-boundary decision model with official evidence, deterministic examples, debugging guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.
