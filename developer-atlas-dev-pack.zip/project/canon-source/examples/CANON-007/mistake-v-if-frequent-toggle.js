const { applyVIf, applyVShow, createElement } = require("./directive-sim");

module.exports = function runMistakeVIfFrequentToggle() {
  const vIfMenu = createElement("QuickMenu");
  const vShowMenu = createElement("QuickMenu");

  for (const open of [true, false, true, false, true]) {
    applyVIf(vIfMenu, open);
    applyVShow(vShowMenu, open);
    if (vShowMenu.mounted) vShowMenu.localState.toggles += 1;
  }

  if (vIfMenu.mountCount !== 3 || vIfMenu.destroyCount !== 2) {
    throw new Error("Expected v-if to repeatedly create and destroy frequent UI");
  }

  if (vShowMenu.mountCount !== 1) {
    throw new Error("Expected v-show to mount frequent UI once");
  }

  if (vShowMenu.localState.toggles !== 5) {
    throw new Error("Expected v-show to preserve local state across toggles");
  }
};
