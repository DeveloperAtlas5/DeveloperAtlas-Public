const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const rootDir = path.resolve(__dirname, "..");
const sourceDir = path.join(rootDir, "feedback");
const packageDir = path.join(rootDir, "output", "share", "developer-atlas-feedback-kit");
const zipPath = path.join(rootDir, "output", "share", "developer-atlas-feedback-kit.zip");

const feedbackFiles = [
  "README.md",
  "tester-feedback-form.md",
  "mentor-review-form.md",
  "developer-review-form.md",
  "ai-context-test-form.md",
  "feedback-analysis-template.md"
];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function removePath(target) {
  if (fs.existsSync(target)) {
    fs.rmSync(target, { recursive: true, force: true });
  }
}

function copyFeedbackFiles() {
  for (const fileName of feedbackFiles) {
    const source = path.join(sourceDir, fileName);
    const destination = path.join(packageDir, fileName);
    if (!fs.existsSync(source)) {
      throw new Error(`Missing feedback source file: feedback/${fileName}`);
    }
    fs.copyFileSync(source, destination);
  }
}

function writeReviewerGuide() {
  const guide = [
    "# Developer Atlas Reviewer Guide",
    "",
    "Thank you for reviewing the Developer Atlas MVP demo.",
    "",
    "## Start Here",
    "",
    "1. Open the demo package folder if you received it:",
    "   `../developer-atlas-mvp-demo/site/index.html`",
    "2. If you received the zip, unzip `developer-atlas-mvp-demo.zip` first.",
    "3. Spend 10 to 20 minutes reviewing the landing page and two or three demo files.",
    "4. Fill out the form that best matches your perspective.",
    "",
    "## Recommended Forms",
    "",
    "- General tester: `tester-feedback-form.md`",
    "- Mentor, advisor, or collaborator: `mentor-review-form.md`",
    "- Working developer: `developer-review-form.md`",
    "- AI assistant workflow tester: `ai-context-test-form.md`",
    "",
    "## What To Focus On",
    "",
    "- Can you understand the product in 30 seconds?",
    "- Does the demo feel credible?",
    "- Which part feels most valuable?",
    "- Which part is confusing or too broad?",
    "- Would Setup/Recovery, AI Context, or Roadmaps solve a real problem for you?",
    "- What is missing before you would use or recommend it?",
    "",
    "## How To Return Feedback",
    "",
    "Fill in the Markdown file directly and send it back, or paste your answers into a message. Short, specific notes are more useful than polished essays.",
    ""
  ].join("\n");

  fs.writeFileSync(path.join(packageDir, "reviewer-guide.md"), guide);
}

function writeDemoInstructions() {
  const instructions = [
    "# Demo Package Instructions",
    "",
    "This feedback kit is designed to be used with the Developer Atlas MVP demo package.",
    "",
    "Expected demo package locations:",
    "",
    "- Folder: `output/share/developer-atlas-mvp-demo/`",
    "- Zip: `output/share/developer-atlas-mvp-demo.zip`",
    "",
    "If both packages are side by side after sharing, open:",
    "",
    "```text",
    "../developer-atlas-mvp-demo/site/index.html",
    "```",
    "",
    "Then read:",
    "",
    "1. `../developer-atlas-mvp-demo/demo/mvp-demo-pack.md`",
    "2. `../developer-atlas-mvp-demo/demo/demo-walkthrough.md`",
    "3. `../developer-atlas-mvp-demo/advisors/recovery-npm-install-fails.md`",
    "4. `../developer-atlas-mvp-demo/reports/team-context-quality-report.md`",
    ""
  ].join("\n");

  fs.writeFileSync(path.join(packageDir, "demo-package-instructions.md"), instructions);
}

function writeManifest(zipCreated) {
  const manifest = {
    generated_at: new Date().toISOString(),
    package_name: "developer-atlas-feedback-kit",
    package_path: "output/share/developer-atlas-feedback-kit",
    zip_path: zipCreated ? "output/share/developer-atlas-feedback-kit.zip" : null,
    demo_package_path: "output/share/developer-atlas-mvp-demo",
    files_included: [
      ...feedbackFiles,
      "reviewer-guide.md",
      "demo-package-instructions.md",
      "package-manifest.json"
    ]
  };

  fs.writeFileSync(path.join(packageDir, "package-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
  return manifest;
}

function createZip() {
  removePath(zipPath);
  try {
    execFileSync(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        `Compress-Archive -Path '${packageDir}\\*' -DestinationPath '${zipPath}' -Force`
      ],
      { stdio: "ignore" }
    );
    return fs.existsSync(zipPath);
  } catch (error) {
    return false;
  }
}

function main() {
  if (!fs.existsSync(sourceDir)) {
    throw new Error("Missing feedback directory.");
  }

  removePath(packageDir);
  ensureDir(packageDir);
  copyFeedbackFiles();
  writeReviewerGuide();
  writeDemoInstructions();
  const zipCreated = createZip();
  const manifest = writeManifest(zipCreated);

  console.log(`Packaged feedback kit at ${manifest.package_path}.`);
  console.log(`Files included: ${manifest.files_included.length}.`);
  console.log(zipCreated ? `Created ${manifest.zip_path}.` : "Zip was not created.");
}

main();
