# Mission 2 - Extract a TodoItem Component

## Today's Mission

Extract one todo row into a `TodoItem` component while keeping the app behavior the same.

## Why this matters

`App.vue` can become hard to read if every todo row, button, and list action stays in one file.

Components help split the app into understandable pieces. In this mission, you are not adding a new feature and you are not rewriting the app. You are moving one repeated todo item UI into a child component so the app is easier to understand.

The goal is simple: make the app easier to read without changing what it does.

## Where this work happens

Work in the same Vue todo project you used for Mission 1.

Use this mission file as the guide.

Do not edit the Atlas package files.

## Quick Start

1. Open your Vue project.
2. Create `src/components/TodoItem.vue`.
3. Move the markup for one todo row into `TodoItem.vue`.
4. Pass the todo into the component as a prop.
5. Emit an event when the todo is toggled or removed.
6. Use `TodoItem` inside `App.vue`.
7. Confirm the app behaves the same as before.

## Estimated time

45-60 minutes

## Difficulty

Guided

## Start here

Optional help: `help/vue-concept-cards.md`

1. Find the `v-for` that renders todos.
2. Identify the markup for one todo item.
3. Create `src/components/TodoItem.vue`.
4. Add props for the todo data.
5. Add emits for actions such as toggle or remove.
6. Import and use the component in `App.vue`.
7. Test that add, complete, filter, delete, and persistence still work if your app supports them.

### Beginner-safe path

1. First make `TodoItem.vue` show the todo text only.
2. Then connect the complete/toggle action.
3. Then connect the remove action if your app has one.
4. Test after each small step.

### Challenge path

If the basic extraction works, check whether the component still behaves correctly with filtering and refresh persistence.

Props and emits are the parent-child connection for this mission. A prop lets `App.vue` give one todo to `TodoItem.vue`. An emit lets `TodoItem.vue` ask `App.vue` to toggle or remove that todo. The parent still owns the todo state.

## Where this change belongs

The new child component belongs in `src/components/TodoItem.vue`.

Create `src/components/TodoItem.vue` inside your Vue todo project, not inside the Atlas package.

Create `src/components/TodoItem.vue`.

Import `TodoItem` in `src/App.vue`.

Use `TodoItem` inside the existing todo list `v-for`.

Keep the todo array/list state in `App.vue`.

Keep localStorage loading/saving in `App.vue` for now.

Do not move all state into `TodoItem.vue`.

Do not create a global store.

### Tiny file map

- `src/App.vue` keeps the todo list state and decides what changes.
- `src/components/TodoItem.vue` displays one todo item and sends user actions back to `App.vue`.

For this mission, the child component should not own the full todo list.

### Parent-child communication

`App.vue` is the parent.

`TodoItem.vue` is the child.

The parent passes one todo down as a prop.

The child emits an event when the user clicks complete or remove.

The parent updates the todo list.

### Tiny parent-child diagram

```txt
App.vue
  owns the todo list
  owns localStorage
  updates todos when events happen

        prop: todo down
        event: toggle/remove up

TodoItem.vue
  shows one todo
  emits user actions
```

Remember: props go down, events go up.

### Shape only example

`App.vue` owns the list:

```vue
<TodoItem
  v-for="todo in todos"
  :key="todo.id"
  :todo="todo"
  @toggle="toggleTodo"
  @remove="removeTodo"
/>
```

`TodoItem.vue` receives one item and asks the parent to act:

```vue
<script setup>
defineProps({ todo: Object })
const emit = defineEmits(['toggle', 'remove'])
</script>
```

This is only the shape of the connection. Keep your own app names if they are different.

Do not move the whole app state into a new store. Do not add Pinia, routing, backend, database, auth, or deployment.

Optional help: `help/vue-concept-cards.md`

## Check your result

You are done when:

- `TodoItem.vue` exists.
- `App.vue` uses `TodoItem` inside the todo list.
- Todos still render.
- Completing or removing todos still works if your app supports it.
- Filtering still works if your app supports it.
- `localStorage` persistence still works if Mission 1 added it.
- No browser console errors appear.

Visible win: the app is cleaner, and the todo behavior still feels the same.

## Completion checklist

- [ ] I created `src/components/TodoItem.vue`.
- [ ] `App.vue` imports and uses `TodoItem`.
- [ ] The todo list still appears.
- [ ] Completing a todo still works if my app supports it.
- [ ] Removing a todo still works if my app supports it.
- [ ] Filtering still works if my app supports it.
- [ ] Refresh persistence still works if Mission 1 added it.
- [ ] I did not add backend, routing, Pinia, database, auth, or deployment.

## If you get stuck

- Component does not show: confirm `TodoItem.vue` is saved under `src/components/` and imported in `App.vue`.
- Import path mismatch: check whether the import path matches your folder structure, such as `./components/TodoItem.vue`.
- Prop name mismatch: make sure the prop name in `TodoItem.vue` matches the name used in `App.vue`.
- Emit name mismatch: make sure the event name emitted by `TodoItem.vue` matches the listener name in `App.vue`.
- Prop mutation warning: keep the todo state changes in `App.vue`; the child should emit an event instead of changing the prop directly.
- Todo actions no longer work: trace one action from the button in `TodoItem.vue` to the emit, then to the handler in `App.vue`.
- App state moved too far: move todo state back to `App.vue` and keep `TodoItem.vue` focused on one row.
- `localStorage` no longer saves after extraction: confirm the same add, toggle, remove, and filter logic still updates the parent todo state that Mission 1 saved.

### If Vue warns about changing a prop

The child should not directly change the todo prop.

Instead, `TodoItem.vue` should emit an event, and `App.vue` should update the todo list.

Take one small step at a time. The mission is complete when the structure is cleaner and the behavior still matches your previous app.

## Ask AI for help

Copy and paste this prompt:

```txt
I am building a Vue 3 todo app. Mission 2 is to extract one todo row into a TodoItem component while keeping behavior the same. Please help me one step at a time. Keep todo state in App.vue for now. Do not add Pinia, routing, backend, auth, database, deployment, or a new architecture.
```

## Skip today

- Pinia
- Routing
- Backend
- Auth/login
- Database
- Deployment
- Full app rewrite
- Styling overhaul
- Moving all state into a global store
- Adding new features

## Next mission preview

Next, you can learn props vs emits more deeply by making the parent and child communicate cleanly.

## After the mission

Before you started, how confident did you feel?

1 2 3 4 5

After finishing or stopping, how confident do you feel now?

1 2 3 4 5

Did you complete the visible win?

- Yes
- Partly
- Not yet

Did recovery help?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.
