const { applyVShow, createElement } = require("./directive-sim");

module.exports = function runVShowTogglesDisplay() {
  const drawer = createElement("FilterDrawer");

  applyVShow(drawer, false);
  if (!drawer.mounted || drawer.style.display !== "none") {
    throw new Error("Expected v-show false to keep drawer mounted but hidden");
  }

  applyVShow(drawer, true);
  if (!drawer.mounted || drawer.style.display !== "") {
    throw new Error("Expected v-show true to keep drawer mounted and visible");
  }

  applyVShow(drawer, false);
  if (drawer.mountCount !== 1) {
    throw new Error(`Expected v-show to mount once, got ${drawer.mountCount}`);
  }
};
