# Laravel Factory

Technology: Laravel

## Simple meaning

A factory creates fake, test, or demo data for a model.

## Why it exists

Factories make it easy to create realistic records without typing every field by hand.

## Where you use it

In `database/factories`.

## When to use it

Use a factory in tests, seeders, demos, or local development data.

## Tiny example

`User::factory()->count(10)->create();`

## Common beginner confusion

A factory describes how to make fake records. It does not usually run by itself.

## Related concepts

- Model
- Seeder
- Migration

## Similar idea in another technology

Frontend mock data serves a similar purpose when you need realistic data before the real API is ready.
