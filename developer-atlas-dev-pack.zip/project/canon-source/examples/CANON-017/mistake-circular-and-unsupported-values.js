const assert = require("node:assert/strict");

module.exports = function runMistakeCircularAndUnsupportedValuesExample() {
  const withUnsupportedValues = {
    name: "Ada",
    nickname: undefined,
    greet() {
      return "hello";
    },
    tags: ["developer", undefined]
  };

  const text = JSON.stringify(withUnsupportedValues);
  const parsed = JSON.parse(text);

  assert.equal(parsed.name, "Ada");
  assert.equal("nickname" in parsed, false);
  assert.equal("greet" in parsed, false);
  assert.deepEqual(parsed.tags, ["developer", null]);

  const circular = { name: "cycle" };
  circular.self = circular;

  assert.throws(() => {
    JSON.stringify(circular);
  }, TypeError);
};
