const { validate } = require("./validation-simulator");

function unsafeStore(payload) {
  return { saved: payload };
}

function safeStore(payload) {
  const result = validate(payload, {
    quantity: ["required", "integer"],
    shipping_method: ["required", { in: ["standard", "express"] }]
  });

  if (!result.passes) {
    return { errors: result.errors };
  }

  return { saved: result.validated };
}

module.exports = function runMistakeTrustingFrontendValidationOnly() {
  const bypassedPayload = {
    quantity: 0.5,
    shipping_method: "teleport"
  };

  const unsafe = unsafeStore(bypassedPayload);
  const safe = safeStore(bypassedPayload);

  if (unsafe.saved.shipping_method !== "teleport") {
    throw new Error("Unsafe store should demonstrate that raw payload can bypass frontend checks.");
  }

  if (!safe.errors.quantity || !safe.errors.shipping_method) {
    throw new Error("Server-side validation should reject bypassed frontend input.");
  }

  return { unsafe, safe };
};
