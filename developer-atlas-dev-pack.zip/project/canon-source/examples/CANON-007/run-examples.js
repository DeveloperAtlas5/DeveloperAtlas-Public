const examples = [
  ["v-if creates/removes element", require("./v-if-creates-removes-element")],
  ["v-show toggles display", require("./v-show-toggles-display")],
  ["mistake: using v-if for frequently toggled UI", require("./mistake-v-if-frequent-toggle")],
  ["mistake: using v-show for expensive initial render", require("./mistake-v-show-expensive-initial-render")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-007 example(s).`);
