const { validate } = require("./validation-simulator");

module.exports = function runControllerInlineValidation() {
  const rules = {
    name: ["required"],
    email: ["required", "email"]
  };

  const valid = validate({ name: "Ada", email: "ada@example.com" }, rules);
  const invalid = validate({ name: "Ada", email: "not-an-email" }, rules);

  if (!valid.passes || valid.validated.email !== "ada@example.com") {
    throw new Error("Inline validation should return validated data for a valid payload.");
  }

  if (invalid.passes || !invalid.errors.email.includes("email")) {
    throw new Error("Inline validation should reject invalid email input.");
  }

  return { valid, invalid };
};
