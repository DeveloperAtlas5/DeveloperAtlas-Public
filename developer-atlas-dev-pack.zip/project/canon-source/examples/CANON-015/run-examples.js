const examples = [
  ["WHERE filters active orders before grouping", require("./where-filters-active-orders-before-grouping")],
  ["HAVING filters customers with COUNT(*) > 1", require("./having-filters-count-greater-than-one")],
  ["using WHERE and HAVING together", require("./where-and-having-together")],
  ["mistake: using WHERE with aggregate COUNT()", require("./mistake-where-with-aggregate-count")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-015 example(s).`);
