# Developer Atlas Static Landing Page

This is a tiny static landing page for the Developer Atlas MVP.

It is intentionally not a full app:

- No routing.
- No backend.
- No authentication.
- No LLM or API calls.
- No build step.

Open `site/index.html` directly in a browser, or run:

```bash
npm run site:preview
```

The packaged public alpha demo starts with:

```text
START_HERE.md
```

Open that file first after unzipping the shareable package. It explains the default learner view, optional AI-assisted builder view, optional help files, and how to give feedback.

`START_HERE.md` includes a short role guide so beginners, Rookie Vue learners, AI-assisted builders, and technical reviewers know what feedback is most useful.

The demo package groups the main mission, optional help files, and feedback materials so testers can start without reading everything.

The demo package now includes `mission-dashboard.html`, a lightweight visual entry point for testers who prefer an overview before opening markdown files.

The package includes a final QA report for checking the alpha handoff before sending it to real testers.

Optional help files live under `help/` in the packaged demo:

- `help/beginner-orientation.md` for testers who are unsure where Vue files live or where terminal commands should run.
- `help/vue-concept-cards.md` for short explanations of `ref()`, `reactive()`, `v-for`, `:key`, and related mission concepts.
- `help/terminal-confidence-guide.md` for testers who are unsure where to run `npm install` or `npm run dev`.

The primary demo is the learner-facing Mission Surface:

```text
output/experience/today-mission-surface.md
```

Recommended local reading order:

1. `output/experience/START_HERE.md`
2. `site/index.html`
3. `output/experience/today-mission-surface.md`
4. Optional: `output/experience/today-mission-surface.vibe.md`
5. Optional for project owners: `output/experience/tester-feedback-report.md`
6. `output/mission/today-mission.md`
7. `output/flow/rookie-vue-todo-flow.md`
8. `output/walkthrough/rookie-vue-todo.md`
9. `output/demo/mvp-demo-pack.md`

The page still links to the larger MVP demo pack, but the Mission Surface is the first clear demonstration of the Atlas experience: one clear next step, one recovery path, one visible win.

The optional AI-assisted builder view helps users ask better prompts, reject unsafe rewrites, and recover when generated code breaks.

Each mission ends with a short reflection so Atlas can measure confidence, recovery, and remaining confusion.

Mission surfaces include a short placement hint so testers can see where the change usually belongs.

Mission surfaces also include a short completion checklist so testers know when the visible win is working.

The package also includes a tester feedback report template for turning collected notes into product fixes. It is optional supporting material for the project owner or reviewer, not an extra step for normal learners.

The package also includes tester handoff messages for inviting beginners, Rookie Vue learners, AI-assisted builders, and reviewers.

The package includes a public alpha readiness report for checking whether the demo is ready to send to a small tester group.

The package includes an alpha focus lock to keep the public alpha narrow before adding new product lines.
