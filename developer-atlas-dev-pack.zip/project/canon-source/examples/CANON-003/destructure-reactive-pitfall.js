const assert = require("node:assert/strict");
const { reactive, toRefs } = require("./reactivity-sim");

function run() {
  const state = reactive({
    count: 0,
    label: "Clicks"
  });

  const { count: staleCount } = state;
  state.count += 1;

  assert.equal(staleCount, 0);
  assert.equal(state.count, 1);

  const refs = toRefs(state);
  const { count } = refs;
  count.value += 1;

  assert.equal(count.value, 2);
  assert.equal(state.count, 2);

  return { staleCount, safeCount: count.value };
}

module.exports = run;

if (require.main === module) run();
