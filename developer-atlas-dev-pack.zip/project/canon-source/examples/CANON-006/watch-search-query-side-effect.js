const { createWatchedRef, watch } = require("./reactivity-sim");

module.exports = function runWatchSearchQuerySideEffect() {
  const searchQuery = createWatchedRef("");
  const searchedQueries = [];

  watch(searchQuery, (query) => {
    const trimmed = query.trim();
    if (trimmed.length >= 3) searchedQueries.push(trimmed);
  });

  searchQuery.value = "vu";
  searchQuery.value = "vue";
  searchQuery.value = "vue computed";

  const actual = searchedQueries.join("|");
  const expected = "vue|vue computed";

  if (actual !== expected) {
    throw new Error(`Expected searched queries ${expected}, got ${actual}`);
  }
};
