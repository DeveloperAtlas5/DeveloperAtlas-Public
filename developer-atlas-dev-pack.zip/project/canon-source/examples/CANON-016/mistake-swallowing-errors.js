const assert = require("node:assert/strict");

module.exports = async function runMistakeSwallowingErrorsExample() {
  async function badSave() {
    try {
      throw new Error("database unavailable");
    } catch {
      return undefined;
    }
  }

  async function betterSave(logs) {
    try {
      throw new Error("database unavailable");
    } catch (error) {
      logs.push(`save failed: ${error.message}`);
      throw error;
    }
  }

  const swallowed = await badSave();
  assert.equal(swallowed, undefined);

  const logs = [];
  await assert.rejects(() => betterSave(logs), /database unavailable/);
  assert.deepEqual(logs, ["save failed: database unavailable"]);
};
