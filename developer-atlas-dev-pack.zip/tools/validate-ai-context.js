const fs = require("fs");
const path = require("path");
const { readGoals } = require("./goal-utils");
const {
  aiContextDir,
  readAiContextRequests
} = require("./ai-context-utils");

const schemaFiles = [
  "ai-context-request.schema.json",
  "ai-context-output.schema.json"
];

const requiredFields = [
  "request_id",
  "profile_id",
  "goals",
  "learner_level",
  "current_task",
  "desired_ai_role",
  "include_sections",
  "max_length",
  "preferred_tone",
  "known_constraints"
];

const levels = new Set(["rookie", "junior", "professional", "ai_tutor"]);

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);
  validateRequests(readAiContextRequests(), errors, warnings);

  console.log("Atlas AI Context validation");
  console.log(`Requests: ${readAiContextRequests().length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const file = path.join(aiContextDir, fileName);
    if (!fs.existsSync(file)) {
      errors.push(`ai-context/${fileName}: missing schema file`);
      continue;
    }
    try {
      JSON.parse(fs.readFileSync(file, "utf8"));
    } catch (error) {
      errors.push(`ai-context/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateRequests(records, errors, warnings) {
  const knownGoals = new Set(readGoals().map((record) => record.goal.goal_id));
  const seen = new Set();

  for (const { request, relativePath } of records) {
    for (const field of requiredFields) {
      if (request[field] === undefined || request[field] === null || request[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }

    if (seen.has(request.request_id)) errors.push(`${relativePath}: duplicate request_id ${request.request_id}`);
    seen.add(request.request_id);

    if (!levels.has(request.learner_level)) errors.push(`${relativePath}: invalid learner_level ${request.learner_level}`);
    for (const field of ["goals", "include_sections", "known_constraints"]) {
      if (!Array.isArray(request[field])) errors.push(`${relativePath}: ${field} should be an array`);
    }
    if (typeof request.max_length !== "number" || request.max_length < 400) {
      errors.push(`${relativePath}: max_length should be at least 400`);
    }
    for (const goal of request.goals || []) {
      if (!knownGoals.has(goal)) warnings.push(`${relativePath}: unknown goal ${goal}`);
    }
  }
}

main();
