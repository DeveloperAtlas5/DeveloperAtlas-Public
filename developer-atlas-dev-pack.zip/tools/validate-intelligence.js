const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const jsonDirs = ["intent", "edr", "patterns"];
const requiredFiles = [
  "intent/ontology.json",
  "intent/intent-types.json",
  "intent/intent-detection-model.json",
  "kernel/constraint-engine.json",
  "brain/decision-matrix.schema.json",
  "brain/reasoning-trace.schema.json",
  "patterns/pattern.schema.json",
  "patterns/pattern-catalog.json",
  "edr/edr.schema.json",
  "kernel/schemas/mission-v2.schema.json"
];

function main() {
  const errors = [];
  const parsed = new Map();

  for (const relativePath of requiredFiles) {
    const absolutePath = path.join(rootDir, relativePath);
    if (!fs.existsSync(absolutePath)) {
      errors.push(`missing required intelligence file: ${relativePath}`);
      continue;
    }
    parseJson(absolutePath, errors, parsed);
  }

  for (const dir of jsonDirs) {
    for (const file of findJsonFiles(path.join(rootDir, dir))) {
      parseJson(file, errors, parsed);
    }
  }

  const intentTypes = parsed.get("intent/intent-types.json");
  const ontology = parsed.get("intent/ontology.json");
  const constraints = parsed.get("kernel/constraint-engine.json");
  const patterns = parsed.get("patterns/pattern-catalog.json");
  const reasoningTrace = parsed.get("brain/reasoning-trace.schema.json");

  if (intentTypes && ontology) {
    const missingCategories = intentTypes.top_level_intents.filter((intent) => !ontology.categories[intent]);
    for (const intent of missingCategories) errors.push(`intent/ontology.json: missing category for ${intent}`);
  }

  const counts = {
    intentTypes: intentTypes?.top_level_intents?.length || 0,
    constraintDimensions: Object.keys(constraints?.dimensions || {}).length,
    patterns: patterns?.patterns?.length || 0,
    reasoningStages: reasoningTrace?.properties?.reasoning_trace?.items?.properties?.stage?.enum?.length || 0
  };

  console.log("Atlas Intelligence validation");
  console.log(`Intent types: ${counts.intentTypes}`);
  console.log(`Constraint dimensions: ${counts.constraintDimensions}`);
  console.log(`Pattern definitions: ${counts.patterns}`);
  console.log(`Reasoning stages: ${counts.reasoningStages}`);
  console.log(`EDR schema: ${parsed.has("edr/edr.schema.json") ? "present" : "missing"}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);

  if (errors.length) process.exitCode = 1;
}

function parseJson(file, errors, parsed) {
  const relativePath = path.relative(rootDir, file).replace(/\\/g, "/");
  if (parsed.has(relativePath)) return;
  try {
    parsed.set(relativePath, JSON.parse(fs.readFileSync(file, "utf8")));
  } catch (error) {
    errors.push(`${relativePath}: invalid JSON (${error.message})`);
  }
}

function findJsonFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) return findJsonFiles(fullPath);
    return entry.isFile() && entry.name.endsWith(".json") ? [fullPath] : [];
  });
}

main();
