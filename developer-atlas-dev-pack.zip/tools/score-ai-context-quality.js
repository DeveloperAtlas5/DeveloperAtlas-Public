const fs = require("fs");
const path = require("path");
const {
  aiContextOutputDir
} = require("./ai-context-utils");

function main() {
  const packs = readContextPacks();
  const scores = packs.map(scorePack);
  const report = buildReport(scores);

  fs.mkdirSync(aiContextOutputDir, { recursive: true });
  fs.writeFileSync(
    path.join(aiContextOutputDir, "ai-context-quality-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(aiContextOutputDir, "ai-context-quality-report.md"),
    toMarkdown(report)
  );

  console.log(`Scored ${packs.length} AI context pack(s).`);
  console.log("Generated output/ai-context/ai-context-quality-report.json.");
  console.log("Generated output/ai-context/ai-context-quality-report.md.");
}

function readContextPacks() {
  if (!fs.existsSync(aiContextOutputDir)) return [];

  return fs.readdirSync(aiContextOutputDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .filter((fileName) => !fileName.includes("report"))
    .sort()
    .map((fileName) => {
      const jsonPath = path.join(aiContextOutputDir, fileName);
      const mdPath = jsonPath.replace(/\.json$/, ".md");
      return {
        ...JSON.parse(fs.readFileSync(jsonPath, "utf8")),
        markdown_length: fs.existsSync(mdPath) ? fs.readFileSync(mdPath, "utf8").length : 0
      };
    });
}

function scorePack(pack) {
  const improvements = [];
  const brevity = brevityScore(pack, improvements);
  const specificity = specificityScore(pack, improvements);
  const constraints = constraintScore(pack, improvements);
  const nextSteps = nextStepClarityScore(pack, improvements);
  const overcomplication = overcomplicationRiskScore(pack, improvements);
  const missingContext = missingContextRiskScore(pack, improvements);
  const usefulness = aiUsefulnessScore(pack, improvements);

  const overall = round(
    brevity * 0.14 +
    specificity * 0.16 +
    constraints * 0.14 +
    nextSteps * 0.16 +
    overcomplication * 0.14 +
    missingContext * 0.12 +
    usefulness * 0.14
  );

  return {
    request_id: pack.request_id,
    brevity_score: brevity,
    specificity_score: specificity,
    constraint_score: constraints,
    next_step_clarity_score: nextSteps,
    overcomplication_risk_score: overcomplication,
    missing_context_risk_score: missingContext,
    ai_usefulness_score: usefulness,
    overall_score: overall,
    recommended_improvements: unique(improvements)
  };
}

function brevityScore(pack, improvements) {
  const length = pack.markdown_length || pack.estimated_length || 0;
  const simpleTask = /todo|next step|debug|hardware advice/i.test(pack.request_id);
  const target = simpleTask ? 1700 : 2200;
  let score = 100;

  if (length > target) score -= Math.min(50, (length - target) / 20);
  if (length < 600) score -= 15;
  if (length > target) improvements.push("Shorten the pack or remove lower-priority context for this task.");
  if (length < 600) improvements.push("Add enough context for the assistant to understand the task and constraints.");

  return clampRound(score);
}

function specificityScore(pack, improvements) {
  let score = 0;
  if (hasConcreteText(pack.current_task)) score += 30;
  if (hasConcreteText(pack.user_goal_summary)) score += 25;
  if (pack.missing_knowledge?.length) score += 20;
  if (pack.current_readiness?.readiness_id && pack.current_readiness.readiness_id !== "unknown") score += 15;
  if (pack.what_to_help_with_now?.length) score += 10;

  if (!hasConcreteText(pack.current_task)) improvements.push("Add a concrete current task.");
  if (!hasConcreteText(pack.user_goal_summary)) improvements.push("Replace vague goals with specific target outcomes.");
  if (!pack.missing_knowledge?.length) improvements.push("Include missing knowledge so the assistant can target gaps.");

  return clampRound(score);
}

function constraintScore(pack, improvements) {
  let score = 0;
  if (pack.hardware_tooling_constraints?.length) score += 35;
  if (pack.what_not_to_overcomplicate?.length) score += 35;
  if ((pack.hardware_tooling_constraints || []).some((item) => /do not|avoid|only|first|no /i.test(item))) score += 15;
  if ((pack.what_not_to_overcomplicate || []).some((item) => /do not|skip|avoid|defer/i.test(item))) score += 15;

  if (!pack.hardware_tooling_constraints?.length) improvements.push("Add known constraints, tooling limits, or hardware boundaries.");
  if (!pack.what_not_to_overcomplicate?.length) improvements.push("Add explicit guidance about what not to overcomplicate.");

  return clampRound(score);
}

function nextStepClarityScore(pack, improvements) {
  let score = 0;
  if (pack.what_to_help_with_now?.length) score += 35;
  if (pack.next_3_steps?.length >= 2) score += 35;
  if (pack.shortest_acceptable_path?.length) score += 20;
  if ((pack.next_3_steps || []).some((item) => /study|verify|install|start|build|ask|check/i.test(item))) score += 10;

  if (!pack.what_to_help_with_now?.length) improvements.push("Add a clear 'what to help with now' instruction.");
  if ((pack.next_3_steps || []).length < 2) improvements.push("Add at least two practical next steps.");
  if (!pack.shortest_acceptable_path?.length) improvements.push("Add the shortest acceptable path.");

  return clampRound(score);
}

function overcomplicationRiskScore(pack, improvements) {
  let score = 100;
  const combined = [
    ...(pack.what_to_help_with_now || []),
    ...(pack.shortest_acceptable_path || []),
    ...(pack.what_not_to_overcomplicate || [])
  ].join(" ").toLowerCase();

  if ((pack.missing_knowledge || []).length > 8) score -= 15;
  if ((pack.hardware_tooling_constraints || []).length > 8) score -= 10;
  if (!/small|first|only|do not|avoid|defer|scope|shortest/.test(combined)) score -= 25;
  if (/architecture|auth|state management|docker|database|backend/.test(combined) && /todo|vue-next-step/.test(pack.request_id)) score -= 15;

  if (score < 80) improvements.push("Reduce overcomplication risk by narrowing scope and naming what to avoid.");
  return clampRound(score);
}

function missingContextRiskScore(pack, improvements) {
  let score = 0;
  const requiredSignals = [
    ["AI role instruction", pack.ai_role_instruction],
    ["current task", pack.current_task],
    ["readiness", pack.current_readiness?.readiness_id],
    ["constraints", pack.hardware_tooling_constraints?.length],
    ["preferred explanation style", pack.preferred_explanation_style],
    ["clarification rules", pack.clarification_rules?.length]
  ];

  for (const [label, value] of requiredSignals) {
    if (value && value !== "unknown") score += 100 / requiredSignals.length;
    else improvements.push(`Add ${label}.`);
  }

  return clampRound(score);
}

function aiUsefulnessScore(pack, improvements) {
  let score = 0;
  if (hasConcreteText(pack.ai_role_instruction)) score += 20;
  if (pack.clarification_rules?.length) score += 15;
  if (hasConcreteText(pack.preferred_explanation_style)) score += 15;
  if (pack.what_to_help_with_now?.length) score += 20;
  if (pack.what_not_to_overcomplicate?.length) score += 15;
  if (pack.next_3_steps?.length) score += 15;

  if (!hasConcreteText(pack.ai_role_instruction)) improvements.push("Add a stronger AI role instruction.");
  if (!pack.clarification_rules?.length) improvements.push("Add clarification rules so the assistant asks only when needed.");
  if (!hasConcreteText(pack.preferred_explanation_style)) improvements.push("Add preferred explanation style.");

  return clampRound(score);
}

function buildReport(scores) {
  const sortedHigh = [...scores].sort((a, b) => b.overall_score - a.overall_score);
  const sortedLow = [...scores].sort((a, b) => a.overall_score - b.overall_score);
  return {
    generated_at: new Date().toISOString(),
    total_context_packs_scored: scores.length,
    average_overall_score: average(scores.map((score) => score.overall_score)),
    highest_quality_pack: sortedHigh[0] || null,
    lowest_quality_pack: sortedLow[0] || null,
    packs_with_high_overcomplication_risk: scores.filter((score) => score.overcomplication_risk_score < 75),
    packs_with_high_missing_context_risk: scores.filter((score) => score.missing_context_risk_score < 75),
    scores
  };
}

function toMarkdown(report) {
  const lines = [
    "# Atlas AI Context Quality Report",
    "",
    `Total context packs scored: ${report.total_context_packs_scored}`,
    `Average overall score: ${report.average_overall_score}`,
    `Highest quality pack: ${report.highest_quality_pack?.request_id || "None"} (${report.highest_quality_pack?.overall_score ?? "n/a"})`,
    `Lowest quality pack: ${report.lowest_quality_pack?.request_id || "None"} (${report.lowest_quality_pack?.overall_score ?? "n/a"})`,
    "",
    "## High Overcomplication Risk",
    "",
    ...formatRisk(report.packs_with_high_overcomplication_risk, "overcomplication_risk_score"),
    "",
    "## High Missing Context Risk",
    "",
    ...formatRisk(report.packs_with_high_missing_context_risk, "missing_context_risk_score"),
    "",
    "## Scores",
    ""
  ];

  for (const score of report.scores) {
    lines.push(
      `### ${score.request_id}`,
      "",
      `Overall: ${score.overall_score}`,
      `Brevity: ${score.brevity_score}`,
      `Specificity: ${score.specificity_score}`,
      `Constraints: ${score.constraint_score}`,
      `Next step clarity: ${score.next_step_clarity_score}`,
      `Overcomplication risk: ${score.overcomplication_risk_score}`,
      `Missing context risk: ${score.missing_context_risk_score}`,
      `AI usefulness: ${score.ai_usefulness_score}`,
      "",
      "Recommended improvements:",
      ...formatList(score.recommended_improvements),
      ""
    );
  }

  return `${lines.join("\n")}\n`;
}

function formatRisk(items, field) {
  return items.length ? items.map((item) => `- ${item.request_id}: ${item[field]}`) : ["- None"];
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function hasConcreteText(value) {
  if (typeof value !== "string" || value.trim().length < 8) return false;
  return !/^(n\/a|none|unknown|todo)$/i.test(value.trim());
}

function average(values) {
  if (!values.length) return 0;
  return round(values.reduce((total, value) => total + value, 0) / values.length);
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

function clampRound(value) {
  return round(Math.max(0, Math.min(100, value)));
}

function round(value) {
  return Number(value.toFixed(2));
}

main();
