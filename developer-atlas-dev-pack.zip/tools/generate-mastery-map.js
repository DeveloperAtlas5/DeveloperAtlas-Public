const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getLearning
} = require("./learning-utils");

function main() {
  const entries = readCanonIndex().entries || [];
  const lines = [
    "# Atlas Mastery Map",
    "",
    "| Canon Node | Mastery Proof | Estimated Practice Time | Interview Readiness | Recommended Next Node |",
    "| --- | --- | ---: | --- | --- |"
  ];
  let count = 0;

  for (const entry of entries) {
    const learning = getLearning(entry);
    const proof = learning.mastery_proof;
    if (!proof) continue;
    count += 1;
    lines.push([
      `${entry.canon_id}: ${escapeCell(entry.title)}`,
      escapeCell(proof.proof),
      Number(learning.estimated_practice_minutes || 0),
      escapeCell(learning.interview_readiness || "not specified"),
      escapeCell((learning.unlocks || [])[0] || "None")
    ].join(" | ").replace(/^/, "| ").replace(/$/, " |"));
  }

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "mastery-map.md"), `${lines.join("\n")}\n`);
  console.log(`Generated output/learning/mastery-map.md with ${count} mastery proofs.`);
}

function escapeCell(value) {
  return String(value || "").replace(/\|/g, "\\|").replace(/\r?\n/g, " ");
}

main();

