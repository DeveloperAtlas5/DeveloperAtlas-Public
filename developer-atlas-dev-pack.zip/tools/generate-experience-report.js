const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const outputDir = path.join(rootDir, "output", "experience");

const principles = [
  "Reduce uncertainty before reducing effort.",
  "Progress over perfection.",
  "Every recommendation should explain why.",
  "Every roadmap should show the smallest useful next step.",
  "Atlas should never shame users for not being ready.",
  "Atlas should help users recover from blockers quickly.",
  "Atlas should make progress visible.",
  "Atlas should support both humans and AI without locking users into one tool.",
  "Atlas should feel like a calm engineering mentor, not a noisy dashboard.",
  "Atlas should help people become capable, not just complete content."
];

function readJson(relativePath, fallback) {
  const fullPath = path.join(rootDir, relativePath);
  if (!fs.existsSync(fullPath)) return fallback;
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function main() {
  ensureDir(outputDir);

  const readiness = readJson("output/readiness/readiness-report.json", {});
  const deltas = readJson("output/readiness/readiness-delta-report.json", {});
  const capability = readJson("output/capability/project-fit-report.json", {});
  const momentum = readJson("output/momentum/momentum-report.json", {});
  const recoveryAverage = extractRecoveryAverage();
  const aiContext = readJson("output/ai-context/ai-context-quality-report.json", {});

  const lines = [
    "# Atlas Experience Report",
    "",
    "## Tagline",
    "",
    "Developer Atlas  ",
    "Learn with confidence. Build with purpose. Grow without getting lost.",
    "",
    "## User Promise",
    "",
    "Atlas helps users understand where they are, what to do next, why it matters, and how to recover when progress gets blocked.",
    "",
    "## Experience Principles",
    "",
    ...principles.map((principle, index) => `${index + 1}. ${principle}`),
    "",
    "## Where Atlas Supports Confidence Today",
    "",
    `- Readiness reports process ${readiness.readiness_examples_processed || 0} profiles and name practical weak areas instead of vague failure.`,
    `- Readiness Delta reports show ${deltas.deltas_processed || 0} before/after examples so users can see that they are closer than last week.`,
    `- AI Context quality scoring averages ${aiContext.average_overall_score || 0}, helping users give AI clearer context without overcomplication.`,
    "",
    "## Where Atlas Supports Momentum Today",
    "",
    `- Capability Intelligence identifies ${(capability.ready_today || []).length} ready-today project and ${(capability.mostly_ready || []).length} mostly-ready projects.`,
    `- Momentum examples estimate ${momentum.estimated_time_saved || 0} minutes saved and a confidence improvement of ${momentum.confidence_improvement || 0}.`,
    "- Capability pathways move from a small project to larger work instead of presenting everything at once.",
    "",
    "## Where Atlas Supports Recovery Today",
    "",
    `- Recovery Advisor examples cover common blockers and average ${recoveryAverage} estimated recovery time.`,
    "- Friction Intelligence models setup blockers, package manager problems, PATH issues, build failures, and local environment drift.",
    "- Setup Advisor outputs include install order, verification checks, and likely friction problems.",
    "",
    "## Where Atlas Still Risks Overwhelming Users",
    "",
    "- The system has many intelligence layers, which can feel broad without a guided first path.",
    "- Some reports expose internal terms before a user understands the simple next step.",
    "- Content validation still has inherited enrichment warnings that could distract contributors from user-facing progress.",
    "- The static landing page is concise, but future demos should keep one primary story instead of showing every subsystem.",
    "",
    "## Recommended UX And Content Improvements",
    "",
    "1. Add a one-page rookie walkthrough that starts with one goal, one project, and one recovery path.",
    "2. Label recommendations as essential, recommended, optional, or safe to defer.",
    "3. Add visible-win summaries to roadmap and readiness outputs.",
    "4. Keep AI context packs short by default and expand only when the user asks.",
    "5. Review all public copy for shame language, noisy terms, and unnecessary architecture labels.",
    "",
    "## Source Files",
    "",
    "- experience/atlas-experience-principles.md",
    "- experience/confidence-design.md",
    "- experience/momentum-design.md",
    "- experience/pleasant-use-principles.md",
    "- experience/user-promise.md",
    "- experience/experience-review-checklist.md",
    ""
  ];

  fs.writeFileSync(path.join(outputDir, "experience-report.md"), lines.join("\n"));
  console.log("Generated output/experience/experience-report.md.");
}

function extractRecoveryAverage() {
  const reportPath = path.join(rootDir, "output", "recovery-advisor", "recovery-advisor-report.md");
  if (!fs.existsSync(reportPath)) return "unknown";
  const text = fs.readFileSync(reportPath, "utf8");
  const match = text.match(/Average recovery time:\s*([^\n]+)/);
  return match ? match[1].trim() : "unknown";
}

main();
