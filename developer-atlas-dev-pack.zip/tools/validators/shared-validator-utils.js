const fs = require("fs");
const path = require("path");
const { rootDir } = require("../content-utils");

const missionDir = path.join(rootDir, "mission");
const outputDir = path.join(rootDir, "output", "mission");
const missionSurfacePath = path.join(rootDir, "output", "experience", "today-mission-surface.md");
const vibeMissionSurfacePath = path.join(rootDir, "output", "experience", "today-mission-surface.vibe.md");
const missionTwoSurfacePath = path.join(rootDir, "output", "experience", "mission-02-todoitem-surface.md");
const vibeMissionTwoSurfacePath = path.join(rootDir, "output", "experience", "mission-02-todoitem-surface.vibe.md");
const missionThreeSurfacePath = path.join(rootDir, "output", "experience", "mission-03-todostats-surface.md");
const vibeMissionThreeSurfacePath = path.join(rootDir, "output", "experience", "mission-03-todostats-surface.vibe.md");
const missionDashboardPath = path.join(rootDir, "output", "experience", "mission-dashboard.html");
const startHerePath = path.join(rootDir, "output", "experience", "START_HERE.md");
const firstTimeQuickStartPath = path.join(rootDir, "output", "experience", "first-time-quick-start.md");
const aiPromptPackPath = path.join(rootDir, "output", "experience", "ai-prompt-pack.md");
const hardenedCanonOutputDir = path.join(rootDir, "output", "experience", "canon", "hardened");
const beginnerOrientationPath = path.join(rootDir, "output", "experience", "beginner-orientation.md");
const vueConceptCardsPath = path.join(rootDir, "output", "experience", "vue-concept-cards.md");
const terminalConfidenceGuidePath = path.join(rootDir, "output", "experience", "terminal-confidence-guide.md");
const testerFeedbackReportPath = path.join(rootDir, "output", "experience", "tester-feedback-report.md");
const testerHandoffMessagesPath = path.join(rootDir, "output", "experience", "tester-handoff-messages.md");
const publicAlphaReadinessReportPath = path.join(rootDir, "output", "experience", "public-alpha-readiness-report.md");
const alphaFocusLockPath = path.join(rootDir, "output", "experience", "alpha-focus-lock.md");
const canonCandidateBacklogReportPath = path.join(rootDir, "output", "experience", "canon-candidate-backlog-report.md");
const alphaPackageFinalQaPath = path.join(rootDir, "output", "experience", "alpha-package-final-qa.md");
const humanAiReadabilityAuditPath = path.join(rootDir, "output", "experience", "human-ai-readability-audit.md");
const inheritedWarningBurnDownReportPath = path.join(rootDir, "output", "experience", "inherited-warning-burndown-report.md");
const aiGuardrailEvaluationPath = path.join(rootDir, "output", "experience", "ai-guardrail-evaluation.md");
const aiGuardrailRedTeamPackPath = path.join(rootDir, "output", "experience", "ai-guardrail-red-team-pack.md");
const aiRedTeamResultsTemplatePath = path.join(rootDir, "output", "experience", "ai-red-team-results-template.md");
const maintainerMapPath = path.join(rootDir, "docs", "maintainer-map.md");
const aiEditingRulesPath = path.join(rootDir, "docs", "ai-editing-rules.md");
const accessibilityPrinciplePath = path.join(rootDir, "docs", "accessibility-principle.md");
const templateDir = path.join(rootDir, "tools", "templates");
const validatorsDir = path.join(rootDir, "tools", "validators");
const startHereTemplatePath = path.join(templateDir, "start-here-template.js");
const dashboardTemplatePath = path.join(templateDir, "dashboard-template.js");
const missionTemplatesPath = path.join(templateDir, "mission-templates.js");
const reportTemplatesPath = path.join(templateDir, "report-templates.js");
const quickStartTemplatePath = path.join(templateDir, "quick-start-template.js");
const aiPromptPackTemplatePath = path.join(templateDir, "ai-prompt-pack-template.js");
const canonTemplatesPath = path.join(templateDir, "canon-templates.js");
const missionExperienceGeneratorPath = path.join(rootDir, "tools", "generate-mission-experience-report.js");
const packagedDemoDir = path.join(rootDir, "output", "share", "developer-atlas-mvp-demo");
const packagedStartHerePath = path.join(packagedDemoDir, "START_HERE.md");
const packagedFirstTimeQuickStartPath = path.join(packagedDemoDir, "first-time-quick-start.md");
const packagedAiPromptPackPath = path.join(packagedDemoDir, "ai", "ai-prompt-pack.md");
const packagedMissionDashboardPath = path.join(packagedDemoDir, "mission-dashboard.html");
const packagedHardenedCanonDir = path.join(packagedDemoDir, "reference", "canon", "hardened");
const packagedBeginnerOrientationPath = path.join(packagedDemoDir, "help", "beginner-orientation.md");
const packagedVueConceptCardsPath = path.join(packagedDemoDir, "help", "vue-concept-cards.md");
const packagedTerminalConfidenceGuidePath = path.join(packagedDemoDir, "help", "terminal-confidence-guide.md");
const packagedTesterFeedbackReportPath = path.join(packagedDemoDir, "reviewer", "tester-feedback-report.md");
const packagedTesterHandoffMessagesPath = path.join(packagedDemoDir, "reviewer", "tester-handoff-messages.md");
const packagedPublicAlphaReadinessReportPath = path.join(packagedDemoDir, "reviewer", "public-alpha-readiness-report.md");
const packagedAlphaFocusLockPath = path.join(packagedDemoDir, "reviewer", "alpha-focus-lock.md");
const packagedCanonCandidateBacklogReportPath = path.join(packagedDemoDir, "reviewer", "canon-candidate-backlog-report.md");
const packagedAlphaPackageFinalQaPath = path.join(packagedDemoDir, "reviewer", "alpha-package-final-qa.md");
const packagedHumanAiReadabilityAuditPath = path.join(packagedDemoDir, "reviewer", "human-ai-readability-audit.md");
const packagedInheritedWarningBurnDownReportPath = path.join(packagedDemoDir, "reviewer", "inherited-warning-burndown-report.md");
const packagedAiGuardrailEvaluationPath = path.join(packagedDemoDir, "reviewer", "ai-guardrail-evaluation.md");
const packagedAiGuardrailRedTeamPackPath = path.join(packagedDemoDir, "reviewer", "ai-guardrail-red-team-pack.md");
const packagedAiRedTeamResultsTemplatePath = path.join(packagedDemoDir, "reviewer", "ai-red-team-results-template.md");
const packagedMissionThreeSurfacePath = path.join(packagedDemoDir, "mission", "mission-03-todostats-surface.md");
const packagedVibeMissionThreeSurfacePath = path.join(packagedDemoDir, "mission", "mission-03-todostats-surface.vibe.md");
const phase93CandidateIdPattern = /CANON-CANDIDATE-(JS|VUE|BROWSER|TOOLING|AI)-\d{3}/i;

const requiredFiles = [
  "README.md",
  "mission-intelligence-spec.md",
  "mission.schema.json",
  "mission-progress.schema.json",
  "mission-history.schema.json"
];

const requiredMissionFields = [
  "mission_id",
  "mission_title",
  "estimated_duration_minutes",
  "difficulty",
  "confidence_score",
  "today_objective",
  "today_canon",
  "today_project",
  "today_setup_check",
  "today_recovery_plan",
  "today_ai_context",
  "what_to_ignore_today",
  "visible_reward_after_completion",
  "next_mission_preview",
  "systems_orchestrated",
  "mission_quality_score"
];

function readIfExists(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return fs.readFileSync(filePath, "utf8");
}

function fileExists(filePath) {
  return fs.existsSync(filePath);
}

function includesAll(text, expectedItems) {
  return expectedItems.every((item) => text.includes(item));
}

function pushError(errors, message) {
  errors.push(message);
}

function pushWarning(warnings, message) {
  warnings.push(message);
}

function countLines(filePath) {
  if (!fs.existsSync(filePath)) return 0;
  return fs.readFileSync(filePath, "utf8").split(/\r?\n/).length;
}

function scanText(text, patterns) {
  return patterns.filter(([pattern]) => pattern.test(text));
}

function normalizePath(filePath) {
  return filePath.replace(/\\/g, "/");
}

function validateSectionsInOrder(text, requiredSections, label, errors) {
  let lastIndex = -1;
  for (const section of requiredSections) {
    const index = text.indexOf(section);
    if (index === -1) {
      errors.push(`${label}: missing section "${section}"`);
      continue;
    }
    if (index < lastIndex) {
      errors.push(`${label}: section "${section}" is out of order`);
    }
    lastIndex = index;
  }
}

function requireText(filePath, label, expectedText, meaning, errors) {
  if (!fs.existsSync(filePath)) {
    errors.push(`${label}: missing file for ${meaning}`);
    return;
  }
  const text = fs.readFileSync(filePath, "utf8");
  if (!text.includes(expectedText)) {
    errors.push(`${label}: missing ${meaning}`);
  }
}

function requirePattern(filePath, label, pattern, meaning, errors) {
  if (!fs.existsSync(filePath)) {
    errors.push(`${label}: missing file for ${meaning}`);
    return;
  }
  const text = fs.readFileSync(filePath, "utf8");
  if (!pattern.test(text)) {
    errors.push(`${label}: missing ${meaning}`);
  }
}

function validateForbiddenTerms(text, label, errors) {
  const forbiddenTerms = [
    /CANON-\d+/i,
    /Gold Candidate/i,
    /scorecard/i,
    /benchmark/i,
    /\bproof\b/i,
    /deterministic architecture/i,
    /Mission Intelligence/i,
    /Flow Engine/i,
    /Capability Intelligence/i
  ];

  for (const pattern of forbiddenTerms) {
    if (pattern.test(text)) {
      errors.push(`${label}: exposes internal Atlas language (${pattern})`);
    }
  }
}

function validateNoShameLanguage(text, label, errors) {
  const shameTerms = [
    /\bfailed\b/i,
    /\bfail\b/i,
    /\bwrong\b/i,
    /\bbad\b/i,
    /should have/i,
    /\bobvious\b/i
  ];

  for (const pattern of shameTerms) {
    if (pattern.test(text)) {
      errors.push(`${label}: contains avoidable shame language (${pattern})`);
    }
  }
}

function validateNoHypeLanguage(text, label, errors) {
  const hypeTerms = [
    /revolutionary/i,
    /\bmagic\b/i,
    /autonomous agent/i,
    /replaces developers/i
  ];

  for (const pattern of hypeTerms) {
    if (pattern.test(text)) {
      errors.push(`${label}: contains avoidable hype language (${pattern})`);
    }
  }
}

function parseJson(filePath, label, errors) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    errors.push(`${label}: invalid JSON (${error.message})`);
    return null;
  }
}

function validateRange(data, field, min, max, errors) {
  if (typeof data[field] !== "number" || data[field] < min || data[field] > max) {
    errors.push(`output/mission/today-mission.json: ${field} should be ${min}-${max}`);
  }
}

module.exports = {
  fs,
  path,
  rootDir,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionThreeSurfacePath,
  vibeMissionThreeSurfacePath,
  missionDashboardPath,
  startHerePath,
  firstTimeQuickStartPath,
  aiPromptPackPath,
  hardenedCanonOutputDir,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  inheritedWarningBurnDownReportPath,
  aiGuardrailEvaluationPath,
  aiGuardrailRedTeamPackPath,
  aiRedTeamResultsTemplatePath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  validatorsDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  quickStartTemplatePath,
  aiPromptPackTemplatePath,
  canonTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedFirstTimeQuickStartPath,
  packagedAiPromptPackPath,
  packagedMissionDashboardPath,
  packagedHardenedCanonDir,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  packagedInheritedWarningBurnDownReportPath,
  packagedAiGuardrailEvaluationPath,
  packagedAiGuardrailRedTeamPackPath,
  packagedAiRedTeamResultsTemplatePath,
  packagedMissionThreeSurfacePath,
  packagedVibeMissionThreeSurfacePath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange,
  readIfExists,
  fileExists,
  includesAll,
  pushError,
  pushWarning,
  countLines,
  scanText,
  normalizePath
};
