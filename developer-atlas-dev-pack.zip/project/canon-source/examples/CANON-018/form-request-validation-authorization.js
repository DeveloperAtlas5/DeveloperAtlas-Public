const assert = require("node:assert/strict");
const { classifyEndpoint } = require("./architecture-rules");

module.exports = function runFormRequestValidationAuthorizationExample() {
  const endpoint = {
    validationRules: 6,
    hasAuthorization: true,
    hasCustomMessages: true,
    routeAwareValidation: true,
    reusedWorkflow: false,
    modelOperations: 1,
    needsTransaction: false,
    hasExternalSideEffects: false,
    usedOutsideHttp: false
  };

  assert.deepEqual(classifyEndpoint(endpoint), ["controller", "form_request"]);
};
