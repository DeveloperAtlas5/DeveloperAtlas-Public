# Atlas Kernel Specification

Atlas Kernel is the deterministic reasoning layer for Developer Atlas.

## Purpose

The Kernel takes structured missions as input and emits decision records plus Markdown and JSON outputs. It is deterministic, template-based, and source-of-truth aligned.

## Inputs

- Mission JSON.
- Atlas Brain pack.
- AI context pack.
- Knowledge graph.
- Knowledge Nodes through generated context.

## Modules

- Intent Engine.
- Context Engine.
- Knowledge Engine.
- Recommendation Engine.
- Evidence Engine.
- Learning Engine.
- Future Constraint Engine.

## Outputs

- `output/kernel/<mission_id>.json`
- `output/kernel/<mission_id>.md`
- `output/kernel/kernel-report.md`

## Non-Goals

- No chatbot behavior.
- No frontend.
- No website.
- No LLM calls.
- No random content expansion.

## Rule

The Kernel implements specifications. It does not redefine the architecture.
