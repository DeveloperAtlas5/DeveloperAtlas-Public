# Setup Advice: beginner-vue-windows

Goal: Set up a first Vue project and run the local dev server.
Recommended setup profile: setup.beginner_vue_windows
Estimated setup time: 59 minutes

## Required Tools

- Visual Studio Code (tool.vscode)
- Node.js (tool.node)
- Git (tool.git)

## Recommended Extensions

- Vue - Official (extension.vue-official)
- Prettier extension (extension.prettier)

## Install Order

1. Install Git
2. Install Node.js LTS
3. Install VS Code
4. Install Vue - Official extension
5. Install project dependencies
6. Run the Vite dev server

## Verification Checklist

- [ ] git --version works
- [ ] node --version works
- [ ] npm --version works
- [ ] A .vue file has syntax highlighting
- [ ] npm run dev starts a local server

## Likely Friction Problems

- friction.javascript.npm.install_fails: npm install fails (78/100)
- friction.javascript.vite.not_starting: Vite dev server not starting (70/100)

## Recovery Links

- friction.javascript.npm.install_fails: Use the project-supported Node version
- friction.javascript.vite.not_starting: Install dependencies

## Beginner Notes

- Install and verify one tool at a time.
- Do not skip verification commands; they tell you exactly where setup broke.
- Use the setup.beginner_vue_windows profile as the main path and avoid optional tools until the first project runs.

## Professional Notes

- Align runtime and package-manager versions with the project before debugging application code.
- Treat repeated setup failures as environment drift and document the recovery path for the team.
- Profile selected deterministically from OS, stack, learner level, editor preference, and available time: setup.beginner_vue_windows.

## What To Do First After Setup

- Run every verification checklist item.
- Create or open the target project.
- Run the project's first success command.
- Start the Vite dev server and open the local URL.
