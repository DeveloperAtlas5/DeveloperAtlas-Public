# Rookie Vue Todo Flow

A guided Atlas journey for one small Vue win.

## Profile Summary

- Level: rookie
- Available time: 6 hours/week
- Desired output: Build one small Vue todo app with local state, list rendering, filtering, and a visible win. Then make the list remember non-sensitive tasks after refresh with the right browser storage choice. Component communication is a later optional step when the app grows into reusable parts.

## Selected Goals

- Learn Vue
- Become Full-Stack Developer

## Readiness

- Status: needs_foundation
- Today starts with a small guided project, not a full roadmap.

Strongest areas:
- hardware: 85
- friction: 84
- tooling: 70

Weakest areas:
- knowledge: 10
- momentum: 47.2
- practice: 56.67

## Hardware Notes

- machine.beginner_laptop_8gb: 8 GB RAM, SSD, 55/256 GB free.
- Keep the first project light; avoid Docker until the local app already runs.
- Watch: browser and editor slow when many tabs are open.

## Setup Checklist

- [ ] git --version works
- [ ] node --version works
- [ ] npm --version works
- [ ] A .vue file has syntax highlighting
- [ ] npm run dev starts a local server

## Likely Friction Risks

- npm install fails
- Vite dev server not starting

## Learn Now

- javascript.array.filter
- javascript.function.fetch
- vue.reactivity.ref
- vue.reactivity.reactive
- vue.reactivity.computed
- vue.reactivity.watch
- vue.directive.v-if
- vue.directive.v-for

## Recommended Next Knowledge

- Browser storage: localStorage vs sessionStorage
- Component communication: props, emits, and model

After the basic todo app works, persistence is the recommended next step: localStorage can remember non-sensitive todos across browser restarts, sessionStorage only lasts for the current tab session, and Vue state is separate from browser storage. Component communication comes after that when the app grows into reusable parts.

## Browser Storage Next Step

Your todo list currently resets after refresh. Make it remember non-sensitive tasks with `localStorage` after the basic app works.

- Use `localStorage` when the user expects the list to survive browser restarts.
- Use `sessionStorage` only for tab-scoped temporary drafts.
- Use neither for sensitive data.
- Keep Vue state and browser storage separate: state updates the screen now; storage remembers small values for later.

## Skip For Now

- Avoid Build Full-Stack Inventory System until blockers are reduced.
- Skip product-specific buying decisions until the workload is measured.
- Skip advanced architecture until the missing foundations are practiced.
- Skip Docker until the first local app runs without it.

## Best Project Now

- Build Vue Todo App
- Fit: ready today
- Estimated time: 6 hours

## Next Project Later

- Build Laravel CRUD API
- Fit: mostly ready

## Recovery Fallback

- Safest first fix: Use the project-supported Node version
- Verify: npm install or npm ci exits with code 0
- Verify: npm run validate or project test command starts successfully
- If stored todos load incorrectly, clear the saved `todos` value and reload with an empty-array fallback.
- If todos disappear after closing the tab, check whether you used `sessionStorage` instead of `localStorage`.
- If objects save as `[object Object]`, save with `JSON.stringify()` and load with `JSON.parse()`.

## Why This Path

- The selected goals point toward Vue, JavaScript, Vite and the requested output is specific.
- Readiness is needs_foundation at 53.63, so the path starts with a finishable project instead of a large roadmap.
- Build Vue Todo App is the best current fit because it is ready_today and estimated at 6 hours.
- Setup is included because local verification prevents avoidable friction.
- AI context is included so a helper can stay scoped and avoid overcomplicating the task.

## AI Context

Use this focused context pack if you want AI help without expanding scope: `output/ai-context/rookie-vue-next-step.md`

## Smallest Useful Next Step

Run the first setup verification: git --version works.

## Confidence Note

You do not need the whole roadmap today. Finish the next small win: Build Vue Todo App. That is enough to create visible progress.

