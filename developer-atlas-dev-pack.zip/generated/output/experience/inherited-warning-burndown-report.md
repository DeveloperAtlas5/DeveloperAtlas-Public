# Inherited Warning Burn-Down Report

## Summary

Before: 1546 inherited content warnings.

After: 0 inherited content warnings.

Inherited warnings reached 0. Validation is quieter because content entries were completed at the source, not because validators were weakened.

## What changed

- Completed missing content-node frontmatter across `content/` entries.
- Kept learner-facing language validation strict.
- Kept package-facing files in the language safety scan.
- Added this owner/reviewer-facing report for warning accountability.
- Clarified that the package manifest lists primary package entries and directory groups, not every nested file.

## Warning categories

| Category | Before | After | Notes |
|---|---:|---:|---|
| Stale generated output | 0 | 0 | No stale generated-output warning source was found. |
| Old package/demo copy | 0 | 0 | Package copy was refreshed after source fixes. |
| Learner-facing wording issue | 0 | 0 | Learner-facing language scan stayed clean. |
| Maintainer-only wording issue | 0 | 0 | No maintainer-only language warning source was found. |
| Canon/candidate wording issue | 0 | 0 | Canon validation stayed clean. |
| Historical/report wording issue | 0 | 0 | Report wording was not the inherited warning source. |
| False positive caused by scan scope | 0 | 0 | Scan scope did not change. |
| Valid warning fixed at source | 1546 | 0 | Content-node metadata warnings were fixed in source files. |

## Top warning sources before cleanup

- 76 content entries were missing shared future metadata fields.
- 76 content entries were missing `human_notes`.
- 56 content entries were missing `troubleshooting_notes` and `exercises`.
- 46 content entries were missing repeated quality and enrichment fields such as `when_to_use`, `when_not_to_use`, `common_mistakes`, `best_practices`, `sources`, `confidence`, `evidence_level`, `problem`, `solution`, `alternatives`, `ai_notes`, `teaching_notes`, and `code_generation_notes`.
- The largest per-file pattern before cleanup was 46 files with 26 warnings each.

## Warning count by file

Before cleanup, content files fell into three repeated groups:

- 46 content files had 26 warnings each.
- 10 content files had 14 warnings each.
- 20 content files had 12 warnings each.

After cleanup, every content file has 0 content validation warnings.

## Warning count by term/rule

- critical: 0
- quality: 0
- enrichment: 0
- future: 0

Before cleanup, the top repeated rules were missing future fields, missing enrichment fields, and missing quality metadata. After cleanup, none remain.

## Files fixed

- 76 files under `content/` were enriched at the source.
- `docs/maintainer-map.md` was updated with warning burn-down maintenance guidance.
- `docs/ai-editing-rules.md` was updated with warning cleanup rules.
- `tools/validate-content.js` now prints an inherited warning summary.
- `tools/package-mvp-demo.js` now packages this report and clarifies manifest scope.
- Validator modules now check that the burn-down report exists and that content warnings remain below the inherited baseline.

## Files regenerated

- `output/experience/inherited-warning-burndown-report.md`.
- `output/share/developer-atlas-mvp-demo/`.
- `output/share/developer-atlas-mvp-demo.zip`.
- Standard generated outputs from `npm run build` and `npm run mission`.

## Files removed

None.

## Scan-scope decisions

Scan scope did not change.

No learner-facing or package-facing files were excluded. `node_modules` was not scanned by the content validator because the content validator reads Atlas entries from `content/`, not vendor dependencies.

## Remaining warnings

None.

## Why any warnings remain

No inherited content warnings remain.

## Manifest decision

The package manifest lists primary package entries and directory groups. It is not intended to enumerate every nested file inside grouped directories such as `mission/`, `help/`, `ai/`, `reference/`, or `reviewer/`.

## Next recommendation

Keep content warning count at 0 during future phases. If a new warning appears, fix the source template or content entry before treating the package as ready.
