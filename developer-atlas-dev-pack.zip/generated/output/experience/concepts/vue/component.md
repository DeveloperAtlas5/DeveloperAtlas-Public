# Vue Component

Technology: Vue

## Simple meaning

A component is a reusable piece of UI with its own template and behavior.

## Why it exists

Components split a page into smaller pieces that are easier to build and understand.

## Where you use it

In `.vue` files, often inside `src/components`.

## When to use it

Use a component when a piece of UI is repeated, complex, or easier to name separately.

## Tiny example

`<TodoItem :todo="todo" />`

## Common beginner confusion

A component should not always own all data. Parent components can keep state and pass data down.

## Related concepts

- Props
- Emits
- v-model

## Similar idea in another technology

A Laravel Blade partial can reuse markup, but a Vue component can also hold browser-side behavior.
