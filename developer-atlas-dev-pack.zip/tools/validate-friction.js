const fs = require("fs");
const path = require("path");
const {
  frictionDir,
  readFrictionNodes
} = require("./friction-utils");

const requiredSchemaFiles = [
  "friction-node.schema.json",
  "diagnostic-tree.schema.json",
  "recovery-path.schema.json",
  "environment-profile.schema.json",
  "momentum-metrics.schema.json"
];

const requiredFields = [
  "id",
  "title",
  "category",
  "affected_tools",
  "affected_os",
  "symptoms",
  "likely_causes",
  "diagnostic_steps",
  "fixes",
  "verification_steps",
  "prevention",
  "related_nodes",
  "estimated_time_lost",
  "estimated_recovery_time",
  "friction_score",
  "confidence",
  "evidence_level"
];

const arrayFields = [
  "affected_tools",
  "affected_os",
  "symptoms",
  "likely_causes",
  "diagnostic_steps",
  "fixes",
  "verification_steps",
  "prevention",
  "related_nodes"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemaFiles(errors);

  let records = [];
  try {
    records = readFrictionNodes();
  } catch (error) {
    errors.push(`friction/examples: unable to read examples (${error.message})`);
  }

  const seenIds = new Set();
  for (const record of records) {
    validateNode(record, seenIds, errors, warnings);
  }

  console.log("Atlas Friction validation");
  console.log(`Friction nodes: ${records.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemaFiles(errors) {
  for (const fileName of requiredSchemaFiles) {
    const schemaPath = path.join(frictionDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`friction/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`friction/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateNode(record, seenIds, errors, warnings) {
  const { node, relativePath } = record;

  for (const field of requiredFields) {
    if (node[field] === undefined || node[field] === null || node[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }

  if (typeof node.id === "string") {
    if (seenIds.has(node.id)) errors.push(`${relativePath}: duplicate id ${node.id}`);
    seenIds.add(node.id);
  }

  for (const field of arrayFields) {
    validateNonEmptyStringArray(relativePath, node, field, errors);
  }

  validateRange(relativePath, node, "estimated_time_lost", 0, Infinity, errors);
  validateRange(relativePath, node, "estimated_recovery_time", 0, Infinity, errors);
  validateRange(relativePath, node, "friction_score", 0, 100, errors);
  validateRange(relativePath, node, "confidence", 0, 1, errors);

  // A friction node can be brief, but it should still give enough recovery surface to be useful.
  if ((node.diagnostic_steps || []).length < 2) warnings.push(`${relativePath}: diagnostic_steps should include at least two checks`);
  if ((node.fixes || []).length < 2) warnings.push(`${relativePath}: fixes should include at least two recovery options`);
  if (node.estimated_recovery_time > node.estimated_time_lost) {
    warnings.push(`${relativePath}: estimated_recovery_time exceeds estimated_time_lost`);
  }
}

function validateNonEmptyStringArray(relativePath, node, field, errors) {
  if (!Array.isArray(node[field]) || !node[field].length) {
    errors.push(`${relativePath}: ${field} should be a non-empty array`);
    return;
  }

  for (const value of node[field]) {
    if (typeof value !== "string" || !value.trim()) {
      errors.push(`${relativePath}: ${field} contains a non-string entry`);
    }
  }
}

function validateRange(relativePath, node, field, min, max, errors) {
  const value = node[field];
  if (typeof value !== "number" || value < min || value > max) {
    errors.push(`${relativePath}: ${field} should be a number from ${min} to ${max}`);
  }
}

main();
