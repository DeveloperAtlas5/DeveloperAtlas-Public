const assert = require("assert");
const { MemoryStorage } = require("./storage-fake");

module.exports = function sessionStorageTabScopedDraft() {
  const firstTabSession = new MemoryStorage("sessionStorage:first-tab");
  const secondTabSession = new MemoryStorage("sessionStorage:second-tab");
  const draft = { email: "ada@example.com", step: 2 };

  firstTabSession.setItem("signup-draft", JSON.stringify(draft));

  assert.deepStrictEqual(JSON.parse(firstTabSession.getItem("signup-draft")), draft);
  assert.strictEqual(secondTabSession.getItem("signup-draft"), null);
};
