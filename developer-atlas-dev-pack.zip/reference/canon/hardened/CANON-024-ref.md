# CANON-024 - ref()

Status: Hardened

## Core idea

ref holds reactive values.

Use `.value` in script. Templates unwrap refs automatically.

## Use this when

Use this for todo text, lists, and small reactive values.

## Basic pattern

Create a ref in script and read it in the template.

## Common friction

Script code needs `.value`; template code usually does not.

## Small example

```js
const newTodo = ref("");
newTodo.value = "Learn Vue";
```

## Check yourself

- Did script code use `.value`?
- Did the template stay simple?

## Related Canon nodes

- CANON-030
- CANON-025
