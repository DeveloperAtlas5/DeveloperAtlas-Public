# Canon Review Template

Canon ID: CANON-019
Node ID: canon.sql.command.inner-join-vs-left-join
Reviewer: Pending Gold Review Panel
Date: 2026-07-03
Stage: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Gold-candidate draft aligns with PostgreSQL, MySQL, and SQLite join behavior.
- Edge cases: Covers unmatched rows, `NULL` right-side columns, `ON` versus `WHERE` filter placement, and one-to-many row multiplication.
- Version concerns: Guidance targets standard relational SQL behavior with dialect-neutral examples.
- Evidence quality: Direct official PostgreSQL, MySQL, and SQLite URLs are included.

## Educational Review

- Beginner clarity: Strong "only matches" versus "keep all left rows" mental model.
- Mental model: Row survival is taught before syntax.
- Exercise quality: Beginner, intermediate, and advanced exercises are present.
- Common mistake coverage: Covers missing rows, duplicate rows, wrong key joins, `SELECT *`, and misplaced filters.

## AI Review

- Structured enough for retrieval: Yes.
- Code generation guidance: Strong and specific.
- Ambiguity risks: AI should ask which table is the main entity list and whether unmatched rows should remain.
- Related node quality: Related Canon and content graph IDs are included.

## Engineering Review

- Decision support: Strong.
- Production realism: Users/orders examples, paid-order filter placement, missing relationship reports, and row-count debugging are practical.
- Trade-offs: Good coverage of preservation, cardinality, `EXISTS`, aggregation, and performance review.
- Anti-pattern coverage: Strong enough for Gold-candidate review.

## Decision

- Approved stage: Gold Candidate
- Required changes: Add named reviewer sign-off before Gold approval.
- Score: 95
