const assert = require("node:assert/strict");
const { innerJoin, users, orders, userMatchesOrder, userOrderProjection } = require("./join-sim");

function run() {
  const rows = innerJoin(users, orders, userMatchesOrder, userOrderProjection);
  const adaRows = rows.filter((row) => row.user_id === 1);

  assert.equal(adaRows.length, 2);
  assert.deepEqual(adaRows.map((row) => row.order_id), [101, 102]);

  const orderCounts = rows.reduce((counts, row) => {
    counts[row.user_id] = (counts[row.user_id] || 0) + 1;
    return counts;
  }, {});

  assert.deepEqual(orderCounts, { 1: 2, 2: 1 });

  return orderCounts;
}

module.exports = run;

if (require.main === module) run();
