# Vue Props

Technology: Vue

## Simple meaning

Props pass data from a parent component down to a child component.

## Why it exists

Props let a child display or use data without owning the source of that data.

## Where you use it

Declared in a child component and passed from the parent template.

## When to use it

Use props when a child needs data from its parent.

## Tiny example

`defineProps({ todo: Object })`

## Common beginner confusion

Props go down. A child should not directly rewrite a prop it receives.

## Related concepts

- Component
- Emits
- v-model

## Similar idea in another technology

A Laravel controller can pass data to a Blade view, but Vue props pass data between browser components.
