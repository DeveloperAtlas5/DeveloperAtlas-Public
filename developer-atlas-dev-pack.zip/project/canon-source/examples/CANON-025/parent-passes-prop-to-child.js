const assert = require("assert");

module.exports = function parentPassesPropToChild() {
  const parentState = {
    todo: { id: 1, text: "Practice props", done: false }
  };

  function TodoItem(props) {
    return {
      label: props.todo.text,
      done: props.todo.done,
      ownsTodo: false
    };
  }

  const rendered = TodoItem({ todo: parentState.todo });

  assert.strictEqual(rendered.label, "Practice props");
  assert.strictEqual(rendered.done, false);
  assert.strictEqual(rendered.ownsTodo, false);
  assert.strictEqual(parentState.todo.text, "Practice props");
};
