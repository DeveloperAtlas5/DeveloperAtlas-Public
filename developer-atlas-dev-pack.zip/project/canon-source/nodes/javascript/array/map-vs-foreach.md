# Array.prototype.map() vs forEach()

## Status Metadata

- Canon ID: CANON-001
- Node ID: canon.javascript.array.map-vs-foreach
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript arrays
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `map()` when every input item should become one output item in a new array. Use `forEach()` when you need to perform an action for each item and do not need a returned array.

The decision is not about which loop is "better." It is about the shape of the result:

- `map()` transforms values.
- `forEach()` performs side effects.
- Other array methods fit other result shapes.

## What Problem This Solves

Developers often ask "How do I loop over this array?" That question is too broad. It leads to code that works by accident, confuses reviewers, or produces `undefined` when a transformed array was expected.

This node solves a daily JavaScript decision:

- Choose `map()` when the result is a transformed array.
- Choose `forEach()` when the result is an external effect.
- Choose another method when the desired result is not one output item per input item.

## Mental Model

Start with the output, not the loop.

Imagine the array method as a contract with the next developer:

- `map()` says: "I am producing a new array from this array."
- `forEach()` says: "I am doing work for each item, and the return value does not matter."
- `filter()` says: "I am keeping only some items."
- `find()` says: "I am looking for one item."
- `reduce()` says: "I am collapsing many items into one value."
- `some()` and `every()` say: "I am answering a yes/no question."
- `for...of` says: "I need imperative control, early exit, or sequential `await`."

| Desired result | Best fit |
| --- | --- |
| New array with same length | `map()` |
| No returned value, only side effects | `forEach()` |
| New array with fewer items | `filter()` |
| First matching item | `find()` |
| One accumulated value | `reduce()` |
| Boolean: at least one match | `some()` |
| Boolean: all items match | `every()` |
| Early exit or sequential async flow | `for...of` |

## Beginner Explanation

Think of `map()` as a machine that turns every item into a new item.

If you have users and want names, each user becomes one name:

```js
const names = users.map((user) => user.name);
```

The input is a list of users. The output is a list of names. That is a `map()` job.

Think of `forEach()` as a checklist. It visits every item so you can do something, but it does not hand you a new list afterward.

```js
users.forEach((user) => {
  console.log(user.name);
});
```

The output is not a new array. The result is that something happened for each user.

Beginner rule:

1. If you want to keep the result, use `map()`.
2. If you only want an action to happen, use `forEach()`.
3. If you want fewer items, one item, one number, or a yes/no answer, use a different method.

## Professional Explanation

`map()` is a declarative transformation. It creates a new array whose elements are the callback return values. It preserves order and creates one output slot for each visited input element. In code review, `map()` should make reviewers look for a meaningful returned value and a consumed result.

`forEach()` is imperative iteration. It returns `undefined` and is appropriate when the callback exists for side effects: logging, instrumentation, mutation of an external object, bridging to an imperative API, or sending work to another system.

The choice affects maintainability. A `map()` whose return value is ignored is misleading. A `forEach()` that pushes into an external array is usually a transformation disguised as mutation. Both may run, but both hide the developer's intent.

For async work, neither method automatically solves control flow. `map()` can prepare an array of promises for `Promise.all()`. `forEach()` should not be used when the caller needs to await each callback.

## Syntax

```js
const result = array.map((item, index, array) => {
  return transformedItem;
});
```

```js
array.forEach((item, index, array) => {
  performSideEffect(item);
});
```

Both methods call a callback with `item`, `index`, and the original array.

Sparse-array note: both `map()` and `forEach()` skip empty slots in sparse arrays. Keep this in mind when debugging arrays created with holes, such as `new Array(3)`, but do not let it distract from the everyday decision rule.

## Decision Guide

Ask these questions in order:

1. Do I need a new array with one output per input?
   Use `map()`.
2. Do I only need to perform an action for each item?
   Use `forEach()`.
3. Do I need fewer items?
   Use `filter()`.
4. Do I need one matching item?
   Use `find()`.
5. Do I need one final value?
   Use `reduce()`.
6. Do I need a yes/no answer?
   Use `some()` or `every()`.
7. Do I need early exit or sequential `await`?
   Use `for...of`.

## Comparison Table

| Feature | `map()` | `forEach()` |
| --- | --- | --- |
| Returns | New array | `undefined` |
| Main intent | Transform values | Run side effects |
| Output length | Same as input length | No output array |
| Chainable | Yes | No |
| Callback should return | Yes | Usually no |
| Best for render data | Yes | Rarely |
| Best for logging | Rarely | Yes |
| Best for mutation | Usually avoid | Sometimes, with care |
| Early break | No | No |
| Async sequencing | No | No |

## When To Use map()

Use `map()` when:

- You need a new array.
- Every input item should become one output item.
- You want chainable transformation.
- You are preparing data for rendering.
- You are converting API data into a UI-friendly shape.

```js
const productCards = products.map((product) => ({
  id: product.id,
  title: product.name,
  priceLabel: `$${product.price.toFixed(2)}`
}));
```

## When To Use forEach()

Use `forEach()` when:

- You are logging.
- You are collecting metrics.
- You are calling an external side-effecting function.
- You intentionally do not need a returned array.
- You are performing imperative integration work.

```js
failedJobs.forEach((job) => {
  logger.warn("Job failed", { id: job.id, reason: job.reason });
});
```

## When Not To Use Either

Do not use `map()` or `forEach()` just because you see an array. Use the method that matches the actual result.

Avoid both when:

- You need early exit. Use `for...of`, `find()`, `some()`, or `every()`.
- You need a filtered list. Use `filter()`.
- You need one item. Use `find()`.
- You need one accumulated value. Use `reduce()`.
- You need sequential async work. Use `for...of` with `await`.
- You need parallel async work. Use `map()` to create promises, then `Promise.all()`.
- You are mutating the same array you are iterating. Prefer a clearer copy or a dedicated data structure.

Sequential async:

```js
for (const user of users) {
  await sendEmail(user);
}
```

Parallel async:

```js
await Promise.all(users.map((user) => sendEmail(user)));
```

## Alternatives

### filter()

Use `filter()` when you want a subset.

```js
const activeUsers = users.filter((user) => user.active);
```

### reduce()

Use `reduce()` when many items become one value.

```js
const total = cart.reduce((sum, item) => sum + item.price, 0);
```

### find()

Use `find()` when you need the first matching item.

```js
const admin = users.find((user) => user.role === "admin");
```

### some()

Use `some()` when you need to know whether at least one item matches.

```js
const hasErrors = fields.some((field) => field.error);
```

### every()

Use `every()` when all items must pass a condition.

```js
const allComplete = tasks.every((task) => task.done);
```

### for...of

Use `for...of` for early exit, sequential async work, or custom imperative control flow.

```js
for (const file of files) {
  if (file.size > limit) break;
  await upload(file);
}
```

## Production Examples

### Transform API Response

```js
const customerRows = response.data.customers.map((customer) => ({
  id: customer.id,
  name: `${customer.first_name} ${customer.last_name}`,
  email: customer.email,
  planLabel: customer.subscription.plan_name,
  renewalDate: new Date(customer.subscription.renews_at).toLocaleDateString("en-US"),
  isPastDue: customer.subscription.status === "past_due"
}));
```

Why `map()` fits: the API returns customer records, and the UI needs one table row per customer with formatted subscription fields.

### Render Vue List Data

In Vue, `map()` is useful when API data needs a stable, template-friendly shape before rendering.

```js
import { computed } from "vue";

const visibleProducts = computed(() =>
  products.value.map((product) => ({
    id: product.id,
    name: product.name,
    priceLabel: new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD"
    }).format(product.priceCents / 100),
    stockLabel: product.stock > 0 ? `${product.stock} in stock` : "Out of stock",
    route: {
      name: "product-details",
      params: { id: product.id }
    }
  }))
);
```

```vue
<li v-for="product in visibleProducts" :key="product.id">
  <RouterLink :to="product.route">
    {{ product.name }} - {{ product.priceLabel }} - {{ product.stockLabel }}
  </RouterLink>
</li>
```

Why `map()` fits: the component renders one list item per product, but the raw API fields are reshaped into display labels and route objects first.

### Side-Effect Logging Example With forEach()

```js
validationErrors.forEach((error) => {
  analytics.track("validation_error", {
    field: error.field,
    code: error.code
  });
});
```

Why `forEach()` fits: the goal is event tracking, not a new array.

## Common Mistakes

- Using `map()` without returning a value.
- Using `forEach()` to build a new array manually.
- Expecting `forEach()` to return the transformed result.
- Using either method when early exit is required.
- Using `map()` only for side effects.
- Using `async` callbacks with `forEach()` and assuming they are awaited.
- Using `map()` for conditional filtering and returning `undefined` for skipped items.

```js
// Mistake: returns [undefined, undefined, undefined]
const names = users.map((user) => {
  user.name;
});
```

```js
// Better
const names = users.map((user) => user.name);
```

```js
// Mistake: transformation hidden behind mutation
const names = [];
users.forEach((user) => {
  names.push(user.name);
});
```

```js
// Better
const names = users.map((user) => user.name);
```

## Debugging Checklist

- If the result is `undefined`, did you assign the return value of `forEach()`?
- If the result array contains `undefined`, did the `map()` callback forget `return`?
- If the result array contains unwanted empty values, should this be `filter()` before `map()`?
- If async work is not awaited, are you using `forEach()` with an async callback?
- If the code is hard to review, does the method match the output shape?
- If you need to stop early, should this be `for...of`, `find()`, `some()`, or `every()`?
- If the code mutates external state, is that mutation intentional and visible from the method choice?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-001/`.

Verification command:

```sh
npm run canon:verify:001
```

The verification suite checks:

- `map()` transforming records into view models.
- `forEach()` producing side effects and returning `undefined`.
- A Vue-ready product transformation.
- The anti-pattern of using `map()` for side effects.

## Performance Notes

For normal application code, choose by intent before micro-performance. Clear method choice prevents bugs and improves review quality.

`map()` allocates a new array. That is correct when the new array is the result you need. If profiling shows allocation matters in a hot path, a `for...of` loop may be clearer and faster because it can combine transformation, filtering, and early exit without intermediate arrays.

Do not choose `forEach()` over `map()` for performance unless profiling shows the transformed array allocation is a real problem. Most mistakes here are semantic, not performance-related.

## AI Coding Guidance

When generating code:

- Use `map()` only if the generated code returns and uses a new array.
- Use `forEach()` only if the goal is a side effect.
- Do not generate `array.map(...)` and ignore the returned value.
- Do not generate `const result = array.forEach(...)`.
- Do not use `forEach(async () => ...)` when the caller needs completion ordering.
- Use `Promise.all(array.map(...))` for parallel async work.
- Use `for...of` with `await` for sequential async work.
- If transforming and filtering, prefer `filter().map()` or a clearly explained `reduce()`.
- Explain the choice using output shape.

Bad AI output:

```js
const result = users.forEach((user) => user.name);
```

Good AI output:

```js
const result = users.map((user) => user.name);
```

## Teaching Notes

Teach this as a decision, not trivia:

- Start with output shape.
- Show the wrong result from assigning `forEach()`.
- Show the `undefined` bug from missing `return` in `map()`.
- Show why `filter()`, `find()`, and `reduce()` are not just alternatives but different answers.
- End with async control flow, because it is where many real bugs appear.

Useful teaching phrase:

> If the method name does not describe the result you want, you probably picked the wrong method.

## Interview Questions

1. What does `map()` return?
2. What does `forEach()` return?
3. Why is `map()` a poor choice for logging?
4. Why is `forEach()` a poor choice for transformations?
5. What would you use for early exit?
6. What happens when a `map()` callback forgets to return?
7. How would you run async work sequentially for each item?
8. How would you run async work in parallel for each item?

## Exercises

### Beginner

Convert an array of product objects into an array of product names.

### Intermediate

Transform API user records into UI view models and explain why `map()` is the right method.

### Advanced

Refactor code that uses `forEach()` with async callbacks into a safe sequential `for...of` loop, then explain the trade-off between sequential and parallel execution.

## Related Atlas Nodes

- `javascript.array.map`
- `javascript.array.foreach`
- `javascript.array.filter`
- `javascript.array.reduce`
- `javascript.array.find`
- `javascript.array.some`
- `javascript.array.every`
- `vue.directive.v-for`

## Evidence And Sources

- MDN Web Docs: Array.prototype.map(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map
- MDN Web Docs: Array.prototype.forEach(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
- ECMAScript specification: Array.prototype.map: https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array.prototype.map
- ECMAScript specification: Array.prototype.forEach: https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array.prototype.foreach
- Vue documentation: list rendering with `v-for` relies on arrays of renderable data and stable keys.

## Proof Of Superiority Summary

Official references explain what `map()` and `forEach()` do. This Canon node explains how to choose between them, what mistakes to avoid, what production examples look like, how async control changes the decision, how AI should generate them, and which alternatives fit different output shapes.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
