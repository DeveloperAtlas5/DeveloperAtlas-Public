# computed() vs watch()

## Status Metadata

- Canon ID: CANON-006
- Node ID: canon.vue.reactivity.computed-vs-watch
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: Vue reactivity
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `computed()` when you need a value that can be derived from reactive state. Use `watch()` when a reactive change should trigger a side effect, such as fetching data, writing to storage, logging, or calling an imperative API.

The everyday rule:

- `computed()` answers: "What value should this be?"
- `watch()` answers: "What should happen because this changed?"

## What Problem This Solves

Vue developers often reach for `watch()` too early. That creates duplicated state, stale values, and code that is harder to trace.

This node solves a common reactivity decision:

- Use `computed()` for derived state.
- Use `watch()` for side-effect reactions.
- Use methods for event-driven actions.
- Use lifecycle hooks for setup and teardown.

## Mental Model

Think in formulas and alarms.

`computed()` is a formula in a spreadsheet. When the cells it reads change, the formula value updates.

```js
const fullName = computed(() => `${firstName.value} ${lastName.value}`);
```

`watch()` is an alarm attached to state. When the watched value changes, the alarm runs a reaction.

```js
watch(searchQuery, (query) => {
  fetchResults(query);
});
```

The key difference is the output:

| Question | Better tool |
| --- | --- |
| Do I need a derived value? | `computed()` |
| Do I need to format, filter, count, or combine state? | `computed()` |
| Do I need to call an API after a change? | `watch()` |
| Do I need to sync with local storage or an external library? | `watch()` |
| Do I need to respond to a click? | Method or event handler |
| Do I need setup or cleanup when mounted? | Lifecycle hook |

## Beginner Explanation

Use `computed()` when the answer can be calculated.

If you have `firstName` and `lastName`, the full name should not be stored separately. It should be calculated from the source values:

```js
const fullName = computed(() => `${firstName.value} ${lastName.value}`);
```

Use `watch()` when something needs to happen after a value changes.

If a search box changes and you need to fetch matching results, that is not just a value. It is a side effect:

```js
watch(searchQuery, (query) => {
  if (query.length >= 3) {
    fetchResults(query);
  }
});
```

Beginner rule:

1. If you can describe it as a value, try `computed()`.
2. If you can describe it as an action, consider `watch()`.
3. If you are copying one reactive value into another, pause. That is often a missing `computed()`.

## Professional Explanation

`computed()` creates cached derived state. Vue tracks the reactive dependencies read inside the getter and recalculates only when those dependencies change. In code review, `computed()` should be pure: no API calls, logging, mutation, timers, storage writes, or router navigation.

`watch()` observes a reactive source and runs a callback when that source changes. It is an effect boundary. That makes it useful for external systems, but also easier to misuse. A watcher that only assigns derived state usually introduces an unnecessary second source of truth.

In production code, the choice affects:

- Data-flow traceability.
- Whether derived values can become stale.
- Whether side effects are isolated.
- Whether the component is easy to test.
- Whether AI-generated Vue code remains predictable.

Prefer `computed()` for renderable values and domain derivations. Use `watch()` when a change must cross the boundary from Vue reactivity into the outside world.

## Syntax

```js
import { computed, ref, watch } from "vue";

const firstName = ref("Ada");
const lastName = ref("Lovelace");

const fullName = computed(() => `${firstName.value} ${lastName.value}`);
```

```js
const searchQuery = ref("");

watch(searchQuery, async (query) => {
  if (query.length < 3) return;
  await fetchResults(query);
});
```

## Decision Guide

Ask these questions in order:

1. Do I need a value that can be calculated from reactive state?
   Use `computed()`.
2. Is the result used in a template, another computed value, or component logic?
   Use `computed()`.
3. Does a state change need to trigger work outside pure calculation?
   Use `watch()`.
4. Is the watcher only copying or formatting another value?
   Replace it with `computed()`.
5. Is the work caused by a user event rather than reactive dependency change?
   Use a method or event handler.
6. Is the work setup or cleanup tied to the component lifecycle?
   Use a lifecycle hook.

## Comparison Table

| Feature | `computed()` | `watch()` |
| --- | --- | --- |
| Main intent | Derived state | Side-effect reaction |
| Returns | A readonly ref-like value by default | A stop handle |
| Best for templates | Yes | Rarely |
| Should be pure | Yes | No, it exists for effects |
| Caching | Cached by dependencies | Not a derived cache |
| Common output | Label, total, filtered list, boolean | Fetch, storage write, analytics, imperative sync |
| Main risk | Side effects hidden in a getter | Duplicated or stale state |
| Review question | "What value is derived?" | "What external effect happens?" |

## When To Use The Primary Option

Use `computed()` when:

- You need a value derived from refs, reactive objects, props, or store state.
- You are formatting display labels.
- You are filtering or sorting visible items for rendering.
- You are calculating totals, counts, disabled states, or validation summaries.
- You want one source of truth instead of mirrored state.

```js
const cartTotalCents = computed(() =>
  cartItems.value.reduce((sum, item) => sum + item.quantity * item.priceCents, 0)
);
```

## When To Use The Alternative

Use `watch()` when:

- A reactive change should call an API.
- A value should be synced to local storage.
- A change should be reported to analytics.
- A third-party imperative library needs to be updated.
- You need cleanup for an async or external side effect.

```js
watch(selectedPlanId, (planId) => {
  analytics.track("plan_selected", { planId });
});
```

## When Not To Use Either

Do not use `computed()` or `watch()` just because state is involved.

Avoid both when:

- A click or submit handler can run the action directly. Use a method.
- The work belongs to component setup or teardown. Use lifecycle hooks.
- The value is parent-owned. Use props and emits.
- The state is shared broadly across the app. Consider a store.
- The operation is a one-time transformation of fetched data. Transform it where the data is loaded.
- You are trying to hide complex business workflow inside a watcher.

## Alternatives

### Methods

Use methods for explicit user actions.

```js
function submitSearch() {
  fetchResults(searchQuery.value);
}
```

### Lifecycle Hooks

Use lifecycle hooks for setup and cleanup.

```js
onMounted(() => {
  connectSocket();
});
```

### Props And Emits

Use props and emits for parent-child communication.

### Store Actions

Use store actions when side effects belong to shared application state rather than one component.

## Production Examples

### Product Search View Model With computed()

```js
const products = ref([]);
const searchQuery = ref("");
const selectedCategory = ref("all");

const visibleProducts = computed(() => {
  const query = searchQuery.value.trim().toLowerCase();

  return products.value
    .filter((product) => {
      const matchesCategory =
        selectedCategory.value === "all" || product.category === selectedCategory.value;
      const matchesQuery = product.name.toLowerCase().includes(query);

      return matchesCategory && matchesQuery;
    })
    .map((product) => ({
      id: product.id,
      name: product.name,
      priceLabel: new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD"
      }).format(product.priceCents / 100),
      stockLabel: product.stock > 0 ? `${product.stock} in stock` : "Out of stock"
    }));
});
```

Why `computed()` fits: the visible product list is a derived value from products, query, and category. No external work happens inside the calculation.

### Search Query Side Effect With watch()

```js
const searchQuery = ref("");
const results = ref([]);
const isSearching = ref(false);

watch(searchQuery, async (query) => {
  const trimmed = query.trim();

  if (trimmed.length < 3) {
    results.value = [];
    return;
  }

  isSearching.value = true;

  try {
    results.value = await api.searchCustomers(trimmed);
  } finally {
    isSearching.value = false;
  }
});
```

Why `watch()` fits: a reactive value crossing a threshold triggers an async API side effect.

### Persist User Preference With watch()

```js
const density = ref("comfortable");

watch(density, (value) => {
  localStorage.setItem("table-density", value);
});
```

Why `watch()` fits: the component syncs reactive state to an external storage API.

## Common Mistakes

- Using `watch()` to maintain a value that could be `computed()`.
- Mutating state inside a `computed()` getter.
- Calling APIs, router navigation, analytics, or storage writes inside `computed()`.
- Watching a broad object when a narrower source would be safer.
- Forgetting that `computed()` returns a ref-like value in script.
- Creating watcher chains where one watcher updates state that triggers another watcher.
- Using `watch()` for submit actions that should be explicit methods.

```js
// Mistake: duplicated derived state
const fullName = ref("");

watch([firstName, lastName], () => {
  fullName.value = `${firstName.value} ${lastName.value}`;
});
```

```js
// Better
const fullName = computed(() => `${firstName.value} ${lastName.value}`);
```

```js
// Mistake: side effect hidden in computed()
const visibleUsers = computed(() => {
  analytics.track("visible_users_calculated");
  return users.value.filter((user) => user.active);
});
```

```js
// Better
const visibleUsers = computed(() => users.value.filter((user) => user.active));
```

## Debugging Checklist

- If a derived value is stale, is it copied into a ref instead of computed?
- If a computed value causes unexpected behavior, does the getter contain a side effect?
- If a watcher runs too often, can the watched source be narrower?
- If a watcher is hard to test, should the side effect be moved to a named function?
- If the template needs a value, should that value be `computed()`?
- If external work needs to happen, is `watch()` the smallest clear effect boundary?
- If an async watcher returns out of order, do you need cancellation, cleanup, or request identity checks?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-006/`.

Verification command:

```sh
npm run canon:verify:006
```

The verification suite checks:

- A computed `fullName` derived from `firstName` and `lastName`.
- A search-query watcher that records side effects only when the threshold is met.
- The anti-pattern of using `watch()` for derived state.
- The anti-pattern of using `computed()` for side effects.

## Performance Notes

`computed()` is cached by reactive dependencies, so it is usually the right place for derived values used repeatedly in templates. Expensive computed work should still be scoped carefully, especially for large arrays.

`watch()` is not a performance shortcut. It can reduce unnecessary external work when the source is narrow, but broad watchers and watcher chains can create noisy updates and difficult debugging.

## AI Coding Guidance

When generating Vue Composition API code:

- Use `computed()` for derived state.
- Keep computed getters pure.
- Do not generate API calls, logging, local storage writes, router navigation, or mutation inside `computed()`.
- Use `watch()` only when a reactive change should trigger a side effect.
- Watch the narrowest source that expresses the trigger.
- Prefer named side-effect functions inside watchers when logic grows.
- Do not use `watch()` to mirror formatted or calculated values into another ref.
- Mention why the choice is derived state or side-effect reaction.

Bad AI output:

```js
const fullName = ref("");

watch([firstName, lastName], () => {
  fullName.value = `${firstName.value} ${lastName.value}`;
});
```

Good AI output:

```js
const fullName = computed(() => `${firstName.value} ${lastName.value}`);
```

## Teaching Notes

Teach in this order:

1. `computed()` as a formula.
2. `watch()` as an alarm.
3. Derived values should not be duplicated.
4. Side effects should be visible.
5. Methods and lifecycle hooks are valid alternatives.

Useful teaching phrase:

> `computed()` makes a value; `watch()` starts a reaction.

## Interview Questions

1. What kind of code belongs inside a computed getter?
2. Why is a watcher usually wrong for `fullName` from `firstName` and `lastName`?
3. What makes `watch()` an effect boundary?
4. Why should computed getters avoid side effects?
5. When would you watch a search query?
6. How can a broad watcher make a component harder to debug?
7. What alternatives should you consider before adding a watcher?

## Exercises

### Beginner

Create `fullName` with `computed()` from `firstName` and `lastName`.

### Intermediate

Watch a search field and call a fake API only when the trimmed query has at least three characters.

### Advanced

Refactor a component that uses two watchers to maintain derived state into computed values and named side-effect functions.

## Related Atlas Nodes

- `vue.reactivity.computed`
- `vue.reactivity.watch`
- `vue.reactivity.ref`
- `vue.reactivity.reactive`
- `vue.directive.v-model`
- `vue.component.defineProps`
- `vue.component.defineEmits`

## Evidence And Sources

- Vue Guide: Computed Properties: https://vuejs.org/guide/essentials/computed.html
- Vue Guide: Watchers: https://vuejs.org/guide/essentials/watchers.html
- Vue Guide: Reactivity Fundamentals: https://vuejs.org/guide/essentials/reactivity-fundamentals.html

## Proof Of Superiority Summary

Official Vue docs explain how computed properties and watchers work. This Canon node explains how to choose between them in production code, why duplicated derived state causes bugs, how side effects should be isolated, how AI should generate safe Vue reactivity code, and when methods, lifecycle hooks, props, emits, or stores are better tools.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
