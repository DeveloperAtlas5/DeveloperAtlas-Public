# Start a Laravel Project

## What this is for

Use this when you want to start or open a Laravel app.

## What you need first

You need PHP and Composer installed before creating or running most Laravel projects.

## Required tools

- PHP
- Composer
- A browser
- VS Code or another text editor

## Recommended extensions

- PHP Intelephense
- Laravel Extra Intellisense

## Start from zero

- Create a project with Composer, such as `composer create-project laravel/laravel example-app`.
- You can also use the Laravel installer if it is already set up.
- Open the new project folder in VS Code.
- Run `php artisan serve`.

## Open an existing project

- Open the Laravel project folder in VS Code.
- Look for `artisan` and `composer.json` to confirm you opened the project root.
- Run the project setup steps from its README if it has one.

## Run or preview the project

- Run `php artisan serve` in the project folder.
- Open the local browser link shown in the terminal.
- Keep the terminal running while you work.

## Where you usually code

- Routes usually live in `routes/web.php` or `routes/api.php`.
- Controllers usually live in `app/Http/Controllers/`.
- Models usually live in `app/Models/`.
- Migrations usually live in `database/migrations/`.

## Common first problems

- `composer` is not recognized: install Composer and reopen the terminal.
- `php artisan serve` cannot run: check that the terminal is in the Laravel project folder.
- Database errors appear: check the `.env` file and migration setup.

## Next Atlas step

After Laravel opens locally, continue with the mission or use the Concept Library for Laravel words.
