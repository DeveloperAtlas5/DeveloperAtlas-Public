const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getLearning,
  unique
} = require("./learning-utils");

const paths = [
  {
    name: "Rookie Frontend Path",
    audience: "Rookie frontend developers who need practical sequencing across JavaScript, CSS, and Vue.",
    order: ["CANON-001", "CANON-009", "CANON-010", "CANON-004", "CANON-003", "CANON-007", "CANON-006"],
    objectives: [
      "Choose the right array method for common UI data work.",
      "Choose Flexbox or Grid based on layout shape.",
      "Understand basic Vue state and conditional rendering."
    ],
    checkpoint: "Build a small product list with filtered search, selected-product lookup, responsive layout, and Vue conditional states."
  },
  {
    name: "JavaScript Array Mastery Path",
    audience: "Rookies and juniors who want confidence choosing array tools.",
    order: ["CANON-001", "CANON-009", "CANON-010", "CANON-002"],
    objectives: [
      "Separate transformation, filtering, lookup, and accumulation.",
      "Avoid side-effect and readability anti-patterns.",
      "Explain trade-offs between map(), filter(), find(), forEach(), and reduce()."
    ],
    checkpoint: "Transform, filter, search, and group a realistic orders dataset without mutating the source array."
  },
  {
    name: "Vue Reactivity Path",
    audience: "Junior Vue developers moving into Composition API decisions.",
    order: ["CANON-003", "CANON-006", "CANON-007"],
    objectives: [
      "Choose ref() or reactive() for state shape.",
      "Choose computed() or watch() for derived state and effects.",
      "Choose v-if or v-show for rendering behavior."
    ],
    checkpoint: "Build a settings panel with editable state, derived labels, watched persistence, and conditional rendering."
  },
  {
    name: "CSS Layout Decision Path",
    audience: "Rookies and juniors who need layout decision confidence.",
    order: ["CANON-004"],
    objectives: [
      "Identify one-dimensional versus two-dimensional layout problems.",
      "Choose Flexbox for alignment and Grid for structured tracks.",
      "Avoid using layout systems when normal flow is enough."
    ],
    checkpoint: "Build a responsive navbar and card grid, then explain why each layout tool was chosen."
  },
  {
    name: "SQL Foundations Path",
    audience: "Rookies and juniors learning to query relational data safely.",
    order: ["CANON-005"],
    objectives: [
      "Understand INNER JOIN and LEFT JOIN row behavior.",
      "Debug missing rows and duplicate-looking parent rows.",
      "Connect filtering decisions to joined result sets."
    ],
    checkpoint: "Create a users/orders report showing users with orders and users without orders."
  }
];

function main() {
  const entriesByCanonId = new Map((readCanonIndex().entries || []).map((entry) => [entry.canon_id, entry]));
  const lines = [
    "# Atlas Learning Curriculum",
    "",
    "This curriculum is generated from Canon learning metadata. It is deterministic and content-system only.",
    ""
  ];

  for (const learningPath of paths) {
    const entries = learningPath.order.map((id) => entriesByCanonId.get(id)).filter(Boolean);
    const totalMinutes = entries.reduce((sum, entry) => {
      const learning = getLearning(entry);
      return sum + Number(learning.estimated_learning_minutes || 0) + Number(learning.estimated_practice_minutes || 0);
    }, 0);
    const practiceTasks = unique(entries.flatMap((entry) => getLearning(entry).recommended_projects || []));

    lines.push(`## ${learningPath.name}`, "");
    lines.push(`- Intended audience: ${learningPath.audience}`);
    lines.push(`- Estimated total time: ${totalMinutes} minutes`);
    lines.push(`- Recommended order: ${learningPath.order.join(" -> ")}`);
    lines.push("");
    lines.push("### Learning Objectives", "");
    for (const objective of learningPath.objectives) lines.push(`- ${objective}`);
    lines.push("", "### Practice Tasks", "");
    for (const task of practiceTasks) lines.push(`- ${task}`);
    lines.push("", "### Mastery Checkpoint", "");
    lines.push(learningPath.checkpoint, "");
  }

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "curriculum.md"), `${lines.join("\n").trim()}\n`);
  console.log(`Generated output/learning/curriculum.md with ${paths.length} learning paths.`);
}

main();

