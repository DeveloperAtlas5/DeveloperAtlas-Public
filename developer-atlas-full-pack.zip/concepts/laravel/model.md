# Laravel Model

Technology: Laravel

## Simple meaning

A model represents data, usually one database table and its records.

## Why it exists

Models give PHP code a clear way to read and change database records.

## Where you use it

Usually in `app/Models`.

## When to use it

Use a model when your app needs to work with stored data such as users, posts, orders, or comments.

## Tiny example

`Post::where('published', true)->get();`

## Common beginner confusion

A model is not the database table itself. It is the PHP class Laravel uses to work with records from that table.

## Related concepts

- Eloquent
- Migration
- Relationship

## Similar idea in another technology

A Vue reactive object can represent data in the browser, but a Laravel model represents records that can live in the database.
