# Laravel API Resource

Technology: Laravel

## Simple meaning

An API Resource shapes model data before sending it as JSON.

## Why it exists

It keeps API responses consistent and avoids exposing every database field by accident.

## Where you use it

In resource classes, usually under `app/Http/Resources`.

## When to use it

Use an API Resource when an API endpoint returns model data to a frontend or another client.

## Tiny example

`return new PostResource($post);`

## Common beginner confusion

A resource is not the same as a model. It is a response shape built from model data.

## Related concepts

- Model
- Controller
- Route

## Similar idea in another technology

A frontend mapper can reshape API data before display, but an API Resource shapes data before it leaves Laravel.
