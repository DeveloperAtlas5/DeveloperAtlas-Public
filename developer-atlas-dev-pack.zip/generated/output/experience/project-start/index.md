# Project Start Guides

Use this when you do not know how to start or open a project yet.

Not knowing how to start a project is normal. These guides exist so you do not have to guess.

## Web basics

- [HTML](html.md)
- [CSS](css.md)
- [JavaScript](javascript.md)

## Frameworks

- [Vue](vue.md)
- [Laravel](laravel.md)

## Backend / database

- [PHP](php.md)
- [SQL](sql.md)
- [Java](java.md)

## How to use these guides

Pick the project type, follow the first setup steps, then continue with the mission or Concept Library.
