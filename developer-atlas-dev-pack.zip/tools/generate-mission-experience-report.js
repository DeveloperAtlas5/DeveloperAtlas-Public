const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { analyzeContent } = require("./quality-utils");
const {
  renderMissionSurface,
  renderVibeMissionSurface,
  renderMissionTwoSurface,
  renderVibeMissionTwoSurface,
  renderMissionThreeSurface,
  renderVibeMissionThreeSurface,
  renderBeginnerOrientation,
  renderVueConceptCards,
  renderTerminalConfidenceGuide
} = require("./templates/mission-templates");
const { renderMissionDashboard } = require("./templates/dashboard-template");
const { renderStartHere } = require("./templates/start-here-template");
const { renderFirstTimeQuickStart } = require("./templates/quick-start-template");
const { renderAiPromptPack } = require("./templates/ai-prompt-pack-template");
const { renderHardenedCanonFiles } = require("./templates/canon-templates");
const {
  renderFeedbackTemplate,
  renderTesterFeedbackReport,
  renderTesterHandoffMessages,
  renderPublicAlphaReadinessReport,
  renderAlphaFocusLock,
  renderCanonCandidateBacklogReport,
  renderAlphaPackageFinalQa,
  renderHumanAiReadabilityAudit,
  renderInheritedWarningBurnDownReport,
  renderAiGuardrailEvaluation
} = require("./templates/report-templates");
const { renderAiGuardrailRedTeamPack } = require("./templates/ai-red-team-template");
const { renderAiRedTeamResultsTemplate } = require("./templates/ai-red-team-results-template");

// Orchestrates generation. Template text lives in tools/templates/.

const missionPath = path.join(rootDir, "output", "mission", "today-mission.json");
const reportPath = path.join(rootDir, "output", "mission", "mission-experience-report.md");
const experienceOutputDir = path.join(rootDir, "output", "experience");
const missionSurfacePath = path.join(experienceOutputDir, "today-mission-surface.md");
const vibeMissionSurfacePath = path.join(experienceOutputDir, "today-mission-surface.vibe.md");
const missionTwoSurfacePath = path.join(experienceOutputDir, "mission-02-todoitem-surface.md");
const vibeMissionTwoSurfacePath = path.join(experienceOutputDir, "mission-02-todoitem-surface.vibe.md");
const missionThreeSurfacePath = path.join(experienceOutputDir, "mission-03-todostats-surface.md");
const vibeMissionThreeSurfacePath = path.join(experienceOutputDir, "mission-03-todostats-surface.vibe.md");
const feedbackTemplatePath = path.join(experienceOutputDir, "mission-feedback-template.md");
const missionDashboardPath = path.join(experienceOutputDir, "mission-dashboard.html");
const startHerePath = path.join(experienceOutputDir, "START_HERE.md");
const firstTimeQuickStartPath = path.join(experienceOutputDir, "first-time-quick-start.md");
const aiPromptPackPath = path.join(experienceOutputDir, "ai-prompt-pack.md");
const hardenedCanonOutputDir = path.join(experienceOutputDir, "canon", "hardened");
const beginnerOrientationPath = path.join(experienceOutputDir, "beginner-orientation.md");
const vueConceptCardsPath = path.join(experienceOutputDir, "vue-concept-cards.md");
const terminalConfidenceGuidePath = path.join(experienceOutputDir, "terminal-confidence-guide.md");
const testerFeedbackReportPath = path.join(experienceOutputDir, "tester-feedback-report.md");
const testerHandoffMessagesPath = path.join(experienceOutputDir, "tester-handoff-messages.md");
const publicAlphaReadinessReportPath = path.join(experienceOutputDir, "public-alpha-readiness-report.md");
const alphaFocusLockPath = path.join(experienceOutputDir, "alpha-focus-lock.md");
const canonCandidateBacklogReportPath = path.join(experienceOutputDir, "canon-candidate-backlog-report.md");
const alphaPackageFinalQaPath = path.join(experienceOutputDir, "alpha-package-final-qa.md");
const humanAiReadabilityAuditPath = path.join(experienceOutputDir, "human-ai-readability-audit.md");
const inheritedWarningBurnDownReportPath = path.join(experienceOutputDir, "inherited-warning-burndown-report.md");
const aiGuardrailEvaluationPath = path.join(experienceOutputDir, "ai-guardrail-evaluation.md");
const aiGuardrailRedTeamPackPath = path.join(experienceOutputDir, "ai-guardrail-red-team-pack.md");
const aiRedTeamResultsTemplatePath = path.join(experienceOutputDir, "ai-red-team-results-template.md");

function main() {
  const mission = JSON.parse(fs.readFileSync(missionPath, "utf8"));
  const contentWarningCounts = analyzeContent().counts;
  const checks = [
    check("One clear next step", Boolean(mission.what_to_do_first), "Mission includes a first action."),
    check("Reduces overwhelm", Array.isArray(mission.what_to_ignore_today) && mission.what_to_ignore_today.length > 0, "Mission tells the user what to ignore today."),
    check("Explains why", Boolean(mission.why_this_mission_matters), "Mission explains why this matters now."),
    check("Includes recovery", Boolean(mission.today_recovery_plan && mission.today_recovery_plan.safest_first_fix), "Mission includes a prepared recovery path."),
    check("Includes AI context", Boolean(mission.today_ai_context), "Mission points to an AI context pack."),
    check("Includes visible win", Boolean(mission.visible_reward_after_completion), "Mission describes the visible reward."),
    check("Supports confidence", Boolean(mission.confidence_first_message), "Mission ends with confidence-building framing.")
  ];
  const score = Math.round((checks.filter((item) => item.passed).length / checks.length) * 100);

  const lines = [
    "# Mission Experience Report",
    "",
    `Mission: ${mission.mission_title}`,
    `Experience score: ${score}/100`,
    "",
    "## Checks",
    "",
    ...checks.map((item) => `- ${item.passed ? "PASS" : "WARN"}: ${item.label} - ${item.note}`),
    "",
    "## Recommendation",
    "",
    score === 100
      ? "Mission output is ready as the primary demo experience."
      : "Improve any WARN items before using Mission as the first demo artifact.",
    ""
  ];

  fs.mkdirSync(experienceOutputDir, { recursive: true });
  if (fs.existsSync(hardenedCanonOutputDir)) {
    fs.rmSync(hardenedCanonOutputDir, { recursive: true, force: true });
  }
  fs.mkdirSync(hardenedCanonOutputDir, { recursive: true });
  fs.writeFileSync(reportPath, `${lines.join("\n")}`);
  fs.writeFileSync(missionSurfacePath, renderMissionSurface(mission));
  fs.writeFileSync(vibeMissionSurfacePath, renderVibeMissionSurface());
  fs.writeFileSync(missionTwoSurfacePath, renderMissionTwoSurface());
  fs.writeFileSync(vibeMissionTwoSurfacePath, renderVibeMissionTwoSurface());
  fs.writeFileSync(missionThreeSurfacePath, renderMissionThreeSurface());
  fs.writeFileSync(vibeMissionThreeSurfacePath, renderVibeMissionThreeSurface());
  fs.writeFileSync(feedbackTemplatePath, renderFeedbackTemplate());
  fs.writeFileSync(missionDashboardPath, renderMissionDashboard());
  fs.writeFileSync(startHerePath, renderStartHere());
  fs.writeFileSync(firstTimeQuickStartPath, renderFirstTimeQuickStart());
  fs.writeFileSync(aiPromptPackPath, renderAiPromptPack());
  for (const canonFile of renderHardenedCanonFiles()) {
    fs.writeFileSync(path.join(hardenedCanonOutputDir, canonFile.fileName), canonFile.content);
  }
  fs.writeFileSync(beginnerOrientationPath, renderBeginnerOrientation());
  fs.writeFileSync(vueConceptCardsPath, renderVueConceptCards());
  fs.writeFileSync(terminalConfidenceGuidePath, renderTerminalConfidenceGuide());
  fs.writeFileSync(testerFeedbackReportPath, renderTesterFeedbackReport());
  fs.writeFileSync(testerHandoffMessagesPath, renderTesterHandoffMessages());
  fs.writeFileSync(publicAlphaReadinessReportPath, renderPublicAlphaReadinessReport());
  fs.writeFileSync(alphaFocusLockPath, renderAlphaFocusLock());
  fs.writeFileSync(canonCandidateBacklogReportPath, renderCanonCandidateBacklogReport());
  fs.writeFileSync(alphaPackageFinalQaPath, renderAlphaPackageFinalQa());
  fs.writeFileSync(humanAiReadabilityAuditPath, renderHumanAiReadabilityAudit());
  fs.writeFileSync(inheritedWarningBurnDownReportPath, renderInheritedWarningBurnDownReport(contentWarningCounts));
  fs.writeFileSync(aiGuardrailEvaluationPath, renderAiGuardrailEvaluation());
  fs.writeFileSync(aiGuardrailRedTeamPackPath, renderAiGuardrailRedTeamPack());
  fs.writeFileSync(aiRedTeamResultsTemplatePath, renderAiRedTeamResultsTemplate());
  console.log("Generated output/mission/mission-experience-report.md.");
  console.log("Generated output/experience/today-mission-surface.md.");
  console.log("Generated output/experience/today-mission-surface.vibe.md.");
  console.log("Generated output/experience/mission-02-todoitem-surface.md.");
  console.log("Generated output/experience/mission-02-todoitem-surface.vibe.md.");
  console.log("Generated output/experience/mission-03-todostats-surface.md.");
  console.log("Generated output/experience/mission-03-todostats-surface.vibe.md.");
  console.log("Generated output/experience/mission-feedback-template.md.");
  console.log("Generated output/experience/mission-dashboard.html.");
  console.log("Generated output/experience/START_HERE.md.");
  console.log("Generated output/experience/first-time-quick-start.md.");
  console.log("Generated output/experience/ai-prompt-pack.md.");
  console.log("Generated output/experience/canon/hardened/*.md.");
  console.log("Generated output/experience/beginner-orientation.md.");
  console.log("Generated output/experience/vue-concept-cards.md.");
  console.log("Generated output/experience/terminal-confidence-guide.md.");
  console.log("Generated output/experience/tester-feedback-report.md.");
  console.log("Generated output/experience/tester-handoff-messages.md.");
  console.log("Generated output/experience/public-alpha-readiness-report.md.");
  console.log("Generated output/experience/alpha-focus-lock.md.");
  console.log("Generated output/experience/canon-candidate-backlog-report.md.");
  console.log("Generated output/experience/alpha-package-final-qa.md.");
  console.log("Generated output/experience/human-ai-readability-audit.md.");
  console.log("Generated output/experience/inherited-warning-burndown-report.md.");
  console.log("Generated output/experience/ai-guardrail-evaluation.md.");
  console.log("Generated output/experience/ai-guardrail-red-team-pack.md.");
  console.log("Generated output/experience/ai-red-team-results-template.md.");
  console.log(`Mission experience score: ${score}/100.`);
}

function check(label, passed, note) {
  return { label, passed, note };
}

















main();
