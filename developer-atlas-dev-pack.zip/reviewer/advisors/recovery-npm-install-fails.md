# Recovery Advice: npm-install-fails

Symptom: npm install fails
Matched friction node: friction.javascript.npm.install_fails (npm install fails)
Estimated recovery time: 25 minutes
Related setup profile: setup.beginner_vue_windows

## Likely Causes Ranked

1. Node version does not match project expectations
2. Permissions problem in global npm cache
3. Registry or network failure
4. Stale node_modules or package-lock.json conflict

## Diagnostic Steps

1. Run node --version and npm --version
2. Read the first real npm error above the stack trace
3. Check package.json engines if present
4. Run npm cache verify

## Safest First Fix

- Use the project-supported Node version

## Alternative Fixes

- Remove node_modules and reinstall
- Prefer npm ci when package-lock.json is authoritative
- Fix permissions rather than using sudo repeatedly

## Verification Steps

- [ ] npm install or npm ci exits with code 0
- [ ] npm run validate or project test command starts successfully

## Prevention Notes

- Pin Node versions with .nvmrc or Volta
- Commit lockfiles for application projects
- Document package manager choice

## Related Tools

- Node.js (tool.node)
- Visual Studio Code (tool.vscode)
- ESLint extension (extension.eslint)
- pnpm (tool.pnpm)

## Beginner Reassurance

- This is a setup or toolchain blocker, not a sign that you cannot code.
- Follow the diagnostic steps in order and verify after each fix.

## Professional Shortcut

- Jump to: Run node --version and npm --version
- Then apply: Use the project-supported Node version
- If verification fails, move to the next likely cause rather than repeating the same fix.

## When To Stop And Ask For Help

- Stop after 35 minutes if no verification step passes.
- Ask for help if the error message changes into a new unknown error.
- Ask for help before deleting project files, changing global permissions, or reinstalling major toolchains.
