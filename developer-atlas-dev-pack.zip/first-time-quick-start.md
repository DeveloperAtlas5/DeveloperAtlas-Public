# First-Time Quick Start

## Open this first

Open `mission-dashboard.html` first.

Choose `Start Mission 1`.

You do not need to browse the folders.

## Where do I work?

Use Atlas as the guide.

Code in your Vue todo project.

Do not edit files inside this Atlas package unless a mission explicitly tells you to.

## Your only goal

Make todos survive refresh.

## If you get nervous

Use help only if you get stuck.

Stay with Mission 1 first.

## Small success checklist

- I can add a todo.
- I can refresh the page.
- My todo is still there.
- I know where to look if I get stuck.
