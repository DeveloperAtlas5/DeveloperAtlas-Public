# Mission Intelligence v1

Mission Intelligence is the primary user experience layer for Developer Atlas.

It does not replace existing Atlas systems. It transforms them into one actionable mission.

## Why Mission Exists

Atlas has many useful systems: Goal Intelligence, Readiness, Hardware, Toolkit, Setup, Recovery, Canon, Learning, Capability, Explainability, Momentum, AI Context, Experience, and Flow.

Users should not have to inspect those systems one by one before they can move.

Mission Intelligence answers:

- What do I do today?
- How long will it take?
- What should I learn?
- What should I build?
- What setup check matters first?
- What recovery path should I use if it breaks?
- What should I ignore today?
- What visible win should I expect?
- What comes next?

## Relationship To Flow

Flow is the orchestration engine behind Mission.

Flow gathers the journey from goal to readiness to setup to learning to capability to AI context. Mission compresses that journey into a single practical objective.

## Mission Output

Each mission includes:

- Mission title
- Estimated duration
- Difficulty
- Confidence score
- Today's objective
- Today's Canon
- Today's project
- Today's setup check
- Today's recovery plan
- Today's AI context
- What to ignore today
- Visible reward after completion
- Next mission preview

## Mission Principles

1. One mission.
2. One clear outcome.
3. No overwhelm.
4. One visible success.
5. Confidence first.
6. Use existing Atlas systems.
7. Explain why, but keep it short.
8. Prefer action over inventory.
9. Show what to ignore.
10. End with the next useful step.
