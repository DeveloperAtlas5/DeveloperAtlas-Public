# array.map vs array.forEach

## Status Metadata

- Canon ID: CANON-CANDIDATE-JS-002
- Node ID: canon.javascript.array.map-vs-foreach-candidate
- Status: candidate
- Score: 55
- Version: 2026.1
- Source family: JavaScript
- Level: rookie/junior
- Audience: future Rookie-to-Junior frontend path
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use map when you need a new array. Use forEach when you are doing something for each item without using a returned array. This candidate supports future Rookie-to-Junior frontend coverage and is not part of the current public alpha mission.

## What Problem This Solves

This reduces beginner confusion around array.map vs array.forEach by turning the topic into a small decision with practical recovery guidance.

## Mental Model

Use map when you need a new array. Use forEach when you are doing something for each item without using a returned array.

## Beginner Explanation

Use map when you need a new array. Use forEach when you are doing something for each item without using a returned array. The goal is not to memorize a rule; the goal is to choose the option that matches what the code is trying to do.

## Professional Explanation

Use this decision to make intent visible in reviews, keep generated code scoped, and reduce hidden maintenance costs. The production signal is code that another developer can explain without reverse-engineering the author's guess.

## Syntax

```text
items.map(item => transform(item));
items.forEach(item => doSomething(item));
```

## Decision Guide

1. Name the task in plain language.
2. Choose array.map when: Use map for transformations and forEach for intentional side effects such as logging or updating outside state.
3. Choose array.forEach when it communicates the intent better.
4. If neither fits, pause and look for a prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| array.map | Use map for transformations and forEach for intentional side effects such as logging or updating outside state. | Can confuse beginners when used by habit. |
| array.forEach | A clearer fit when the primary option does not match the task | Can add noise if the project does not need it. |

## When To Use The Primary Option

- Use map for transformations and forEach for intentional side effects such as logging or updating outside state.
- Use it when it makes the code easier to explain.
- Use it when it matches the surrounding project convention.

## When To Use The Alternative

- Use it when array.map would hide the real intent.
- Use it when the alternative gives the learner or reviewer a clearer signal.
- Use it when existing project code already follows that pattern.

## When Not To Use This Decision

- Do not use map when the returned array is ignored.
- Do not expand the current Rookie Vue alpha mission just to use this candidate.
- Do not treat this candidate as fully reviewed evidence.

## Alternatives

- Use an existing Gold Candidate node when this topic overlaps one.
- Use a smaller prerequisite concept when the learner is blocked earlier.

## Production Examples

### Beginner Example

```text
const labels = todos.map(todo => todo.title);
todos.forEach(todo => console.log(todo.id));
```

### Review Example

```text
Before accepting the code, explain why array.map or array.forEach matches the task.
```

## Common Mistakes

- Using map only to push into another array hides the real intent.
- Copying generated code without checking whether it matches the task.
- Treating the candidate as final before examples and sources are hardened.

## Debugging Checklist

- If the result is undefined, check whether forEach was used where map was needed.
- Compare the current behavior with the intended choice.
- Ask whether a smaller prerequisite concept would unblock the learner faster.

## Mechanical Verification

Runnable or deterministic examples should be added during a future hardening sprint. This candidate intentionally has no runnable example folder yet.

## Performance Notes

No performance claim is finalized for this candidate. Future hardening should separate real runtime concerns from readability and learning concerns.

## AI Coding Guidance

- Ask AI whether the code needs a returned array or a side effect before choosing.
- Ask for a small, scoped change.
- Ask the assistant to explain the trade-off before producing code.

## Teaching Notes

Start with the plain-language model, show the beginner example, then ask the learner to explain the choice back in one sentence. Keep this candidate optional until a mission needs it.

## Interview Questions

1. When would you choose array.map?
2. What mistake would make array.forEach or another concept clearer?

## Exercises

### Beginner

Rewrite one loop into map and one loop into forEach, then explain the difference.

### Junior

Find one example in a small project and explain whether it uses the clearer option.

## Related Atlas Nodes

- CANON-001
- CANON-CANDIDATE-JS-003

## Evidence And Sources

- Candidate backlog entry only. Official source links must be added during hardening.
- Evidence level: candidate draft.
- Confidence: medium.

## Proof Of Superiority Summary

This candidate has a draft improvement hypothesis only. It should not be treated as reviewed or publication-ready.

## Scorecard Placeholder

- Current score: 55
- Status: candidate
- Needs official sources, stronger examples, verification, editorial review, and reviewer sign-off before any Gold consideration.
