# Object.keys() vs Object.values() vs Object.entries()

## Status Metadata

- Canon ID: CANON-012
- Node ID: canon.javascript.object.keys-vs-values-vs-entries
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript objects
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `Object.keys()` when you need property names. Use `Object.values()` when you need property values. Use `Object.entries()` when you need both the property name and its value together.

This is not a style preference. It is a result-shape decision:

- `Object.keys()` returns names.
- `Object.values()` returns values.
- `Object.entries()` returns `[key, value]` pairs.

## What Problem This Solves

Developers often reach for whichever object method they remember first, then write extra indexing or awkward lookups around it. That makes code noisier and hides intent.

This node solves a daily JavaScript decision:

- Choose `keys()` when the key is the data.
- Choose `values()` when only the values matter.
- Choose `entries()` when key and value must stay together.

## Mental Model

Start with what you need to carry through the next step.

Think of an object as a small labeled cabinet:

- `Object.keys()` gives you the drawer labels.
- `Object.values()` gives you the contents.
- `Object.entries()` gives you label-and-content pairs.

```js
const prices = {
  basic: 1000,
  pro: 2500
};

Object.keys(prices); // ["basic", "pro"]
Object.values(prices); // [1000, 2500]
Object.entries(prices); // [["basic", 1000], ["pro", 2500]]
```

The method contract is:

> I am turning an object's own enumerable string-keyed properties into an array with the shape I need next.

## Beginner Explanation

Use `Object.keys()` when you want the names on the left side of the object:

```js
const fieldNames = Object.keys(formErrors);
```

Use `Object.values()` when you only care about the values:

```js
const errorMessages = Object.values(formErrors);
```

Use `Object.entries()` when you need the name and value together:

```js
const rows = Object.entries(formErrors).map(([field, message]) => ({
  field,
  message
}));
```

Beginner rule:

1. Need names? Use `Object.keys()`.
2. Need values? Use `Object.values()`.
3. Need both? Use `Object.entries()`.

## Professional Explanation

`Object.keys()`, `Object.values()`, and `Object.entries()` return arrays based on an object's own enumerable string-keyed properties. They do not include inherited properties. They do not include non-enumerable properties. Symbol-keyed properties are not returned by these methods.

In production code, the best choice reduces follow-up work:

- `Object.keys(config)` is clear when validating required option names.
- `Object.values(metrics)` is clear when aggregating numeric values.
- `Object.entries(labels)` is clear when rendering labels with their values or converting object shape.

The review signal is simple: if code calls `Object.keys(obj)` and then repeatedly does `obj[key]`, `Object.entries(obj)` may communicate intent better. If code calls `Object.entries(obj)` and ignores the key, `Object.values(obj)` is likely clearer.

Property order follows standard JavaScript property ordering rules: integer-like keys first in ascending order, then other string keys in insertion order. Do not use plain object property order as a substitute for explicit domain ordering when order matters.

## Syntax

```js
const keys = Object.keys(object);
const values = Object.values(object);
const entries = Object.entries(object);
```

Common forms:

```js
Object.keys(errors).forEach((fieldName) => {
  highlightField(fieldName);
});
```

```js
const total = Object.values(totalsByCategory).reduce((sum, value) => sum + value, 0);
```

```js
const rows = Object.entries(settings).map(([key, value]) => ({
  key,
  value
}));
```

## Decision Guide

Ask these questions in order:

1. Do I need only property names?
   Use `Object.keys()`.
2. Do I need only property values?
   Use `Object.values()`.
3. Do I need the property name and value together?
   Use `Object.entries()`.
4. Do I need symbol keys?
   Use `Object.getOwnPropertySymbols()` or `Reflect.ownKeys()`.
5. Do I need non-enumerable properties?
   Use `Object.getOwnPropertyNames()` or descriptors.
6. Do I need guaranteed custom ordering?
   Sort the resulting array explicitly or use an ordered data structure.
7. Do I need frequent key/value insertions and deletions?
   Consider `Map`.

## Comparison Table

| Choice | Returns | Best For | Trade-Off |
| --- | --- | --- | --- |
| `Object.keys()` | Array of property names | Dynamic field names, validation, whitelists | Requires `object[key]` if value is also needed |
| `Object.values()` | Array of property values | Totals, statistics, value-only checks | Loses the property name |
| `Object.entries()` | Array of `[key, value]` pairs | Rendering rows, transforming objects, preserving labels | Slightly more structure to destructure |
| `Object.fromEntries()` | Object from pairs | Rebuilding objects after entry transforms | Requires valid `[key, value]` pairs |
| `Reflect.ownKeys()` | String and symbol keys | Complete key reflection | Includes more than most app code needs |
| `Map` | Iterable key/value collection | Dynamic dictionaries with non-string keys | Different API than plain objects |

## When To Use The Primary Option

Use the object helper that preserves exactly the information the next step needs. In this three-way decision, the "primary" option is not always one method. The primary option is the method whose returned array shape matches the work:

- Use `Object.keys()` for names.
- Use `Object.values()` for values.
- Use `Object.entries()` for key-value pairs.

## When To Use The Alternative

Use an alternative when your first choice forces awkward follow-up code:

- If `Object.keys()` makes you repeatedly read `object[key]`, use `Object.entries()`.
- If `Object.entries()` makes you ignore the key, use `Object.values()`.
- If `Object.values()` loses information you need later, use `Object.entries()`.
- If none of the three include the properties you need, use a reflection API such as `Reflect.ownKeys()`.

## When To Use Object.keys()

Use `Object.keys()` when:

- The property name is what you need.
- You are checking which fields exist.
- You are validating required fields.
- You are iterating dynamic form fields.
- You need a count of own enumerable string-keyed properties.

```js
const missingFields = requiredFields.filter((field) => {
  return !Object.keys(formValues).includes(field);
});
```

## When To Use Object.values()

Use `Object.values()` when:

- The keys do not matter.
- You need to total or average numeric values.
- You need to check whether any value passes a condition.
- You are producing statistics from a lookup object.

```js
const totalRevenueCents = Object.values(revenueByPlan).reduce((sum, cents) => {
  return sum + cents;
}, 0);
```

## When To Use Object.entries()

Use `Object.entries()` when:

- You need key and value together.
- You are rendering label/value rows.
- You are transforming an object into another object.
- You would otherwise call `object[key]` repeatedly after `Object.keys()`.
- You want to pair naturally with `Object.fromEntries()`.

```js
const displayRows = Object.entries(profile).map(([field, value]) => ({
  label: fieldLabels[field] ?? field,
  value
}));
```

## When Not To Use This Decision

Do not use these methods when:

- You need inherited properties. Use `for...in` carefully with `Object.hasOwn()` checks.
- You need symbol keys. Use `Object.getOwnPropertySymbols()` or `Reflect.ownKeys()`.
- You need non-enumerable properties. Use `Object.getOwnPropertyNames()` or descriptors.
- You need stable custom order. Sort explicitly or store order separately.
- You need a dynamic collection with non-string keys. Use `Map`.
- You are working with arrays. Use array methods directly.
- You are serializing domain data and need schema control. Use explicit field lists.

## Alternatives

### Object.fromEntries()

Use `Object.fromEntries()` when entries should become a new object.

```js
const publicSettings = Object.fromEntries(
  Object.entries(settings).filter(([key]) => !key.startsWith("_"))
);
```

### Map

Use `Map` when keys are not naturally strings or the collection changes often.

```js
const cache = new Map();
cache.set(user, permissions);
```

### Object.hasOwn()

Use `Object.hasOwn()` when checking whether one property exists.

```js
if (Object.hasOwn(formValues, "email")) {
  validateEmail(formValues.email);
}
```

### Reflect.ownKeys()

Use `Reflect.ownKeys()` when both string and symbol keys matter.

```js
const allOwnKeys = Reflect.ownKeys(record);
```

## Production Examples

### Dynamic Form Fields With Object.keys()

```js
const touchedFieldNames = Object.keys(touchedFields);

const visibleErrors = touchedFieldNames
  .filter((fieldName) => formErrors[fieldName])
  .map((fieldName) => ({
    fieldName,
    message: formErrors[fieldName]
  }));
```

Why `Object.keys()` fits: the workflow starts from dynamic field names. The key is the field identity.

### Totals And Statistics With Object.values()

```js
const revenueByPlan = {
  basic: 120000,
  pro: 340000,
  enterprise: 890000
};

const totalRevenueCents = Object.values(revenueByPlan).reduce((sum, cents) => {
  return sum + cents;
}, 0);

const averageRevenueCents = totalRevenueCents / Object.values(revenueByPlan).length;
```

Why `Object.values()` fits: the calculation only needs numeric values.

### Rendering Label/Value Pairs With Object.entries()

```js
const accountSummary = {
  plan: "Pro",
  seats: 12,
  status: "Active"
};

const rows = Object.entries(accountSummary).map(([key, value]) => ({
  label: key[0].toUpperCase() + key.slice(1),
  value: String(value)
}));
```

Why `Object.entries()` fits: each rendered row needs both a label source and a value.

### Transform Object Shape

```js
const normalizedFilters = Object.fromEntries(
  Object.entries(rawFilters)
    .filter(([, value]) => value !== "" && value !== null)
    .map(([key, value]) => [key, String(value).trim()])
);
```

Why `Object.entries()` fits: the transform needs to inspect and return both key and value.

## Common Mistakes

- Using `Object.keys()` and repeatedly writing `object[key]` when `Object.entries()` would be clearer.
- Using `Object.values()` and later needing the key that was discarded.
- Expecting inherited properties to appear.
- Expecting symbol keys to appear.
- Assuming property order is a domain ordering guarantee.
- Using `Object.entries()` and ignoring one side of the pair.
- Forgetting that values can still be object references, not deep clones.

```js
// Mistake: key/value pair needed, but value lookup is repeated
const rows = Object.keys(settings).map((key) => ({
  key,
  value: settings[key]
}));
```

```js
// Better
const rows = Object.entries(settings).map(([key, value]) => ({
  key,
  value
}));
```

```js
// Mistake: inherited properties are not included
const base = { inherited: true };
const object = Object.create(base);
object.own = true;

Object.keys(object); // ["own"]
```

## Debugging Checklist

- If a property is missing, is it inherited rather than own?
- If a property is missing, is it non-enumerable?
- If a symbol key is missing, should you use `Reflect.ownKeys()`?
- If order looks surprising, are there integer-like keys?
- If the key is needed later, should this be `Object.entries()` instead of `Object.values()`?
- If the value lookup is noisy, should this be `Object.entries()` instead of `Object.keys()`?
- If object values mutate later, are you expecting a deep copy that these methods do not provide?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-012/`.

Verification command:

```sh
npm run canon:verify:012
```

The verification suite checks:

- `Object.keys()` for dynamic form fields.
- `Object.values()` for totals and statistics.
- `Object.entries()` for rendering label/value pairs.
- The inherited-property anti-pattern.

## Performance Notes

These methods allocate arrays. That is usually the right trade-off for clear application code.

For very large objects or hot paths, measure. If allocation matters, a `for...in` loop with `Object.hasOwn()` or a purpose-built data structure may be more appropriate. In normal production code, the larger risk is unclear intent: choosing `keys()`, `values()`, or `entries()` poorly makes future changes more error-prone.

## AI Coding Guidance

When generating code:

- Use `Object.keys()` only when property names are the useful result.
- Use `Object.values()` only when property names are irrelevant.
- Use `Object.entries()` when both key and value are used.
- Do not generate `Object.keys(obj).map((key) => obj[key])` when `Object.values(obj)` is enough.
- Do not generate `Object.keys(obj).map((key) => ({ key, value: obj[key] }))` when `Object.entries(obj)` is clearer.
- Mention that inherited, non-enumerable, and symbol properties are excluded when that matters.
- Use `Object.fromEntries()` for entry-to-object transforms.
- Use `Map` when non-string keys or frequent dynamic updates are central.

Bad AI output:

```js
const total = Object.keys(scores).reduce((sum, key) => sum + scores[key], 0);
```

Better:

```js
const total = Object.values(scores).reduce((sum, score) => sum + score, 0);
```

Good `entries()` output:

```js
const rows = Object.entries(settings).map(([key, value]) => ({ key, value }));
```

## Teaching Notes

Teach this as a shape decision:

1. Show a tiny object.
2. Ask whether the learner needs names, values, or both.
3. Show the returned array shape for each method.
4. Connect `entries()` to destructuring.
5. Show the inherited-property boundary.
6. End with `Object.fromEntries()` as the reverse move.

Useful teaching phrase:

> Choose the method that keeps the information you still need.

## Interview Questions

1. What does `Object.keys()` return?
2. What does `Object.values()` return?
3. What does `Object.entries()` return?
4. Do these methods include inherited properties?
5. Do these methods include symbol keys?
6. When is `Object.entries()` clearer than `Object.keys()`?
7. When is `Object.values()` clearer than `Object.entries()`?
8. How would you turn filtered entries back into an object?

## Exercises

### Beginner

Given an object of form errors, return the field names that currently have errors.

### Intermediate

Given an object of category totals, calculate the total and average.

### Advanced

Transform a settings object by removing private keys and trimming string values, then rebuild the object with `Object.fromEntries()`.

## Related Atlas Nodes

- `javascript.object.keys`
- `javascript.array.map`
- `javascript.array.reduce`
- `javascript.array.filter`
- `CANON-001`
- `CANON-002`
- `CANON-009`

## Evidence And Sources

- MDN Web Docs: Object.keys(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/keys
- MDN Web Docs: Object.values(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/values
- MDN Web Docs: Object.entries(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/entries
- ECMAScript specification: Object.keys: https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.keys
- ECMAScript specification: Object.values: https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.values
- ECMAScript specification: Object.entries: https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.entries
- Industry reference pattern: production JavaScript commonly uses `entries()` for UI label/value rows and `values()` for aggregate statistics when object keys are not needed.

## Proof Of Superiority Summary

Official references explain what each method returns. This Canon node explains how to choose between them, what information each method keeps or discards, how the choice affects production readability, how inherited and symbol properties affect debugging, and how AI assistants should generate object iteration code.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
