const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const capabilityDir = path.join(rootDir, "capability");
const capabilityExamplesDir = path.join(capabilityDir, "examples");
const capabilityOutputDir = path.join(rootDir, "output", "capability");

function ensureCapabilityOutputDir() {
  fs.mkdirSync(capabilityOutputDir, { recursive: true });
}

function readCapabilities() {
  if (!fs.existsSync(capabilityExamplesDir)) return [];

  return fs.readdirSync(capabilityExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(capabilityExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        capability: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function countValues(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

module.exports = {
  capabilityDir,
  capabilityExamplesDir,
  capabilityOutputDir,
  ensureCapabilityOutputDir,
  readCapabilities,
  countValues,
  unique
};

