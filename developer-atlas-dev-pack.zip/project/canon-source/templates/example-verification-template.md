# Canon Example Verification Template

Canon ID:
Node ID:

## Purpose

Runnable examples prove that Canon examples are mechanically sound, not just plausible.

## Folder

Examples should live in:

```text
canon/examples/CANON-000/
```

## Recommended Files

- `run-examples.js`
- `primary-example.js`
- `alternative-example.js`
- `anti-pattern-example.js`

## Run Command

```sh
npm run canon:verify:000
```

## Verification Notes

- Use Node's built-in `assert` module when possible.
- Avoid external dependencies unless the Canon node cannot be verified without them.
- Verify both correct patterns and at least one common anti-pattern.
- Keep examples short enough for readers to understand.
