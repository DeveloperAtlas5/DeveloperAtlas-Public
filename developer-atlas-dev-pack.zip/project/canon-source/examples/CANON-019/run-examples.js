const examples = [
  ["INNER JOIN returns users with orders", require("./inner-join-users-with-orders")],
  ["LEFT JOIN returns all users including those without orders", require("./left-join-all-users")],
  ["mistake: expecting INNER JOIN to keep unmatched users", require("./mistake-inner-join-unmatched-users")],
  ["mistake: filtering LEFT JOIN in WHERE causing it to behave like INNER JOIN", require("./mistake-left-join-filtered-in-where")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-019 example(s).`);
