# CANON-025 Proof Of Superiority

## Status

- Canon ID: CANON-025
- Node ID: canon.vue.components.props-vs-emits-vs-model
- Status: Gold Candidate
- Current score: 95

## Baseline Compared

Official Vue documentation explains props, component events, component `v-model`, and `<script setup>` macros separately. That reference material is accurate and should remain the evidence base.

Common tutorials often teach these features as syntax:

- How to pass a prop.
- How to emit an event.
- How to use `v-model`.

What they often do not make explicit is the decision model: who owns the value, which direction information travels, and when two-way binding is a clean API rather than hidden coupling.

## Atlas Improvement

Atlas improves the topic by turning separate Vue features into one component communication decision:

- Props are parent-to-child data.
- Emits are child-to-parent events.
- `v-model` or `defineModel()` is a controlled editing contract for parent-owned values.
- Direct prop mutation is named as the central anti-pattern.

This makes the node useful for:

- Rookies learning component communication after reactivity.
- Juniors designing reusable components.
- Professionals reviewing component APIs.
- AI assistants generating safer Vue code.

## Evidence

- Vue official docs, Props: https://vuejs.org/guide/components/props.html
- Vue official docs, Component Events: https://vuejs.org/guide/components/events.html
- Vue official docs, Component v-model: https://vuejs.org/guide/components/v-model.html
- Vue official docs, `defineProps()` and `defineEmits()`: https://vuejs.org/api/sfc-script-setup.html#defineprops-defineemits
- Vue official docs, `defineModel()`: https://vuejs.org/api/sfc-script-setup.html#definemodel

## Mechanical Verification

Examples in `canon/examples/CANON-025/` verify the core behavior deterministically:

- Parent passes prop to child.
- Child emits event to parent.
- `v-model` updates parent-owned state through an update event.
- Child prop mutation is detected as the wrong pattern.

Run:

```bash
npm run canon:verify:025
```

## Why This Is Better Than Generic Documentation

The Atlas node is not trying to replace Vue docs. It adds the missing decision layer:

- A beginner mental model.
- A professional component API explanation.
- A comparison table.
- Concrete production examples.
- Debugging guidance.
- AI coding guidance.
- Related Atlas nodes.
- Deterministic examples.

## Remaining Gap Before Gold

Named reviewer sign-off is still required:

- Technical reviewer.
- Educational reviewer.
- AI-readiness reviewer.
- Engineering reviewer.
