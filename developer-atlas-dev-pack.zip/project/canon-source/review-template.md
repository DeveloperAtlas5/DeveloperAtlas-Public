# Canon Review Template

Canon ID:
Node ID:
Reviewer:
Date:
Stage:

## Technical Review

- Accuracy:
- Edge cases:
- Version concerns:
- Evidence quality:

## Educational Review

- Beginner clarity:
- Mental model:
- Exercise quality:
- Common mistake coverage:

## AI Review

- Structured enough for retrieval:
- Code generation guidance:
- Ambiguity risks:
- Related node quality:

## Engineering Review

- Decision support:
- Production realism:
- Trade-offs:
- Anti-pattern coverage:

## Decision

- Approved stage:
- Required changes:
- Score:

