const examples = [
  ["computed fullName from firstName/lastName", require("./computed-full-name")],
  ["watch search query side effect simulation", require("./watch-search-query-side-effect")],
  ["mistake: using watch for derived state", require("./mistake-watch-for-derived-state")],
  ["mistake: using computed for side effects", require("./mistake-computed-for-side-effects")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-006 example(s).`);
