const fs = require("fs");
const path = require("path");
const {
  teamContextOutputDir,
  readTeamContexts,
  countValues,
  unique
} = require("./team-context-utils");

function main() {
  const contexts = readTeamContexts().map((record) => ({
    ...record.context,
    generated: readGeneratedContext(record.context.project_id)
  }));
  const scores = contexts.map(scoreContext);
  const report = buildReport(scores);

  fs.mkdirSync(teamContextOutputDir, { recursive: true });
  fs.writeFileSync(
    path.join(teamContextOutputDir, "team-context-quality-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(teamContextOutputDir, "team-context-quality-report.md"),
    toMarkdown(report)
  );

  console.log(`Scored ${scores.length} team context(s).`);
  console.log("Generated output/team-context/team-context-quality-report.json.");
  console.log("Generated output/team-context/team-context-quality-report.md.");
}

function readGeneratedContext(projectId) {
  const jsonFile = path.join(teamContextOutputDir, `${projectId}.json`);
  const sharedFile = path.join(teamContextOutputDir, `${projectId}-shared-ai-context.md`);
  const onboardingFile = path.join(teamContextOutputDir, `${projectId}-onboarding-context.md`);

  return {
    json: fs.existsSync(jsonFile) ? JSON.parse(fs.readFileSync(jsonFile, "utf8")) : null,
    sharedMarkdown: fs.existsSync(sharedFile) ? fs.readFileSync(sharedFile, "utf8") : "",
    onboardingMarkdown: fs.existsSync(onboardingFile) ? fs.readFileSync(onboardingFile, "utf8") : ""
  };
}

function scoreContext(context) {
  const improvements = [];
  const alignment = alignmentScore(context, improvements);
  const onboarding = onboardingClarityScore(context, improvements);
  const aiSafety = aiSafetyScore(context, improvements);
  const specificity = contextSpecificityScore(context, improvements);
  const drift = driftRiskScore(context, improvements);
  const forbidden = forbiddenAssumptionsScore(context, improvements);
  const tooling = toolingClarityScore(context, improvements);
  const overall = round(
    alignment * 0.16 +
    onboarding * 0.14 +
    aiSafety * 0.16 +
    specificity * 0.14 +
    drift * 0.14 +
    forbidden * 0.12 +
    tooling * 0.14
  );

  return {
    project_id: context.project_id,
    alignment_score: alignment,
    onboarding_clarity_score: onboarding,
    ai_safety_score: aiSafety,
    context_specificity_score: specificity,
    drift_risk_score: drift,
    forbidden_assumptions_score: forbidden,
    tooling_clarity_score: tooling,
    overall_score: overall,
    recommended_improvements: unique(improvements)
  };
}

function alignmentScore(context, improvements) {
  let score = 0;
  if (context.project_goals?.length >= 2) score += 20;
  if (context.tech_stack?.length >= 3) score += 20;
  if (context.coding_standards?.length >= 3) score += 25;
  if (context.shared_canon_nodes?.length >= 3) score += 20;
  if (hasConcreteText(context.current_sprint)) score += 15;

  if ((context.tech_stack || []).length < 3) improvements.push("Clarify the approved stack.");
  if ((context.coding_standards || []).length < 3) improvements.push("Add more shared coding standards.");
  if (!hasConcreteText(context.current_sprint)) improvements.push("Add the current sprint or project phase.");

  return clampRound(score);
}

function onboardingClarityScore(context, improvements) {
  let score = 0;
  if (context.onboarding_notes?.length >= 3) score += 35;
  if (context.shared_setup_profile) score += 20;
  if (context.approved_tools?.length >= 3) score += 15;
  if (context.known_friction?.length) score += 15;
  if (context.generated?.onboardingMarkdown?.includes("Ask For Help When")) score += 15;

  if ((context.onboarding_notes || []).length < 3) improvements.push("Add clearer onboarding notes.");
  if (!context.shared_setup_profile) improvements.push("Add a shared setup profile.");
  if (!(context.known_friction || []).length) improvements.push("Add known friction for onboarding recovery.");

  return clampRound(score);
}

function aiSafetyScore(context, improvements) {
  let score = 0;
  if (context.ai_usage_rules?.length >= 3) score += 40;
  if (context.what_ai_should_not_do?.length >= 3) score += 30;
  if ((context.ai_usage_rules || []).some((rule) => /assumption|preserve|avoid|scope|trade/i.test(rule))) score += 15;
  if ((context.what_ai_should_not_do || []).some((rule) => /do not|unless|avoid/i.test(rule))) score += 15;

  if ((context.ai_usage_rules || []).length < 3) improvements.push("Add explicit AI usage rules.");
  if ((context.what_ai_should_not_do || []).length < 3) improvements.push("Add forbidden AI assumptions.");

  return clampRound(score);
}

function contextSpecificityScore(context, improvements) {
  let score = 0;
  if ((context.project_goals || []).every(hasConcreteText)) score += 25;
  if (hasConcreteText(context.current_sprint)) score += 25;
  if ((context.architecture_notes || []).filter(isSpecificArchitectureNote).length >= 2) score += 25;
  if ((context.coding_standards || []).filter(hasConcreteText).length >= 3) score += 25;

  if ((context.architecture_notes || []).filter(isSpecificArchitectureNote).length < 2) {
    improvements.push("Make architecture notes more specific.");
  }

  return clampRound(score);
}

function driftRiskScore(context, improvements) {
  let score = 100;
  if (!hasConcreteText(context.current_sprint)) score -= 25;
  if ((context.coding_standards || []).length < 3) score -= 20;
  if ((context.ai_usage_rules || []).length < 3) score -= 15;
  if ((context.shared_canon_nodes || []).length < 3) score -= 15;
  if (!context.shared_setup_profile) score -= 15;
  if (!(context.known_friction || []).length) score -= 10;

  if (score < 85) improvements.push("Reduce drift risk by strengthening sprint, standards, setup, and shared Canon references.");
  return clampRound(score);
}

function forbiddenAssumptionsScore(context, improvements) {
  let score = 0;
  const rules = context.what_ai_should_not_do || [];
  if (rules.length >= 3) score += 50;
  if (rules.some((rule) => /do not/i.test(rule))) score += 20;
  if (rules.some((rule) => /unless|until|out of scope|first/i.test(rule))) score += 20;
  if (rules.some((rule) => /validation|architecture|docker|auth|dependencies|frontend/i.test(rule))) score += 10;

  if (rules.length < 3) improvements.push("Add more forbidden assumptions for AI assistants.");
  return clampRound(score);
}

function toolingClarityScore(context, improvements) {
  let score = 0;
  if (context.approved_tools?.length >= 4) score += 25;
  if (context.shared_toolkit_nodes?.length >= 4) score += 25;
  if (context.shared_setup_profile) score += 20;
  if (context.known_friction?.length >= 2) score += 20;
  if (context.shared_hardware_assumptions?.length) score += 10;

  if ((context.approved_tools || []).length < 4) improvements.push("Add approved tools for the team workflow.");
  if ((context.shared_toolkit_nodes || []).length < 4) improvements.push("Add shared toolkit nodes.");
  if ((context.known_friction || []).length < 2) improvements.push("Add setup and friction context.");

  return clampRound(score);
}

function buildReport(scores) {
  const byHigh = [...scores].sort((a, b) => b.overall_score - a.overall_score);
  const byLow = [...scores].sort((a, b) => a.overall_score - b.overall_score);
  const byDrift = [...scores].sort((a, b) => a.drift_risk_score - b.drift_risk_score);

  return {
    generated_at: new Date().toISOString(),
    contexts_scored: scores.length,
    average_score: average(scores.map((score) => score.overall_score)),
    highest_quality_context: byHigh[0] || null,
    lowest_quality_context: byLow[0] || null,
    highest_drift_risk: byDrift[0] || null,
    most_common_missing_context: countValues(scores.flatMap((score) => score.recommended_improvements)).slice(0, 8),
    scores
  };
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Team Context Quality Report",
    "",
    `Contexts scored: ${report.contexts_scored}`,
    `Average score: ${report.average_score}`,
    `Highest quality context: ${report.highest_quality_context?.project_id || "None"} (${report.highest_quality_context?.overall_score ?? "n/a"})`,
    `Lowest quality context: ${report.lowest_quality_context?.project_id || "None"} (${report.lowest_quality_context?.overall_score ?? "n/a"})`,
    `Highest drift risk: ${report.highest_drift_risk?.project_id || "None"} (drift safety score ${report.highest_drift_risk?.drift_risk_score ?? "n/a"})`,
    "",
    "## Most Common Missing Context",
    "",
    ...formatCounts(report.most_common_missing_context),
    "",
    "## Scores",
    ""
  ];

  for (const score of report.scores) {
    lines.push(
      `### ${score.project_id}`,
      "",
      `Overall: ${score.overall_score}`,
      `Alignment: ${score.alignment_score}`,
      `Onboarding clarity: ${score.onboarding_clarity_score}`,
      `AI safety: ${score.ai_safety_score}`,
      `Context specificity: ${score.context_specificity_score}`,
      `Drift risk score: ${score.drift_risk_score}`,
      `Forbidden assumptions: ${score.forbidden_assumptions_score}`,
      `Tooling clarity: ${score.tooling_clarity_score}`,
      "",
      "Recommended improvements:",
      ...formatList(score.recommended_improvements),
      ""
    );
  }

  return `${lines.join("\n")}\n`;
}

function isSpecificArchitectureNote(value) {
  return hasConcreteText(value) && !/^(use good architecture|follow best practices|keep it simple)$/i.test(value.trim());
}

function hasConcreteText(value) {
  return typeof value === "string" && value.trim().length >= 12;
}

function average(values) {
  if (!values.length) return 0;
  return round(values.reduce((total, value) => total + value, 0) / values.length);
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function clampRound(value) {
  return round(Math.max(0, Math.min(100, value)));
}

function round(value) {
  return Number(value.toFixed(2));
}

main();
