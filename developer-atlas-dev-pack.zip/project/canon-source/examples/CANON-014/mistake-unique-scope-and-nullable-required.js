const { validate } = require("./validation-simulator");

module.exports = function runMistakeUniqueScopeAndNullableRequired() {
  const members = [
    { id: 1, project_id: 10, email: "ada@example.com" },
    { id: 2, project_id: 20, email: "ada@example.com" }
  ];

  const globalUnique = validate(
    { email: "ada@example.com" },
    { email: ["required", { unique: true, column: "email" }] },
    { records: members }
  );

  const scopedUnique = validate(
    { email: "ada@example.com" },
    { email: ["required", { unique: true, column: "email", scope: { column: "project_id", value: 30 } }] },
    { records: members }
  );

  const nullableNickname = validate(
    { nickname: "" },
    { nickname: ["nullable"] }
  );

  const requiredNickname = validate(
    { nickname: "" },
    { nickname: ["required"] }
  );

  if (globalUnique.passes) {
    throw new Error("Global unique rule should reject an email used in another project.");
  }

  if (!scopedUnique.passes) {
    throw new Error("Scoped unique rule should allow the same email in a different project.");
  }

  if (!nullableNickname.passes || requiredNickname.passes) {
    throw new Error("Nullable and required rules should describe different contracts.");
  }

  return { globalUnique, scopedUnique, nullableNickname, requiredNickname };
};
