const {
  fs,
  path,
  rootDir,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionDashboardPath,
  startHerePath,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedMissionDashboardPath,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange
} = require("./shared-validator-utils");

function validateMaintainerFileGrowth(warnings) {
  const watchlist = [
    {
      relativePath: "tools/generate-mission-experience-report.js",
      threshold: 2500,
      message: "Maintainer warning: tools/generate-mission-experience-report.js is becoming large. Consider splitting template sections before adding many more missions."
    },
    {
      relativePath: "tools/templates/mission-templates.js",
      threshold: 2000,
      message: "Maintainer warning: tools/templates/mission-templates.js is becoming large. Consider splitting mission templates before adding many more missions."
    },
    {
      relativePath: "tools/templates/report-templates.js",
      threshold: 2000,
      message: "Maintainer warning: tools/templates/report-templates.js is becoming large. Consider splitting report templates by concern before adding many more reports."
    },
    {
      relativePath: "tools/templates/dashboard-template.js",
      threshold: 800,
      message: "Maintainer warning: tools/templates/dashboard-template.js is becoming large. Consider splitting dashboard sections before adding more dashboard content."
    },
    {
      relativePath: "tools/templates/start-here-template.js",
      threshold: 800,
      message: "Maintainer warning: tools/templates/start-here-template.js is becoming large. Consider splitting START_HERE sections before adding more package guidance."
    },
    {
      relativePath: "tools/validate-mission.js",
      threshold: 500,
      message: "Maintainer warning: tools/validate-mission.js is becoming large. Keep it as an orchestrator and move concern-specific checks into tools/validators/."
    },
    {
      relativePath: "tools/validators/mission-content-validator.js",
      threshold: 1200,
      message: "Maintainer warning: tools/validators/mission-content-validator.js is becoming large. Consider splitting mission content checks by mission before adding Mission 3."
    },
    {
      relativePath: "tools/validators/dashboard-accessibility-validator.js",
      threshold: 800,
      message: "Maintainer warning: tools/validators/dashboard-accessibility-validator.js is becoming large. Consider splitting dashboard and accessibility checks before adding many more dashboard rules."
    },
    {
      relativePath: "tools/validators/report-validator.js",
      threshold: 1200,
      message: "Maintainer warning: tools/validators/report-validator.js is becoming large. Consider splitting report checks by report type before adding many more owner reports."
    },
    {
      relativePath: "tools/validators/maintainer-docs-validator.js",
      threshold: 800,
      message: "Maintainer warning: tools/validators/maintainer-docs-validator.js is becoming large. Consider splitting maintainer docs checks before adding many more governance files."
    },
    {
      relativePath: "tools/validators/language-safety-validator.js",
      threshold: 800,
      message: "Maintainer warning: tools/validators/language-safety-validator.js is becoming large. Consider splitting language scans by audience before adding many more terms."
    },
    {
      relativePath: "tools/validators/package-structure-validator.js",
      threshold: 800,
      message: "Maintainer warning: tools/validators/package-structure-validator.js is becoming large. Consider splitting package and scope checks before adding many more packaged files."
    },
    {
      relativePath: "tools/validators/file-growth-validator.js",
      threshold: 500,
      message: "Maintainer warning: tools/validators/file-growth-validator.js is becoming large. Consider moving watchlist data out of code if it grows further."
    },
    {
      relativePath: "tools/package-mvp-demo.js",
      threshold: 800,
      message: "Maintainer warning: tools/package-mvp-demo.js is becoming large. Consider splitting package manifest helpers before adding many more package files."
    }
  ];

  for (const item of watchlist) {
    const filePath = path.join(rootDir, item.relativePath);
    if (!fs.existsSync(filePath)) continue;
    const lineCount = fs.readFileSync(filePath, "utf8").split(/\r?\n/).length;
    if (lineCount > item.threshold) {
      warnings.push(`${item.message} Current line count: ${lineCount}; warning threshold: ${item.threshold}.`);
    }
  }
}

module.exports = {
  validateMaintainerFileGrowth
};
