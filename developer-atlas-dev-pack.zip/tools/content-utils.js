const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const contentDir = path.join(rootDir, "content");

function findMarkdownFiles(dir = contentDir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  return entries.flatMap((entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) return findMarkdownFiles(fullPath);
    return entry.isFile() && entry.name.endsWith(".md") ? [fullPath] : [];
  });
}

function parseValue(value) {
  const trimmed = value.trim();
  if (trimmed === "") return "";
  if (trimmed === "[]") return [];
  if (
    (trimmed.startsWith("[") && trimmed.endsWith("]")) ||
    (trimmed.startsWith("{") && trimmed.endsWith("}"))
  ) {
    try {
      return JSON.parse(trimmed);
    } catch {
      // Keep compatibility with the lightweight front matter parser below.
    }
  }
  if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
    const inner = trimmed.slice(1, -1).trim();
    return inner ? inner.split(",").map((item) => parseValue(item)) : [];
  }
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1);
  }
  if (/^-?\d+$/.test(trimmed)) return Number(trimmed);
  return trimmed;
}

function parseFrontMatter(markdown) {
  const normalized = markdown.replace(/^\uFEFF/, "");
  const match = normalized.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  if (!match) throw new Error("Missing YAML front matter block");

  const data = {};
  const lines = match[1].split(/\r?\n/);
  let currentKey = null;

  for (const line of lines) {
    if (!line.trim()) continue;

    const arrayItem = line.match(/^\s+-\s*(.*)$/);
    if (arrayItem) {
      if (!currentKey) throw new Error(`Array item has no key: ${line}`);
      if (!Array.isArray(data[currentKey])) data[currentKey] = [];
      data[currentKey].push(parseValue(arrayItem[1]));
      continue;
    }

    const pair = line.match(/^([A-Za-z0-9_-]+):(?:\s*(.*))?$/);
    if (!pair) throw new Error(`Unsupported front matter line: ${line}`);

    currentKey = pair[1];
    const rawValue = pair[2] ?? "";
    data[currentKey] = rawValue.trim() === "" ? [] : parseValue(rawValue);
  }

  return data;
}

function readEntries() {
  return findMarkdownFiles()
    .sort()
    .map((file) => {
      const markdown = fs.readFileSync(file, "utf8");
      return {
        file,
        relativePath: path.relative(rootDir, file),
        markdown,
        frontMatter: parseFrontMatter(markdown)
      };
    });
}

function compareEntries(a, b) {
  const technology = a.frontMatter.technology.localeCompare(b.frontMatter.technology);
  if (technology !== 0) return technology;
  const category = a.frontMatter.category.localeCompare(b.frontMatter.category);
  if (category !== 0) return category;
  return a.frontMatter.title.localeCompare(b.frontMatter.title);
}

function escapeTableCell(value) {
  return String(value ?? "")
    .replace(/\r?\n/g, " ")
    .replace(/\|/g, "\\|")
    .trim();
}

function slugifyHeading(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}

module.exports = {
  rootDir,
  contentDir,
  readEntries,
  compareEntries,
  escapeTableCell,
  slugifyHeading
};
