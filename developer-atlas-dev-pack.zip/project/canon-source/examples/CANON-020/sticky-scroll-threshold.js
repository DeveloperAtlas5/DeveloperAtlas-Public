const assert = require("node:assert/strict");
const { stickyPosition } = require("./layout-simulator");

module.exports = function runStickyScrollThresholdExample() {
  const beforeThreshold = stickyPosition({
    normalTop: 120,
    scrollTop: 40,
    thresholdTop: 0,
    scrollContainerHeight: 400,
    contentHeight: 900
  });

  const afterThreshold = stickyPosition({
    normalTop: 120,
    scrollTop: 140,
    thresholdTop: 0,
    scrollContainerHeight: 400,
    contentHeight: 900
  });

  const noThreshold = stickyPosition({
    normalTop: 120,
    scrollTop: 140,
    thresholdTop: Number.NaN,
    scrollContainerHeight: 400,
    contentHeight: 900
  });

  assert.equal(beforeThreshold.stuck, false);
  assert.equal(beforeThreshold.visualTop, 80);
  assert.equal(afterThreshold.stuck, true);
  assert.equal(afterThreshold.visualTop, 0);
  assert.equal(noThreshold.stuck, false);
  assert.equal(afterThreshold.requiresScrollContainer, true);
  assert.equal(afterThreshold.requiresThreshold, true);
};
