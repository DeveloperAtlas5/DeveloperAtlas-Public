const RELATIONSHIP_TYPES = [
  "alternative",
  "uses",
  "used_in",
  "requires",
  "required_by",
  "extends",
  "implements",
  "parent",
  "child",
  "next",
  "previous",
  "compares_to",
  "similar_to",
  "solves",
  "causes",
  "fixes",
  "optimizes",
  "teaches",
  "part_of",
  "workflow_step",
  "recipe_step",
  "project_step",
  "security_note",
  "performance_note",
  "deprecated_by",
  "replaced_by",
  "introduced_in",
  "removed_in"
];

const STRUCTURED_NODE_TYPES = [
  "decision_guide",
  "comparison",
  "problem",
  "recipe",
  "project",
  "learning_path"
];

const RECOMMENDATION_FIELDS = [
  "recommended_for",
  "avoid_for",
  "best_alternative",
  "tradeoffs",
  "industry_usage",
  "beginner_score",
  "professional_score",
  "interview_score",
  "production_score",
  "learning_priority"
];

function hasValue(value) {
  return value !== undefined && value !== null && value !== "" && (!Array.isArray(value) || value.length > 0);
}

function buildGraph(entries) {
  const nodeIds = new Set(entries.map((entry) => entry.frontMatter.id));
  const nodes = entries.map((entry) => {
    const data = entry.frontMatter;
    return {
      id: data.id,
      slug: data.slug,
      title: data.title,
      technology: data.technology,
      category: data.category,
      type: data.type,
      difficulty: data.difficulty,
      importance: data.importance,
      frequency: data.frequency,
      confidence: data.confidence ?? null,
      evidence_level: data.evidence_level ?? null,
      source: entry.relativePath
    };
  });

  const edges = [];
  const externalReferences = [];
  const addEdge = (source, target, type, extra = {}) => {
    if (!source || !target || !type) return;
    if (!nodeIds.has(target)) {
      externalReferences.push({ source, target, type, reason: extra.reason ?? null });
      return;
    }
    edges.push({
      source,
      target,
      type,
      reason: extra.reason ?? null,
      priority: extra.priority ?? null,
      weight: extra.weight ?? null,
      confidence: extra.confidence ?? null,
      target_exists: true
    });
  };

  for (const entry of entries) {
    const data = entry.frontMatter;
    const source = data.id;

    for (const target of data.related || []) addEdge(source, target, "similar_to", { reason: "legacy related link" });
    for (const target of data.alternatives || []) addEdge(source, target, "alternative", { reason: "listed alternative" });
    for (const target of data.recipes || []) addEdge(source, target, "used_in", { reason: "recipe reference" });
    for (const target of data.projects || []) addEdge(source, target, "used_in", { reason: "project reference" });
    for (const target of data.required_nodes || []) addEdge(source, target, "requires", { reason: "required knowledge node" });
    for (const target of data.related_nodes || []) addEdge(source, target, "similar_to", { reason: "structured related node" });
    for (const target of data.related_recipes || []) addEdge(source, target, "used_in", { reason: "related recipe" });
    for (const target of data.related_projects || []) addEdge(source, target, "used_in", { reason: "related project" });
    for (const target of data.required_projects || []) addEdge(source, target, "requires", { reason: "required project" });
    for (const target of data.prerequisites || []) addEdge(source, target, "requires", { reason: "learning path prerequisite" });
    for (const target of data.recommended_order || []) addEdge(source, target, "teaches", { reason: "learning path step" });

    for (const relationship of data.relationships || []) {
      addEdge(source, relationship.target, relationship.type, relationship);
    }
  }

  const relationshipCounts = countBy(edges, "type");
  const missingEdges = edges.filter((edge) => !edge.target_exists);

  return {
    nodes,
    edges,
    relationshipTypes: RELATIONSHIP_TYPES,
    structuredNodeTypes: STRUCTURED_NODE_TYPES,
    statistics: {
      node_count: nodes.length,
      edge_count: edges.length,
      relationship_type_count: RELATIONSHIP_TYPES.length,
      used_relationship_types: relationshipCounts,
      missing_edge_count: missingEdges.length,
      external_reference_count: externalReferences.length,
      structured_node_counts: countStructuredNodes(entries)
    },
    missingEdges,
    externalReferences
  };
}

function recommendationCompleteness(data) {
  const missing = RECOMMENDATION_FIELDS.filter((field) => !hasValue(data[field]));
  return {
    missing,
    score: Math.round(((RECOMMENDATION_FIELDS.length - missing.length) / RECOMMENDATION_FIELDS.length) * 100)
  };
}

function countBy(items, field) {
  const counts = {};
  for (const item of items) counts[item[field]] = (counts[item[field]] || 0) + 1;
  return counts;
}

function countStructuredNodes(entries) {
  const counts = {};
  for (const type of STRUCTURED_NODE_TYPES) counts[type] = 0;
  for (const entry of entries) {
    const type = entry.frontMatter.type;
    if (type in counts) counts[type] += 1;
  }
  return counts;
}

module.exports = {
  RELATIONSHIP_TYPES,
  STRUCTURED_NODE_TYPES,
  RECOMMENDATION_FIELDS,
  buildGraph,
  recommendationCompleteness,
  hasValue
};
