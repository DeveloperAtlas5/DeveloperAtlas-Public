const assert = require("node:assert/strict");
const { innerJoinUsersOrders } = require("./data");

module.exports = function runInnerJoinUsersWithOrdersExample() {
  const rows = innerJoinUsersOrders();
  const emails = [...new Set(rows.map((row) => row.user.email))];

  assert.equal(rows.length, 3);
  assert.deepEqual(emails, ["ada@example.com", "grace@example.com"]);
  assert.equal(emails.includes("linus@example.com"), false);
};
