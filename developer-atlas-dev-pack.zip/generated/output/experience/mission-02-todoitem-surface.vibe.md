# Mission 2 - AI-Assisted TodoItem Extraction

## Today's AI-assisted Mission

Use AI to extract one todo row into `TodoItem.vue` while keeping the todo app behavior the same.

## Where this work happens

Work in the same Vue todo project you used for Mission 1.

Use this mission file as the guide.

Do not edit the Atlas package files.

## AI mission boundary

AI should complete Mission 2, not redesign the project.

Edit my Vue todo project, not the Atlas package.

Goal: extract `TodoItem.vue`.

Work in the same Vue todo project from Mission 1.

Create `src/components/TodoItem.vue`.

Keep todo list state and localStorage in `App.vue`.

Use props down and events up.

Do not create extra components.

Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.

Keep the smallest useful change.

Do not accept "cleaner", "production-ready", "more reusable", or "proper architecture" changes if they add files or architecture outside this mission.

For Mission 2, "cleaner architecture" still means only one extraction: `TodoItem.vue`.

If the answer changes too much, reject it and ask for a smaller patch.

## Goal

Make the app easier to understand without changing what it does. Keep todo state in `App.vue`, pass one todo into the child as a prop, and emit actions back to the parent.

## Quick Start With AI

1. Ask AI to find the markup for one todo row.
2. Ask AI to create `src/components/TodoItem.vue` in your Vue todo project.
3. Ask AI to keep todo state in `App.vue`.
4. Ask AI to pass the todo as a prop.
5. Ask AI to emit toggle/remove events back to the parent.
6. Reject any new architecture.
7. Test that the app behaves the same.

## Tiny file map

- `src/App.vue`: keeps the todo list state, localStorage behavior, and parent actions.
- `src/components/TodoItem.vue`: displays one todo and emits user actions.

## Tiny parent-child diagram

```txt
App.vue owns todos and persistence.
TodoItem.vue displays one todo.
AI should pass data down with props.
AI should send actions up with emits.
```

Props go down. Events go up.

## Copy/paste prompt

```txt
You are helping me with Developer Atlas Mission 2.

Edit my Vue todo project, not the Atlas package.

Goal: extract one `TodoItem.vue` component.

Create `src/components/TodoItem.vue`.

Keep todo list state and localStorage in `src/App.vue`.

Use props to pass one todo down.

Use events to ask the parent to toggle or remove a todo.

Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, extra components, or a new architecture.

Format your answer with clear headings, file names, small code blocks, spacing, and verification steps.

Make the answer easy for me, another human, or a future AI session to understand later.

If I ask for cleaner, production-ready, reusable, or faster changes that go beyond this mission, park those ideas and keep the smallest current-mission patch.

After the change, explain what changed and how I can verify it.
```

## What to ask AI

Copy and paste this prompt:

```txt
I am building a Vue 3 todo app. Edit my Vue todo project, not the Atlas package. Extract the repeated markup for one todo row into `src/components/TodoItem.vue`. Tell AI to create `src/components/TodoItem.vue` in your Vue todo project. Create only TodoItem.vue as the new component. Keep todo state in App.vue. Keep localStorage in App.vue. Pass the todo into the child as a prop and emit events back to the parent for actions like toggle or remove. Do not create extra components. Do not create a store or composable for later. Do not reorganize folders. Do not rename unrelated variables. Do not change styling unless needed for the extraction. Do not add Pinia, routing, backend, auth, database, deployment, or a new architecture. Explain each changed file.
```

## What AI may change

- `src/App.vue`.
- `src/components/TodoItem.vue`.
- Only the parent-child connection needed for this mission.

## What AI must not change

- Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, extra components, or a new architecture.
- Do not move todo list state or localStorage out of `src/App.vue`.
- Do not rewrite the whole app.
- Do not change unrelated styling.

## Before you accept the answer

- Confirm `src/components/TodoItem.vue` was created.
- Confirm todo list state and localStorage stayed in `src/App.vue`.
- Confirm props go down and events go up.
- Confirm AI explains what changed before I accept the answer.

## Ask AI to explain it back

Explain what changed before I accept the answer. Use plain language and tell me how props down and events up connect `App.vue` and `TodoItem.vue`.

## What to accept

Accept changes that:

- Create only `src/components/TodoItem.vue` as the new component.
- Update `App.vue` to use `TodoItem`.
- Keep todo state in `App.vue`.
- Keep localStorage in `App.vue`.
- Pass one todo as a prop.
- Emit toggle/remove events from child to parent.
- Preserve existing behavior.
- Explain why each changed file was touched.

## What to reject

Reject changes that:

- Add Pinia.
- Add routing.
- Add backend.
- Add auth.
- Add database.
- Add deployment.
- Create a new architecture.
- Create extra components.
- Create a new folder structure.
- Move state into `TodoItem.vue`.
- Move state out of `App.vue`.
- Move persistence out of `App.vue`.
- Move all state into a new store.
- Create a store.
- Create a composable `for later`.
- Change the localStorage architecture.
- Add new features.
- Rewrite the whole app.
- Change styling as a side quest.
- Change unrelated files.
- Remove existing features.
- Mutate props directly in the child.
- Rename many variables unnecessarily.

## Recovery prompt

```txt
Please make a smaller patch. Only change the files needed for Developer Atlas Mission 2. Undo the extra architecture and return to the smallest solution for this mission.
```

## Files likely to change

- `src/App.vue`
- `src/components/TodoItem.vue`

## Files that should not change today

- Router files.
- Backend files.
- `package.json`.
- Deployment files.
- Auth files.
- Unrelated styling files.
- Global store files unless they already exist and are explicitly part of the current project.

## Test the result

- Todos render.
- Complete or toggle works.
- Remove works if supported.
- Filters still work if supported.
- `localStorage` still works.
- Browser console has no errors.

## Completion checklist

- [ ] `src/components/TodoItem.vue` exists.
- [ ] `App.vue` imports and uses `TodoItem`.
- [ ] Todo state stayed in `App.vue`.
- [ ] The child receives a todo as a prop.
- [ ] The child emits toggle or remove actions back to the parent.
- [ ] Existing todo behavior still works.
- [ ] `localStorage` persistence still works if Mission 1 added it.
- [ ] AI did not add Pinia, routing, backend, auth, database, deployment, or a new architecture.

## If AI breaks it

Use this recovery prompt first:

```txt
Do not rewrite the app. Compare the version before and after the TodoItem extraction. Identify the smallest change that broke the todo behavior.
```

If the previous behavior is still broken, use this prompt:

```txt
Show me the smallest diff that keeps TodoItem.vue but restores the previous behavior. Do not reorganize folders, rename unrelated variables, or add new components.
```

Then use this cleanup prompt if needed:

```txt
Undo any unrelated changes. Keep only the TodoItem extraction and the parent-child communication needed for this mission.
```

Helpful checks:

- Check for prop name mismatch, emit name mismatch, direct prop mutation, moved state, or moved localStorage behavior.
- Confirm `TodoItem.vue` receives the todo as a prop.
- Confirm `TodoItem.vue` emits events instead of changing the prop directly.
- Confirm `App.vue` listens for those events.
- Confirm the parent handler still updates the same todo state used by filtering and `localStorage`.

## Explain it back

After the code works, ask:

```txt
Explain how props and emits connect App.vue and TodoItem.vue in this code. Use beginner-friendly language and give me three small questions to check if I understood.
```

## Skip today

- Pinia.
- Routing.
- Backend.
- Auth/login.
- Database.
- Deployment.
- Full app rewrite.
- Styling overhaul.
- Moving all state into a global store.
- Adding new features.

## Next mission preview

Next, you can learn props vs emits more deeply by making the parent and child communicate cleanly.

## After the mission

Before you asked AI, how confident did you feel?

1 2 3 4 5

After testing the AI-assisted extraction, how confident do you feel now?

1 2 3 4 5

Did the AI change stay inside the mission scope?

- Yes
- Mostly
- It changed too much

Did you reject or undo any unnecessary AI changes?

- Yes
- No
- Not needed

Did recovery help?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.
