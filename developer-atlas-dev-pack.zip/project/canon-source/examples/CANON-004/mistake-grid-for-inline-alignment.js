const assert = require("node:assert/strict");
const { hasDeclaration } = require("./css-rule-utils");

const overbuiltCss = `
.icon-button {
  display: grid;
  grid-template-columns: auto auto;
}
`;

const betterCss = `
.icon-button {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}
`;

function run() {
  assert.equal(hasDeclaration(overbuiltCss, ".icon-button", "display: grid"), true);
  assert.equal(hasDeclaration(betterCss, ".icon-button", "display: inline-flex"), true);
  assert.equal(hasDeclaration(betterCss, ".icon-button", "align-items: center"), true);

  return { overbuiltCss, betterCss };
}

module.exports = run;

if (require.main === module) run();
