const assert = require("assert");

module.exports = function vModelUpdatesParentState() {
  const parentState = {
    email: "ada@example.com"
  };

  function BaseInput(props, emit) {
    emit("update:modelValue", "grace@example.com");
    return props.modelValue;
  }

  function emit(eventName, value) {
    if (eventName === "update:modelValue") {
      parentState.email = value;
    }
  }

  const displayedValue = BaseInput({ modelValue: parentState.email }, emit);

  assert.strictEqual(displayedValue, "ada@example.com");
  assert.strictEqual(parentState.email, "grace@example.com");
};
