# CSS display: block vs inline vs inline-block

## Status Metadata

- Canon ID: CANON-021
- Node ID: canon.css.layout.display-block-vs-inline-vs-inline-block
- Status: candidate
- Score: 55
- Version: 2026.1
- Batch: 05
- Level: rookie/junior
- Source family: CSS
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

This candidate explains when to choose display: block and when to choose display: inline / inline-block. It is intentionally draft-level and exists to broaden Atlas coverage before a future Gold hardening sprint.

## What Problem This Solves

Developers often use display values by trial and error when they need predictable flow, sizing, and line behavior.

## Mental Model

Block elements take a full row, inline elements sit inside text flow, and inline-block keeps inline placement while allowing box sizing.

## Beginner Explanation

Start by asking what job the code or concept is doing. If it matches display: block, keep the decision simple; if the shape points toward display: inline / inline-block, choose the alternative intentionally instead of guessing.

## Professional Explanation

In production, this decision affects readability, reviewability, and future changes. The best choice should make intent obvious, reduce hidden coupling, and match the conventions of the surrounding stack.

## Syntax

```text
display: block;
display: inline;
display: inline-block;
```

## Decision Guide

1. Identify the immediate problem being solved.
2. Choose display: block when it matches the primary behavior.
3. Choose display: inline / inline-block when the trade-off is clearer or the primary option would hide intent.
4. If neither option fits, step back and choose a simpler architecture or prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| display: block | The main use case for this decision | Can be misused when the problem is actually different |
| display: inline / inline-block | The most common alternative path | Can add confusion if chosen only by habit |

## When To Use The Primary Option

- Use it when the goal matches the primary behavior directly.
- Use it when it keeps the surrounding code easier to review.
- Use it when beginners can explain the result without hidden rules.

## When To Use The Alternative

- Use it when the primary option would force awkward workarounds.
- Use it when the alternative better communicates intent to the next developer.
- Use it when the project convention already points there.

## When Not To Use This Decision

- Do not use this decision as a substitute for understanding the underlying system.
- Do not choose either side just because an AI assistant suggested it without context.
- Do not harden this candidate until official sources, examples, and verification are added.

## Alternatives

- Use an adjacent Canon node when the real issue is a prerequisite concept.
- Use project conventions when both options are technically acceptable.

## Production Examples

### Example 1

```text
Draft example: apply this decision in a small production-like feature before hardening.
```

### Example 2

```text
Draft example: show the most common misuse and the clearer alternative.
```

## Common Mistakes

- Choosing by habit instead of intent.
- Copying an answer without checking project constraints.
- Treating this candidate as Gold before evidence and verification are complete.

## Debugging Checklist

- Confirm the current behavior matches the intended decision.
- Check whether a simpler related node explains the confusion first.
- Look for hidden assumptions in generated or copied code.

## Mechanical Verification

Runnable examples should live in `canon/examples/CANON-021/` during a future hardening sprint. This candidate intentionally has no runnable examples yet.

## Performance Notes

Performance guidance is not finalized for this candidate. Future hardening should separate real performance concerns from premature optimization.

## AI Coding Guidance

- Ask for the user's goal before choosing between display: block and display: inline / inline-block.
- Prefer the option that makes the code easiest to explain and maintain.
- Mention trade-offs instead of presenting one side as universally better.

## Teaching Notes

Teach the mental model first, then show the decision table, then practice with one small realistic task. Keep the first exercise narrow enough that the learner can finish it without context switching.

## Interview Questions

1. What problem does display: block solve better than the alternative?
2. What mistake would make display: inline / inline-block the better choice?

## Exercises

### Beginner

Explain the difference in one paragraph and identify one safe beginner use case.

### Intermediate

Refactor a small example where the wrong choice hides intent.

### Advanced

Write a short review note explaining the trade-off to another developer.

## Related Atlas Nodes

- `CANON-004`
- `CANON-020`
- `css.property.display`

## Evidence And Sources

- Official source URL to be added during Gold hardening.

## Proof Of Superiority Summary

Atlas should improve on normal documentation by turning reference facts into a practical decision, but this candidate still needs evidence, verification, and editorial review.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 12 |
| beginner_teaching | 15 | 8 |
| professional_depth | 15 | 7 |
| decision_guidance | 15 | 9 |
| production_examples | 10 | 5 |
| ai_readiness | 10 | 5 |
| evidence | 5 | 2 |
| relationships | 5 | 3 |
| exercises | 3 | 2 |
| readability | 2 | 2 |
| Total | 100 | 55 |
