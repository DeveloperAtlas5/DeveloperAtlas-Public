const {
  fs,
  missionDashboardPath,
  packagedDemoDir,
  packagedMissionDashboardPath,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage
} = require("./shared-validator-utils");

function validateMissionDashboard(errors, warnings) {
  validateMissionDashboardFile(
    missionDashboardPath,
    "output/experience/mission-dashboard.html",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateMissionDashboardFile(
    packagedMissionDashboardPath,
    "output/share/developer-atlas-mvp-demo/mission-dashboard.html",
    errors,
    warnings,
    true
  );
}

function validateMissionDashboardFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing mission dashboard`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/Developer Atlas Public Alpha/i, "dashboard title"],
    [/Start here/i, "start here section"],
    [/This dashboard is the main entry point[\s\S]*You do not need to browse the folders/i, "main entry point orientation"],
    [/Recommended first step[\s\S]*next useful action[\s\S]*Start Mission 1[\s\S]*Read here\. Code in your Vue todo project\.[\s\S]*First time\?[\s\S]*first-time-quick-start\.md[\s\S]*Mission 1 remains the primary tester path/i, "recommended first step hero"],
    [/Need a different path\?[\s\S]*Choose a different goal only if the recommended first step is not the path you need/i, "secondary goal chooser"],
    [/Start[\s\S]*Continue[\s\S]*Use AI[\s\S]*I'm stuck[\s\S]*Review/i, "simplified goal labels"],
    [/aria-label="Start - begin with Mission 1"/i, "accessible Start label"],
    [/aria-label="Continue - go to Mission 2 or Mission 3"/i, "accessible Continue label"],
    [/aria-label="Use AI - use scoped AI guidance"/i, "accessible Use AI label"],
    [/aria-label="I'm stuck - open recovery and help"/i, "accessible stuck label"],
    [/aria-label="Review - inspect feedback and QA files"/i, "accessible Review label"],
    [/Progressive visibility: show only what helps the user's current goal/i, "progressive visibility principle"],
    [/Fastest path:[\s\S]*Choose your goal[\s\S]*open the mission link shown there[\s\S]*use help only if needed[\s\S]*answer feedback at the end/i, "fastest path guidance"],
    [/Starting path[\s\S]*Start with Mission 1[\s\S]*Use help only if you get stuck[\s\S]*Answer feedback after testing[\s\S]*Open Mission 1[\s\S]*Optional terminal help[\s\S]*Optional Vue concept cards[\s\S]*Optional beginner orientation/i, "short starting path panel"],
    [/Continuing path[\s\S]*Mission 1 -> Mission 2 -> Mission 3[\s\S]*Mission 1 remains the primary tester path[\s\S]*Mission 2: Open after Mission 1[\s\S]*Mission 3: Open after Mission 2[\s\S]*Open the next mission only after finishing the previous one[\s\S]*Open Mission 2[\s\S]*Open Mission 3/i, "compact continuing path panel"],
    [/AI-assisted path[\s\S]*Use this path when AI helps you write code[\s\S]*Give AI one mission at a time[\s\S]*Reject architecture expansion[\s\S]*Ask AI to explain what changed before you accept it[\s\S]*Open AI Mission 1[\s\S]*Open AI Mission 2[\s\S]*Open AI Mission 3[\s\S]*Optional: AI prompt pack[\s\S]*Accept small mission changes[\s\S]*Reject new architecture/i, "simplified AI-assisted path panel"],
    [/I am stuck[\s\S]*Pick the blocker first[\s\S]*Terminal problem ->[\s\S]*terminal guide[\s\S]*Vue concept problem ->[\s\S]*concept cards[\s\S]*Not sure where to edit ->[\s\S]*placement section[\s\S]*Too much to read ->[\s\S]*read-aloud or Mission 1 only/i, "blocker-based stuck path panel"],
    [/Reviewer path[\s\S]*This path is for reviewers, mentors, or the project owner[\s\S]*tester feedback template[\s\S]*final QA report[\s\S]*alpha focus lock[\s\S]*human-AI readability audit[\s\S]*AI guardrail evaluation[\s\S]*AI guardrail red-team pack[\s\S]*AI red-team results template[\s\S]*Accessibility principle/i, "reviewer path panel"],
    [/What you can ignore/i, "ignore section"],
    [/You do not need to browse the folders/i, "do-not-browse-folders guidance"],
    [/Optional reference[\s\S]*reference\/canon\/hardened\/[\s\S]*hardened Canon notes[\s\S]*not required before starting Mission 1/i, "optional hardened Canon note"],
    [/START_HERE\.md/i, "START_HERE pointer"],
    [/first-time-quick-start\.md/i, "first-time quick start pointer"],
    [/mission\/today-mission-surface\.md/i, "main mission pointer"],
    [/mission\/today-mission-surface\.vibe\.md/i, "AI-assisted builder pointer"],
    [/mission\/mission-02-todoitem-surface\.md/i, "Mission 2 pointer"],
    [/mission\/mission-02-todoitem-surface\.vibe\.md/i, "Mission 2 AI-assisted pointer"],
    [/mission\/mission-03-todostats-surface\.md/i, "Mission 3 pointer"],
    [/mission\/mission-03-todostats-surface\.vibe\.md/i, "Mission 3 AI-assisted pointer"],
    [/ai\/ai-prompt-pack\.md/i, "optional AI prompt pack pointer"],
    [/help\/beginner-orientation\.md/i, "beginner orientation pointer"],
    [/help\/vue-concept-cards\.md/i, "Vue concept cards pointer"],
    [/help\/terminal-confidence-guide\.md/i, "terminal confidence pointer"],
    [/mission\/mission-feedback-template\.md/i, "feedback template pointer"],
    [/reviewer\/alpha-package-final-qa\.md/i, "final QA pointer"],
    [/reviewer\/alpha-focus-lock\.md/i, "focus lock pointer"],
    [/reviewer\/human-ai-readability-audit\.md/i, "human-AI readability audit pointer"],
    [/Normal testers do not need to read everything/i, "normal testers do not need everything"],
    [/Package manifest[\s\S]*Feedback owner reports[\s\S]*Readiness reports[\s\S]*Focus lock[\s\S]*Source\/build scripts[\s\S]*Technical internals/i, "ignore list"],
    [/<header[\s\S]*<main[\s\S]*<section[\s\S]*<nav[\s\S]*<footer/i, "semantic dashboard landmarks"],
    [/aria-label="Dashboard sections"/i, "dashboard navigation label"],
    [/role="group" aria-label="Choose a dashboard goal"/i, "goal button group"],
    [/aria-controls="panel-starting"[\s\S]*aria-controls="panel-continuing"[\s\S]*aria-controls="panel-ai"[\s\S]*aria-controls="panel-stuck"[\s\S]*aria-controls="panel-reviewing"/i, "goal button panel controls"],
    [/aria-pressed="true"[\s\S]*aria-label="Start - begin with Mission 1"/i, "Start selected by default"],
    [/id="panel-starting"[\s\S]*data-goal-panel="starting"/i, "starting panel present"],
    [/id="panel-continuing"[\s\S]*data-goal-panel="continuing"[\s\S]*hidden/i, "continuing panel hidden by default"],
    [/id="panel-ai"[\s\S]*data-goal-panel="ai"[\s\S]*hidden/i, "AI panel hidden by default"],
    [/id="panel-stuck"[\s\S]*data-goal-panel="stuck"[\s\S]*hidden/i, "stuck panel hidden by default"],
    [/id="panel-reviewing"[\s\S]*data-goal-panel="reviewing"[\s\S]*hidden/i, "reviewer panel hidden by default"],
    [/\[data-goal-panel\]\[hidden\][\s\S]*display:\s*none/i, "hidden panel CSS"],
    [/const goalButtons = Array\.from\(document\.querySelectorAll\("\[data-goal\]"\)\)/i, "goal buttons query"],
    [/const goalPanels = Array\.from\(document\.querySelectorAll\("\[data-goal-panel\]"\)\)/i, "goal panels query"],
    [/function showGoal\(goal\)[\s\S]*panel\.hidden = !active[\s\S]*button\.setAttribute\("aria-pressed", String\(button\.dataset\.goal === goal\)\)/i, "goal panel toggle behavior"],
    [/goalButtons\.forEach[\s\S]*addEventListener\("click"[\s\S]*showGoal\(button\.dataset\.goal\)/i, "goal click behavior"],
    [/showGoal\("starting"\)/i, "starting panel initialized"],
    [/a:focus,[\s\S]*button:focus[\s\S]*outline:\s*3px solid currentColor/i, "visible keyboard focus states"],
    [/>Open Mission 1<\/a>/i, "clear Mission 1 link label"],
    [/>Open Mission 2<\/a>/i, "clear Mission 2 link label"],
    [/>Open Mission 3<\/a>/i, "clear Mission 3 link label"],
    [/>Open AI Mission 3<\/a>/i, "clear AI Mission 3 link label"],
    [/>Optional terminal help<\/a>/i, "clear optional terminal link label"],
    [/Read dashboard aloud/i, "read-aloud button"],
    [/Stop reading/i, "stop read-aloud button"],
    [/aria-live="polite"/i, "read-aloud live status"],
    [/speechSynthesis/i, "browser speech synthesis support"],
    [/SpeechSynthesisUtterance/i, "speech synthesis utterance"],
    [/Start with Mission 1[\s\S]*Use Atlas as the guide[\s\S]*Write code in your own Vue todo project[\s\S]*different goal only if you are continuing, using AI, stuck, or reviewing[\s\S]*Mission 2 comes after Mission 1[\s\S]*Mission 3 comes after Mission 2[\s\S]*optional help only when you need it/i, "simplified read-aloud summary"],
    [/readButton\.addEventListener\("click"[\s\S]*speechSynthesis\.speak\(utterance\)/i, "read-aloud click gating"],
    [/Read-aloud is not supported in this browser/i, "read-aloud unsupported fallback"],
    [/Reading dashboard summary/i, "read-aloud active status"],
    [/Read-aloud stopped/i, "read-aloud stop status"],
    [/Accessibility foundation:[\s\S]*readable[\s\S]*listenable[\s\S]*keyboard-friendly[\s\S]*screen-reader-aware[\s\S]*AI-assistable[\s\S]*small wins/i, "accessibility foundation footer"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }

  if (/<script\s+[^>]*src=/i.test(text)) {
    errors.push(`${label}: dashboard accessibility support should not add external script dependencies`);
  }

  if (/\sautoplay\b/i.test(text)) {
    errors.push(`${label}: read-aloud support must not autoplay`);
  }
}

module.exports = {
  validateMissionDashboard
};
