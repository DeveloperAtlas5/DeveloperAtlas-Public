const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { capabilityDir, capabilityOutputDir } = require("./capability-utils");

const schemaFiles = ["pathway.schema.json"];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);
  validateGeneratedPathway(errors, warnings);

  console.log("Atlas Capability Pathway validation");
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const file = path.join(capabilityDir, fileName);
    if (!fs.existsSync(file)) {
      errors.push(`capability/${fileName}: missing schema file`);
      continue;
    }
    try {
      JSON.parse(fs.readFileSync(file, "utf8"));
    } catch (error) {
      errors.push(`capability/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateGeneratedPathway(errors, warnings) {
  const file = path.join(capabilityOutputDir, "capability-pathway.json");
  if (!fs.existsSync(file)) {
    warnings.push("output/capability/capability-pathway.json has not been generated yet");
    return;
  }

  let pathway;
  try {
    pathway = JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (error) {
    errors.push(`output/capability/capability-pathway.json: invalid JSON (${error.message})`);
    return;
  }

  requireString(pathway, "pathway_id", errors);
  requireObject(pathway, "profile_summary", errors);
  if (!Array.isArray(pathway.weeks) || pathway.weeks.length !== 4) {
    errors.push("output/capability/capability-pathway.json: weeks must contain exactly 4 items");
    return;
  }

  const knownCapabilities = knownCapabilityIds();
  pathway.weeks.forEach((week, index) => {
    if (week.week !== index + 1) errors.push(`week ${index + 1}: week number should be ${index + 1}`);
    requireObject(week.project, `week ${index + 1}.project`, errors);
    if (week.project && !knownCapabilities.has(week.project.capability_id)) {
      errors.push(`week ${index + 1}: unknown capability_id ${week.project.capability_id}`);
    }
    requireString(week, "focus", errors, `week ${index + 1}`);
    requireString(week, "fit_level", errors, `week ${index + 1}`);
    requireString(week, "ai_ready_weekly_prompt", errors, `week ${index + 1}`);
    for (const field of ["prep_tasks", "required_knowledge", "required_tools", "friction_risks", "hardware_notes", "practice_tasks", "mastery_checkpoints"]) {
      if (!Array.isArray(week[field])) errors.push(`week ${index + 1}: ${field} should be an array`);
    }
  });
}

function knownCapabilityIds() {
  const dir = path.join(rootDir, "capability", "examples");
  if (!fs.existsSync(dir)) return new Set();
  return new Set(fs.readdirSync(dir)
    .filter((fileName) => fileName.endsWith(".json"))
    .map((fileName) => JSON.parse(fs.readFileSync(path.join(dir, fileName), "utf8")).capability_id));
}

function requireString(data, field, errors, label = "pathway") {
  if (typeof data?.[field] !== "string" || !data[field].trim()) errors.push(`${label}: missing ${field}`);
}

function requireObject(data, field, errors) {
  if (!data || typeof data !== "object" || Array.isArray(data)) errors.push(`${field}: should be an object`);
}

main();
