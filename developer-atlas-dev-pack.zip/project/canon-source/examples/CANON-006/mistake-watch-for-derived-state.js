const { computed, createWatchedRef, watch } = require("./reactivity-sim");

module.exports = function runMistakeWatchForDerivedState() {
  const firstName = createWatchedRef("Ada");
  const lastName = createWatchedRef("Lovelace");
  const mirroredFullName = createWatchedRef("");

  watch(firstName, () => {
    mirroredFullName.value = `${firstName.value} ${lastName.value}`;
  });

  firstName.value = "Grace";

  if (mirroredFullName.value !== "Grace Lovelace") {
    throw new Error("Expected watcher-maintained full name after firstName changed");
  }

  lastName.value = "Hopper";

  if (mirroredFullName.value === "Grace Hopper") {
    throw new Error("Expected mirrored watcher state to be stale after unwatched lastName changed");
  }

  const fullName = computed(() => `${firstName.value} ${lastName.value}`);

  if (fullName.value !== "Grace Hopper") {
    throw new Error(`Expected computed full name to stay current, got ${fullName.value}`);
  }
};
