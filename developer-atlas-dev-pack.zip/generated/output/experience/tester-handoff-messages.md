# Developer Atlas Tester Handoff Messages

## Purpose

These messages help invite testers to review the Developer Atlas public alpha demo. Ask testers to start with `START_HERE.md`, then choose the path that fits them. These are communication templates for the project owner or reviewer.

## Short invite message

Hi! I am testing an early version of Developer Atlas. It helps learners and AI-assisted builders know what to do next without getting overwhelmed. If you have 10 minutes, please unzip the demo and open `START_HERE.md` first. Feedback on what feels clear or confusing would help a lot.

## Longer invite message

Hi! I am testing an early version of Developer Atlas, a project that helps developers move through one clear learning/building mission at a time.

Please unzip the demo package and open `START_HERE.md` first. From there, the default learner view is `mission/today-mission-surface.md`. If you use AI coding tools, there is also an optional AI-assisted builder view at `mission/today-mission-surface.vibe.md`.

A 10-minute review is enough: read START_HERE, skim the main mission surface, and tell me what felt clear or confusing. If you have 30 minutes, you can also review the AI-assisted view and the feedback questions.

The most useful feedback is whether you knew what to do next, whether the mission felt too simple or too complex, whether the placement and completion checklist helped, and what would make Atlas more useful.

## Message for complete beginners

Could you review this as someone new to the topic? Please open `START_HERE.md` first. I am mainly interested in whether you knew where to start, which words felt confusing, whether the mission felt calm or overwhelming, and whether the checklist helped you understand when the mission was complete.

## Message for Rookie Vue learners

Could you review this as a Rookie Vue learner? Please open `START_HERE.md` first, then the main mission surface. I would like to know whether the mission felt doable, whether the placement guidance helped, whether the recovery section covered likely mistakes, and whether browser storage made sense.

## Message for AI-assisted builders

Could you review this as someone who uses AI while coding? Please open `START_HERE.md` first, then the optional AI-assisted builder view. I would like feedback on whether the AI prompt was useful, whether the accept/reject guidance helped, whether file-scope guidance prevented AI from doing too much, and whether the explain-it-back guidance helped.

## Message for mentors or technical reviewers

Could you review this from a mentoring or technical review perspective? Please open `START_HERE.md` first. I would like to know whether the package is easy to test, whether Atlas feels like one calm mission, whether tester feedback can become product fixes, and whether too much internal machinery is visible.

## Follow-up message after testing

Thanks again for looking at the Atlas demo. When you have a moment, could you send me four quick notes?

1. One thing that felt clear.
2. One thing that felt confusing.
3. Whether you would use Atlas again.
4. What would make it more useful.

Short answers are completely fine.

## What feedback to ask for

- Did you know what to do next?
- Did the mission feel too simple, too complex, or about right?
- Did the placement guidance help?
- Did the completion checklist help?
- Did the recovery guidance help?
- If you use AI, did the vibe-coder view help?
- What still felt unclear?
- What would make you more likely to use Atlas again?
