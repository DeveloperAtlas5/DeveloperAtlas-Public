const users = [
  { id: 1, email: "ada@example.com" },
  { id: 2, email: "grace@example.com" },
  { id: 3, email: "linus@example.com" }
];

const orders = [
  { id: 101, userId: 1, status: "paid", totalCents: 5000 },
  { id: 102, userId: 1, status: "draft", totalCents: 2500 },
  { id: 103, userId: 2, status: "paid", totalCents: 7500 }
];

function innerJoinUsersOrders() {
  return users.flatMap((user) =>
    orders
      .filter((order) => order.userId === user.id)
      .map((order) => ({ user, order }))
  );
}

function leftJoinUsersOrders(rightFilter = () => true) {
  return users.flatMap((user) => {
    const matches = orders.filter((order) => order.userId === user.id && rightFilter(order));

    if (matches.length === 0) {
      return [{ user, order: null }];
    }

    return matches.map((order) => ({ user, order }));
  });
}

module.exports = {
  users,
  orders,
  innerJoinUsersOrders,
  leftJoinUsersOrders
};
