const examples = [
  ["save todo list to localStorage using JSON.stringify()", require("./save-todo-list-localstorage")],
  ["load todo list from localStorage using JSON.parse()", require("./load-todo-list-localstorage")],
  ["sessionStorage tab-scoped draft example", require("./sessionstorage-tab-draft")],
  ["mistake: storing sensitive data in browser storage", require("./mistake-sensitive-browser-storage")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-022 example(s).`);
