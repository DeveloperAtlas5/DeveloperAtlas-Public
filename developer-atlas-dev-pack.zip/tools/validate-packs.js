const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const shareDir = path.join(rootDir, "output", "share");

const forbiddenLearnerTerms = [
  /Gold Candidate/i,
  /scorecard/i,
  /benchmark/i,
  /\bproof\b/i,
  /deterministic architecture/i,
  /Mission Intelligence/i,
  /Flow Engine/i,
  /Capability Intelligence/i,
  /revolutionary/i,
  /\bmagic\b/i,
  /autonomous agent/i,
  /replaces developers/i,
  /\bfailed\b/i,
  /\bwrong\b/i,
  /\bbad\b/i,
  /\bobvious\b/i,
  /should have/i
];

const packs = {
  rookie: {
    dirName: "developer-atlas-rookie-pack",
    zipName: "developer-atlas-rookie-pack.zip",
    expectedRoot: [
      "START_HERE.md",
      "mission-dashboard.html",
      "package-manifest.json",
      "mission",
      "help"
    ],
    learnerDirs: ["mission", "help"]
  },
  full: {
    dirName: "developer-atlas-full-pack",
    zipName: "developer-atlas-full-pack.zip",
    expectedRoot: [
      "START_HERE.md",
      "first-time-quick-start.md",
      "mission-dashboard.html",
      "package-manifest.json",
      "mission",
      "help",
      "ai",
      "reference",
      "concepts",
      "project-start",
      "reviewer"
    ],
    learnerDirs: ["mission", "help", "ai", "reference", "concepts", "project-start"]
  },
  dev: {
    dirName: "developer-atlas-dev-pack",
    zipName: "developer-atlas-dev-pack.zip",
    expectedRootIncludes: [
      "START_HERE.md",
      "first-time-quick-start.md",
      "mission-dashboard.html",
      "package-manifest.json",
      "mission",
      "help",
      "ai",
      "reference",
      "concepts",
      "project-start",
      "reviewer",
      "tools",
      "docs",
      "content",
      "schemas",
      "package.json"
    ],
    learnerDirs: ["mission", "help", "ai", "reference", "concepts", "project-start"]
  }
};

function read(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

function listFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  const files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const entryPath = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...listFiles(entryPath));
    else files.push(entryPath);
  }
  return files;
}

function rootEntries(packDir) {
  return fs.readdirSync(packDir).sort();
}

function requireExists(target, label, errors) {
  if (!fs.existsSync(target)) errors.push(`${label}: missing`);
}

function validateRootExact(packDir, expected, label, errors) {
  const actual = rootEntries(packDir);
  for (const entry of expected) {
    if (!actual.includes(entry)) errors.push(`${label}: missing root entry ${entry}`);
  }
  for (const entry of actual) {
    if (!expected.includes(entry)) errors.push(`${label}: unexpected root entry ${entry}`);
  }
}

function validateRootIncludes(packDir, expected, label, errors) {
  const actual = rootEntries(packDir);
  for (const entry of expected) {
    if (!actual.includes(entry)) errors.push(`${label}: missing root entry ${entry}`);
  }
}

function validateManifest(packDir, label, errors) {
  const manifestPath = path.join(packDir, "package-manifest.json");
  requireExists(manifestPath, `${label}/package-manifest.json`, errors);
  if (!fs.existsSync(manifestPath)) return;
  let manifest;
  try {
    manifest = JSON.parse(read(manifestPath));
  } catch (error) {
    errors.push(`${label}/package-manifest.json: invalid JSON`);
    return;
  }
  for (const key of ["pack_name", "pack_audience", "manifest_scope", "generated_at", "entry_points", "directories", "notes"]) {
    if (!(key in manifest)) errors.push(`${label}/package-manifest.json: missing ${key}`);
  }
  if (!/Primary files and directories/i.test(manifest.manifest_scope || "")) {
    errors.push(`${label}/package-manifest.json: manifest scope should explain primary files and directories`);
  }
}

function validatePackSelectorNote(errors) {
  const sourcePath = path.join(rootDir, "output", "experience", "which-pack-should-i-send.md");
  requireExists(sourcePath, "output/experience/which-pack-should-i-send.md", errors);
  if (!fs.existsSync(sourcePath)) return;
  const text = read(sourcePath);
  const required = [
    [/Rookie Pack[\s\S]*(complete beginner|first-time tester)/i, "Rookie beginner guidance"],
    [/Rookie Pack is non-AI and Mission 1 only/i, "Rookie non-AI Mission 1 guidance"],
    [/Rookie Pack is not a zero-install or zero-project setup pack/i, "Rookie zero-project boundary"],
    [/Rookie Pack is the safest first send for beginners who already have a basic Vue project/i, "Rookie project prerequisite"],
    [/real-feedback-register\.md/i, "real feedback register reference"],
    [/Full Pack[\s\S]*(Missions 1-3|normal learner testing)/i, "Full learner guidance"],
    [/Use Full Pack for AI-assisted learner testing/i, "Full AI-assisted guidance"],
    [/Send Full Pack when you want AI-assisted testing or Missions 1-3/i, "Full AI or Missions 1-3 guidance"],
    [/Dev Pack[\s\S]*(maintainer|contributor)/i, "Dev maintainer guidance"],
    [/Do not send Dev Pack to normal beginners/i, "Dev Pack beginner warning"],
    [/When unsure, send Rookie Pack first only if the learner already has a Vue project/i, "default Rookie recommendation with prerequisite"],
    [/Do not send multiple packs at once to a new tester/i, "single-pack warning"],
    [/After choosing a pack, use `pack-send-checklist\.md` before sending it/i, "send checklist reference"],
    [/\| Situation \| Send \|[\s\S]*\| Complete beginner with a Vue project \| Rookie Pack \|[\s\S]*\| Testing Missions 1-3 \| Full Pack \|[\s\S]*\| Maintainer or contributor \| Dev Pack \|/i, "simple decision table"]
  ];
  for (const [pattern, meaning] of required) {
    if (!pattern.test(text)) errors.push(`output/experience/which-pack-should-i-send.md: missing ${meaning}`);
  }
  const lines = text.split(/\r?\n/).length;
  if (lines >= 90) errors.push("output/experience/which-pack-should-i-send.md: should stay under 90 lines");
}

function validatePackSendChecklist(errors) {
  const sourcePath = path.join(rootDir, "output", "experience", "pack-send-checklist.md");
  requireExists(sourcePath, "output/experience/pack-send-checklist.md", errors);
  if (!fs.existsSync(sourcePath)) return;
  const text = read(sourcePath);
  const required = [
    [/Use this checklist before sending an Atlas pack to a tester/i, "purpose"],
    [/owner-facing and not required learner reading/i, "owner-facing note"],
    [/Run `npm run package:packs`[\s\S]*Run `npm run validate:packs`[\s\S]*Choose one tester goal[\s\S]*Choose one pack[\s\S]*Do not send multiple packs to a new tester/i, "before sending checklist"],
    [/Send only one zip/i, "send one zip"],
    [/For Rookie and Full Pack, tell them to open `mission-dashboard\.html` in a browser/i, "dashboard first guidance"],
    [/For Rookie Pack, tell them it starts after their basic Vue to-do project already exists/i, "Rookie project prerequisite"],
    [/Rookie Pack is not a zero-install or zero-project setup pack/i, "Rookie zero-project boundary"],
    [/real-feedback-register\.md/i, "real feedback register reference"],
    [/For Rookie Pack, do not mention AI or reference material/i, "Rookie AI/reference omission"],
    [/First tester signal: the Rookie Pack start was clear, but Mission 1 needed better laptop readability/i, "first tester readability signal"],
    [/Complete beginner or first-impression test with a basic Vue project already open: Rookie Pack[\s\S]*Rookie Mission 1 non-AI test: Rookie Pack[\s\S]*Normal learner, AI-assisted, or Missions 1-3 test: Full Pack[\s\S]*Maintainer or contributor: Dev Pack[\s\S]*Unsure: Rookie Pack first/i, "pack guidance"],
    [/Rookie Pack: Was it clear this starts after your Vue project already exists\?/i, "Rookie focused question"],
    [/Full Pack: Could you follow the missions without feeling lost\?/i, "Full focused question"],
    [/Dev Pack: Could you find the build, validation, and packaging files\?/i, "Dev focused question"],
    [/Quick copy\/paste messages[\s\S]*Rookie Pack message[\s\S]*Full Pack message[\s\S]*Dev Pack message/i, "copy paste messages"],
    [/Do not send all packs at once[\s\S]*Do not send Dev Pack to a beginner[\s\S]*Do not ask for too much feedback/i, "what not to do"]
  ];
  for (const [pattern, meaning] of required) {
    if (!pattern.test(text)) errors.push(`output/experience/pack-send-checklist.md: missing ${meaning}`);
  }
  const lines = text.split(/\r?\n/).length;
  if (lines >= 90) errors.push("output/experience/pack-send-checklist.md: should stay under 90 lines");
}

function validateMultiPackReport(errors) {
  const reportPath = path.join(rootDir, "output", "experience", "multi-pack-distribution-report.md");
  requireExists(reportPath, "output/experience/multi-pack-distribution-report.md", errors);
  if (!fs.existsSync(reportPath)) return;
  const text = read(reportPath);
  if (!/Use `which-pack-should-i-send\.md` to choose a pack, then `pack-send-checklist\.md` before sending it/i.test(text)) {
    errors.push("output/experience/multi-pack-distribution-report.md: missing selector and checklist reference");
  }
  if (!/Phase 119 simplified the Rookie Pack into a non-AI Mission 1 first-reaction test/i.test(text)) {
    errors.push("output/experience/multi-pack-distribution-report.md: missing Phase 119 hard-cut note");
  }
  if (!/Rookie Pack assumes the learner already has a basic Vue project[\s\S]*not a zero-install or zero-project setup pack/i.test(text)) {
    errors.push("output/experience/multi-pack-distribution-report.md: missing Rookie project-boundary note");
  }
  if (!/Future Atlas flow idea: Goal -> Build or Learn -> Solo or AI Help -> Concept Library \/ Mission Path/i.test(text)) {
    errors.push("output/experience/multi-pack-distribution-report.md: missing future flow note");
  }
  if (!/real-feedback-register\.md/i.test(text)) {
    errors.push("output/experience/multi-pack-distribution-report.md: missing real feedback register reference");
  }
}

function validateConceptLibraryOutput(errors) {
  const conceptsDir = path.join(rootDir, "output", "experience", "concepts");
  requireExists(path.join(conceptsDir, "index.md"), "output/experience/concepts/index.md", errors);
  if (fs.existsSync(path.join(conceptsDir, "index.md"))) {
    const index = read(path.join(conceptsDir, "index.md"));
    if (!/Need to start a project first\? See \[Project Start Guides\]\(\.\.\/project-start\/index\.md\)/i.test(index)) {
      errors.push("Concept Library index: missing Project Start Guides cross-link");
    }
    if (!/## Laravel[\s\S]*## Vue[\s\S]*## Comparisons[\s\S]*## AI Standards[\s\S]*Use these when AI is helping with code/i.test(index)) {
      errors.push("Concept Library index: AI Standards should be secondary after human concept sections");
    }
  }
  const laravelCards = listFiles(path.join(conceptsDir, "laravel")).filter((file) => /\.md$/i.test(file));
  const vueCards = listFiles(path.join(conceptsDir, "vue")).filter((file) => /\.md$/i.test(file));
  const comparisonCards = listFiles(path.join(conceptsDir, "comparisons")).filter((file) => /\.md$/i.test(file));
  const aiStandardCards = listFiles(path.join(conceptsDir, "ai-standards")).filter((file) => /\.md$/i.test(file));
  if (laravelCards.length < 8) errors.push(`Concept Library: expected at least 8 Laravel cards, found ${laravelCards.length}`);
  if (vueCards.length < 8) errors.push(`Concept Library: expected at least 8 Vue cards, found ${vueCards.length}`);
  if (comparisonCards.length < 3) errors.push(`Concept Library: expected at least 3 comparison cards, found ${comparisonCards.length}`);
  if (aiStandardCards.length !== 6) errors.push(`AI Standards: expected 6 nodes, found ${aiStandardCards.length}`);

  const aiStandardNames = [
    "ai-code-readability-standard.md",
    "ai-small-patch-standard.md",
    "ai-explain-before-change-standard.md",
    "ai-human-review-standard.md",
    "ai-concept-check-standard.md",
    "ai-no-scope-creep-standard.md"
  ];
  const aiRequiredSections = [
    "## Simple meaning",
    "## Why it exists",
    "## What AI should do",
    "## What AI should avoid",
    "## Before changing code",
    "## While writing code",
    "## After the change",
    "## Human check",
    "## Related Atlas nodes"
  ];
  for (const fileName of aiStandardNames) {
    const filePath = path.join(conceptsDir, "ai-standards", fileName);
    requireExists(filePath, `AI Standard ${fileName}`, errors);
    if (!fs.existsSync(filePath)) continue;
    const text = read(filePath);
    for (const heading of aiRequiredSections) {
      if (!text.includes(heading)) errors.push(`AI Standard ${fileName}: missing ${heading}`);
    }
  }
  const aiReadability = path.join(conceptsDir, "ai-standards", "ai-code-readability-standard.md");
  const aiSmallPatch = path.join(conceptsDir, "ai-standards", "ai-small-patch-standard.md");
  const aiExplain = path.join(conceptsDir, "ai-standards", "ai-explain-before-change-standard.md");
  const aiReview = path.join(conceptsDir, "ai-standards", "ai-human-review-standard.md");
  const aiConcept = path.join(conceptsDir, "ai-standards", "ai-concept-check-standard.md");
  const aiNoScope = path.join(conceptsDir, "ai-standards", "ai-no-scope-creep-standard.md");
  if (fs.existsSync(aiReadability) && !/(?=[\s\S]*clear names)(?=[\s\S]*indentation|[\s\S]*spacing)(?=[\s\S]*Comment the why)/i.test(read(aiReadability))) {
    errors.push("AI Code Readability Standard: missing clear names, indentation/spacing, or comment-the-why guidance");
  }
  if (fs.existsSync(aiSmallPatch) && !/(?=[\s\S]*smallest useful change)(?=[\s\S]*unrelated)/i.test(read(aiSmallPatch))) {
    errors.push("AI Small Patch Standard: missing smallest useful change or unrelated rewrite warning");
  }
  if (fs.existsSync(aiExplain) && !/Name the file or area being changed/i.test(read(aiExplain))) {
    errors.push("AI Explain-Before-Change Standard: should name the file or area being changed");
  }
  if (fs.existsSync(aiReview) && !/human stays in control/i.test(read(aiReview))) {
    errors.push("AI Human Review Standard: should say the human stays in control");
  }
  if (fs.existsSync(aiConcept) && !/Identify which Atlas concepts apply before answering/i.test(read(aiConcept))) {
    errors.push("AI Concept Check Standard: should identify relevant Atlas concepts before answering");
  }
  if (fs.existsSync(aiNoScope) && !/Do not add features because they seem useful|Adding auth/i.test(read(aiNoScope))) {
    errors.push("AI No-Scope-Creep Standard: should warn against adding unasked features");
  }
}

function validateProjectStartOutput(errors) {
  const projectStartDir = path.join(rootDir, "output", "experience", "project-start");
  const indexPath = path.join(projectStartDir, "index.md");
  requireExists(indexPath, "output/experience/project-start/index.md", errors);
  if (fs.existsSync(indexPath)) {
    const index = read(indexPath);
    if (!/Not knowing how to start a project is normal/i.test(index)) {
      errors.push("Project Start Guides index: should normalize not knowing how to start");
    }
    for (const slug of ["html", "css", "javascript", "vue", "php", "laravel", "sql", "java"]) {
      if (!new RegExp(`\\(${slug}\\.md\\)`, "i").test(index)) {
        errors.push(`Project Start Guides index: missing ${slug} link`);
      }
    }
  }

  const requiredSections = [
    "## What this is for",
    "## What you need first",
    "## Required tools",
    "## Recommended extensions",
    "## Start from zero",
    "## Open an existing project",
    "## Run or preview the project",
    "## Where you usually code",
    "## Common first problems",
    "## Next Atlas step"
  ];
  for (const slug of ["html", "css", "javascript", "vue", "php", "laravel", "sql", "java"]) {
    const guidePath = path.join(projectStartDir, `${slug}.md`);
    requireExists(guidePath, `Project Start Guide ${slug}`, errors);
    if (!fs.existsSync(guidePath)) continue;
    const guide = read(guidePath);
    for (const heading of requiredSections) {
      if (!guide.includes(heading)) errors.push(`Project Start Guide ${slug}: missing ${heading}`);
    }
  }

  const guideText = (slug) => {
    const guidePath = path.join(projectStartDir, `${slug}.md`);
    return fs.existsSync(guidePath) ? read(guidePath) : "";
  };
  if (!/index\.html[\s\S]*browser/i.test(guideText("html"))) errors.push("HTML Project Start Guide: missing index.html/browser guidance");
  if (!/(?=[\s\S]*Node\.js)(?=[\s\S]*Vite)(?=[\s\S]*npm install)(?=[\s\S]*npm run dev)(?=[\s\S]*src\/App\.vue)(?=[\s\S]*Vue - Official)/i.test(guideText("vue"))) {
    errors.push("Vue Project Start Guide: missing required Vue setup details");
  }
  if (!/(?=[\s\S]*PHP)(?=[\s\S]*Composer)(?=[\s\S]*php artisan serve)(?=[\s\S]*routes)(?=[\s\S]*Controllers)(?=[\s\S]*Models)(?=[\s\S]*Migrations)/i.test(guideText("laravel"))) {
    errors.push("Laravel Project Start Guide: missing required Laravel setup details");
  }
  if (!/SQL usually runs inside a database tool or application/i.test(guideText("sql"))) {
    errors.push("SQL Project Start Guide: should explain SQL runs inside a database tool or app");
  }
}

function validateRealFeedbackRegister(errors) {
  const registerPath = path.join(rootDir, "output", "experience", "real-feedback-register.md");
  requireExists(registerPath, "output/experience/real-feedback-register.md", errors);
  if (!fs.existsSync(registerPath)) return;
  const text = read(registerPath);
  const required = [
    [/records real tester feedback only/i, "real feedback only"],
    [/Do not add simulated feedback here/i, "simulated feedback exclusion"],
    [/mission text was too dense and small on laptop/i, "dense/small mission feedback"],
    [/Beginner wording feedback/i, "beginner wording feedback"],
    [/Vue project prerequisite[\s\S]*browser-opening instructions|browser[\s\S]*Vue project prerequisite/i, "entry boundary feedback"],
    [/Phase 120/i, "Phase 120 reference"],
    [/Phase 122/i, "Phase 122 reference"],
    [/Phase 123/i, "Phase 123 reference"],
    [/Phase 124/i, "Phase 124 reference"]
  ];
  for (const [pattern, meaning] of required) {
    if (!pattern.test(text)) errors.push(`Real Feedback Register: missing ${meaning}`);
  }
}

function extractLinks(text) {
  const links = [];
  const markdown = /\[[^\]]+\]\(([^)]+)\)/g;
  const href = /href="([^"]+)"/g;
  let match;
  while ((match = markdown.exec(text))) links.push(match[1]);
  while ((match = href.exec(text))) links.push(match[1]);
  return links;
}

function isExternalOrAnchor(link) {
  return /^(https?:|mailto:|tel:|#)/i.test(link);
}

function cleanLink(link) {
  return link.split("#")[0].split("?")[0];
}

function stripCodeFences(text) {
  return text
    .replace(/```[\s\S]*?```/g, "")
    .replace(/<pre[\s\S]*?<\/pre>/gi, "")
    .replace(/<code[\s\S]*?<\/code>/gi, "")
    .replace(/`[^`]*`/g, "");
}

function validateInternalLinks(packDir, label, errors) {
  const files = listFiles(packDir).filter((file) => {
    if (!/\.(md|html)$/i.test(file)) return false;
    const relative = path.relative(packDir, file).replace(/\\/g, "/");
    if (/^(tools|docs|content|schemas|generated|project)\//.test(relative)) return false;
    return true;
  });
  for (const file of files) {
    const text = stripCodeFences(read(file));
    for (const rawLink of extractLinks(text)) {
      if (isExternalOrAnchor(rawLink)) continue;
      const clean = cleanLink(rawLink);
      if (!clean) continue;
      const target = path.resolve(path.dirname(file), clean);
      if (!target.startsWith(packDir)) {
        errors.push(`${label}/${path.relative(packDir, file)}: link escapes pack (${rawLink})`);
        continue;
      }
      if (!fs.existsSync(target)) {
        errors.push(`${label}/${path.relative(packDir, file)}: broken internal link (${rawLink})`);
      }
    }
  }
}

function validateLearnerLanguage(packDir, config, label, errors) {
  const files = [
    path.join(packDir, "START_HERE.md"),
    path.join(packDir, "first-time-quick-start.md"),
    path.join(packDir, "mission-dashboard.html")
  ];
  for (const dir of config.learnerDirs) {
    files.push(...listFiles(path.join(packDir, dir)).filter((file) => /\.(md|html)$/i.test(file)));
  }
  for (const file of files) {
    if (!fs.existsSync(file)) continue;
    const text = read(file);
    for (const pattern of forbiddenLearnerTerms) {
      if (pattern.test(text)) {
        errors.push(`${label}/${path.relative(packDir, file)}: learner-facing forbidden term ${pattern}`);
      }
    }
  }
}

function validateDashboardCommon(packDir, label, errors) {
  const dashboardPath = path.join(packDir, "mission-dashboard.html");
  requireExists(dashboardPath, `${label}/mission-dashboard.html`, errors);
  if (!fs.existsSync(dashboardPath)) return;
  const text = read(dashboardPath);
  if (!/Start Mission 1/i.test(text)) errors.push(`${label}/mission-dashboard.html: missing Start Mission 1`);
  if (!/Read dashboard aloud[\s\S]*Stop reading[\s\S]*speechSynthesis/i.test(text)) {
    errors.push(`${label}/mission-dashboard.html: missing read-aloud support`);
  }
  const startIndex = text.indexOf("Start Mission 1");
  const missionTwoIndex = text.indexOf("Mission 2");
  if (missionTwoIndex !== -1 && missionTwoIndex < startIndex) {
    errors.push(`${label}/mission-dashboard.html: Mission 1 should remain first visible action`);
  }
}

function validateReviewerLinksOnlyReviewPath(packDir, label, errors) {
  const dashboardPath = path.join(packDir, "mission-dashboard.html");
  if (!fs.existsSync(dashboardPath)) return;
  const text = read(dashboardPath);
  const reviewIndex = text.indexOf('id="panel-reviewing"');
  const referenceIndex = text.indexOf('id="optional-reference"');
  for (const link of [
    "reviewer/alpha-package-final-qa.md",
    "reviewer/alpha-focus-lock.md",
    "reviewer/human-ai-readability-audit.md",
    "reviewer/ai-guardrail-evaluation.md",
    "reviewer/ai-guardrail-red-team-pack.md",
    "reviewer/ai-red-team-results-template.md"
  ]) {
    const linkIndex = text.indexOf(link);
    if (linkIndex === -1) {
      errors.push(`${label}/mission-dashboard.html: missing reviewer link ${link}`);
    } else if (reviewIndex === -1 || referenceIndex === -1 || linkIndex < reviewIndex || linkIndex > referenceIndex) {
      errors.push(`${label}/mission-dashboard.html: reviewer link outside Review path (${link})`);
    }
  }
}

function validateRookie(packDir, errors) {
  validateRootExact(packDir, packs.rookie.expectedRoot, "Rookie Pack", errors);
  requireExists(path.join(packDir, "mission", "today-mission-surface.md"), "Rookie Pack Mission 1", errors);
  requireExists(path.join(packDir, "help", "terminal-confidence-guide.md"), "Rookie Pack terminal help", errors);
  for (const forbidden of [
    "first-time-quick-start.md",
    "atlas-reader.html",
    "ai",
    "reference",
    "concepts",
    "project-start",
    "reviewer",
    "tools",
    "docs",
    "content",
    "help/beginner-orientation.md",
    "help/vue-concept-cards.md",
    "mission/today-mission-surface.vibe.md",
    "mission/mission-feedback-template.md",
    "mission/mission-02-todoitem-surface.md",
    "mission/mission-02-todoitem-surface.vibe.md",
    "mission/mission-03-todostats-surface.md",
    "mission/mission-03-todostats-surface.vibe.md",
    "real-feedback-register.md",
    "reviewer/real-feedback-register.md"
  ]) {
    if (fs.existsSync(path.join(packDir, forbidden))) errors.push(`Rookie Pack: should exclude ${forbidden}`);
  }
  const dashboard = read(path.join(packDir, "mission-dashboard.html"));
  if (/mission-02|mission-03|Mission 2|Mission 3|reviewer\/|ai\/|vibe|reference\/|canon|mission-feedback-template/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should not link Mission 2, Mission 3, AI, reference, reviewer, Canon, or feedback files");
  }
  if (/concepts\/|Concept Library/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should not link Concept Library");
  }
  if (/project-start\/|Project Start Guides/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should not link Project Start Guides");
  }
  const startIndex = dashboard.indexOf("Start Mission 1");
  const helpIndex = dashboard.indexOf("Terminal help");
  if (startIndex === -1 || (helpIndex !== -1 && helpIndex < startIndex)) {
    errors.push("Rookie Pack dashboard: Mission 1 should be the first visible action");
  }
  if (!/Read in Atlas\. Code in your Vue project/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should say read in Atlas and code in the Vue project");
  }
  if (!/basic Vue to-do project already open in VS Code/i.test(dashboard) || !/starts after your basic Vue to-do project already exists/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should clarify the Vue project prerequisite");
  }
  if (!/Developer Atlas Rookie Reader|book-style guide|small book/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should present Atlas as a reader/book-style surface");
  }
  if (!/Before you start[\s\S]*What you will do[\s\S]*Step 1 - Open your Vue project[\s\S]*Step 2 - Save to-do items[\s\S]*Step 3 - Load to-do items after refresh[\s\S]*Check your work[\s\S]*If you get stuck[\s\S]*Extra context/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should include Mission 1 content directly");
  }
  if (!/You do not need to browse the folders/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should say folder browsing is not required");
  }
  if (!/Quick Terms[\s\S]*Vue state[\s\S]*ref[\s\S]*localStorage[\s\S]*App\.vue/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should include mission Quick Terms");
  }
  if (!/<details>[\s\S]*<summary>Vue state<\/summary>/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: Quick Terms should be collapsible or visually secondary");
  }
  if (!/larger-text[\s\S]*smaller-text/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should include font-size controls");
  }
  if (!/toggle-theme|High contrast|warm/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should include a theme or contrast control");
  }
  const startHere = read(path.join(packDir, "START_HERE.md"));
  if (/fetch\s*\(/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should not use browser-side fetch() to load Markdown");
  }
  if (!/Open `mission-dashboard\.html` from Windows File Explorer/i.test(startHere)) errors.push("Rookie Pack START_HERE: missing File Explorer dashboard instruction");
  if (!/small book in your browser/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: should say Atlas opens like a small book in the browser");
  }
  if (!/opens in VS Code[\s\S]*Windows File Explorer[\s\S]*double-click[\s\S]*mission-dashboard\.html/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should explain what to do if the HTML opens in VS Code");
  }
  if (!/opens in VS Code[\s\S]*Windows File Explorer[\s\S]*double-click `mission-dashboard\.html`/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: missing VS Code browser-open fallback");
  }
  if (!/This Rookie Pack starts after your basic Vue to-do project already exists/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: missing starts-after-project boundary");
  }
  if (!/You do not need to browse the folders/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: should say folder browsing is not needed");
  }
  if (!/Read in Atlas[\s\S]*Code in your Vue project/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: missing read/code boundary");
  }
  if (!/If the terminal feels confusing, open `help\/terminal-confidence-guide\.md`/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: missing terminal help instruction");
  }
  if (!/You need a basic Vue to-do project already open in VS Code/i.test(startHere)) {
    errors.push("Rookie Pack START_HERE: missing VS Code project prerequisite");
  }
  const startHereLines = startHere.split(/\r?\n/).length;
  if (startHereLines >= 12) errors.push("Rookie Pack START_HERE: should stay under 12 lines");
  const missionFiles = listFiles(path.join(packDir, "mission")).map((file) => path.relative(path.join(packDir, "mission"), file).replace(/\\/g, "/"));
  if (missionFiles.length !== 1 || missionFiles[0] !== "today-mission-surface.md") {
    errors.push("Rookie Pack mission/: should include only today-mission-surface.md");
  }
  const helpFiles = listFiles(path.join(packDir, "help")).map((file) => path.relative(path.join(packDir, "help"), file).replace(/\\/g, "/"));
  if (helpFiles.length !== 1 || helpFiles[0] !== "terminal-confidence-guide.md") {
    errors.push("Rookie Pack help/: should include only terminal-confidence-guide.md");
  }
  const fileCount = listFiles(packDir).length;
  if (fileCount !== 5) errors.push(`Rookie Pack: should have exactly 5 files, found ${fileCount}`);
  const mission = read(path.join(packDir, "mission", "today-mission-surface.md"));
  const missionRequired = [
    [/## Before you start/i, "Before you start"],
    [/## What you will do/i, "What you will do"],
    [/## Where you will code/i, "Where you will code"],
    [/## Step 1 - Open your Vue project/i, "Step 1"],
    [/## Step 2 - Save to-do items/i, "Step 2"],
    [/## Step 3 - Load to-do items after refresh/i, "Step 3"],
    [/Atlas is where you read[\s\S]*Your Vue project is where you code/i, "read/code boundary"],
    [/You need a basic Vue to-do project already open in VS Code/i, "Vue project prerequisite"],
    [/This Rookie Pack starts after your basic Vue to-do project already exists/i, "starts-after-project boundary"],
    [/If your Vue project is not created yet, stop here and get the starter project first/i, "starter project stop guidance"],
    [/stay saved after you refresh|stays saved after you refresh/i, "clear saved-after-refresh wording"],
    [/Vue state is the data your page is using right now[\s\S]*If the state changes, the page updates[\s\S]*to-do items are in Vue state[\s\S]*`localStorage` lets them stay saved after refresh/i, "beginner Vue state explanation"],
    [/## Extra context/i, "deeper explanation lower in file"]
  ];
  for (const [pattern, meaning] of missionRequired) {
    if (!pattern.test(mission)) errors.push(`Rookie Pack Mission 1: missing ${meaning}`);
  }
  const firstActionIndex = mission.indexOf("## Step 1 - Open your Vue project");
  const extraContextIndex = mission.indexOf("## Extra context");
  if (extraContextIndex !== -1 && firstActionIndex !== -1 && extraContextIndex < firstActionIndex) {
    errors.push("Rookie Pack Mission 1: deeper explanation should stay after the first action");
  }
  if (/Next mission preview|After this, you can learn|Mission 2|mission-02|component extraction|reusable component/i.test(mission)) {
    errors.push("Rookie Pack Mission 1: should not include a Mission 2 preview");
  }
  const rookieText = stripCodeFences([dashboard, startHere, mission].join("\n"));
  if (/Welcome back/i.test(rookieText)) errors.push("Rookie Pack learner text: should not say Welcome back");
  if (/\bblocker\b/i.test(rookieText)) errors.push("Rookie Pack learner text: should not use unexplained blocker");
  if (/Difficulty:\s*guided/i.test(rookieText)) errors.push("Rookie Pack learner text: should not use unexplained Difficulty: guided");
  if (/\btodos?\b/i.test(rookieText)) errors.push("Rookie Pack learner prose: use to-do wording instead of todo/todos");
  if (/Where this work happens/i.test(rookieText)) errors.push("Rookie Pack learner text: replace Where this work happens");
  if (!/Open your Vue project/i.test(mission)) errors.push("Rookie Pack Mission 1: should start with the small action Open your Vue project");
  if (!/font-size:\s*18px/i.test(dashboard) || !/line-height:\s*1\.7/i.test(dashboard) || !/760px/i.test(dashboard)) {
    errors.push("Rookie Pack dashboard: should keep larger font, comfortable line height, and readable width");
  }
}

function validateFull(packDir, errors) {
  validateRootExact(packDir, packs.full.expectedRoot, "Full Pack", errors);
  for (const required of [
    "mission/today-mission-surface.md",
    "mission/today-mission-surface.vibe.md",
    "mission/mission-02-todoitem-surface.md",
    "mission/mission-02-todoitem-surface.vibe.md",
    "mission/mission-03-todostats-surface.md",
    "mission/mission-03-todostats-surface.vibe.md",
    "mission/mission-feedback-template.md",
    "first-time-quick-start.md",
    "help/beginner-orientation.md",
    "help/vue-concept-cards.md",
    "help/terminal-confidence-guide.md",
    "ai/ai-prompt-pack.md",
    "reference/canon/hardened",
    "concepts/index.md",
    "concepts/ai-standards/ai-code-readability-standard.md",
    "concepts/ai-standards/ai-small-patch-standard.md",
    "concepts/ai-standards/ai-explain-before-change-standard.md",
    "concepts/ai-standards/ai-human-review-standard.md",
    "concepts/ai-standards/ai-concept-check-standard.md",
    "concepts/ai-standards/ai-no-scope-creep-standard.md",
    "project-start/index.md",
    "reviewer"
  ]) {
    requireExists(path.join(packDir, required), `Full Pack ${required}`, errors);
  }
  requireExists(path.join(packDir, "reviewer", "which-pack-should-i-send.md"), "Full Pack reviewer/which-pack-should-i-send.md", errors);
  requireExists(path.join(packDir, "reviewer", "pack-send-checklist.md"), "Full Pack reviewer/pack-send-checklist.md", errors);
  requireExists(path.join(packDir, "reviewer", "real-feedback-register.md"), "Full Pack reviewer/real-feedback-register.md", errors);
  validateReviewerLinksOnlyReviewPath(packDir, "Full Pack", errors);
  const dashboard = read(path.join(packDir, "mission-dashboard.html"));
  if (!/AI-assisted path[\s\S]*hidden/i.test(dashboard)) errors.push("Full Pack dashboard: AI path should remain secondary");
  const aiPromptPack = read(path.join(packDir, "ai", "ai-prompt-pack.md"));
  if (!/Use AI to explain, suggest small examples, and check your understanding[\s\S]*Do not use AI to skip the mission for you/i.test(aiPromptPack)) {
    errors.push("Full Pack AI guidance: should clarify AI helps explain and should not take over learning");
  }
  if (!/Before helping with code, check the relevant AI Standard nodes[\s\S]*AI Code Readability Standard[\s\S]*AI Small Patch Standard[\s\S]*AI Explain-Before-Change Standard[\s\S]*AI Human Review Standard[\s\S]*AI Concept Check Standard[\s\S]*AI No-Scope-Creep Standard/i.test(aiPromptPack)) {
    errors.push("Full Pack AI guidance: should reference the AI Standard nodes");
  }
  if (!/Use these standards to explain, narrow, and verify the answer/i.test(aiPromptPack)) {
    errors.push("Full Pack AI guidance: should say AI standards explain, narrow, and verify");
  }
  if (!/Do not use them to take over the learner's work/i.test(aiPromptPack)) {
    errors.push("Full Pack AI guidance: should say AI standards do not take over learner work");
  }
  const conceptIndex = dashboard.indexOf("concepts/index.md");
  const startIndex = dashboard.indexOf("Start Mission 1");
  const optionalReferenceIndex = dashboard.indexOf("optional-reference");
  if (conceptIndex === -1) {
    errors.push("Full Pack dashboard: missing optional Concept Library link");
  } else if (conceptIndex < startIndex || optionalReferenceIndex === -1 || conceptIndex < optionalReferenceIndex) {
    errors.push("Full Pack dashboard: Concept Library link should stay optional/secondary");
  }
  const projectStartIndex = dashboard.indexOf("project-start/index.md");
  if (projectStartIndex === -1) {
    errors.push("Full Pack dashboard: missing optional Project Start Guides link");
  } else if (projectStartIndex < startIndex || optionalReferenceIndex === -1 || projectStartIndex < optionalReferenceIndex) {
    errors.push("Full Pack dashboard: Project Start Guides link should stay optional/secondary");
  }
}

function validateDev(packDir, errors) {
  validateRootIncludes(packDir, packs.dev.expectedRootIncludes, "Dev Pack", errors);
  for (const required of ["tools", "docs", "content", "schemas", "reviewer", "concepts/index.md", "concepts/ai-standards/ai-code-readability-standard.md", "project-start/index.md", "reviewer/real-feedback-register.md", "content/concepts/concept-library.json", "project/concepts-source/concept-library.json", "generated/output/experience/concepts/index.md", "generated/output/experience/concepts/ai-standards/ai-code-readability-standard.md", "generated/output/experience/project-start/index.md"]) {
    requireExists(path.join(packDir, required), `Dev Pack ${required}`, errors);
  }
  requireExists(path.join(packDir, "reviewer", "which-pack-should-i-send.md"), "Dev Pack reviewer/which-pack-should-i-send.md", errors);
  requireExists(path.join(packDir, "reviewer", "pack-send-checklist.md"), "Dev Pack reviewer/pack-send-checklist.md", errors);
  for (const forbidden of ["node_modules", ".git"]) {
    if (fs.existsSync(path.join(packDir, forbidden))) errors.push(`Dev Pack: should exclude ${forbidden}`);
  }
  const zipFiles = listFiles(packDir).filter((file) => /\.zip$/i.test(file));
  if (zipFiles.length) errors.push("Dev Pack: should not include old zip artifacts");
}

function validateNoMissionFour(packDir, label, errors) {
  const files = listFiles(packDir).filter((file) => {
    if (!/\.(md|html|json)$/i.test(file)) return false;
    const relative = path.relative(packDir, file).replace(/\\/g, "/");
    if (/^(tools|docs|content|schemas|generated|project)\//.test(relative)) return false;
    return true;
  });
  for (const file of files) {
    const text = read(file);
    const futureMissionPattern = new RegExp(["Mission", "\\s*", "4"].join("") + "|" + ["mission", "-", "04"].join(""), "i");
    if (futureMissionPattern.test(text)) {
      errors.push(`${label}/${path.relative(packDir, file)}: should not reference future mission scope`);
    }
  }
}

function main() {
  const errors = [];
  validatePackSelectorNote(errors);
  validatePackSendChecklist(errors);
  validateMultiPackReport(errors);
  validateConceptLibraryOutput(errors);
  validateProjectStartOutput(errors);
  validateRealFeedbackRegister(errors);
  for (const [key, config] of Object.entries(packs)) {
    const label = `${key[0].toUpperCase()}${key.slice(1)} Pack`;
    const packDir = path.join(shareDir, config.dirName);
    const zipPath = path.join(shareDir, config.zipName);
    requireExists(packDir, label, errors);
    requireExists(zipPath, `${label} zip`, errors);
    if (!fs.existsSync(packDir)) continue;
    validateManifest(packDir, label, errors);
    validateDashboardCommon(packDir, label, errors);
    validateInternalLinks(packDir, label, errors);
    validateLearnerLanguage(packDir, config, label, errors);
    validateNoMissionFour(packDir, label, errors);
  }

  if (fs.existsSync(path.join(shareDir, packs.rookie.dirName))) validateRookie(path.join(shareDir, packs.rookie.dirName), errors);
  if (fs.existsSync(path.join(shareDir, packs.rookie.dirName, "reviewer", "which-pack-should-i-send.md")) || fs.existsSync(path.join(shareDir, packs.rookie.dirName, "which-pack-should-i-send.md"))) {
    errors.push("Rookie Pack: should not include which-pack-should-i-send.md");
  }
  if (fs.existsSync(path.join(shareDir, packs.rookie.dirName, "reviewer", "pack-send-checklist.md")) || fs.existsSync(path.join(shareDir, packs.rookie.dirName, "pack-send-checklist.md"))) {
    errors.push("Rookie Pack: should not include pack-send-checklist.md");
  }
  if (fs.existsSync(path.join(shareDir, packs.full.dirName))) validateFull(path.join(shareDir, packs.full.dirName), errors);
  if (fs.existsSync(path.join(shareDir, packs.dev.dirName))) validateDev(path.join(shareDir, packs.dev.dirName), errors);

  console.log("Atlas Pack validation");
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  if (errors.length) process.exitCode = 1;
}

main();
