const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readTools, readSetupProfiles } = require("./toolkit-utils");
const { readFrictionNodes } = require("./friction-utils");
const {
  teamContextDir,
  readTeamContexts
} = require("./team-context-utils");

const schemaFiles = [
  "team-profile.schema.json",
  "project-context.schema.json",
  "shared-ai-context.schema.json",
  "onboarding-context.schema.json",
  "team-context-quality.schema.json"
];

const requiredFields = [
  "team_id",
  "project_id",
  "project_goals",
  "tech_stack",
  "approved_tools",
  "coding_standards",
  "architecture_notes",
  "current_sprint",
  "known_friction",
  "shared_canon_nodes",
  "shared_toolkit_nodes",
  "shared_setup_profile",
  "shared_hardware_assumptions",
  "onboarding_notes",
  "ai_usage_rules",
  "what_ai_should_not_do"
];

const arrayFields = [
  "project_goals",
  "tech_stack",
  "approved_tools",
  "coding_standards",
  "architecture_notes",
  "known_friction",
  "shared_canon_nodes",
  "shared_toolkit_nodes",
  "shared_hardware_assumptions",
  "onboarding_notes",
  "ai_usage_rules",
  "what_ai_should_not_do"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);
  const contexts = readTeamContexts();
  const known = readKnownIds();
  validateContexts(contexts, known, errors, warnings);

  console.log("Atlas Team Context validation");
  console.log(`Team contexts: ${contexts.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const file = path.join(teamContextDir, fileName);
    if (!fs.existsSync(file)) {
      errors.push(`team-context/${fileName}: missing schema file`);
      continue;
    }
    try {
      JSON.parse(fs.readFileSync(file, "utf8"));
    } catch (error) {
      errors.push(`team-context/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function readKnownIds() {
  const canonIndex = JSON.parse(fs.readFileSync(path.join(rootDir, "canon", "canon-index.json"), "utf8"));
  return {
    canonIds: new Set(canonIndex.entries.map((entry) => entry.canon_id)),
    toolIds: new Set(readTools().map((record) => record.data.id)),
    setupProfileIds: new Set(readSetupProfiles().map((record) => record.data.profile_id)),
    frictionIds: new Set(readFrictionNodes().map((record) => record.node.id))
  };
}

function validateContexts(records, known, errors, warnings) {
  const seenProjects = new Set();

  for (const { context, relativePath } of records) {
    for (const field of requiredFields) {
      if (context[field] === undefined || context[field] === null || context[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }
    for (const field of arrayFields) validateArray(relativePath, context, field, errors);

    if (seenProjects.has(context.project_id)) errors.push(`${relativePath}: duplicate project_id ${context.project_id}`);
    seenProjects.add(context.project_id);

    warnUnknown(relativePath, context.approved_tools, known.toolIds, "approved_tools", warnings);
    warnUnknown(relativePath, context.shared_toolkit_nodes, known.toolIds, "shared_toolkit_nodes", warnings);
    warnUnknown(relativePath, context.shared_canon_nodes, known.canonIds, "shared_canon_nodes", warnings);
    warnUnknown(relativePath, context.known_friction, known.frictionIds, "known_friction", warnings);

    if (!known.setupProfileIds.has(context.shared_setup_profile)) {
      warnings.push(`${relativePath}: shared_setup_profile references unknown setup profile ${context.shared_setup_profile}`);
    }
    if (!context.ai_usage_rules?.length) warnings.push(`${relativePath}: team contexts should include AI usage rules`);
    if (!context.what_ai_should_not_do?.length) warnings.push(`${relativePath}: team contexts should include forbidden AI assumptions`);
  }
}

function validateArray(relativePath, data, field, errors) {
  if (!Array.isArray(data[field]) || data[field].length === 0) {
    errors.push(`${relativePath}: ${field} should be a non-empty array`);
    return;
  }
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

function warnUnknown(relativePath, values, knownSet, label, warnings) {
  for (const value of values || []) {
    if (!knownSet.has(value)) warnings.push(`${relativePath}: ${label} references unknown id ${value}`);
  }
}

main();
