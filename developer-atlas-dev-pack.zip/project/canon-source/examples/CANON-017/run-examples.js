const examples = [
  ["parse API JSON response string", require("./parse-api-response-string")],
  ["stringify object for localStorage/API payload", require("./stringify-for-storage-and-api")],
  ["mistake: parsing an object that is already parsed", require("./mistake-parse-already-parsed-object")],
  ["mistake: stringifying circular object or unsupported values", require("./mistake-circular-and-unsupported-values")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-017 example(s).`);
