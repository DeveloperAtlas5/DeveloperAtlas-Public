const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "brain");
const outputPath = path.join(outputDir, "atlas-brain-pack.json");
const outputV2Path = path.join(outputDir, "atlas-brain-pack-v2.json");
const intentOntologyOutputPath = path.join(outputDir, "engineering-intent-ontology.json");

function readJson(relativePath) {
  return JSON.parse(fs.readFileSync(path.join(rootDir, relativePath), "utf8"));
}

function main() {
  const contextPack = readJson("output/ai/atlas-context-pack.json");
  const graph = readJson("output/graph/knowledge-graph.json");
  const reasoningFlow = readJson("brain/reasoning-flow.json");
  const personas = readJson("brain/personas.json");
  const decisionModel = readJson("brain/decision-model.json");
  const phase9 = readPhase9Models();

  const highConfidenceNodes = contextPack.knowledge.filter((node) => Number(node.confidence || 0) >= 5);
  const highImportanceNodes = contextPack.knowledge.filter((node) => Number(node.importance || 0) >= 5);
  const recommendationReadyNodes = contextPack.recommendations.filter((node) =>
    node.recommended_for.length > 0 &&
    node.avoid_for.length > 0 &&
    node.tradeoffs.length > 0 &&
    node.best_alternative
  );

  const brainPack = {
    metadata: {
      name: "Atlas Brain",
      version: "0.1",
      generated_at: new Date().toISOString(),
      description: "Structured reasoning layer for Developer Atlas. Not a chatbot."
    },
    reasoning_flow: reasoningFlow,
    personas,
    decision_model: decisionModel,
    node_count: graph.statistics.node_count,
    edge_count: graph.statistics.edge_count,
    high_confidence_nodes: highConfidenceNodes.map(toNodeSummary),
    high_importance_nodes: highImportanceNodes.map(toNodeSummary),
    recommendation_ready_nodes: recommendationReadyNodes.map((node) => node.id),
    relationship_summary: {
      relationship_types_defined: graph.statistics.relationship_type_count,
      used_relationship_types: graph.statistics.used_relationship_types,
      missing_edge_count: graph.statistics.missing_edge_count,
      external_reference_count: graph.statistics.external_reference_count
    }
  };

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${JSON.stringify(brainPack, null, 2)}\n`);
  fs.writeFileSync(outputV2Path, `${JSON.stringify(toBrainPackV2(brainPack, phase9), null, 2)}\n`);
  fs.writeFileSync(intentOntologyOutputPath, `${JSON.stringify(phase9.engineering_intents.ontology, null, 2)}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)}.`);
  console.log(`Generated ${path.relative(rootDir, outputV2Path)}.`);
}

function toNodeSummary(node) {
  return {
    id: node.id,
    title: node.title,
    technology: node.technology,
    category: node.category,
    type: node.type,
    confidence: node.confidence,
    evidence_level: node.evidence_level,
    importance: node.importance
  };
}

function readPhase9Models() {
  return {
    engineering_intents: {
      ontology: readJson("intent/ontology.json"),
      types: readJson("intent/intent-types.json"),
      detection_model: readJson("intent/intent-detection-model.json")
    },
    constraint_models: {
      engine: readJson("kernel/constraint-engine.json")
    },
    decision_matrices: {
      schema: readJson("brain/decision-matrix.schema.json"),
      matrices: []
    },
    reasoning_models: {
      trace_schema: readJson("brain/reasoning-trace.schema.json"),
      flow: readJson("brain/reasoning-flow.json")
    },
    recommendation_models: {
      v2_document: readText("kernel/recommendation-engine-v2.md")
    },
    learning_models: {
      engine_document: readText("learning/learning-engine.md")
    },
    patterns: {
      schema: readJson("patterns/pattern.schema.json"),
      catalog: readJson("patterns/pattern-catalog.json")
    },
    edrs: {
      schema: readJson("edr/edr.schema.json"),
      records: []
    },
    mission_models: {
      v1_schema: readJson("kernel/schemas/mission.schema.json"),
      v2_schema: readJson("kernel/schemas/mission-v2.schema.json")
    }
  };
}

function readText(relativePath) {
  return fs.readFileSync(path.join(rootDir, relativePath), "utf8");
}

function toBrainPackV2(brainPack, phase9) {
  const constraintDimensions = Object.keys(phase9.constraint_models.engine.dimensions || {});
  const reasoningStages = phase9.reasoning_models.trace_schema.properties.reasoning_trace.items.properties.stage.enum;
  return {
    metadata: {
      name: "Atlas Brain Pack v2",
      version: "0.2",
      generated_at: new Date().toISOString(),
      deterministic: true,
      description: "Engineering Intent Intelligence bundle for deterministic Atlas Kernel reasoning."
    },
    foundation: brainPack,
    engineering_intents: phase9.engineering_intents,
    constraint_models: phase9.constraint_models,
    decision_matrices: phase9.decision_matrices,
    patterns: phase9.patterns,
    edrs: phase9.edrs,
    reasoning_models: phase9.reasoning_models,
    recommendation_models: phase9.recommendation_models,
    learning_models: phase9.learning_models,
    mission_models: phase9.mission_models,
    statistics: {
      intent_type_count: phase9.engineering_intents.types.top_level_intents.length,
      constraint_dimension_count: constraintDimensions.length,
      decision_matrix_count: phase9.decision_matrices.matrices.length,
      pattern_count: phase9.patterns.catalog.patterns.length,
      edr_count: phase9.edrs.records.length,
      reasoning_stage_count: reasoningStages.length,
      node_count: brainPack.node_count,
      edge_count: brainPack.edge_count
    }
  };
}

main();
