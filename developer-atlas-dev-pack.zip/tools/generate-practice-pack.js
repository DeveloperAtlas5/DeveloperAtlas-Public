const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getLearning
} = require("./learning-utils");

const levels = [
  ["rookie", "rookie_practice"],
  ["junior", "junior_practice"],
  ["professional", "professional_practice"]
];

function main() {
  const entries = readCanonIndex().entries || [];
  const pack = {
    generated_at: new Date().toISOString(),
    levels: {
      rookie: [],
      junior: [],
      professional: []
    }
  };

  for (const entry of entries) {
    const learning = getLearning(entry);
    for (const [level, field] of levels) {
      for (const task of learning[field] || []) {
        pack.levels[level].push({
          canon_id: entry.canon_id,
          title: entry.title,
          task_title: task.title,
          task: task.task,
          estimated_minutes: task.estimated_minutes,
          success_criteria: task.success_criteria
        });
      }
    }
  }

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "practice-pack.json"), `${JSON.stringify(pack, null, 2)}\n`);
  fs.writeFileSync(path.join(learningOutputDir, "practice-pack.md"), toMarkdown(pack));

  const count = Object.values(pack.levels).reduce((sum, tasks) => sum + tasks.length, 0);
  console.log(`Generated output/learning/practice-pack.json and output/learning/practice-pack.md with ${count} practice tasks.`);
}

function toMarkdown(pack) {
  const lines = ["# Atlas Practice Pack", ""];
  for (const level of Object.keys(pack.levels)) {
    lines.push(`## ${capitalize(level)}`, "");
    for (const item of pack.levels[level]) {
      lines.push(`### ${item.canon_id}: ${item.task_title}`);
      lines.push("");
      lines.push(`- Canon node: ${item.title}`);
      lines.push(`- Task: ${item.task}`);
      lines.push(`- Estimated time: ${item.estimated_minutes} minutes`);
      lines.push(`- Success criteria: ${item.success_criteria}`);
      lines.push("");
    }
  }
  return `${lines.join("\n").trim()}\n`;
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

main();

