const examples = [
  ["map transform", require("./map-transform")],
  ["forEach side effect", require("./foreach-side-effect")],
  ["Vue-ready transformation", require("./vue-ready-transformation")],
  ["anti-pattern: map used for side effects", require("./anti-pattern-map-side-effects")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-001 example(s).`);
