# props vs local state

## Status Metadata

- Canon ID: CANON-CANDIDATE-VUE-005
- Node ID: canon.vue.components.props-vs-local-state
- Status: candidate
- Score: 55
- Version: 2026.1
- Source family: Vue
- Level: rookie/junior
- Audience: future Rookie-to-Junior frontend path
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Props are data passed from a parent. Local state belongs to the component itself. This candidate supports future Rookie-to-Junior frontend coverage and is not part of the current public alpha mission.

## What Problem This Solves

This reduces beginner confusion around props vs local state by turning the topic into a small decision with practical recovery guidance.

## Mental Model

Props are data passed from a parent. Local state belongs to the component itself.

## Beginner Explanation

Props are data passed from a parent. Local state belongs to the component itself. The goal is not to memorize a rule; the goal is to choose the option that matches what the code is trying to do.

## Professional Explanation

Use this decision to make intent visible in reviews, keep generated code scoped, and reduce hidden maintenance costs. The production signal is code that another developer can explain without reverse-engineering the author's guess.

## Syntax

```text
defineProps({ title: String });
const editing = ref(false);
```

## Decision Guide

1. Name the task in plain language.
2. Choose props when: Use props for data the parent owns and local state for temporary UI details inside the child.
3. Choose local state when it communicates the intent better.
4. If neither fits, pause and look for a prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| props | Use props for data the parent owns and local state for temporary UI details inside the child. | Can confuse beginners when used by habit. |
| local state | A clearer fit when the primary option does not match the task | Can add noise if the project does not need it. |

## When To Use The Primary Option

- Use props for data the parent owns and local state for temporary UI details inside the child.
- Use it when it makes the code easier to explain.
- Use it when it matches the surrounding project convention.

## When To Use The Alternative

- Use it when props would hide the real intent.
- Use it when the alternative gives the learner or reviewer a clearer signal.
- Use it when existing project code already follows that pattern.

## When Not To Use This Decision

- Do not copy props into local state unless you are intentionally editing a draft.
- Do not expand the current Rookie Vue alpha mission just to use this candidate.
- Do not treat this candidate as fully reviewed evidence.

## Alternatives

- Use an existing Gold Candidate node when this topic overlaps one.
- Use a smaller prerequisite concept when the learner is blocked earlier.

## Production Examples

### Beginner Example

```text
const props = defineProps({ todo: Object });
const isEditing = ref(false);
```

### Review Example

```text
Before accepting the code, explain why props or local state matches the task.
```

## Common Mistakes

- Mutating a prop directly inside a child component.
- Copying generated code without checking whether it matches the task.
- Treating the candidate as final before examples and sources are hardened.

## Debugging Checklist

- If parent and child disagree, check whether child state copied a prop and drifted.
- Compare the current behavior with the intended choice.
- Ask whether a smaller prerequisite concept would unblock the learner faster.

## Mechanical Verification

Runnable or deterministic examples should be added during a future hardening sprint. This candidate intentionally has no runnable example folder yet.

## Performance Notes

No performance claim is finalized for this candidate. Future hardening should separate real runtime concerns from readability and learning concerns.

## AI Coding Guidance

- Ask AI to name which component owns each piece of state.
- Ask for a small, scoped change.
- Ask the assistant to explain the trade-off before producing code.

## Teaching Notes

Start with the plain-language model, show the beginner example, then ask the learner to explain the choice back in one sentence. Keep this candidate optional until a mission needs it.

## Interview Questions

1. When would you choose props?
2. What mistake would make local state or another concept clearer?

## Exercises

### Beginner

Split a todo item into a child component with props plus one local edit toggle.

### Junior

Find one example in a small project and explain whether it uses the clearer option.

## Related Atlas Nodes

- CANON-025
- CANON-CANDIDATE-VUE-006

## Evidence And Sources

- Candidate backlog entry only. Official source links must be added during hardening.
- Evidence level: candidate draft.
- Confidence: medium.

## Proof Of Superiority Summary

This candidate has a draft improvement hypothesis only. It should not be treated as reviewed or publication-ready.

## Scorecard Placeholder

- Current score: 55
- Status: candidate
- Needs official sources, stronger examples, verification, editorial review, and reviewer sign-off before any Gold consideration.
