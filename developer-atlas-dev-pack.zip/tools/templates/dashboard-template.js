// Template source for generated Developer Atlas outputs.
// Edit this file first, then run npm run mission and npm run validate:mission.

function renderMissionDashboard() {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Developer Atlas Public Alpha</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f6f7f4;
      --surface: #ffffff;
      --ink: #17201b;
      --muted: #5b675f;
      --line: #d9dfd8;
      --accent: #2f6f63;
      --strong: #20322c;
      --soft: #e8f1ed;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.55;
      color: var(--ink);
      background: var(--bg);
    }

    .shell {
      width: min(1040px, calc(100% - 32px));
      margin: 0 auto;
      padding: 40px 0;
    }

    header {
      padding: 28px 0 20px;
      border-bottom: 1px solid var(--line);
    }

    h1,
    h2 {
      margin: 0;
      letter-spacing: 0;
    }

    h1 {
      font-size: clamp(2rem, 5vw, 3.75rem);
      line-height: 1.05;
    }

    h2 {
      font-size: 1.05rem;
      margin-bottom: 10px;
    }

    p {
      margin: 0;
      color: var(--muted);
    }

    a {
      color: var(--accent);
      font-weight: 700;
      text-decoration-thickness: 2px;
      text-underline-offset: 3px;
    }

    a:focus,
    button:focus {
      outline: 3px solid currentColor;
      outline-offset: 3px;
    }

    button {
      border: 2px solid var(--accent);
      border-radius: 8px;
      background: var(--accent);
      color: #ffffff;
      cursor: pointer;
      font: inherit;
      font-weight: 700;
      padding: 10px 14px;
    }

    button.secondary {
      background: #ffffff;
      color: var(--accent);
    }

    .intro {
      max-width: 720px;
      margin-top: 14px;
      font-size: 1.08rem;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px;
      margin-top: 22px;
    }

    section,
    nav {
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 18px;
    }

    .primary {
      border-color: #9fc6ba;
      background: var(--soft);
    }

    .hero-action {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 14px;
      border: 2px solid var(--strong);
      border-radius: 8px;
      background: var(--strong);
      color: #ffffff;
      padding: 12px 16px;
      text-decoration: none;
    }

    .wide {
      grid-column: 1 / -1;
    }

    .goal-controls {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 12px;
    }

    .goal-button {
      background: #ffffff;
      color: var(--accent);
    }

    .goal-button[aria-pressed="true"] {
      background: var(--strong);
      border-color: var(--strong);
      color: #ffffff;
    }

    [data-goal-panel][hidden] {
      display: none;
    }

    .path {
      display: grid;
      gap: 10px;
      margin-top: 12px;
    }

    .path-links {
      display: flex;
      flex-wrap: wrap;
      gap: 10px 16px;
      margin-top: 12px;
    }

    .path-item {
      padding: 12px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #fbfcfa;
    }

    code {
      font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
      font-size: 0.95em;
      color: var(--strong);
      background: #eef4f1;
      border-radius: 4px;
      padding: 1px 4px;
    }

    ul {
      margin: 10px 0 0;
      padding-left: 20px;
      color: var(--muted);
    }

    li + li {
      margin-top: 6px;
    }

    .note {
      margin-top: 10px;
      font-size: 0.95rem;
    }

    .controls {
      margin-top: 12px;
    }

    .controls button + button {
      margin-left: 8px;
    }

    .status {
      margin-top: 10px;
      color: var(--strong);
      font-weight: 600;
    }

    footer {
      border-top: 1px solid var(--line);
      margin-top: 22px;
      padding-top: 18px;
    }

    @media (max-width: 720px) {
      .shell {
        width: min(100% - 24px, 1040px);
        padding: 24px 0;
      }

      .grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <header class="shell">
    <h1>Developer Atlas Public Alpha</h1>
    <p class="intro">Developer Atlas helps learners and AI-assisted builders know what to do next without getting overwhelmed.</p>
  </header>

  <main class="shell">
    <div class="grid">
      <section class="primary wide" aria-labelledby="start-here">
        <h2 id="start-here">Start here</h2>
        <p>This dashboard is the main entry point. You do not need to browse the folders.</p>
        <p class="note">Use <a href="START_HERE.md">START_HERE</a> only if you want the short written map.</p>
      </section>

      <section class="primary wide" aria-labelledby="recommended-first-step">
        <h2 id="recommended-first-step">Recommended first step</h2>
        <p>The first screen should show the next useful action, not the whole product.</p>
        <a class="hero-action" href="mission/today-mission-surface.md">Start Mission 1</a>
        <p class="note">Read here. Code in your Vue todo project.</p>
        <p class="note">First time? <a href="first-time-quick-start.md">Open the quick start</a>.</p>
        <p class="note">Mission 1 remains the primary tester path.</p>
      </section>

      <section class="primary wide" aria-labelledby="choose-goal">
        <h2 id="choose-goal">Need a different path?</h2>
        <p>Choose a different goal only if the recommended first step is not the path you need.</p>
        <div class="goal-controls" role="group" aria-label="Choose a dashboard goal">
          <button type="button" class="goal-button" data-goal="starting" aria-controls="panel-starting" aria-pressed="true" aria-label="Start - begin with Mission 1">Start</button>
          <button type="button" class="goal-button" data-goal="continuing" aria-controls="panel-continuing" aria-pressed="false" aria-label="Continue - go to Mission 2 or Mission 3">Continue</button>
          <button type="button" class="goal-button" data-goal="ai" aria-controls="panel-ai" aria-pressed="false" aria-label="Use AI - use scoped AI guidance">Use AI</button>
          <button type="button" class="goal-button" data-goal="stuck" aria-controls="panel-stuck" aria-pressed="false" aria-label="I'm stuck - open recovery and help">I'm stuck</button>
          <button type="button" class="goal-button" data-goal="reviewing" aria-controls="panel-reviewing" aria-pressed="false" aria-label="Review - inspect feedback and QA files">Review</button>
        </div>
        <p class="note">Progressive visibility: show only what helps the user's current goal.</p>
      </section>

      <section class="primary wide" aria-labelledby="read-aloud">
        <h2 id="read-aloud">Read-aloud option</h2>
        <p>Use this optional control if listening helps. It reads a short dashboard summary only after you press the button.</p>
        <div class="controls">
          <button type="button" id="read-dashboard">Read dashboard aloud</button>
          <button type="button" id="stop-reading" class="secondary">Stop reading</button>
        </div>
        <p class="status" id="read-status" aria-live="polite">Read-aloud is ready if your browser supports it.</p>
      </section>

      <nav class="wide" aria-label="Dashboard sections">
        <h2>Dashboard sections</h2>
        <div class="path-links">
          <a href="#recommended-first-step">Recommended first step</a>
          <a href="#choose-goal">Need a different path?</a>
          <a href="#read-aloud">Read-aloud option</a>
          <a href="#ignore">What you can ignore</a>
        </div>
      </nav>

      <section class="wide primary" aria-labelledby="fastest-path">
        <h2 id="fastest-path">Fastest path</h2>
        <p><strong>Fastest path:</strong> Choose your goal, open the mission link shown there, use help only if needed, answer feedback at the end.</p>
      </section>

      <section class="wide" id="panel-starting" data-goal-panel="starting" aria-labelledby="starting-path">
        <h2 id="starting-path">Starting path</h2>
        <p>Start with Mission 1. Use help only if you get stuck. Answer feedback after testing.</p>
        <div class="path">
          <div class="path-item">
            <strong>Main step</strong>
            <p><a href="mission/today-mission-surface.md">Open Mission 1</a></p>
          </div>
          <div class="path-item">
            <strong>Optional support</strong>
            <ul>
              <li><a href="help/terminal-confidence-guide.md">Optional terminal help</a></li>
              <li><a href="help/vue-concept-cards.md">Optional Vue concept cards</a></li>
              <li><a href="help/beginner-orientation.md">Optional beginner orientation</a></li>
            </ul>
          </div>
        </div>
      </section>

      <section class="wide" id="panel-continuing" data-goal-panel="continuing" aria-labelledby="continuing-path" hidden>
        <h2 id="continuing-path">Continuing path</h2>
        <p><code>Mission 1 -> Mission 2 -> Mission 3</code></p>
        <p class="note">Mission 1 remains the primary tester path. Mission 2: Open after Mission 1. Mission 3: Open after Mission 2.</p>
        <p class="note">Open the next mission only after finishing the previous one.</p>
        <div class="path-links">
          <a href="mission/mission-02-todoitem-surface.md">Open Mission 2</a>
          <a href="mission/mission-03-todostats-surface.md">Open Mission 3</a>
        </div>
      </section>

      <section class="wide" id="panel-ai" data-goal-panel="ai" aria-labelledby="ai-path" hidden>
        <h2 id="ai-path">AI-assisted path</h2>
        <p>Use this path when AI helps you write code.</p>
        <ul>
          <li>Give AI one mission at a time.</li>
          <li>Reject architecture expansion.</li>
          <li>Ask AI to explain what changed before you accept it.</li>
          <li>Ask AI for a readable answer with file names, spacing, and verification steps.</li>
          <li>If AI suggests cleaner architecture, park it unless the mission asks for it.</li>
          <li>If you are not using a <code>.vibe.md</code> file, start with the universal AI preamble in <code>ai/ai-prompt-pack.md</code>.</li>
        </ul>
        <div class="path-links">
          <a href="mission/today-mission-surface.vibe.md">Open AI Mission 1</a>
          <a href="mission/mission-02-todoitem-surface.vibe.md">Open AI Mission 2</a>
          <a href="mission/mission-03-todostats-surface.vibe.md">Open AI Mission 3</a>
          <a href="ai/ai-prompt-pack.md">Optional: AI prompt pack</a>
        </div>
        <p class="note">Accept small mission changes. Reject new architecture.</p>
      </section>

      <section class="wide" id="panel-stuck" data-goal-panel="stuck" aria-labelledby="stuck-path" hidden>
        <h2 id="stuck-path">I am stuck</h2>
        <p>Pick the blocker first.</p>
        <ul>
          <li>Terminal problem -> <a href="help/terminal-confidence-guide.md">terminal guide</a>.</li>
          <li>Vue concept problem -> <a href="help/vue-concept-cards.md">concept cards</a>.</li>
          <li>Not sure where to edit -> open the current mission's placement section.</li>
          <li>Too much to read -> use read-aloud or Mission 1 only.</li>
        </ul>
        <p class="note"><a href="mission/today-mission-surface.md#if-you-get-stuck">Open Mission 1 recovery</a>.</p>
      </section>

      <section class="wide" id="panel-reviewing" data-goal-panel="reviewing" aria-labelledby="reviewer-path" hidden>
        <h2 id="reviewer-path">Reviewer path</h2>
        <p>This path is for reviewers, mentors, or the project owner.</p>
        <ul>
          <li><a href="mission/mission-feedback-template.md">Open tester feedback template</a>.</li>
          <li><a href="reviewer/alpha-package-final-qa.md">Open final QA report</a>.</li>
          <li><a href="reviewer/alpha-focus-lock.md">Open alpha focus lock</a>.</li>
          <li><a href="reviewer/human-ai-readability-audit.md">Open human-AI readability audit</a>.</li>
          <li><a href="reviewer/ai-guardrail-evaluation.md">AI guardrail evaluation</a>.</li>
          <li><a href="reviewer/ai-guardrail-red-team-pack.md">AI guardrail red-team pack</a>.</li>
          <li><a href="reviewer/ai-red-team-results-template.md">AI red-team results template</a>.</li>
        </ul>
        <p class="note">Accessibility principle: readable, listenable, keyboard-friendly, screen-reader-aware, calm, recoverable, AI-assistable, and broken into small wins.</p>
      </section>

      <section class="wide" aria-labelledby="optional-reference">
        <h2 id="optional-reference">Optional reference</h2>
        <p>Optional reference: <a href="reference/canon/hardened/">hardened Canon notes</a>.</p>
        <p class="note">Optional lookup: <a href="concepts/index.md">Concept Library</a>.</p>
        <p class="note">Need to start or open a project first? <a href="project-start/index.md">Project Start Guides</a>.</p>
        <p class="note">These notes support Missions 1-3. They are not required before starting Mission 1.</p>
      </section>

      <section class="wide" aria-labelledby="ignore">
        <h2 id="ignore">What you can ignore</h2>
        <p>Normal testers do not need to read everything. You can ignore these unless you are reviewing the project itself:</p>
        <ul>
          <li>Package manifest.</li>
          <li>Feedback owner reports.</li>
          <li>Readiness reports.</li>
          <li>Focus lock.</li>
          <li>Source/build scripts.</li>
          <li>Technical internals.</li>
        </ul>
      </section>
    </div>
  </main>

  <footer class="shell">
    <p>Accessibility foundation: readable, listenable, keyboard-friendly, screen-reader-aware, calm, recoverable, AI-assistable, and broken into small wins.</p>
  </footer>

  <script>
    const dashboardSummary = "Developer Atlas public alpha. Start with Mission 1. Use Atlas as the guide. Write code in your own Vue todo project. Use a different goal only if you are continuing, using AI, stuck, or reviewing. Mission 2 comes after Mission 1. Mission 3 comes after Mission 2. Use optional help only when you need it.";
    const readButton = document.getElementById("read-dashboard");
    const stopButton = document.getElementById("stop-reading");
    const readStatus = document.getElementById("read-status");
    const goalButtons = Array.from(document.querySelectorAll("[data-goal]"));
    const goalPanels = Array.from(document.querySelectorAll("[data-goal-panel]"));

    function setReadStatus(message) {
      readStatus.textContent = message;
    }

    function showGoal(goal) {
      goalPanels.forEach((panel) => {
        const active = panel.dataset.goalPanel === goal;
        panel.hidden = !active;
      });

      goalButtons.forEach((button) => {
        button.setAttribute("aria-pressed", String(button.dataset.goal === goal));
      });
    }

    goalButtons.forEach((button) => {
      button.addEventListener("click", () => showGoal(button.dataset.goal));
    });

    showGoal("starting");

    readButton.addEventListener("click", () => {
      if (!("speechSynthesis" in window) || typeof SpeechSynthesisUtterance === "undefined") {
        setReadStatus("Read-aloud is not supported in this browser.");
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(dashboardSummary);
      utterance.onstart = () => setReadStatus("Reading dashboard summary.");
      utterance.onend = () => setReadStatus("Read-aloud finished.");
      utterance.onerror = () => setReadStatus("Read-aloud stopped.");
      window.speechSynthesis.speak(utterance);
    });

    stopButton.addEventListener("click", () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
      setReadStatus("Read-aloud stopped.");
    });
  </script>
</body>
</html>
`;
}

module.exports = {
  renderMissionDashboard
};
