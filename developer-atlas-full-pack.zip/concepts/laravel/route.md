# Laravel Route

Technology: Laravel

## Simple meaning

A route matches a URL and HTTP method to the code Laravel should run.

## Why it exists

Routes let the app decide what should happen when someone visits a page or sends an API request.

## Where you use it

In route files such as `routes/web.php` and `routes/api.php`.

## When to use it

Use a route when you need a URL to show a page, submit a form, or return data.

## Tiny example

`Route::get('/posts', [PostController::class, 'index']);`

## Common beginner confusion

Beginners often mix up the route and the controller. The route is the address; the controller is the code that handles the request.

## Related concepts

- Controller
- Middleware
- Request

## Similar idea in another technology

Vue Router also maps URLs to what the user sees, but it usually changes the browser view instead of handling a server request.
