const path = require("path");

const sitePath = path.join(__dirname, "..", "site", "index.html");

console.log("Developer Atlas static landing page");
console.log("");
console.log(`Open this file in your browser: ${sitePath}`);
console.log("");
console.log("Public alpha guide: output/experience/START_HERE.md");
console.log("Primary demo after the landing page: output/experience/today-mission-surface.md");
console.log("Optional AI-assisted builder view: output/experience/today-mission-surface.vibe.md");
console.log("Optional project-owner feedback template: output/experience/tester-feedback-report.md");
console.log("Then inspect: output/mission/today-mission.md or output/flow/rookie-vue-todo-flow.md");
console.log("");
console.log("No dev server is required. This is plain HTML and CSS.");
