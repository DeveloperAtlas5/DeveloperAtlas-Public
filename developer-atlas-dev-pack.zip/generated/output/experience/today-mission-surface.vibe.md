# Welcome back

This is the AI-assisted version of today's mission. Use it when you want help from an AI coding tool without letting the task grow too large.

## Today's AI-assisted Mission

Use AI to make your Vue todo app remember tasks after refresh without letting it rewrite the whole app.

## Quick Start With AI

1. Open your Vue project.
2. Ask AI to identify where the todo state currently lives.
3. Tell AI to keep the change near the existing todo state.
4. Tell AI not to create new architecture.
5. Let AI change only the smallest needed file or files.
6. Test refresh persistence before accepting the change.
7. Ask AI to explain the final change back to you.

## Goal

Your todo list should survive a page refresh using `localStorage`.

- `localStorage` is appropriate for non-sensitive todo data that should survive refresh and browser restart.
- `sessionStorage` can survive refresh, but it is limited to the current tab/session.
- Neither should be used for sensitive data.
- Vue state controls what the app shows now.
- Browser storage controls what can be restored later.

## Where this work happens

Work in your Vue todo project.

Use this mission file as the guide.

Do not edit the Atlas package files.

## AI mission boundary

AI should complete Mission 1, not redesign the project.

Edit my Vue todo project, not the Atlas package.

Goal: make todos survive refresh.

Likely file: `src/App.vue`.

Keep todo state in `App.vue`.

Use localStorage only for persistence.

Do not create new components for Mission 1.

Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.

Keep the smallest useful change.

Do not accept "cleaner", "production-ready", "more reusable", or "proper architecture" changes if they add files or architecture outside this mission.

For Mission 1, even useful-sounding improvements belong later if they move state out of `App.vue`, add new files, or change architecture.

If the answer changes too much, reject it and ask for a smaller patch.

## Copy/paste prompt

```txt
You are helping me with Developer Atlas Mission 1.

Edit my Vue todo project, not the Atlas package.

Goal: make my todos survive page refresh.

Use the smallest useful change.

Keep todo state in `src/App.vue`.

Use localStorage only for persistence.

Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, new components, or a new architecture.

Format your answer with clear headings, file names, small code blocks, spacing, and verification steps.

Make the answer easy for me, another human, or a future AI session to understand later.

If I ask for cleaner, production-ready, reusable, or faster changes that go beyond this mission, park those ideas and keep the smallest current-mission patch.

After the change, explain what changed and how I can verify it.
```

## What to ask AI

Copy and paste this prompt:

```txt
I am building a Vue 3 todo app. Edit my Vue todo project, not the Atlas package. Add localStorage persistence for non-sensitive todo items. Only change the todo state logic, usually in src/App.vue for this mission. Do not add backend, auth, Pinia, routing, database, deployment, or a new architecture. Explain every changed line.
```

## What AI may change

- `src/App.vue`.
- Existing todo state logic.
- localStorage save/load code for non-sensitive todo data.

## What AI must not change

- Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.
- Do not create new components for Mission 1.
- Do not rewrite the whole app.
- Do not change unrelated styling.

## Before you accept the answer

- Confirm the change is small.
- Confirm the likely file is `src/App.vue`.
- Confirm todos survive refresh.
- Confirm AI explains what changed before I accept the answer.

## Ask AI to explain it back

Explain what changed before I accept the answer. Use plain language and tell me how to verify the mission checklist.

## What to accept

Accept changes that:

- Keep the change minimal.
- Stay near the existing todo state.
- Preserve the current app structure.
- Explain which files changed and why.
- Save todos with `JSON.stringify()`.
- Load todos with `JSON.parse()`.
- Use the same storage key when saving and loading.
- Keep Vue state separate from browser storage.
- Keep storage for non-sensitive todo data only.
- Keep existing working features intact.
- Include a simple test path.

## What to reject

Reject changes that:

- Add a new component structure unless the project already uses it.
- Add a new store or composable unless it already exists and is the natural location.
- Move state into a new architecture.
- Rewrite the app.
- Change unrelated files.
- Add Pinia, routing, backend, auth, database, deployment, or cloud sync.
- Add abstractions `for later`.
- Store sensitive data.
- Introduce many new files.
- Remove existing working features.

## Recovery prompt

```txt
Please make a smaller patch. Only change the files needed for Developer Atlas Mission 1. Undo the extra architecture and return to the smallest solution for this mission.
```

## Files likely to change

- `App.vue`.
- Maybe one existing todo component.
- Maybe one existing composable or store file, but only if the project already has one.

This mission should usually not require many file changes.

## Where AI should place the change

Optional help: `help/beginner-orientation.md` if you are unsure which folder is your actual Vue project.

Tell AI to edit your Vue todo project, not the Atlas package.

Ask AI to place the storage logic near the existing todo state. In a small Vue app, that is usually `App.vue`. If the project already has a todo composable or store, AI may use that existing file.

AI should not create a new architecture just to add `localStorage`. It should not modify router, backend, `package.json`, deployment, auth, or unrelated styling for this mission. Ask it to explain why each changed file is necessary.

Copy and paste this prompt fragment:

```txt
Place the localStorage logic near the existing todo state. Do not create new architecture. Before changing files, tell me which file you will edit and why.
```

## Files that should not change today

- Router files.
- Backend files.
- `package.json`.
- Deployment files.
- Build config.
- Unrelated styling files.
- Authentication files.

## Test the result

1. Add a todo.
2. Refresh the page.
3. Confirm the todo is still visible.
4. Complete or edit a todo if the app supports it.
5. Refresh again.
6. Confirm the state still works.
7. Check the browser console for errors.

## Completion checklist

- [ ] The todo survives refresh.
- [ ] AI changed only the files needed for this mission.
- [ ] AI did not add backend, auth, Pinia, routing, database, deployment, or a new architecture.
- [ ] I understand which file changed and why.
- [ ] The storage key is consistent when saving and loading.
- [ ] The code uses `JSON.stringify()` when saving objects or arrays.
- [ ] The code uses `JSON.parse()` when loading saved todos.
- [ ] I checked the browser console for errors.

## If AI breaks it

If the terminal output is confusing, copy the command, folder path, and last terminal lines before asking AI for help.

Optional help: `help/terminal-confidence-guide.md` for terminal commands and project-folder checks.

Use this recovery prompt first:

```txt
Do not rewrite the app. Compare the previous version and current version. Identify the smallest change that caused the todo list to stop working.
```

Then use this cleanup prompt if needed:

```txt
Undo any unrelated changes. Keep only the smallest localStorage persistence change.
```

Storage-specific checks:

- Confirm the same storage key is used for saving and loading.
- Confirm `JSON.stringify()` happens before saving arrays or objects.
- Confirm `JSON.parse()` happens when loading stored todos.
- Avoid `[object Object]` by not saving raw objects directly.
- Handle empty storage safely with a fallback.
- Use `localStorage` instead of `sessionStorage` for this mission.

## Explain it back

Optional help: `help/vue-concept-cards.md` if AI uses Vue words you do not fully understand.

After the code works, ask:

```txt
Explain how Vue state and localStorage work together in this code in beginner-friendly language. Then quiz me with three small questions to check if I understood.
```

## Skip today

- Backend.
- Login/auth.
- Database.
- Cloud sync.
- Pinia.
- Routing.
- Deployment.
- Encryption/security architecture.
- Full app rewrite.

## Next mission preview

After this, you can learn how to extract the todo item into a reusable component.

## After the mission

Before you asked AI, how confident did you feel?

1 2 3 4 5

After testing the AI-assisted change, how confident do you feel now?

1 2 3 4 5

Did the AI change stay inside the mission scope?

- Yes
- Mostly
- No, it changed too much

Did you reject or undo any unnecessary AI changes?

- Yes
- No
- Not needed

Did Atlas help you recover when AI broke or over-expanded the code?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.
