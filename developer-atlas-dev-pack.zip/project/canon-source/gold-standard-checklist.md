# Gold Standard Checklist

A Canon node cannot become Gold unless it has:

- Score of 95 or higher.
- Proof of superiority.
- Evidence references.
- Working examples.
- Decision guidance.
- AI coding guidance.
- Related graph links.
- Beginner explanation.
- Professional explanation.
- Production examples.
- Common mistakes.
- Debugging checklist.
- Exercises.
- Clear trade-offs.

Gold means the node is good enough to become a teaching, reference, advisor, and AI-generation source.

