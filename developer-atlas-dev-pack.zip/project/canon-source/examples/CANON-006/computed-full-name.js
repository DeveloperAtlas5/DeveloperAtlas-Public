const { computed, ref } = require("./reactivity-sim");

module.exports = function runComputedFullName() {
  const firstName = ref("Ada");
  const lastName = ref("Lovelace");

  const fullName = computed(() => `${firstName.value} ${lastName.value}`);

  if (fullName.value !== "Ada Lovelace") {
    throw new Error(`Expected Ada Lovelace, got ${fullName.value}`);
  }

  firstName.value = "Grace";
  lastName.value = "Hopper";

  if (fullName.value !== "Grace Hopper") {
    throw new Error(`Expected Grace Hopper after source update, got ${fullName.value}`);
  }
};
