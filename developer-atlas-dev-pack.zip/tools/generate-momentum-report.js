const fs = require("fs");
const path = require("path");
const {
  momentumOutputDir,
  ensureMomentumOutputDir,
  readMomentumSessions
} = require("./momentum-utils");

function main() {
  const sessions = readMomentumSessions().map((record) => record.session);
  const report = buildReport(sessions);

  ensureMomentumOutputDir();
  fs.writeFileSync(
    path.join(momentumOutputDir, "momentum-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(momentumOutputDir, "momentum-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/momentum/momentum-report.json for ${sessions.length} session(s).`);
  console.log("Generated output/momentum/momentum-report.md.");
}

function buildReport(sessions) {
  const timeLostWithoutAtlas = sum(sessions, "estimated_time_lost_without_atlas");
  const timeLostWithAtlas = sum(sessions, "estimated_time_lost_with_atlas");
  const averageConfidenceBefore = average(sessions.map((session) => session.confidence_before));
  const averageConfidenceAfter = average(sessions.map((session) => session.confidence_after));
  const blockerCounts = countValues(sessions.flatMap((session) => session.blockers_encountered));

  return {
    sessions_processed: sessions.length,
    blockers_encountered: sessions.reduce((sum, session) => sum + session.blockers_encountered.length, 0),
    estimated_time_saved: timeLostWithoutAtlas - timeLostWithAtlas,
    average_confidence_before: round(averageConfidenceBefore),
    average_confidence_after: round(averageConfidenceAfter),
    confidence_improvement: round(averageConfidenceAfter - averageConfidenceBefore),
    most_common_blockers: blockerCounts,
    recommended_next_friction_nodes: recommendedFrictionNodes(blockerCounts),
    recommended_toolkit_improvements: recommendedToolkitImprovements(blockerCounts),
    recommended_learning_improvements: recommendedLearningImprovements(sessions)
  };
}

function recommendedFrictionNodes(blockerCounts) {
  const known = new Set(blockerCounts.map((item) => item.value));
  const recommendations = [];

  if (!known.has("friction.node.version_mismatch")) recommendations.push("Add a Node/PHP version mismatch Friction Node.");
  if (!known.has("friction.database.connection_refused")) recommendations.push("Add a database connection refused Friction Node.");
  recommendations.push("Add a PATH diagnostics tree that covers PHP, Composer, Node, and Git.");

  return recommendations;
}

function recommendedToolkitImprovements(blockerCounts) {
  const values = new Set(blockerCounts.map((item) => item.value));
  const recommendations = [];

  if (values.has("friction.javascript.npm.install_fails")) {
    recommendations.push("Add a Node version manager tool recommendation.");
  }
  if (values.has("friction.php.composer.not_recognized") || values.has("friction.php.php_not_in_path")) {
    recommendations.push("Add a Windows PATH verification setup checklist.");
  }
  recommendations.push("Add a database GUI or local database setup profile for Laravel learners.");

  return recommendations;
}

function recommendedLearningImprovements(sessions) {
  const recommendations = [
    "Add a short lesson on reading terminal errors before retrying commands.",
    "Add setup verification as the first checkpoint in beginner learning paths."
  ];

  if (sessions.some((session) => session.learner_profile.includes("rookie"))) {
    recommendations.push("Add rookie reassurance notes to setup and recovery learning plans.");
  }

  return recommendations;
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Momentum Report",
    "",
    `Sessions processed: ${report.sessions_processed}`,
    `Blockers encountered: ${report.blockers_encountered}`,
    `Estimated time saved: ${report.estimated_time_saved} minutes`,
    `Average confidence before: ${report.average_confidence_before}`,
    `Average confidence after: ${report.average_confidence_after}`,
    `Confidence improvement: ${report.confidence_improvement}`,
    "",
    "## Most Common Blockers",
    "",
    ...formatCounts(report.most_common_blockers),
    "",
    "## Recommended Next Friction Nodes",
    "",
    ...formatList(report.recommended_next_friction_nodes),
    "",
    "## Recommended Toolkit Improvements",
    "",
    ...formatList(report.recommended_toolkit_improvements),
    "",
    "## Recommended Learning Improvements",
    "",
    ...formatList(report.recommended_learning_improvements)
  ];

  return `${lines.join("\n")}\n`;
}

function sum(items, field) {
  return items.reduce((total, item) => total + Number(item[field] || 0), 0);
}

function average(values) {
  return values.length ? values.reduce((total, value) => total + value, 0) / values.length : 0;
}

function round(value) {
  return Number(value.toFixed(2));
}

function countValues(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
