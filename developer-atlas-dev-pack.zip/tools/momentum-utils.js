const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const momentumDir = path.join(rootDir, "momentum");
const momentumExamplesDir = path.join(momentumDir, "examples");
const momentumOutputDir = path.join(rootDir, "output", "momentum");

function ensureMomentumOutputDir() {
  fs.mkdirSync(momentumOutputDir, { recursive: true });
}

function readMomentumSessions() {
  if (!fs.existsSync(momentumExamplesDir)) return [];

  return fs.readdirSync(momentumExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(momentumExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        session: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

module.exports = {
  momentumDir,
  momentumExamplesDir,
  momentumOutputDir,
  ensureMomentumOutputDir,
  readMomentumSessions
};
