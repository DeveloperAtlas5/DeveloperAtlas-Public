# Developer Atlas Alpha Focus Lock

## Summary

Atlas has a strong long-term vision, but the public alpha must stay narrow. The purpose of this focus lock is to protect Atlas from becoming too broad before the first real tester loop.

Test the current slice before building more.

## Core Alpha Bet

Atlas can help rookie-to-junior developers and AI-assisted builders make progress without getting lost.

This is the current testable wedge.

## Current Winning Slice

Rookie Vue Todo + browser storage persistence + recovery + AI-scoped mission guidance.

Why this slice is strong:

- It creates a visible win.
- It is beginner-friendly.
- It is useful for AI-assisted builders.
- It tests mission, recovery, placement, checklist, and reflection.
- It is narrow enough to validate.

## Build Now

- Improve beginner setup orientation.
- Improve Vue concept clarity for the current Rookie Vue slice.
- Improve terminal confidence for the current Rookie Vue slice.
- Improve package simplification and navigation clarity.
- Improve mission dashboard / package lightness.
- Improve mission scannability and redundancy polish.
- Improve beginner setup clarity.
- Improve file/folder orientation.
- Improve terminal command clarity.
- Improve Vue concept clarity for `ref()`, `reactive()`, and `:key`.
- Improve mission surface polish.
- Improve internal terminology cleanup in packaged learner-facing files.
- Collect real tester feedback.
- Refine the Rookie Vue path.
- Add Mission 2 only as the next Rookie Vue mission after Mission 1.
- Polish Mission 2 clarity for parent-child communication and AI scope control.
- Add Mission 3 only as the next Rookie Vue mission after Mission 2.
- Improve dashboard filtering for the user's current goal.
- Simplify the dashboard so the recommended first action appears before optional paths.
- Add the smallest first-time quick start for Mission 1.
- Harden only Canon nodes used by Missions 1-3.
- Clarify where learners read and where they code.
- Harden the AI-assisted path for Missions 1-3 without adding product scope.
- Add AI guardrail evaluation for the current AI-assisted Rookie Vue path.
- Add AI output readability guardrails for the current AI-assisted Rookie Vue path.
- Add an AI guardrail red-team pack for the current AI-assisted Rookie Vue path.

Mission 2 is allowed because it extends the current Rookie Vue slice and tests momentum. It does not expand into a new product line.

Mission 2 clarity polish is allowed because it improves the current Rookie Vue progression path without adding a new product line.

Mission 2 visual bridge and stricter AI guardrails are allowed because they improve the current Rookie Vue progression path without adding a new product line.

Mission 3 is allowed because it extends the current Rookie Vue Todo path and tests progression without adding a new product line.

Goal-based dashboard filtering is allowed because it reduces friction in the current Rookie Vue path without adding a new product line.

Progressive visibility: show only what helps the user's current goal.

Dashboard simplification is allowed because it reduces choice pressure in the current Rookie Vue path without adding a new product line.

The first screen should show the next useful action, not the whole product.

Quick-start and hardened Canon integration is allowed because it supports the current Rookie Vue path without adding a new product line.

Harden only Canon nodes used by Missions 1-3 before expanding the backlog.

Workspace clarity is allowed because it reduces friction in the current Rookie Vue path without adding scope.

AI-assisted path hardening is allowed because it supports the current Rookie Vue path without adding new product scope.

AI guardrail evaluation is allowed because it tests the current AI-assisted Rookie Vue path without adding new product scope.

AI output readability guardrails are allowed because they strengthen the current AI-assisted Rookie Vue path without adding new product scope.

AI guardrail red-team pack is allowed because it tests the current AI-assisted Rookie Vue path without adding learner scope.

AI red-team result capture is allowed because it supports testing the current AI-assisted Rookie Vue path without adding learner scope.

AI drift tightening is allowed because it strengthens the current AI-assisted Rookie Vue path without adding learner scope.

Learner-first package structure is allowed because it reduces first-impression file overwhelm without adding learner scope.

Accessibility foundation work is allowed because it improves the current Rookie Vue learner experience without adding a new product line.

After adding beginner, Vue concept, and terminal support, the next narrow improvement is to reduce package navigation friction rather than adding more guidance files.

The 50-tester simulation supports a lighter package entry point before adding more Canon or new product lines.

After the dashboard and package simplification improvements, the next step is real tester evidence, not more support files.

Latest feedback supports polishing the current alpha flow, not adding more content or product lines.

## Build Next

Only consider these after feedback:

- Next Rookie Vue mission.
- Small concept clarity cards.
- Better site preview flow.
- Simple code placement examples.
- Stronger feedback triage from real testers.
- One additional stack only if Vue alpha shows strong signal.

## Not Yet

These ideas may be valid later, but they are not alpha priorities:

- Enterprise/team plans.
- Private Canon.
- Marketplace.
- Certifications.
- University partnerships.
- Full IDE extension.
- CLI.
- API/data licensing.
- Public Canon contribution system.
- Multi-stack expansion.
- Dashboards/accounts.
- Analytics infrastructure.

## Do Not Build Before Feedback

Do not build these before testing with 3-5 real users:

- New product lines.
- New intelligence systems.
- Large roadmaps.
- Enterprise features.
- Certification.
- Marketplace.
- Full IDE extension.
- Big UI redesign.
- Large Canon expansion.

The updated feedback supports beginner orientation as the next narrow fix. It does not justify expanding into new product lines yet.

The latest simulated feedback supports terminal confidence as the next narrow fix. It does not justify starting IDE extension work yet.

## Product Risks

- Scope creep.
- Content bottleneck.
- Document-heavy UX.
- Internal terminology leakage.
- Maintenance burden.
- Unclear distribution.
- Too much architecture before usage proof.

## Content Strategy

- Canon quality matters more than Canon quantity.
- Do not chase node count.
- Add Canon only when a mission needs it.
- Prefer one high-quality mission loop over many shallow topics.
- Use tester confusion to decide the next Canon or concept card.

## UX Strategy

- The user should see one clear mission.
- Internal systems should stay invisible.
- Supporting files should be optional.
- Reduce document heaviness over time.
- The mission surface should become the future product surface.

## Business Strategy

- Do not optimize for fundraising yet.
- Do not build enterprise before usage proof.
- Initial wedge should be individual learners and AI-assisted builders.
- Early pricing hypotheses can be Pro and small team plans later.
- Distribution should start with small tester loops, learning communities, and developer Discords before large-scale go-to-market.

## Alpha Success Metrics

- Tester knows what to open first.
- Tester knows what to do next.
- Tester completes visible win or understands blocker.
- Confidence delta increases.
- Recovery section helps.
- Vibe-coder view prevents AI over-expansion.
- Tester would use Atlas again.
- Repeated confusion decreases after fixes.

## Expansion Triggers

Only expand beyond Rookie Vue when:

- At least 5-10 real testers complete the loop.
- Most testers understand the mission without explanation.
- At least 60-70% report confidence improvement.
- Repeated beginner confusion is addressed.
- Vibe-coder users report accept/reject guidance is useful.
- The package no longer feels too document-heavy.

## Next Action

Send the current package to 3-5 real testers before adding new product lines.

Use real feedback to choose between beginner orientation, Vue concept clarity, or mission surface simplification as the next fix.
