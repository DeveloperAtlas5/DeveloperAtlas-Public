# Constraint Specification

Constraints describe the conditions that affect a recommendation.

## Purpose

The Constraint Engine should make Atlas recommendations context-aware instead of generic.

## Constraint Categories

- `persona`: rookie, junior, mid_level, senior, staff_engineer, cto, ai_coding_assistant.
- `technology`: language, framework, runtime, tool, database.
- `difficulty`: beginner, intermediate, advanced, expert.
- `output_shape`: code, explanation, decision record, troubleshooting steps, learning path.
- `production_risk`: low, medium, high.
- `performance_sensitivity`: low, medium, high.
- `security_sensitivity`: low, medium, high.
- `maintainability_priority`: low, medium, high.
- `time_constraint`: exploratory, normal, urgent.
- `existing_conventions`: project or team constraints.

## Outputs

- Normalized constraints.
- Warnings for missing constraints that materially affect the decision.
- Constraint weights for future ranking.

## Rule

Ask clarifying questions only when missing constraints would materially change the recommendation.
