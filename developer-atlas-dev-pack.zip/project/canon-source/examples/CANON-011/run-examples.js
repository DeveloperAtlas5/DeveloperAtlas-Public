const examples = [
  ["async/await for readable sequential flow", require("./async-await-sequential-flow")],
  ["Promise.then() for compact transformation chain", require("./promise-then-transformation-chain")],
  ["mistake: missing return in .then() callback", require("./mistake-missing-return-in-then")],
  ["mistake: try/catch without await", require("./mistake-try-catch-without-await")]
];

(async () => {
  for (const [name, run] of examples) {
    await run();
    console.log(`PASS ${name}`);
  }

  console.log(`Verified ${examples.length} CANON-011 example(s).`);
})().catch((error) => {
  console.error(`FAIL ${error.message}`);
  process.exitCode = 1;
});
