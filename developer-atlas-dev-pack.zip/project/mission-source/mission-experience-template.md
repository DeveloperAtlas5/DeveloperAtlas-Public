# Mission Experience Template

Use this structure for future Mission outputs.

## Mission Title

Use an action-oriented title that says what the user will finish.

## Why This Mission Matters

Explain why this mission is worth doing now. Keep it short and confidence-building.

## Mission Snapshot

- Estimated time
- Difficulty
- Confidence

## Today's Objective

State one clear outcome.

## What Atlas Already Checked

Summarize the behind-the-scenes systems:

- Goal
- Readiness
- Setup
- Recovery
- Learning
- Capability
- AI context

## What To Do First

Give the smallest useful next step.

## Today's Canon

List only the Canon nodes that matter for this mission.

## Today's Project

Name the project and the expected output.

## Today's Setup Check

Give one verification check before building.

## Likely Blocker

Name the most likely blocker without making it feel scary.

## Recovery Prepared

Give the safe first fix and verification steps.

## AI Context Available

Point to the AI context pack if useful.

## What To Ignore Today

Tell the user what can safely wait.

## Visible Win

Describe what the user will be able to see, run, or explain after finishing.

## Next Mission Preview

Preview the next mission without pulling attention away from today.

## Confidence Note

End with calm encouragement grounded in the mission outcome.
