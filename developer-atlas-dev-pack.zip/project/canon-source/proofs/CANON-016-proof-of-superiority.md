# CANON-016 Proof Of Superiority

Canon ID: CANON-016
Node ID: canon.javascript.error.try-catch-vs-promise-catch
Title: try/catch vs Promise.catch()

## What Official Docs Explain Well

MDN and the ECMAScript specification explain `try...catch`, async functions, promise rejection handling, and `Promise.prototype.catch()`.

## What Developers Still Struggle With

Developers rarely struggle because they cannot type the syntax. They struggle because the failure boundary is in the wrong place:

- `try/catch` wraps a promise that is never awaited.
- `.catch()` hides a failure by returning nothing useful.
- A catch handler logs without context.
- A low-level handler swallows an error that the caller needed to observe.
- Independent promises are handled locally before the code decides fail-fast or partial-success semantics.

These mistakes become unhandled rejections, silent data loss, misleading UI fallbacks, and hard-to-debug production failures.

## How Atlas Improves The Explanation

Atlas turns the topic into an error-boundary decision:

- Use `try/catch` for synchronous throws.
- Use `try/catch` with `await` for local async workflow handling.
- Use `.catch()` for returned promise chains and compact adapters.
- Use both only when each boundary has a distinct responsibility.
- Never swallow errors without logging, rethrowing, recovering, or marking the result as degraded.

## What Decision Support Atlas Adds

The node asks whether the failing work is synchronous, awaited, returned, or floating before recommending a pattern. It also routes developers toward `Promise.all()`, `Promise.allSettled()`, `finally`, retries, validation, cancellation, or observability when error syntax is not the real decision.

## What Production Guidance Atlas Adds

The node includes practical examples for configuration parsing, dashboard loading, promise-chain adapters, and preserving failure after logging. It covers swallowed errors, broad catch blocks, floating promises, and catch handlers that accidentally convert failure into success.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct generation rules:

- Ask whether the work is synchronous, awaited, returned, or floating.
- Generate `try/catch` for synchronous code and multi-step `async`/`await`.
- Generate `.catch()` for compact returned promise chains.
- Do not generate empty catch blocks.
- Log, recover, rethrow, or mark degraded.
- Warn when `try/catch` wraps an unawaited promise.

## Why This Deserves Gold Candidate Status

CANON-016 deserves Gold Candidate status because it connects official JavaScript error mechanics to production reliability, async debugging, API error handling, and AI code-generation guardrails. It still needs named reviewer sign-off before final Gold approval.
