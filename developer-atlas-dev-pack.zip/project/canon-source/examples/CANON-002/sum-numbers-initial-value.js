module.exports = function runSumNumbersInitialValue() {
  const numbers = [12, 8, 5, 15];

  const total = numbers.reduce((sum, number) => sum + number, 0);
  const emptyTotal = [].reduce((sum, number) => sum + number, 0);

  if (total !== 40) {
    throw new Error(`Expected total to be 40, got ${total}`);
  }

  if (emptyTotal !== 0) {
    throw new Error(`Expected empty total to be 0, got ${emptyTotal}`);
  }
};
