const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const walkthroughDir = path.join(rootDir, "walkthrough");
const examplesDir = path.join(walkthroughDir, "examples");

const requiredFields = [
  "walkthrough_id",
  "title",
  "learner_level",
  "goal",
  "why_this_goal_matters",
  "smallest_useful_next_step",
  "capability_id",
  "setup_request_id",
  "recovery_request_id",
  "canon_nodes",
  "ai_context_request_id",
  "visible_win",
  "next_step_after_finishing",
  "source_outputs"
];

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function listJsonFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter((file) => file.endsWith(".json"))
    .map((file) => path.join(dir, file));
}

function existsRelative(relativePath) {
  return fs.existsSync(path.join(rootDir, relativePath));
}

function validateExample(file) {
  const errors = [];
  let data;

  try {
    data = readJson(file);
  } catch (error) {
    return [`${path.relative(rootDir, file)}: invalid JSON (${error.message})`];
  }

  for (const field of requiredFields) {
    if (data[field] === undefined || data[field] === null || data[field] === "") {
      errors.push(`${data.walkthrough_id || path.basename(file)}: missing ${field}`);
    }
  }

  if (data.learner_level !== "rookie") {
    errors.push(`${data.walkthrough_id}: learner_level must be rookie`);
  }

  if (!Array.isArray(data.canon_nodes) || data.canon_nodes.length === 0) {
    errors.push(`${data.walkthrough_id}: canon_nodes must include at least one Canon node`);
  }

  if (!Array.isArray(data.source_outputs) || data.source_outputs.length === 0) {
    errors.push(`${data.walkthrough_id}: source_outputs must include at least one file`);
  } else {
    for (const source of data.source_outputs) {
      if (!existsRelative(source)) {
        errors.push(`${data.walkthrough_id}: missing source output ${source}`);
      }
    }
  }

  return errors;
}

function main() {
  const errors = [];
  const schemaPath = path.join(walkthroughDir, "rookie-walkthrough.schema.json");

  if (!fs.existsSync(schemaPath)) {
    errors.push("walkthrough/rookie-walkthrough.schema.json: missing schema file");
  } else {
    try {
      readJson(schemaPath);
    } catch (error) {
      errors.push(`walkthrough/rookie-walkthrough.schema.json: invalid JSON (${error.message})`);
    }
  }

  const examples = listJsonFiles(examplesDir);
  if (examples.length === 0) {
    errors.push("walkthrough/examples: no walkthrough examples found");
  }

  for (const file of examples) {
    errors.push(...validateExample(file));
  }

  console.log("Atlas Walkthrough validation");
  console.log(`Walkthrough examples: ${examples.length}`);
  console.log(`Errors: ${errors.length}`);

  if (errors.length) {
    for (const error of errors) console.log(`  - ${error}`);
    process.exit(1);
  }

  console.log("Warnings: 0");
}

main();
