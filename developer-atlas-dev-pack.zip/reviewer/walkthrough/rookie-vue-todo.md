# Rookie Vue Todo Walkthrough

## 1. Welcome

You do not need to know everything before you start. This walkthrough gives you one calm path: get set up, build one tiny Vue app, recover if setup breaks, and leave with a visible win.

## 2. Goal

Learn Vue by building a first small interactive app.

## 3. Why This Goal Matters

A tiny todo app proves the beginner can connect state, inputs, list rendering, filtering, and stable keys in one working project.

## 4. Smallest Useful Next Step

Get the Vue starter project running locally, then build one todo list with add, complete, filter, and delete behavior.

## 5. Setup Check

Before coding, confirm Node.js and npm work, dependencies install, and the Vite dev server starts.

## 6. What To Install

- Node.js
- Visual Studio Code
- Vue - Official extension
- Git

## 7. What Usually Gets In The Way

- npm install fails because dependencies or Node versions do not match.
- Vite does not start because dependencies are missing, the Node version does not match, or the port is already in use.
- The todo list resets after refresh because Vue state lives in memory unless you save it somewhere.
- Stored todos come back broken because arrays and objects need JSON.stringify() before saving and JSON.parse() when loading.
- The app becomes too large because backend, auth, or routing is added too early.

## 8. Recovery Path If It Breaks

If the dev server does not start, do not panic. Treat it as a normal setup blocker.

This is a setup or toolchain blocker, not a sign that you cannot code.

Safest first fix: Install dependencies

Verification: npm run dev prints a local URL

## 9. What To Learn Now

- Use ref() for simple Vue state.
- Use v-model for form input.
- Use v-for with stable keys for todo rows.
- Use filter() to switch between all, active, and completed todos.
- Recommended next step: make the todo list remember tasks after refresh with localStorage and JSON.stringify()/JSON.parse().
- Optional next step: use props/emits/model when splitting the todo app into reusable components.

Helpful learning topics:

- Vue reactivity: simple state
- Showing and hiding UI
- Filtering todo items
- Stable keys for todo rows
- Browser storage for remembering todos
- Component communication for splitting the app later

## 10. What To Skip For Now

- Backend APIs
- Authentication
- Routing
- State management libraries
- Saving sensitive data in browser storage
- Advanced component architecture before the one-component todo works

## 11. Project Task

Build a Vue todo app with one input, an add button, a todo list, complete/delete actions, and a simple filter.

Build Vue Todo App is the right size for this walkthrough. Keep the first version small enough to finish.

## 12. Persistence Next Step

Your todo list currently resets after refresh. Make it remember non-sensitive tasks with localStorage. Use sessionStorage only for tab-scoped drafts, never store sensitive data in either storage, and remember that Vue state and browser storage are separate concerns.

Storage recovery tips:

- If the list resets after refresh, check that you save after todo changes and load when the app starts.
- If saved todos load incorrectly, clear the old saved value and reload with an empty-array fallback.
- If todos vanish after closing the tab, check whether you used sessionStorage instead of localStorage.


## 13. AI-Ready Context Pack

Use this context pack when asking an AI assistant for help. It keeps the answer focused on the next practical step instead of expanding into backend, auth, routing, or state management.

- output/ai-context/rookie-vue-next-step.md

Preview:

AI role: Act as a Patient Vue tutor and scope guard. Use Atlas context first, stay vendor-neutral, and help with the next practical step. Goals: Learn Vue (frontend) Readiness: needs_foundation; keep the next step small and guided. Current task: The basic Vue todo app works, but the list resets after refresh. Help make it remember non-sensitive tasks using the right browser storage choice. Use localStorage for persisten...

## 14. Visible Win

**You can now build a small interactive Vue app.**

That win matters. It proves you can connect input, state, list rendering, filtering, and user interaction in one working app.

## 15. Next Step After Finishing

Recommended next step: make the todo list remember tasks after refresh with localStorage. After that, split one todo row into a child component with props and emits. You do not need advanced component communication on day one, but props/emits/model become useful when your app grows from one component into reusable parts.

Keep the next step small. The goal is momentum, not proving everything at once.
