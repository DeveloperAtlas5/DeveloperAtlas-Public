const assert = require("node:assert/strict");

module.exports = async function runPromiseCatchChainRejectionExample() {
  function loadDisplayName() {
    return Promise.reject(new Error("user missing"))
      .then((user) => user.displayName)
      .catch((error) => `Fallback: ${error.message}`);
  }

  const displayName = await loadDisplayName();

  assert.equal(displayName, "Fallback: user missing");
};
