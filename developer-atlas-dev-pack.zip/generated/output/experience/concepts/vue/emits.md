# Vue Emits

Technology: Vue

## Simple meaning

Emits send events from a child component up to a parent component.

## Why it exists

Emits let a child ask the parent to do something without taking over parent state.

## Where you use it

Declared in a child component and listened to in the parent template.

## When to use it

Use emits when a button or action inside a child should update parent-owned data.

## Tiny example

`const emit = defineEmits(['remove']); emit('remove', id);`

## Common beginner confusion

Props go down; emits go up. Emits are not the child directly changing the parent's data.

## Related concepts

- Props
- Component
- v-model

## Similar idea in another technology

An HTML form submit tells the server something happened; a Vue emit tells the parent component something happened.
