module.exports = function runArrayToLookupObject() {
  const products = [
    { sku: "TEE-BLK-M", name: "Black T-shirt", priceCents: 2500 },
    { sku: "MUG-WHT", name: "White Mug", priceCents: 1400 }
  ];

  const productsBySku = products.reduce((lookup, product) => {
    lookup[product.sku] = product;
    return lookup;
  }, {});

  if (productsBySku["TEE-BLK-M"].name !== "Black T-shirt") {
    throw new Error("Expected lookup to return the T-shirt by SKU");
  }

  if (Object.keys(productsBySku).length !== 2) {
    throw new Error("Expected lookup to contain 2 products");
  }
};
