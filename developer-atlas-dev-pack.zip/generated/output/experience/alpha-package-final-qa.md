# Alpha Package Final QA

## Summary

This report verifies that the public alpha package is ready for a small real tester handoff. The package should remain focused on the Rookie Vue slice: one mission, optional help, recovery guidance, AI-assisted builder guidance, and a simple feedback path.

Mission 1 remains the primary tester path. Mission 2 is available only after Mission 1 to test momentum.

## Release Decision

Status: `ready_to_send_to_real_testers`

This means ready for 3-5 real testers, not a public launch.

## Package Structure Check

Expected package structure:

```txt
START_HERE.md
first-time-quick-start.md
mission-dashboard.html
mission/
help/
ai/
reference/canon/hardened/
reviewer/
```

The package root contains only entry points, purpose-named folders, and `package-manifest.json`.

The package keeps learner files grouped and keeps reviewer material under `reviewer/`.

- [x] package root contains only entry points and manifest.
- [x] mission-dashboard.html is the main entry point.
- [x] ai-prompt-pack.md lives under ai/.
- [x] hardened Canon lives under reference/.
- [x] reviewer-facing reports live under reviewer/.
- [x] dashboard links updated paths.
- [x] Mission 1 remains first visible action.
- [x] AI path remains secondary.
- [x] reviewer files are only linked from Review path.

## Dashboard Check

`mission-dashboard.html` references:

- `START_HERE.md`
- `first-time-quick-start.md`
- `mission/today-mission-surface.md`
- `mission/today-mission-surface.vibe.md`
- `mission/mission-02-todoitem-surface.md`
- `mission/mission-02-todoitem-surface.vibe.md`
- `mission/mission-03-todostats-surface.md`
- `mission/mission-03-todostats-surface.vibe.md`
- `help/beginner-orientation.md`
- `help/vue-concept-cards.md`
- `help/terminal-confidence-guide.md`
- `mission/mission-feedback-template.md`
- optional `reference/canon/hardened/` reference notes

It includes Choose your goal, goal buttons for starting, continuing, AI-assisted building, getting unstuck, and reviewing Atlas.

It includes Recommended first step and points clearly to Mission 1 as the first action.

Goal selection is secondary, with simplified labels: Start, Continue, Use AI, I'm stuck, and Review.

It includes a Starting path, Continuing path, AI-assisted path, I am stuck path, and Reviewer path.

The starting panel is short. The continuing panel shows Mission 1 -> Mission 2 -> Mission 3. The reviewer panel says it is for reviewers, mentors, or the project owner.

Only the starting panel is visible by default. The other panels stay hidden until selected.

Mission 1 remains primary, Mission 2 appears after Mission 1, and Mission 3 appears after Mission 2.

It includes a Fastest path card, says optional help is optional, and tells normal testers they do not need to read everything.

The quick-start link is light and does not replace Mission 1 as the first action.

## Accessibility Check

- [x] Dashboard uses semantic `header`, `main`, `section`, `nav`, and `footer` landmarks.
- [x] Dashboard links are keyboard reachable and use clear action labels.
- [x] Dashboard has visible focus states for links and buttons.
- [x] Dashboard does not rely on color alone to explain the path.
- [x] Dashboard includes optional read-aloud controls.
- [x] Read-aloud does not autoplay.
- [x] `START_HERE.md` includes a short accessibility note.

## START_HERE Check

`START_HERE.md` tells testers where to start, includes a short What the folders mean section for `mission/`, `help/`, `ai/`, `reference/`, and `reviewer/`, points to the main mission, points to optional help files, and keeps reviewer files out of the default learner path.

## Quick Start Check

- [x] `first-time-quick-start.md` exists.
- [x] Quick start is linked from START_HERE.
- [x] Quick start is linked lightly from dashboard.
- [x] Quick start does not replace Mission 1.
- [x] Quick start explains where to work.
- [x] Mission 1 remains first visible action.

## Workspace Clarity Check

- [x] Dashboard explains read here/code there.
- [x] START_HERE explains read here/code there.
- [x] Mission 1 says code changes belong in the learner's Vue todo project.
- [x] Mission 2 says TodoItem.vue belongs in the learner's Vue todo project.
- [x] Mission 3 says TodoStats.vue belongs in the learner's Vue todo project.
- [x] Vibe versions tell AI to edit the learner's Vue todo project.

## AI-Assisted Path Check

- [x] AI path gives one mission at a time.
- [x] Vibe files tell AI to edit the learner's Vue todo project.
- [x] Vibe files reject architecture expansion.
- [x] Vibe files include explain-it-back guidance.
- [x] AI prompt pack exists.
- [x] AI prompt pack is optional.
- [x] AI guardrail evaluation report exists.
- [x] AI guardrail evaluation is reviewer-facing.
- [x] Dashboard links guardrail evaluation only from Review path if linked.
- [x] AI prompt pack includes before-accepting guidance.
- [x] AI prompt pack includes overbuild recovery prompt.
- [x] AI guardrail evaluation mentions readable formatting.
- [x] AI prompt pack includes a clear formatting prompt.
- [x] Vibe mission prompts ask for clear formatting.
- [x] Vibe mission prompts ask for file names before code.
- [x] Vibe mission prompts ask for verification steps.
- [x] AI editing rules mention human and AI readability.
- [x] Accessibility principle mentions readable AI formatting.
- [x] AI red-team pack exists.
- [x] AI red-team pack is packaged under reviewer.
- [x] AI red-team pack is reviewer-facing.
- [x] Dashboard links red-team pack only from Review path if linked.
- [x] Red-team pack includes Mission 1, Mission 2, Mission 3, and general behavior tests.
- [x] Red-team pack includes pass criteria.
- [x] Red-team pack avoids forbidden terms.
- [x] AI red-team results template exists.
- [x] AI red-team results template is packaged under reviewer.
- [x] AI red-team results template is reviewer-facing.
- [x] Dashboard links results template only from Review path if linked.
- [x] Red-team pack references results template.
- [x] AI guardrail evaluation references results template.
- [x] Results template includes scope, readability, recovery, decision, and follow-up sections.
- [x] AI prompt pack includes universal AI preamble.
- [x] AI prompt pack includes cleaner-improvement recovery prompt.
- [x] Vibe prompts warn against quality drift.
- [x] AI guardrail evaluation mentions quality drift.
- [x] AI red-team pack includes high-risk drift patterns.
- [x] Results template captures quality drift and off-script usage.
- [x] Vibe files include recovery prompt.
- [x] Vibe files include explain-it-back guidance.
- [x] AI path remains secondary.
- [x] Mission 1 remains first visible action.

## Hardened Canon Check

- [x] Hardened Canon folder exists.
- [x] Only current mission Canon nodes are hardened.
- [x] Canon IDs are unique.
- [x] Forbidden learner-facing/internal terms are absent.
- [x] Hype terms are absent.
- [x] Shame terms are absent.

## Mission Path Check

Primary tester path:

```txt
START_HERE.md -> mission/today-mission-surface.md -> completion checklist -> after-mission reflection
```

Secondary momentum path after Mission 1:

```txt
START_HERE.md -> mission/mission-02-todoitem-surface.md
```

Third progression path after Mission 2:

```txt
START_HERE.md -> mission/mission-02-todoitem-surface.md -> mission/mission-03-todostats-surface.md
```

Optional AI-assisted builder path:

```txt
START_HERE.md -> mission/today-mission-surface.vibe.md
```

Current polish checks:

- Main mission includes `## Quick Start`.
- Vibe mission includes `## Quick Start With AI`.
- Mission 2 includes `## Quick Start` and keeps state in `App.vue`.
- Mission 2 vibe includes `## Quick Start With AI` and rejects new architecture.
- Mission 2 includes a tiny file map.
- Mission 2 includes a beginner-safe path.
- Mission 2 includes a parent-child communication explanation.
- Mission 2 includes a shape-only example.
- Mission 2 includes tiny parent-child diagram.
- Mission 2 includes props go down, events go up.
- Mission 2 vibe includes a tiny file map.
- Mission 2 vibe includes tiny parent-child diagram.
- Mission 2 vibe rejects multiple new components.
- Mission 2 vibe rejects moving state out of `App.vue`.
- Mission 2 vibe rejects extra components.
- Mission 2 vibe rejects folder restructuring.
- Mission 2 vibe rejects styling side quests.
- Mission 2 vibe rejects unrelated renaming.
- Mission 2 keeps Mission 1 -> Mission 2 progression clear.
- Mission 2 remains after Mission 1.
- Mission 3 exists.
- Mission 3 default and vibe surfaces are packaged.
- Mission 3 is clearly after Mission 2.
- Mission 1 remains primary.
- Mission 2 remains after Mission 1.
- Mission 3 keeps state in `App.vue`.
- Mission 3 keeps localStorage in `App.vue`.
- Mission 3 creates `TodoStats.vue`.
- Mission 3 blocks backend, routing, Pinia, auth, database, deployment, and new architecture.
- Dashboard and START_HERE reference Mission 3 correctly.
- AI guardrail evaluation report exists.
- AI guardrail evaluation is reviewer-facing.
- Dashboard links guardrail evaluation only from Review path if linked.
- AI prompt pack includes before-accepting guidance.
- AI prompt pack includes overbuild recovery prompt.
- AI guardrail evaluation mentions readable formatting.
- AI prompt pack includes a clear formatting prompt.
- Vibe mission prompts ask for clear formatting.
- Vibe mission prompts ask for file names before code.
- Vibe mission prompts ask for verification steps.
- AI editing rules mention human and AI readability.
- Accessibility principle mentions readable AI formatting.
- AI red-team pack exists.
- AI red-team pack is packaged under reviewer.
- AI red-team pack is reviewer-facing.
- Dashboard links red-team pack only from Review path if linked.
- Red-team pack includes Mission 1, Mission 2, Mission 3, and general behavior tests.
- Red-team pack includes pass criteria.
- Red-team pack avoids forbidden terms.
- AI red-team results template exists.
- AI red-team results template is packaged under reviewer.
- AI red-team results template is reviewer-facing.
- Dashboard links results template only from Review path if linked.
- Red-team pack references results template.
- AI guardrail evaluation references results template.
- Results template includes scope, readability, recovery, decision, and follow-up sections.
- AI prompt pack includes universal AI preamble.
- AI prompt pack includes cleaner-improvement recovery prompt.
- Vibe prompts warn against quality drift.
- AI guardrail evaluation mentions quality drift.
- AI red-team pack includes high-risk drift patterns.
- Results template captures quality drift and off-script usage.
- Vibe files include recovery prompt.
- Vibe files include explain-it-back guidance.
- AI path remains secondary.
- Dashboard includes Choose your goal.
- Dashboard includes Recommended first step.
- Dashboard points clearly to Mission 1 as first action.
- Dashboard keeps goal selection secondary.
- Dashboard uses simplified goal labels.
- Dashboard keeps the starting panel short.
- Dashboard continuing panel shows Mission 1 -> Mission 2 -> Mission 3.
- Dashboard reviewer panel says it is for reviewers, mentors, or the project owner.
- Dashboard includes Starting path.
- Dashboard includes Continuing path.
- Dashboard includes AI-assisted path.
- Dashboard includes I am stuck path.
- Dashboard includes Reviewer path.
- Dashboard keeps only one panel visible by default.
- Dashboard keeps Mission 1 primary, Mission 2 after Mission 1, and Mission 3 after Mission 2.
- Dashboard keeps accessibility and read-aloud support working.
- Dashboard includes Fastest Path.
- Help files are clearly optional.
- Vibe reject rules block structural rewrites and new architecture.

## Optional Help Check

Help files are optional and grouped under `help/`:

- Beginner orientation.
- Vue concept cards.
- Terminal confidence guide.

Help references are clearly labeled optional.

## Feedback Capture Check

Testers can give feedback through:

- After-mission reflection.
- `mission/mission-feedback-template.md`.

The project owner can triage feedback through:

- `reviewer/tester-feedback-report.md`.

## Real tester feedback record

Tester role:
Time spent:
Started from:
Mission clarity:
Help used:
Blocker:
Confidence before:
Confidence after:
Would use again:
Most useful part:
Most confusing part:
Suggested next fix:

## Canon Backlog Isolation Check

The 20 new Canon candidate nodes are not part of the normal learner path. Candidate backlog supports future work but should not distract alpha testers.

## Package Manifest Check

`package-manifest.json` should include `mission-dashboard.html`, grouped mission files, grouped help files, `ai/`, `reference/`, and `reviewer/`.

Mission 3 default and vibe surfaces are the only new learner-facing mission files in this phase.

## Remaining Risks

- Package may still feel large to some testers.
- Markdown may still feel less product-like than an app UI.
- Real user behavior may differ from simulated feedback.
- Some beginners may still need live help with setup.
- No paid conversion data yet.

## Send-To-Testers Checklist

- [ ] Zip file refreshed.
- [ ] Opened package root.
- [ ] Opened `mission-dashboard.html`.
- [ ] Opened `START_HERE.md`.
- [ ] Opened main mission.
- [ ] Confirmed optional help links.
- [ ] Confirmed feedback template.
- [ ] Sent to 3-5 testers.

## Next Action

Send the refreshed demo package to 3-5 real testers before adding more features.
