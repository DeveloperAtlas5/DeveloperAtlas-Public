const { renderRows } = require("./keyed-patch-simulator");

module.exports = function runStableIdKeyPreservesIdentity() {
  const initialItems = [
    { id: "a", label: "Ada" },
    { id: "g", label: "Grace" },
    { id: "k", label: "Katherine" }
  ];

  const firstRender = renderRows(initialItems, (item) => item.id);
  const reorderedItems = [initialItems[2], initialItems[0], initialItems[1]];
  const secondRender = renderRows(reorderedItems, (item) => item.id, firstRender.stateByKey);

  const katherineRow = secondRender.rows[0];

  if (katherineRow.itemId !== "k" || katherineRow.state.createdFor !== "k") {
    throw new Error("Stable ID key should keep Katherine's state with Katherine after reorder.");
  }

  return secondRender.rows;
};
