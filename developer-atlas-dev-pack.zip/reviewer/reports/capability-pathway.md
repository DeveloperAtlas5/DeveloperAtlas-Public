# Atlas Capability Pathway

Pathway: capability.pathway.4_week_project_ladder
Readiness profile: readiness.rookie_vue_app
Readiness score: 53.63/100
Available hours per week: 6
Desired output: Build a small Vue app with components, list rendering, and API data.

## Week 1: Build Vue Todo App

Focus: Finish one ready-today project and protect momentum.
Fit: ready_today
Estimated hours: 6
Output artifact: Small Vue todo app with add, complete, filter, and delete behavior.

Prep tasks:
- Review javascript.array.filter.
- Review javascript.function.fetch.
- Review vue.reactivity.ref.
- Study and practice the first missing knowledge node: javascript.array.filter.
- Verify or install the most important missing tool: extension.vue-official.
- Do not start if: Node or Vite cannot start yet.

Required knowledge:
- Vue reactivity: choosing simple state
- Vue conditional display
- Stable keys for list rows
- javascript.array.filter
- javascript.function.fetch
- vue.reactivity.ref
- vue.reactivity.reactive
- vue.reactivity.computed
- vue.reactivity.watch

Recommended next knowledge:
- Browser storage: localStorage vs sessionStorage
- Component communication: props, emits, and model
Note: After the basic todo app works, persistence is the recommended next step: localStorage can remember non-sensitive todos across browser restarts, sessionStorage only lasts for the current tab session, and Vue state is separate from browser storage. Component communication comes after that when the app grows into reusable parts.

Required tools:
- Node.js
- Visual Studio Code
- Git
- Vue - Official
- ESLint extension
- Prettier extension

Friction risks:
- friction.javascript.npm.install_fails: npm install fails
- friction.javascript.vite.not_starting: Vite dev server not starting
- friction.javascript.npm.install_fails.
- friction.javascript.vite.not_starting.

Hardware notes:
- No major hardware concern detected for this week.

Practice tasks:
- Choose ref() for simple state: Create a count and label with ref() and update them safely. (20 min)
- Toggle empty state: Use v-if to create and remove an empty-state message. (15 min)
- Add stable keys: Render a todo list with :key="todo.id" and explain what the key identifies. (20 min)

Mastery checkpoints:
- Can choose ref() for replaceable values and primitives.
- Can choose reactive() for stable state objects.
- Can choose v-if for conditional existence.
- Can choose v-show for frequent visibility toggles.
- Can choose stable unique keys for dynamic lists.
- Can explain when index keys are acceptable.
- Can add todo items with v-model.
- Can render todo items with v-for and stable keys.

AI-ready weekly prompt:
Week 1: help me build Build Vue Todo App. Help me build a tiny Vue todo app. Keep scope to local state, v-model, v-for, filtering, stable keys, and then one persistence step. Do not add backend, auth, routing, or state management. After the basic app works, help me save non-sensitive todos to localStorage with JSON.stringify() and restore them with JSON.parse(). Explain that sessionStorage survives refresh but not a closed tab/session, and that Vue state and browser storage are separate concerns. Treat props/emits/model as a later optional step for splitting components. Current fit is ready today. Practice first: Choose ref() for simple state. Keep the plan deterministic, beginner-safe, and focused on a finished artifact.

## Week 2: Build Laravel CRUD API

Focus: Add one mostly-ready project after targeted prep.
Fit: mostly_ready
Estimated hours: 10
Output artifact: CRUD API for one resource with validation and JSON responses.

Prep tasks:
- Complete the smallest missing foundation before starting the project.
- Review html.element.input.
- Review html.element.button.
- Review css.property.grid-template-columns.
- Study and practice the first missing knowledge node: html.element.input.
- Verify or install the most important missing tool: extension.vue-official.
- Do not start if: Composer or php artisan is not working.

Required knowledge:
- Laravel validation boundaries
- SQL filtering: WHERE vs HAVING
- html.element.input
- html.element.button
- css.property.grid-template-columns
- javascript.array.map
- javascript.array.filter
- vue.reactivity.ref

Recommended next knowledge:
- None
Note: None

Required tools:
- Composer
- Git
- Postman
- Vue - Official
- PHP Intelephense
- Prettier extension

Friction risks:
- friction.php.composer.not_recognized: composer is not recognized
- friction.php.php_not_in_path: php is not in PATH
- friction.laravel.artisan_missing: Laravel artisan file missing
- friction.php.composer.not_recognized.
- friction.php.php_not_in_path.
- friction.laravel.artisan_missing.

Hardware notes:
- No major hardware concern detected for this week.

Practice tasks:
- Validate before saving: Write inline validation for a contact form and save only the validated data. (25 min)
- Separate row and group filters: Write one SQL query that uses WHERE for paid orders and another that uses HAVING for customers with more than one order. (20 min)

Mastery checkpoints:
- Can write validation rules that match a request contract.
- Can choose inline validation for small local rules.
- Can choose WHERE for row filters and HAVING for aggregate filters.
- Can use WHERE and HAVING together in grouped reports.
- Can create route, controller, model, and migration.
- Can validate request input before saving.
- Can test success and validation errors in an API client.

AI-ready weekly prompt:
Week 2: help me build Build Laravel CRUD API. Help me build a one-resource Laravel CRUD API. Focus on routes, validation, model persistence, and API testing. Do not add auth or extra architecture yet. Current fit is mostly ready. Practice first: Validate before saving. Keep the plan deterministic, beginner-safe, and focused on a finished artifact.

## Week 3: Run Local LLM Learning Experiment

Focus: Take on a harder project while watching scope.
Fit: mostly_ready
Estimated hours: 8
Output artifact: Local AI sizing notes with a repeatable experiment log.

Prep tasks:
- Complete the smallest missing foundation before starting the project.
- Review html.element.input.
- Review html.element.button.
- Review css.property.grid-template-columns.
- Study and practice the first missing knowledge node: html.element.input.
- Verify or install the most important missing tool: extension.vue-official.
- Do not start if: The goal is to buy hardware before measuring a workload.

Required knowledge:
- Promise coordination: all vs allSettled
- Async JavaScript: async, await, and then
- Object iteration: keys, values, and entries
- html.element.input
- html.element.button
- css.property.grid-template-columns
- javascript.array.find
- vue.directive.v-for
- laravel.routing.route_get

Recommended next knowledge:
- None
Note: None

Required tools:
- Git
- Node.js
- Vue - Official
- PHP Intelephense
- Prettier extension

Friction risks:
- friction.javascript.npm.install_fails: npm install fails
- friction.javascript.npm.install_fails.

Hardware notes:
- workload.local_llm_learning has high purchase-mismatch risk; use experiments before hardware commitments.
- workload.local_llm_serious has high purchase-mismatch risk; use experiments before hardware commitments.

Practice tasks:
- Handle partial success: Use Promise.allSettled() to report mixed upload results. (40 min)
- Fix async error handling: Given a try/catch that does not catch a rejection, fix it using await or a returned promise chain. (30 min)
- Render label/value settings rows: Use Object.entries() to render a settings object into label/value row data. (30 min)

Mastery checkpoints:
- Can choose Promise.all() when all results are required.
- Can choose Promise.allSettled() when partial success is acceptable.
- Can choose async/await for readable sequencing and Promise.then() for explicit chains.
- Can explain why an async function always returns a promise.
- Can choose Object.keys() when property names are the useful result.
- Can choose Object.values() when only values matter.
- Can state target model, memory limits, and observed behavior.
- Can explain local vs cloud trade-offs.

AI-ready weekly prompt:
Week 3: help me build Run Local LLM Learning Experiment. Help me run a small local LLM learning experiment. Focus on measuring model size, VRAM fit, latency, and local-vs-cloud trade-offs. Do not recommend products. Current fit is mostly ready. Practice first: Handle partial success. Keep the plan deterministic, beginner-safe, and focused on a finished artifact.

## Week 4: Build Full-Stack Inventory System

Focus: Prepare the deferred stretch project without overcommitting.
Fit: defer
Estimated hours: 24
Output artifact: Inventory app with Vue frontend, Laravel API, validation, and database persistence.

Prep tasks:
- Complete the smallest missing foundation before starting the project.
- Review html.element.input.
- Review html.element.button.
- Review css.property.grid-template-columns.
- Study and practice the first missing knowledge node: html.element.input.
- Verify or install the most important missing tool: extension.vue-official.
- Do not start if: Vue basics and Laravel validation are not practiced yet.

Required knowledge:
- Vue reactivity: choosing simple state
- SQL joins: combining related rows
- Promise coordination: all vs allSettled
- Laravel validation boundaries
- SQL filtering: WHERE vs HAVING
- html.element.input
- html.element.button
- css.property.grid-template-columns
- javascript.array.map
- javascript.array.filter
- vue.reactivity.ref

Recommended next knowledge:
- None
Note: None

Required tools:
- Visual Studio Code
- Git
- Node.js
- Composer
- Postman
- Vue - Official
- PHP Intelephense
- Prettier extension

Friction risks:
- friction.javascript.npm.install_fails: npm install fails
- friction.javascript.vite.not_starting: Vite dev server not starting
- friction.php.composer.not_recognized: composer is not recognized
- friction.laravel.artisan_missing: Laravel artisan file missing
- friction.javascript.npm.install_fails.
- friction.javascript.vite.not_starting.
- friction.php.composer.not_recognized.
- friction.laravel.artisan_missing.

Hardware notes:
- No major hardware concern detected for this week.

Practice tasks:
- Choose ref() for simple state: Create a count and label with ref() and update them safely. (20 min)
- Join users and orders: Write an INNER JOIN that returns only users with orders. (25 min)
- Load all required resources: Use Promise.all() for three required async values. (25 min)
- Validate before saving: Write inline validation for a contact form and save only the validated data. (25 min)

Mastery checkpoints:
- Can choose ref() for replaceable values and primitives.
- Can choose reactive() for stable state objects.
- Can choose INNER JOIN when matches are required.
- Can choose LEFT JOIN when preserving left-side rows matters.
- Can choose Promise.all() when all results are required.
- Can choose Promise.allSettled() when partial success is acceptable.
- Can write validation rules that match a request contract.
- Can choose inline validation for small local rules.

AI-ready weekly prompt:
Week 4: help me build Build Full-Stack Inventory System. Help me plan a small full-stack inventory system with Vue and Laravel. Only proceed if the smaller Vue and Laravel API projects are already working. Current fit is defer. Practice first: Choose ref() for simple state. Keep the plan deterministic, beginner-safe, and focused on a finished artifact.

## What to Avoid For Now

- Avoid Build Full-Stack Inventory System until blockers are reduced.
- Skip product-specific buying decisions until the workload is measured.
- Skip advanced architecture until the missing foundations are practiced.
- Skip Docker until the first local app runs without it.

## Deferred Items

- Build Full-Stack Inventory System: 55.28/100
