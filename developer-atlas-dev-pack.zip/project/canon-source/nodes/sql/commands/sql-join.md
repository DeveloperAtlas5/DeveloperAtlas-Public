# SQL JOIN

## Status Metadata

- Canon ID: CANON-005
- Node ID: canon.sql.command.join
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: SQL
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use a SQL `JOIN` when a question needs columns from related tables in one result set. Use `INNER JOIN` when only matching rows should appear. Use `LEFT JOIN` when every row from the left table should remain, even if the right table has no match.

The everyday rule:

- `INNER JOIN` answers "show me rows that have a match."
- `LEFT JOIN` answers "show me all left rows, plus matching right data when it exists."
- Cardinality decides whether the result has one row per entity or multiple rows per entity.

## What Problem This Solves

Many developers learn join syntax before they understand result shape. That creates common production bugs:

- Rows disappear because an `INNER JOIN` removed unmatched records.
- Rows multiply because a one-to-many relationship creates multiple matches.
- A `LEFT JOIN` accidentally behaves like an `INNER JOIN` because a right-table filter is placed in `WHERE`.
- AI-generated SQL joins tables on plausible but wrong keys.

This node teaches joins as relationship reasoning, not keyword memorization.

## Mental Model

A join pairs rows by a relationship.

Start with two questions:

1. What is the main table whose rows I care about?
2. Should rows from that main table survive when there is no match?

Example:

- Users are the main rows.
- Orders are optional related rows.
- If you need all users, use `LEFT JOIN`.
- If you need only users with orders, use `INNER JOIN`.

Think of the `ON` clause as the relationship rule:

```sql
users.id = orders.user_id
```

That rule says: "An order belongs to a user when its `user_id` matches the user's `id`."

## Beginner Explanation

Imagine two tables:

`users`

| id | name |
| --- | --- |
| 1 | Ada |
| 2 | Grace |
| 3 | Linus |

`orders`

| id | user_id | total |
| --- | --- | --- |
| 101 | 1 | 50 |
| 102 | 1 | 25 |
| 103 | 2 | 75 |

An `INNER JOIN` gives users who have matching orders. Linus disappears because Linus has no order.

A `LEFT JOIN` keeps every user. Linus stays, but the order columns are `NULL`.

The beginner decision:

1. Need only rows with matches? Use `INNER JOIN`.
2. Need all rows from the main table? Use `LEFT JOIN`.
3. Got more rows than expected? Check whether one row on the left matches many rows on the right.

## Professional Explanation

Joins are not only syntax; they encode data relationships and cardinality. The join type determines null-preservation. The join condition determines row pairing. The relationship cardinality determines row multiplication.

In production code, a join should make the intended result shape obvious:

- One-to-one joins enrich a row.
- Many-to-one joins attach a parent or lookup row.
- One-to-many joins expand result rows unless aggregated.
- Outer joins preserve unmatched rows and introduce nulls.

A correct join considers:

- The driving table.
- The join keys.
- The expected row count.
- Whether unmatched rows should survive.
- Whether right-table filters belong in `ON` or `WHERE`.
- Whether indexes support the join condition.

## Syntax

```sql
SELECT users.id, users.name, orders.id AS order_id
FROM users
INNER JOIN orders ON orders.user_id = users.id;
```

```sql
SELECT users.id, users.name, orders.id AS order_id
FROM users
LEFT JOIN orders ON orders.user_id = users.id;
```

## Decision Guide

Ask these questions in order:

1. Do I need columns from more than one related table?
   Consider a `JOIN`.
2. What is the main table whose rows must define the result?
   Put that table on the left for `LEFT JOIN`.
3. Should rows without a match be removed?
   Use `INNER JOIN`.
4. Should rows without a match remain?
   Use `LEFT JOIN`.
5. Can one left row match many right rows?
   Expect duplicate-looking left data or aggregate first.
6. Am I filtering right-table columns after a `LEFT JOIN`?
   Put optional-match filters in `ON` when unmatched left rows must survive.

## Comparison Table

| Join Type | Keeps Unmatched Left Rows | Keeps Only Matches | Common Use | Main Risk |
| --- | --- | --- | --- | --- |
| `INNER JOIN` | No | Yes | Required relationships | Missing rows |
| `LEFT JOIN` | Yes | No | Optional relationships | Unexpected nulls |
| `CROSS JOIN` | No relationship needed | No | Cartesian combinations | Row explosion |
| Self join | Depends on join type | Depends | Hierarchies or comparisons | Confusing aliases |

## When To Use The Primary Option

Use `INNER JOIN` when:

- The relationship is required for the question.
- You only want rows with matching related data.
- Missing related rows should be excluded.
- You are joining orders to customers and only valid customer orders matter.

```sql
SELECT orders.id, users.email, orders.total_cents
FROM orders
INNER JOIN users ON users.id = orders.user_id;
```

## When To Use The Alternative

Use `LEFT JOIN` when:

- The left table is the main list.
- Related data is optional.
- You need to find missing related rows.
- You want all users, even users without orders.

```sql
SELECT users.id, users.name, orders.id AS order_id
FROM users
LEFT JOIN orders ON orders.user_id = users.id;
```

## When Not To Use This Decision

Do not use a join just because two tables are involved.

Avoid a join when:

- You only need to check whether related rows exist. Use `EXISTS`.
- You need a count or total per row. Aggregate before joining or use a grouped query.
- The join would create row explosion and you only need summary data.
- The relationship is better represented by a foreign key lookup already loaded in application memory.
- You are using a join to hide unclear data modeling.

Example existence check:

```sql
SELECT users.id, users.email
FROM users
WHERE EXISTS (
  SELECT 1
  FROM orders
  WHERE orders.user_id = users.id
);
```

## Alternatives

- `EXISTS` for existence checks.
- `NOT EXISTS` for missing related rows.
- Aggregation with `GROUP BY` for counts and totals.
- Common table expressions for staged queries.
- Application-side lookup only for small, already-loaded reference data.

## Production Examples

### INNER JOIN Users With Orders

```sql
SELECT users.id, users.email, orders.id AS order_id, orders.total_cents
FROM users
INNER JOIN orders ON orders.user_id = users.id
ORDER BY users.id, orders.id;
```

Why `INNER JOIN` fits: the result should include only users who have orders.

### LEFT JOIN Users And Optional Orders

```sql
SELECT users.id, users.email, orders.id AS order_id
FROM users
LEFT JOIN orders ON orders.user_id = users.id
ORDER BY users.id, orders.id;
```

Why `LEFT JOIN` fits: the report starts from users, and users with no orders must remain visible.

### Count Orders Without Multiplying User Rows

```sql
SELECT users.id, users.email, COUNT(orders.id) AS order_count
FROM users
LEFT JOIN orders ON orders.user_id = users.id
GROUP BY users.id, users.email;
```

Why aggregation fits: the one-to-many join is collapsed back to one row per user.

## Common Mistakes

- Joining on the wrong key.
- Using `INNER JOIN` when unmatched rows should remain.
- Using `LEFT JOIN` but adding a right-table condition in `WHERE`, removing unmatched rows.
- Forgetting that one-to-many joins multiply rows.
- Selecting unqualified column names like `id` when both tables have `id`.
- Using `SELECT *` in joined production queries.
- Joining before aggregating when the intended result is one row per parent.

Bad `LEFT JOIN` filter:

```sql
SELECT users.id, orders.id AS order_id
FROM users
LEFT JOIN orders ON orders.user_id = users.id
WHERE orders.status = 'paid';
```

Better when unmatched users should remain:

```sql
SELECT users.id, orders.id AS order_id
FROM users
LEFT JOIN orders
  ON orders.user_id = users.id
 AND orders.status = 'paid';
```

## Debugging Checklist

- What table defines the expected row count?
- Should unmatched left rows remain?
- Are join keys correct and indexed?
- Is the relationship one-to-one, many-to-one, or one-to-many?
- Did a one-to-many join multiply rows?
- Did an `INNER JOIN` remove rows you expected to keep?
- Did a `WHERE` condition on the right table cancel your `LEFT JOIN`?
- Are selected columns qualified with table names or aliases?
- Would `EXISTS` or aggregation express the question more safely?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-005/`.

Verification command:

```sh
npm run canon:verify:005
```

The verification suite checks:

- `INNER JOIN` users and orders.
- `LEFT JOIN` users and orders.
- Duplicate rows from one-to-many joins.
- Missing rows caused by using `INNER JOIN` when `LEFT JOIN` was intended.

## Performance Notes

Join performance depends on data size, indexes, cardinality, selected columns, and filters. A clear join can still be slow without indexes on join keys.

Practical guidance:

- Index foreign key columns used in joins.
- Select only needed columns.
- Aggregate before or after joining based on the intended row shape.
- Check query plans for large tables.
- Avoid accidental cross joins.

## AI Coding Guidance

When generating SQL joins:

- Identify the main table first.
- Choose `INNER JOIN` only when unmatched rows should be removed.
- Choose `LEFT JOIN` when the left table must be preserved.
- Always include an explicit `ON` condition.
- Qualify ambiguous columns.
- Avoid `SELECT *` in production examples.
- Mention row multiplication for one-to-many relationships.
- Put optional right-table filters in `ON` if unmatched left rows must remain.
- Prefer `EXISTS` for existence checks.

Bad AI output:

```sql
SELECT *
FROM users
JOIN orders;
```

Good AI output:

```sql
SELECT users.id, users.email, orders.id AS order_id
FROM users
INNER JOIN orders ON orders.user_id = users.id;
```

## Teaching Notes

Teach joins with tiny tables before syntax diagrams.

Recommended teaching order:

1. Show users and orders.
2. Draw the relationship key: `orders.user_id -> users.id`.
3. Run `INNER JOIN` and ask which users disappear.
4. Run `LEFT JOIN` and ask where nulls appear.
5. Add a second order and show row multiplication.
6. Add aggregation to restore one row per user.

Useful teaching phrase:

> A join does not just add columns; it changes the number of rows.

## Interview Questions

1. What is the difference between `INNER JOIN` and `LEFT JOIN`?
2. Why can joining orders to users produce multiple rows for one user?
3. How can a `WHERE` clause accidentally change the behavior of a `LEFT JOIN`?
4. When would you use `EXISTS` instead of a join?
5. Why should production joins avoid `SELECT *`?
6. What indexes matter for join performance?

## Exercises

### Beginner

Join users to orders and explain why users without orders disappear.

### Intermediate

Rewrite an `INNER JOIN` as a `LEFT JOIN` so users without orders remain.

### Advanced

Fix a report that duplicates users because of a one-to-many join, then explain whether aggregation or `EXISTS` is the better solution.

## Related Atlas Nodes

- `sql.command.join`
- `sql.command.where`
- `sql.command.select`

## Evidence And Sources

- PostgreSQL docs: Joins Between Tables: https://www.postgresql.org/docs/current/tutorial-join.html
- PostgreSQL docs: Joined Tables: https://www.postgresql.org/docs/current/queries-table-expressions.html#QUERIES-JOIN
- MySQL docs: JOIN Clause: https://dev.mysql.com/doc/en/join.html
- SQLite docs: SELECT statement and join operators: https://sqlite.org/lang_select.html

## Proof Of Superiority Summary

Official SQL documentation explains join syntax and join types. This Canon node explains how to choose a join based on result shape, unmatched-row behavior, and cardinality; how to debug missing or duplicated rows; how to avoid common AI-generated SQL mistakes; and when `EXISTS`, aggregation, or staged queries are safer than a join.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
