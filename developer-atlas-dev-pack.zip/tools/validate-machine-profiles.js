const fs = require("fs");
const path = require("path");
const {
  hardwareDir,
  readMachineProfiles,
  readContextualHardwareHints,
  readWorkloadProfiles
} = require("./hardware-utils");

const schemaFiles = [
  "machine-profile.schema.json",
  "contextual-hardware-hint.schema.json"
];

const profileFields = [
  "profile_id",
  "device_type",
  "operating_system",
  "cpu",
  "gpu",
  "gpu_vram_gb",
  "system_ram_gb",
  "storage_type",
  "storage_total_gb",
  "storage_free_gb",
  "primary_goals",
  "current_pain_points",
  "upgrade_budget_level"
];

const hintFields = [
  "hint_id",
  "related_canon_nodes",
  "related_workloads",
  "trigger_topics",
  "condition",
  "message_rookie",
  "message_professional",
  "severity",
  "hardware_reason",
  "suggested_check",
  "related_machine_profile_fields"
];

const validDeviceTypes = new Set(["laptop", "desktop", "server", "cloud"]);
const validBudgetLevels = new Set(["none", "low", "medium", "high", "unknown"]);
const validSeverities = new Set(["info", "note", "warning"]);

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);

  let profiles = [];
  let hints = [];
  let workloads = [];
  try {
    profiles = readMachineProfiles();
    hints = readContextualHardwareHints();
    workloads = readWorkloadProfiles();
  } catch (error) {
    errors.push(`hardware: unable to read machine profiles or hints (${error.message})`);
  }

  validateProfiles(profiles, errors, warnings);
  validateHints(hints, new Set(workloads.map((record) => record.workload.workload_id)), errors, warnings);

  console.log("Atlas Machine Profile validation");
  console.log(`Machine profiles: ${profiles.length}`);
  console.log(`Contextual hardware hints: ${hints.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const schemaPath = path.join(hardwareDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`hardware/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`hardware/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateProfiles(profiles, errors, warnings) {
  const seenIds = new Set();

  for (const { profile, relativePath } of profiles) {
    validateRequired(relativePath, profile, profileFields, errors);

    if (typeof profile.profile_id === "string") {
      if (seenIds.has(profile.profile_id)) errors.push(`${relativePath}: duplicate profile_id ${profile.profile_id}`);
      seenIds.add(profile.profile_id);
    }

    if (!validDeviceTypes.has(profile.device_type)) {
      errors.push(`${relativePath}: device_type should be one of ${[...validDeviceTypes].join(", ")}`);
    }
    if (!validBudgetLevels.has(profile.upgrade_budget_level)) {
      errors.push(`${relativePath}: upgrade_budget_level should be one of ${[...validBudgetLevels].join(", ")}`);
    }

    validateNumber(relativePath, profile, "gpu_vram_gb", 0, errors);
    validateNumber(relativePath, profile, "system_ram_gb", 0, errors);
    validateNumber(relativePath, profile, "storage_total_gb", 0, errors);
    validateNumber(relativePath, profile, "storage_free_gb", 0, errors);
    validateArray(relativePath, profile, "primary_goals", errors);
    validateArray(relativePath, profile, "current_pain_points", errors);

    if (profile.storage_free_gb > profile.storage_total_gb) {
      errors.push(`${relativePath}: storage_free_gb cannot exceed storage_total_gb`);
    }
    if (profile.system_ram_gb <= 8 && profile.primary_goals.some((goal) => /docker|laravel|unity|llm/i.test(goal))) {
      warnings.push(`${relativePath}: low RAM for one or more stated goals`);
    }
  }
}

function validateHints(hints, workloadIds, errors, warnings) {
  const seenIds = new Set();
  const profileFieldSet = new Set(profileFields);

  for (const { hint, relativePath } of hints) {
    validateRequired(relativePath, hint, hintFields, errors);

    if (typeof hint.hint_id === "string") {
      if (seenIds.has(hint.hint_id)) errors.push(`${relativePath}: duplicate hint_id ${hint.hint_id}`);
      seenIds.add(hint.hint_id);
    }

    if (!validSeverities.has(hint.severity)) {
      errors.push(`${relativePath}: severity should be info, note, or warning`);
    }

    for (const field of [
      "related_canon_nodes",
      "related_workloads",
      "trigger_topics",
      "related_machine_profile_fields"
    ]) {
      validateArray(relativePath, hint, field, errors, field === "related_canon_nodes");
    }

    for (const workloadId of hint.related_workloads || []) {
      if (!workloadIds.has(workloadId)) warnings.push(`${relativePath}: related workload ${workloadId} does not exist`);
    }

    for (const field of hint.related_machine_profile_fields || []) {
      if (!profileFieldSet.has(field)) warnings.push(`${relativePath}: unknown machine profile field ${field}`);
    }
  }
}

function validateRequired(relativePath, data, fields, errors) {
  for (const field of fields) {
    if (data[field] === undefined || data[field] === null || data[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }
}

function validateArray(relativePath, data, field, errors, allowEmpty = false) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }
  if (!allowEmpty && data[field].length === 0) errors.push(`${relativePath}: ${field} should not be empty`);
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

function validateNumber(relativePath, data, field, min, errors) {
  if (typeof data[field] !== "number" || data[field] < min) {
    errors.push(`${relativePath}: ${field} should be a number >= ${min}`);
  }
}

main();

