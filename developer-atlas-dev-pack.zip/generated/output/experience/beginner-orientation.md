# Beginner Orientation

## What this package is

This package is a public alpha demo of Developer Atlas. It helps testers review the mission, recovery guidance, completion checklist, AI-assisted builder view, and feedback flow.

Atlas package = read, guide, and reference.

Vue todo project = code and workspace.

Do not edit files inside the Atlas package unless a mission explicitly tells you to.

Most files here are guidance files. They help you understand what to do, where to look, and what to ignore while testing the Rookie Vue mission.

## Where to start

Start with:

```txt
START_HERE.md
```

Start there first. It tells you which mission file to open.

## Where the mission lives

The main learner-facing mission is:

```txt
mission/today-mission-surface.md
```

There is also an optional AI-assisted builder view:

```txt
mission/today-mission-surface.vibe.md
```

Open the AI-assisted view only if you normally use AI coding tools or want to review that path.

## Where your app code usually lives

In a real Vue project, app code usually lives in:

```txt
src/App.vue
src/components/
```

For this Rookie Vue mission, the first likely file to edit is:

```txt
src/App.vue
```

If your project is very small, App.vue may contain most of the todo app.

If your project already has components, the todo item may live in src/components/.

## What App.vue means

App.vue is usually the main Vue component. In small beginner projects, it often holds the main app layout and state.

For this mission, App.vue is the first place to check because the todo list state often starts there.

## Where to run terminal commands

For a little more help with commands, open `help/terminal-confidence-guide.md`.

Terminal commands should usually be run from the root folder of the Vue project.

Example commands:

```bash
npm install
npm run dev
```

Run these commands in the folder that contains:

```txt
package.json
```

If the terminal says it cannot find a script or package file, you may not be inside the project folder yet.

## What package.json means

package.json is the file that tells Node/npm what scripts and packages the project uses.

If you see package.json in the folder, you are probably near the right place to run npm commands.

## What to ignore for now

Beginners can ignore these during alpha testing:

- Feedback reports.
- Technical reports.
- Validation files.
- Source scripts.
- Package generation scripts.
- Internal project-owner notes.

You only need:

- `START_HERE.md`.
- `mission/today-mission-surface.md`.
- The completion checklist.
- The after-mission reflection.

AI-assisted builders can also open:

```txt
mission/today-mission-surface.vibe.md
```

## Tiny glossary

For slightly deeper Vue explanations, open `help/vue-concept-cards.md`.

**Vue** - a JavaScript framework for building interactive user interfaces.

**App.vue** - usually the main Vue component. In small apps, it often holds the main layout and state.

**Component** - a reusable piece of a Vue app, such as a todo item or button.

**Vue state** - the data your app is using right now, such as the current todo list.

**localStorage** - browser storage that can keep non-sensitive data after refresh and browser restart.

**sessionStorage** - browser storage that can keep non-sensitive data for the current tab/session.

**Terminal** - the place where you type commands such as `npm install` or `npm run dev`.

**Project folder** - the folder that contains the app files you are working on. For npm commands, it usually contains `package.json`.

**package.json** - the file that lists project scripts and packages for Node/npm.

**npm** - the tool commonly used to install packages and run scripts in JavaScript projects.
