// Orchestrates mission/package validation. Concern-specific checks live in tools/validators/.
const { requiredFiles, missionDir, parseJson } = require("./validators/shared-validator-utils");
const { validateGeneratedMission, validateStartHere, validateMissionSurface, validateVibeMissionSurface, validateAiPromptPack, validateMissionTwoSurface, validateVibeMissionTwoSurface, validateMissionThreeSurface, validateVibeMissionThreeSurface, validatePhase95And96Guardrails } = require("./validators/mission-content-validator");
const { validateMissionDashboard } = require("./validators/dashboard-accessibility-validator");
const { validateBeginnerOrientation, validateVueConceptCards, validateTerminalConfidenceGuide, validateTesterFeedbackReport, validateTesterHandoffMessages, validatePublicAlphaReadinessReport, validateAlphaFocusLock, validateCanonCandidateBacklogReport, validateAlphaPackageFinalQa, validateHumanAiReadabilityAudit, validateInheritedWarningBurnDownReport } = require("./validators/report-validator");
const { validateHardenedCanon } = require("./validators/hardened-canon-validator");
const { validatePackagedDemoStructure, validatePublicAlphaScopeNotExpanded } = require("./validators/package-structure-validator");
const { validateAiGuardrailEvaluation } = require("./validators/ai-guardrail-validator");
const { validateTemplateSplit, validateValidatorSplit, validatePhase97MaintainerGuardrails, validateAccessibilityPrinciple } = require("./validators/maintainer-docs-validator");
const { validateLearnerFacingPackageLanguage } = require("./validators/language-safety-validator");
const { validateMaintainerFileGrowth } = require("./validators/file-growth-validator");
const fs = require("fs");
const path = require("path");

function main() {
  const errors = [];
  const warnings = [];

  for (const fileName of requiredFiles) {
    const filePath = path.join(missionDir, fileName);
    if (!fs.existsSync(filePath)) {
      errors.push(`mission/${fileName}: missing file`);
      continue;
    }
    if (fileName.endsWith(".json")) parseJson(filePath, `mission/${fileName}`, errors);
  }

  validateGeneratedMission(errors, warnings);
  validateMissionSurface(errors, warnings);
  validateVibeMissionSurface(errors, warnings);
  validateAiPromptPack(errors, warnings);
  validateMissionTwoSurface(errors, warnings);
  validateVibeMissionTwoSurface(errors, warnings);
  validateMissionThreeSurface(errors, warnings);
  validateVibeMissionThreeSurface(errors, warnings);
  validateMissionDashboard(errors, warnings);
  validateStartHere(errors, warnings);
  validateBeginnerOrientation(errors, warnings);
  validateVueConceptCards(errors, warnings);
  validateTerminalConfidenceGuide(errors, warnings);
  validateTesterFeedbackReport(errors, warnings);
  validateTesterHandoffMessages(errors, warnings);
  validatePublicAlphaReadinessReport(errors, warnings);
  validateAlphaFocusLock(errors, warnings);
  validateCanonCandidateBacklogReport(errors, warnings);
  validateAlphaPackageFinalQa(errors, warnings);
  validateInheritedWarningBurnDownReport(errors, warnings);
  validateAiGuardrailEvaluation(errors, warnings);
  validateHardenedCanon(errors, warnings);
  validateTemplateSplit(errors);
  validateValidatorSplit(errors);
  validatePhase97MaintainerGuardrails(errors, warnings);
  validateAccessibilityPrinciple(errors);
  validatePhase95And96Guardrails(errors);
  validatePackagedDemoStructure(errors, warnings);
  validatePublicAlphaScopeNotExpanded(errors);
  validateLearnerFacingPackageLanguage(errors);
  validateMaintainerFileGrowth(warnings);

  console.log("Atlas Mission validation");
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

main();
