const fs = require("fs");
const path = require("path");
const {
  teamContextOutputDir,
  ensureTeamContextOutputDir,
  readTeamContexts,
  countValues,
  unique
} = require("./team-context-utils");

function main() {
  const contexts = readTeamContexts().map((record) => record.context);
  ensureTeamContextOutputDir();

  const generated = [];
  for (const context of contexts) {
    const shared = buildSharedAiContext(context);
    const onboarding = buildOnboardingContext(context);

    fs.writeFileSync(
      path.join(teamContextOutputDir, `${context.project_id}.json`),
      `${JSON.stringify({ source_context: context, shared_ai_context: shared, onboarding_context: onboarding }, null, 2)}\n`
    );
    fs.writeFileSync(
      path.join(teamContextOutputDir, `${context.project_id}-shared-ai-context.md`),
      sharedToMarkdown(shared)
    );
    fs.writeFileSync(
      path.join(teamContextOutputDir, `${context.project_id}-onboarding-context.md`),
      onboardingToMarkdown(onboarding)
    );

    generated.push({
      project_id: context.project_id,
      shared_ai_context: `output/team-context/${context.project_id}-shared-ai-context.md`,
      onboarding_context: `output/team-context/${context.project_id}-onboarding-context.md`,
      json: `output/team-context/${context.project_id}.json`
    });
  }

  const report = buildReport(contexts, generated);
  fs.writeFileSync(
    path.join(teamContextOutputDir, "team-context-report.md"),
    reportToMarkdown(report)
  );

  console.log(`Generated team context packs for ${contexts.length} project(s).`);
  console.log("Generated output/team-context/team-context-report.md.");
}

function buildSharedAiContext(context) {
  return {
    project_id: context.project_id,
    project_summary: `${context.project_id}: ${context.project_goals.join(" ")}`,
    team_standards: context.coding_standards,
    approved_stack: context.tech_stack,
    current_sprint: context.current_sprint,
    constraints: unique([
      ...context.architecture_notes,
      ...context.shared_hardware_assumptions
    ]),
    ai_rules: context.ai_usage_rules,
    forbidden_assumptions: context.what_ai_should_not_do,
    relevant_canon_nodes: context.shared_canon_nodes,
    setup_friction_context: unique([
      `Setup profile: ${context.shared_setup_profile}`,
      ...context.known_friction
    ]),
    onboarding_guidance: context.onboarding_notes
  };
}

function buildOnboardingContext(context) {
  return {
    project_id: context.project_id,
    first_day_focus: `Run the project using ${context.shared_setup_profile}, read the sprint goal, and make one small reviewable change.`,
    setup_profile: context.shared_setup_profile,
    approved_tools: context.approved_tools,
    starter_canon_nodes: context.shared_canon_nodes.slice(0, 5),
    known_friction: context.known_friction,
    team_expectations: unique([
      ...context.coding_standards.slice(0, 4),
      "Ask before changing architecture or adding dependencies."
    ]),
    ask_for_help_when: [
      "Setup fails after following the shared setup profile.",
      "An AI suggestion conflicts with team standards.",
      "A task appears to require architecture outside the current sprint."
    ]
  };
}

function buildReport(contexts, generated) {
  return {
    team_contexts_created: contexts.length,
    projects: contexts.map((context) => context.project_id),
    strongest_team_value: strongestTeamValue(contexts),
    most_common_stack: countValues(contexts.flatMap((context) => context.tech_stack)).slice(0, 8),
    most_common_canon_nodes: countValues(contexts.flatMap((context) => context.shared_canon_nodes)).slice(0, 8),
    most_common_friction: countValues(contexts.flatMap((context) => context.known_friction)).slice(0, 8),
    generated_files: generated.flatMap((item) => [item.json, item.shared_ai_context, item.onboarding_context])
  };
}

function strongestTeamValue(contexts) {
  const aiRules = contexts.reduce((total, context) => total + context.ai_usage_rules.length, 0);
  const forbidden = contexts.reduce((total, context) => total + context.what_ai_should_not_do.length, 0);
  const standards = contexts.reduce((total, context) => total + context.coding_standards.length, 0);
  if (aiRules + forbidden >= standards) return "Aligned AI usage rules and forbidden assumptions across projects.";
  return "Shared coding standards and setup expectations for repeatable onboarding.";
}

function sharedToMarkdown(shared) {
  return [
    `# Shared AI Context: ${shared.project_id}`,
    "",
    `Project summary: ${shared.project_summary}`,
    `Current sprint: ${shared.current_sprint}`,
    "",
    "## Approved Stack",
    "",
    ...formatList(shared.approved_stack),
    "",
    "## Team Standards",
    "",
    ...formatList(shared.team_standards),
    "",
    "## Constraints",
    "",
    ...formatList(shared.constraints),
    "",
    "## AI Rules",
    "",
    ...formatList(shared.ai_rules),
    "",
    "## Forbidden Assumptions",
    "",
    ...formatList(shared.forbidden_assumptions),
    "",
    "## Relevant Canon Nodes",
    "",
    ...formatList(shared.relevant_canon_nodes),
    "",
    "## Setup And Friction Context",
    "",
    ...formatList(shared.setup_friction_context),
    "",
    "## Onboarding Guidance",
    "",
    ...formatList(shared.onboarding_guidance)
  ].join("\n") + "\n";
}

function onboardingToMarkdown(onboarding) {
  return [
    `# Onboarding Context: ${onboarding.project_id}`,
    "",
    `First day focus: ${onboarding.first_day_focus}`,
    `Setup profile: ${onboarding.setup_profile}`,
    "",
    "## Approved Tools",
    "",
    ...formatList(onboarding.approved_tools),
    "",
    "## Starter Canon Nodes",
    "",
    ...formatList(onboarding.starter_canon_nodes),
    "",
    "## Known Friction",
    "",
    ...formatList(onboarding.known_friction),
    "",
    "## Team Expectations",
    "",
    ...formatList(onboarding.team_expectations),
    "",
    "## Ask For Help When",
    "",
    ...formatList(onboarding.ask_for_help_when)
  ].join("\n") + "\n";
}

function reportToMarkdown(report) {
  return [
    "# Atlas Team Context Report",
    "",
    `Team contexts created: ${report.team_contexts_created}`,
    `Strongest team value: ${report.strongest_team_value}`,
    "",
    "## Projects",
    "",
    ...formatList(report.projects),
    "",
    "## Most Common Stack",
    "",
    ...formatCounts(report.most_common_stack),
    "",
    "## Most Common Canon Nodes",
    "",
    ...formatCounts(report.most_common_canon_nodes),
    "",
    "## Most Common Friction",
    "",
    ...formatCounts(report.most_common_friction),
    "",
    "## Generated Files",
    "",
    ...formatList(report.generated_files)
  ].join("\n") + "\n";
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

main();
