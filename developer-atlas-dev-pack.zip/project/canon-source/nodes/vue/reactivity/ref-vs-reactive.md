# ref() vs reactive()

## Status Metadata

- Canon ID: CANON-003
- Node ID: canon.vue.reactivity.ref-vs-reactive
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: Vue reactivity
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `ref()` as the default way to declare reactive state in Vue Composition API, especially for primitives, replaceable values, and values returned from composables. Use `reactive()` when several object fields belong together and will be mutated as one cohesive object.

The everyday rule:

- `ref()` wraps a value behind `.value`.
- `reactive()` wraps an object in a proxy.
- `computed()` is for derived values.
- `watch()` is for side effects.

## What Problem This Solves

Vue developers often know both APIs but still get stuck on practical questions:

- Why does this state update in the template but not in script?
- Why does a destructured property stop updating?
- Should a form be one `reactive()` object or many `ref()` values?
- Why did replacing a `reactive()` object break state?
- Why does AI-generated Vue code omit `.value`?

This node solves the decision by focusing on state shape, replacement behavior, and how the state crosses component or composable boundaries.

## Mental Model

Think in wrappers.

`ref()` is a box with a `.value` inside it. Vue tracks reads and writes to that box.

```js
const count = ref(0);
count.value++;
```

`reactive()` is a proxy around an object. Vue tracks reads and writes to the object's properties.

```js
const form = reactive({ email: "", password: "" });
form.email = "ada@example.com";
```

The key difference is what you hold:

| Question | Better default |
| --- | --- |
| Is this a primitive like string, number, or boolean? | `ref()` |
| Will I replace the whole value? | `ref()` |
| Will I return this from a composable? | `ref()` or `toRefs()` |
| Is this a cohesive object with several fields? | `reactive()` |
| Am I deriving a value from other state? | `computed()` |
| Am I reacting with a side effect? | `watch()` |

## Beginner Explanation

Use `ref()` when you have one piece of state.

```js
const isOpen = ref(false);
isOpen.value = true;
```

In the script, you use `.value`. In the template, Vue unwraps refs for you.

```vue
<button>{{ isOpen ? "Open" : "Closed" }}</button>
```

Use `reactive()` when several fields belong together, like a form.

```js
const form = reactive({
  email: "",
  password: ""
});

form.email = "ada@example.com";
```

Beginner rule:

1. Start with `ref()` when unsure.
2. Use `reactive()` when the state is clearly one object.
3. Do not destructure `reactive()` casually.
4. Use `computed()` when the value can be calculated from other state.

## Professional Explanation

Vue's Composition API gives two core state primitives. `ref()` creates a stable container whose tracked value lives at `.value`. It works for primitives and objects, supports whole-value replacement, and is predictable when returned from composables.

`reactive()` creates a reactive proxy for an object. It is ergonomic for grouped object state because you can read and write properties directly. The trade-off is identity and destructuring: if you destructure a property into a plain variable, you detach that variable from the proxy's tracked property access.

In production code, the choice is not only syntax preference. It affects:

- How state is returned from composables.
- Whether whole-value replacement is expected.
- Whether destructuring is safe.
- How easy AI or teammates can generate correct updates.
- Whether form state is easier to validate and reset as a unit.

Prefer `ref()` for values that cross boundaries. Prefer `reactive()` for cohesive local objects when property access is clearer than `.value`.

## Syntax

```js
import { ref, reactive, computed, toRefs } from "vue";

const count = ref(0);
count.value++;

const form = reactive({
  email: "",
  password: ""
});
form.email = "ada@example.com";
```

Safe destructuring with `toRefs()`:

```js
const state = reactive({ count: 0, label: "Clicks" });
const { count, label } = toRefs(state);

count.value++;
```

## Decision Guide

Ask these questions in order:

1. Is the state a primitive value?
   Use `ref()`.
2. Will the whole value be replaced, such as a selected item, API result, or array?
   Use `ref()`.
3. Will the state be returned from a composable?
   Prefer `ref()` values or use `toRefs()` for reactive object properties.
4. Are several fields part of one local object, such as form fields or modal state?
   Use `reactive()`.
5. Is the value derived from other state?
   Use `computed()`, not `ref()` or `reactive()` as manual cache.
6. Do you need to run a side effect when state changes?
   Use `watch()`.

## Comparison Table

| Feature | `ref()` | `reactive()` |
| --- | --- | --- |
| Best default | Most state, especially primitives | Cohesive object state |
| Access in script | `value.value` | `object.property` |
| Access in template | Unwrapped | Direct property access |
| Works with primitives | Yes | No, object types only |
| Whole-value replacement | Natural | Avoid replacing the proxy |
| Destructuring safety | Stable if you keep the ref | Unsafe unless using `toRefs()` |
| Composable return values | Excellent | Needs care |
| Form ergonomics | Good for individual fields | Good for grouped fields |
| AI mistake risk | Forgetting `.value` | Unsafe destructuring or replacement |

## When To Use The Primary Option

Use `ref()` when:

- The value is a string, number, boolean, array, or nullable object.
- You expect to replace the whole value.
- You are storing loading, error, selected item, current route-derived state, or API result state.
- You are returning state from a composable.
- You want explicit `.value` in script code.

```js
const isLoading = ref(false);
const selectedUser = ref(null);
const users = ref([]);
```

## When To Use The Alternative

Use `reactive()` when:

- Several fields belong together.
- The state is local to the component or composable.
- Mutating properties is clearer than replacing the object.
- You are modeling form state, filters, or UI state as a single object.

```js
const filters = reactive({
  search: "",
  status: "active",
  page: 1
});
```

## When Not To Use This Decision

Do not use either API as a substitute for the right reactivity tool:

- Use `computed()` for derived values.
- Use `watch()` for side effects.
- Use props for parent-provided state.
- Use emits for child-to-parent updates.
- Use a store when state is shared widely across the app.
- Avoid `reactive()` when you need to frequently replace the whole object.
- Avoid casual destructuring of `reactive()` properties.

## Alternatives

- `computed()` for derived values.
- `watch()` for side effects.
- `toRef()` and `toRefs()` for property refs.
- Props and emits for component boundaries.
- Pinia or another store for shared application state.

## Production Examples

### Fetch State With ref()

```js
const users = ref([]);
const isLoading = ref(false);
const errorMessage = ref("");

async function loadUsers() {
  isLoading.value = true;
  errorMessage.value = "";

  try {
    users.value = await api.fetchUsers();
  } catch (error) {
    errorMessage.value = "Could not load users.";
  } finally {
    isLoading.value = false;
  }
}
```

Why `ref()` fits: each value can be replaced independently, and the array from the API is replaced as a whole.

### Form State With reactive()

```js
const form = reactive({
  email: "",
  password: "",
  rememberMe: false
});

function resetForm() {
  form.email = "";
  form.password = "";
  form.rememberMe = false;
}
```

Why `reactive()` fits: the fields belong together and are mutated as one local form object.

### Composable Return With toRefs()

```js
function useLoginForm() {
  const form = reactive({
    email: "",
    password: ""
  });

  return {
    ...toRefs(form)
  };
}
```

Why `toRefs()` fits: callers can destructure returned properties without losing reactivity.

## Common Mistakes

- Forgetting `.value` when reading or writing refs in script code.
- Writing `count++` instead of `count.value++`.
- Destructuring a `reactive()` object into plain variables.
- Replacing a `reactive()` object instead of mutating its properties.
- Using `watch()` to manually maintain a value that should be `computed()`.
- Returning a raw `reactive()` object from a composable and then destructuring it at the call site.
- Mixing `ref()` and `reactive()` in one state object without a clear reason.

## Debugging Checklist

- If a ref is not updating, did you forget `.value` in script code?
- If a destructured value is stale, did it come from `reactive()` without `toRefs()`?
- If a form reset fails, are you replacing the reactive object instead of mutating its properties?
- If a derived value is out of sync, should it be `computed()`?
- If a side effect runs too often, should the watched source be narrower?
- If AI-generated code looks plausible but fails, check `.value`, destructuring, and whole-object replacement first.

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-003/`.

Verification command:

```sh
npm run canon:verify:003
```

The verification suite checks:

- `ref()` primitive updates through `.value`.
- `reactive()` object property updates.
- The mistake of forgetting `.value`.
- The destructuring pitfall and a safe `toRefs()`-style alternative.

## Performance Notes

Choose `ref()` or `reactive()` for clarity before performance. In most components, the performance difference is less important than correct dependency tracking and maintainable state boundaries.

Performance-sensitive concerns usually come from too much reactive state, overly broad watchers, or expensive computed work, not from the simple choice between `ref()` and `reactive()`.

## AI Coding Guidance

When generating Vue Composition API code:

- Prefer `ref()` for primitive, replaceable, nullable, API result, and composable-returned state.
- Use `.value` for refs in script code.
- Do not use `.value` in templates.
- Use `reactive()` for cohesive local object state.
- Do not destructure `reactive()` directly unless using `toRefs()` or `toRef()`.
- Do not replace a `reactive()` object wholesale.
- Use `computed()` for derived state.
- Use `watch()` only for side effects.
- Explain the choice using state shape and boundary behavior.

Bad AI output:

```js
const count = ref(0);
count++;
```

Good AI output:

```js
const count = ref(0);
count.value++;
```

## Teaching Notes

Teach in this order:

1. Ref as a box with `.value`.
2. Template unwrapping.
3. Reactive as an object proxy.
4. Destructuring pitfall.
5. Computed and watch as separate tools.

Useful teaching phrase:

> `ref()` protects a value; `reactive()` protects an object relationship.

## Interview Questions

1. Why does `ref()` require `.value` in script code?
2. Why does the template not require `.value` for refs?
3. What can go wrong when destructuring `reactive()`?
4. When would you choose `reactive()` for a form?
5. When should a value be `computed()` instead?
6. How would you safely return reactive object fields from a composable?

## Exercises

### Beginner

Create a counter with `ref()` and increment it from a function.

### Intermediate

Create a login form with `reactive()` and a reset function.

### Advanced

Refactor a composable that returns a raw reactive object so callers can safely destructure its fields.

## Related Atlas Nodes

- `vue.reactivity.ref`
- `vue.reactivity.reactive`
- `vue.reactivity.computed`
- `vue.reactivity.watch`
- `vue.directive.v-model`
- `vue.component.defineProps`
- `vue.component.defineEmits`

## Evidence And Sources

- Vue Reactivity API: Core, `ref()` and `reactive()`: https://vuejs.org/api/reactivity-core
- Vue Guide: Reactivity Fundamentals: https://vuejs.org/guide/essentials/reactivity-fundamentals.html
- Vue SFC `<script setup>` API: https://vuejs.org/api/sfc-script-setup
- Vue Guide: Composition API FAQ: https://vuejs.org/guide/extras/composition-api-faq.html

## Proof Of Superiority Summary

Official Vue docs explain what `ref()` and `reactive()` do. This Canon node explains how to choose between them in production code, why common mistakes happen, how destructuring changes behavior, how AI should generate safe Composition API code, and when `computed()`, `watch()`, props, emits, or stores are better tools.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 9 |
| ai_readiness | 10 | 10 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
