# Pack Send Checklist

## Purpose

Use this checklist before sending an Atlas pack to a tester.

This is owner-facing and not required learner reading.

## Before sending

- Run `npm run package:packs`.
- Run `npm run validate:packs`.
- Choose one tester goal.
- Choose one pack.
- Do not send multiple packs to a new tester.

## Pick one pack

- Complete beginner or first-impression test with a basic Vue project already open: Rookie Pack.
- Rookie Mission 1 non-AI test: Rookie Pack.
- Normal learner, AI-assisted, or Missions 1-3 test: Full Pack.
- Maintainer or contributor: Dev Pack.
- Unsure: Rookie Pack first.

Use `which-pack-should-i-send.md` if the choice is unclear.

Use `real-feedback-register.md` after the tester responds.

## Send one zip

Send only one zip.

Tell the tester what to open first.

For Rookie and Full Pack, tell them to open `mission-dashboard.html` in a browser.

For Rookie Pack, tell them it starts after their basic Vue to-do project already exists.

For Rookie Pack, do not mention AI or reference material.

First tester signal: the Rookie Pack start was clear, but Mission 1 needed better laptop readability.

Second tester signal: Rookie Pack is not a zero-install or zero-project setup pack.

Do not explain every folder before they open it.

## Ask one question

- Rookie Pack: Was it clear this starts after your Vue project already exists?
- Full Pack: Could you follow the missions without feeling lost?
- Dev Pack: Could you find the build, validation, and packaging files?

Ask one main question first. Add follow-up questions only after they respond.

## Record the result

- Record pack sent.
- Record tester type.
- Record first reaction.
- Record where they got stuck.
- Record the next improvement.
- Record real feedback in `reviewer/real-feedback-register.md`.

## What not to do

- Do not send all packs at once.
- Do not send Dev Pack to a beginner.
- Do not explain the whole project before the tester opens the pack.
- Do not ask for too much feedback in the first message.
- Do not add new features before recording the result.
- For Rookie Pack, do not mention AI or reference material.

## Quick copy/paste messages

### Rookie Pack message

Hey, I'm testing the beginner version of Developer Atlas. This starts after you already have a basic Vue to-do project. Please unzip this, open `mission-dashboard.html` in your browser, and tell me one thing first: is that starting point clear?

### Full Pack message

Hey, I'm testing the current learner version of Developer Atlas. Please unzip this, open `mission-dashboard.html`, try the mission path, and tell me whether you could follow it without feeling lost.

### Dev Pack message

Hey, I'm sharing the maintainer version of Developer Atlas. This includes the build, validation, packaging, docs, and project internals. Please check whether you can find the files needed to understand how the package is built.
