# CANON-022 Proof Of Superiority

## Status

- Canon ID: CANON-022
- Node ID: canon.javascript.storage.localstorage-vs-sessionstorage
- Status: Gold Candidate
- Current score: 95

## Baseline Compared

MDN explains `localStorage`, `sessionStorage`, the Web Storage API, and the `Storage` interface accurately. That reference material is the evidence base.

Common tutorials often show simple snippets like:

- Save a string with `localStorage.setItem()`.
- Read a value with `localStorage.getItem()`.
- Clear a key.

What they often do not make explicit is the decision model: expected lifetime, tab/session scope, JSON conversion, storage security, and when Web Storage should not be used.

## Atlas Improvement

Atlas improves the topic by turning Web Storage into a practical beginner and production decision:

- `localStorage` is persistent browser key-value storage.
- `sessionStorage` is tab/session-scoped key-value storage.
- Both store strings, so arrays and objects require JSON conversion.
- Neither is appropriate for secrets, tokens, passwords, private keys, or sensitive personal data.
- The Rookie Vue Todo app can use `localStorage` as a practical next persistence feature.

## Evidence

- MDN, `Window.localStorage`: https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
- MDN, `Window.sessionStorage`: https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage
- MDN, Web Storage API: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API
- MDN, Storage interface: https://developer.mozilla.org/en-US/docs/Web/API/Storage

## Mechanical Verification

Examples in `canon/examples/CANON-022/` verify the core behavior deterministically:

- Save todo list to `localStorage` using `JSON.stringify()`.
- Load todo list from `localStorage` using `JSON.parse()`.
- Save a tab-scoped draft to `sessionStorage`.
- Reject sensitive data as a browser-storage mistake.

Run:

```bash
npm run canon:verify:022
```

## Why This Is Better Than Generic Documentation

The Atlas node is not trying to replace MDN. It adds the missing decision layer:

- Beginner mental model.
- Professional review signals.
- Security and privacy warnings.
- JSON relationship to CANON-017.
- Rookie Vue Todo persistence next step.
- Deterministic examples.
- AI coding guidance.

## Remaining Gap Before Gold

Named reviewer sign-off is still required:

- Technical reviewer.
- Educational reviewer.
- AI-readiness reviewer.
- Engineering reviewer.
