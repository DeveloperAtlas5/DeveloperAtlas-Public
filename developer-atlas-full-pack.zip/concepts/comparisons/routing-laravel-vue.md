# Routing in Laravel vs Vue

## Shared idea

Routing decides what should happen when the user goes somewhere.

## Laravel routing

A browser or API request goes to Laravel. Laravel matches the URL and sends it to a controller, closure, middleware, or response.

## Vue routing

The browser URL changes. Vue Router decides which component or page view should be shown.

## Main difference

Laravel routing usually handles server requests. Vue routing usually changes the page view inside the browser.

## Related concepts

Controller, Component, API route, Page, Link
