const orders = [
  { id: 1, customer_id: "c1", status: "paid", active: true, total_cents: 70000 },
  { id: 2, customer_id: "c1", status: "paid", active: true, total_cents: 50000 },
  { id: 3, customer_id: "c1", status: "refunded", active: true, total_cents: 30000 },
  { id: 4, customer_id: "c2", status: "paid", active: false, total_cents: 40000 },
  { id: 5, customer_id: "c2", status: "paid", active: true, total_cents: 20000 },
  { id: 6, customer_id: "c3", status: "pending", active: true, total_cents: 90000 }
];

function groupByCustomer(rows) {
  const groups = new Map();

  for (const row of rows) {
    const current = groups.get(row.customer_id) || {
      customer_id: row.customer_id,
      count: 0,
      total_cents: 0,
      rows: []
    };

    current.count += 1;
    current.total_cents += row.total_cents;
    current.rows.push(row);
    groups.set(row.customer_id, current);
  }

  return Array.from(groups.values()).sort((a, b) => a.customer_id.localeCompare(b.customer_id));
}

function assertNoAggregateInWhere(whereExpression) {
  if (/\b(COUNT|SUM|AVG|MIN|MAX)\s*\(/i.test(whereExpression)) {
    throw new Error("Aggregate functions belong in HAVING, not WHERE.");
  }
}

module.exports = {
  orders,
  groupByCustomer,
  assertNoAggregateInWhere
};
