# CANON-029 - v-for + :key

Status: Hardened

## Core idea

v-for renders lists.

:key helps Vue track items predictably.

Use a stable id when available.

## Use this when

Use this when rendering todos.

## Basic pattern

Loop through the list and give each item a stable key.

## Common friction

Unstable keys can cause unpredictable updates.

## Small example

```vue
<li v-for="todo in todos" :key="todo.id">{{ todo.text }}</li>
```

## Check yourself

- Does each item have a stable key?
- Does the key come from the todo when possible?

## Related Canon nodes

- CANON-030
- CANON-031
