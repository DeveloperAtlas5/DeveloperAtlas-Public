const fs = require("fs");
const path = require("path");
const {
  toolkitDir,
  readTools,
  readSetupProfiles
} = require("./toolkit-utils");

const requiredSchemaFiles = [
  "tool.schema.json",
  "extension.schema.json",
  "setup-profile.schema.json",
  "tool-decision-guide.schema.json"
];

const requiredToolFields = [
  "id",
  "name",
  "category",
  "description",
  "solves",
  "recommended_for",
  "avoid_when",
  "beginner_fit",
  "professional_fit",
  "platforms",
  "price_model",
  "setup_difficulty",
  "friction_reduction_score",
  "related_friction_nodes",
  "related_canon_nodes",
  "alternatives",
  "install_notes",
  "verification_steps"
];

const toolArrayFields = [
  "solves",
  "recommended_for",
  "avoid_when",
  "platforms",
  "related_friction_nodes",
  "related_canon_nodes",
  "alternatives",
  "install_notes",
  "verification_steps"
];

const requiredProfileFields = [
  "profile_id",
  "audience",
  "operating_system",
  "stack",
  "required_tools",
  "recommended_extensions",
  "optional_tools",
  "setup_order",
  "verification_checklist",
  "common_friction_nodes"
];

const profileArrayFields = [
  "stack",
  "required_tools",
  "recommended_extensions",
  "optional_tools",
  "setup_order",
  "verification_checklist",
  "common_friction_nodes"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemaFiles(errors);

  let toolRecords = [];
  let profileRecords = [];

  try {
    toolRecords = readTools();
    profileRecords = readSetupProfiles();
  } catch (error) {
    errors.push(`toolkit: unable to read JSON files (${error.message})`);
  }

  const knownToolIds = new Set(toolRecords.map((record) => record.data.id));
  validateTools(toolRecords, errors, warnings);
  validateProfiles(profileRecords, knownToolIds, errors, warnings);

  console.log("Atlas Toolkit validation");
  console.log(`Tools and extensions: ${toolRecords.length}`);
  console.log(`Setup profiles: ${profileRecords.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemaFiles(errors) {
  for (const fileName of requiredSchemaFiles) {
    const schemaPath = path.join(toolkitDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`toolkit/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`toolkit/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateTools(records, errors, warnings) {
  const seenIds = new Set();

  for (const { data, relativePath } of records) {
    validateRequiredFields(relativePath, data, requiredToolFields, errors);
    validateUniqueId(relativePath, data.id, seenIds, errors);

    for (const field of toolArrayFields) {
      validateStringArray(relativePath, data, field, errors);
    }

    validateRange(relativePath, data, "beginner_fit", 0, 100, errors);
    validateRange(relativePath, data, "professional_fit", 0, 100, errors);
    validateRange(relativePath, data, "setup_difficulty", 0, 100, errors);
    validateRange(relativePath, data, "friction_reduction_score", 0, 100, errors);

    // Tools that claim high friction reduction should explain how setup success is verified.
    if (data.friction_reduction_score >= 80 && (!data.verification_steps || data.verification_steps.length < 2)) {
      warnings.push(`${relativePath}: high-friction-reduction tools should include at least two verification steps`);
    }
  }
}

function validateProfiles(records, knownToolIds, errors, warnings) {
  const seenIds = new Set();

  for (const { data, relativePath } of records) {
    validateRequiredFields(relativePath, data, requiredProfileFields, errors);
    validateUniqueId(relativePath, data.profile_id, seenIds, errors);

    for (const field of profileArrayFields) {
      validateStringArray(relativePath, data, field, errors);
    }

    for (const field of ["required_tools", "recommended_extensions", "optional_tools"]) {
      for (const id of data[field] || []) {
        if (!knownToolIds.has(id)) warnings.push(`${relativePath}: ${field} references unknown tool ${id}`);
      }
    }
  }
}

function validateRequiredFields(relativePath, data, fields, errors) {
  for (const field of fields) {
    if (data[field] === undefined || data[field] === null || data[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }
}

function validateUniqueId(relativePath, id, seenIds, errors) {
  if (typeof id !== "string" || !id.trim()) {
    errors.push(`${relativePath}: id should be a non-empty string`);
    return;
  }

  if (seenIds.has(id)) errors.push(`${relativePath}: duplicate id ${id}`);
  seenIds.add(id);
}

function validateStringArray(relativePath, data, field, errors) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }

  for (const value of data[field]) {
    if (typeof value !== "string" || !value.trim()) {
      errors.push(`${relativePath}: ${field} contains a non-string entry`);
    }
  }
}

function validateRange(relativePath, data, field, min, max, errors) {
  const value = data[field];
  if (typeof value !== "number" || value < min || value > max) {
    errors.push(`${relativePath}: ${field} should be a number from ${min} to ${max}`);
  }
}

main();
