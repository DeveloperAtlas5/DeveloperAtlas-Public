# Atlas AI Context Report

Context packs generated: 4

## Shortest Pack

- local-ai-hardware-advice: 1502 characters

## Most Complete Pack

- jefry-fullstack-ai-game-dev: 18 context points

## Generated Files

- output/ai-context/jefry-fullstack-ai-game-dev.json
- output/ai-context/jefry-fullstack-ai-game-dev.md
- output/ai-context/laravel-api-debugging.json
- output/ai-context/laravel-api-debugging.md
- output/ai-context/local-ai-hardware-advice.json
- output/ai-context/local-ai-hardware-advice.md
- output/ai-context/rookie-vue-next-step.json
- output/ai-context/rookie-vue-next-step.md
