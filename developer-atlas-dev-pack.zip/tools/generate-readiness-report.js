const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readGoals } = require("./goal-utils");
const { readTools } = require("./toolkit-utils");
const { readFrictionNodes } = require("./friction-utils");
const { readMachineProfiles, readWorkloadProfiles } = require("./hardware-utils");
const {
  readinessOutputDir,
  ensureReadinessOutputDir,
  readReadinessProfiles,
  average,
  round,
  unique
} = require("./readiness-utils");

function main() {
  const profiles = readReadinessProfiles().map((record) => record.profile);
  const context = readContext();
  const reports = profiles.map((profile) => buildReadinessReport(profile, context));
  const summary = buildSummary(reports);

  ensureReadinessOutputDir();

  for (const report of reports) {
    const baseName = report.profile_summary.readiness_id.replace(/^readiness\./, "").replace(/\./g, "-");
    fs.writeFileSync(path.join(readinessOutputDir, `${baseName}.json`), `${JSON.stringify(report, null, 2)}\n`);
    fs.writeFileSync(path.join(readinessOutputDir, `${baseName}.md`), toMarkdown(report));
  }

  fs.writeFileSync(path.join(readinessOutputDir, "readiness-report.json"), `${JSON.stringify(summary, null, 2)}\n`);
  fs.writeFileSync(path.join(readinessOutputDir, "readiness-report.md"), toSummaryMarkdown(summary));

  console.log(`Generated readiness reports for ${reports.length} profile(s).`);
  console.log("Generated output/readiness/readiness-report.json and output/readiness/readiness-report.md.");
}

function readContext() {
  const canonIndex = JSON.parse(fs.readFileSync(path.join(rootDir, "canon", "canon-index.json"), "utf8"));
  const momentumPath = path.join(rootDir, "output", "momentum", "momentum-report.json");
  const momentum = fs.existsSync(momentumPath)
    ? JSON.parse(fs.readFileSync(momentumPath, "utf8"))
    : { confidence_improvement: 0, most_common_blockers: [] };

  return {
    goalsById: new Map(readGoals().map((record) => [record.goal.goal_id, record.goal])),
    canonById: new Map(canonIndex.entries.map((entry) => [entry.canon_id, entry])),
    toolsById: new Map(readTools().map((record) => [record.data.id, record.data])),
    frictionById: new Map(readFrictionNodes().map((record) => [record.node.id, record.node])),
    machineById: new Map(readMachineProfiles().map((record) => [record.profile.profile_id, record.profile])),
    workloadsById: new Map(readWorkloadProfiles().map((record) => [record.workload.workload_id, record.workload])),
    momentum
  };
}

function buildReadinessReport(profile, context) {
  const targetGoals = profile.target_goal_ids.map((goalId) => context.goalsById.get(goalId)).filter(Boolean);
  const requiredKnowledge = unique(targetGoals.flatMap((goal) => goal.required_knowledge_nodes));
  const recommendedCanon = unique(targetGoals.flatMap((goal) => goal.recommended_canon_nodes));
  const requiredTools = unique(targetGoals.flatMap((goal) => goal.required_tools));
  const recommendedTools = unique(targetGoals.flatMap((goal) => goal.recommended_tools));
  const frictionRisks = unique(targetGoals.flatMap((goal) => goal.common_friction_nodes));
  const workloadIds = unique(targetGoals.flatMap((goal) => goal.hardware_considerations));
  const machine = context.machineById.get(profile.machine_profile_id);

  const missingKnowledge = requiredKnowledge.filter((nodeId) => !profile.known_nodes.includes(nodeId));
  const missingPractice = recommendedCanon.filter((canonId) => {
    return !profile.completed_practice.some((practice) => practice.includes(canonId));
  });
  const toolingGaps = inferToolingGaps(profile, requiredTools, recommendedTools);
  const hardwareConcerns = inferHardwareConcerns(machine, workloadIds, context);
  const likelyFrictionRisks = frictionRisks.filter((risk) => context.frictionById.has(risk));

  const scores = scoreReadiness({
    profile,
    targetGoals,
    requiredKnowledge,
    missingKnowledge,
    recommendedCanon,
    missingPractice,
    requiredTools,
    toolingGaps,
    workloadIds,
    hardwareConcerns,
    likelyFrictionRisks,
    momentum: context.momentum
  });

  const areas = categoryScores(scores);
  const estimatedHoursToReady = estimateHoursToReady(missingKnowledge, missingPractice, toolingGaps, likelyFrictionRisks);

  return {
    profile_summary: {
      readiness_id: profile.readiness_id,
      profile_id: profile.profile_id,
      learner_level: profile.learner_level,
      machine_profile_id: profile.machine_profile_id,
      available_hours_per_week: profile.available_hours_per_week,
      desired_output: profile.desired_output
    },
    target_goals: targetGoals.map((goal) => goal.goal_id),
    readiness_score: scores.overall_score,
    readiness_status: scores.status,
    score_breakdown: scores,
    strongest_areas: areas.slice(-3).reverse().map((area) => `${area.label}: ${area.score}`),
    weakest_areas: areas.slice(0, 3).map((area) => `${area.label}: ${area.score}`),
    missing_knowledge: missingKnowledge,
    missing_practice: missingPractice,
    tooling_gaps: toolingGaps,
    hardware_concerns: hardwareConcerns,
    likely_friction_risks: likelyFrictionRisks,
    estimated_hours_to_ready: estimatedHoursToReady,
    recommended_next_3_steps: nextSteps(missingKnowledge, missingPractice, toolingGaps, likelyFrictionRisks, scores),
    what_to_skip_for_now: skipList(profile, targetGoals, scores),
    ai_ready_context_summary: aiContext(profile, targetGoals, scores, missingKnowledge, toolingGaps, hardwareConcerns)
  };
}

function inferToolingGaps(profile, requiredTools, recommendedTools) {
  const stackText = profile.preferred_stack.join(" ").toLowerCase();
  const constraintsText = profile.constraints.join(" ").toLowerCase();
  const likelyReady = new Set();

  if (/vue|javascript|node|web/.test(stackText)) likelyReady.add("tool.node");
  if (/laravel|php/.test(stackText)) likelyReady.add("tool.composer");
  if (/vue|web|laravel|javascript|php|sql|unity|ai/.test(stackText)) likelyReady.add("tool.git");
  if (/vue|web|javascript|laravel/.test(stackText)) likelyReady.add("tool.vscode");
  if (/api|laravel/.test(stackText)) likelyReady.add("tool.postman");
  if (/docker/.test(stackText) && !constraintsText.includes("avoid docker")) likelyReady.add("tool.docker");

  return unique([...requiredTools, ...recommendedTools])
    .filter((toolId) => !likelyReady.has(toolId))
    .slice(0, 10);
}

function inferHardwareConcerns(machine, workloadIds, context) {
  const concerns = [];
  if (!machine) return ["Machine profile is missing; verify hardware assumptions before committing to the project."];

  if (machine.system_ram_gb <= 8 && workloadIds.some((id) => /fullstack|docker|unity/.test(id))) {
    concerns.push("RAM may limit multitasking, local services, Docker, or game tooling.");
  }
  if (machine.gpu_vram_gb < 12 && workloadIds.some((id) => id.includes("llm"))) {
    concerns.push("Local AI work may be constrained by GPU VRAM; validate model size before buying anything.");
  }
  if (machine.storage_total_gb > 0 && machine.storage_free_gb / machine.storage_total_gb < 0.15) {
    concerns.push("Low storage headroom can cause dependency, build, Docker, or asset-cache friction.");
  }
  for (const workloadId of workloadIds) {
    const workload = context.workloadsById.get(workloadId);
    if (workload && workload.estimated_risk_of_wrong_purchase >= 85) {
      concerns.push(`${workloadId} has high purchase-mismatch risk; use experiments before hardware commitments.`);
    }
  }

  return unique(concerns);
}

function scoreReadiness(input) {
  const knowledgeScore = ratioScore(input.requiredKnowledge.length - input.missingKnowledge.length, input.requiredKnowledge.length);
  const canonPracticeScore = ratioScore(input.recommendedCanon.length - input.missingPractice.length, input.recommendedCanon.length);
  const generalPracticeScore = ratioScore(
    input.profile.completed_practice.length,
    Math.max(1, Math.ceil(input.recommendedCanon.length * 0.6))
  );
  const practiceScore = round(Math.max(canonPracticeScore, generalPracticeScore * 0.85));
  const toolingScore = clamp(100 - input.toolingGaps.length * 10);
  const hardwareScore = clamp(100 - input.hardwareConcerns.length * 15);
  const frictionScore = clamp(100 - input.likelyFrictionRisks.length * 8);
  const momentumScore = clamp(input.profile.confidence_before * 80 + (input.momentum.confidence_improvement || 0) * 40);
  const totalHours = input.targetGoals.reduce((total, goal) => {
    return total + goal.estimated_learning_hours + goal.estimated_practice_hours;
  }, 0);
  const timeScore = clamp(input.profile.available_hours_per_week >= 10 ? 85 : input.profile.available_hours_per_week >= 6 ? 70 : 50);

  const overall = round(
    knowledgeScore * 0.24 +
    practiceScore * 0.16 +
    toolingScore * 0.14 +
    hardwareScore * 0.12 +
    frictionScore * 0.12 +
    momentumScore * 0.12 +
    timeScore * 0.1 -
    Math.min(5, totalHours / 120)
  );

  return {
    knowledge_score: knowledgeScore,
    practice_score: practiceScore,
    tooling_score: toolingScore,
    hardware_score: hardwareScore,
    friction_score: frictionScore,
    momentum_score: round(momentumScore),
    time_score: timeScore,
    overall_score: clamp(overall),
    status: statusFor(overall)
  };
}

function ratioScore(done, total) {
  return total ? round(clamp((done / total) * 100)) : 100;
}

function statusFor(score) {
  if (score >= 85) return "ready";
  if (score >= 70) return "mostly_ready";
  if (score >= 45) return "needs_foundation";
  return "defer_for_now";
}

function categoryScores(scores) {
  return [
    ["knowledge", scores.knowledge_score],
    ["practice", scores.practice_score],
    ["tooling", scores.tooling_score],
    ["hardware", scores.hardware_score],
    ["friction", scores.friction_score],
    ["momentum", scores.momentum_score],
    ["time", scores.time_score]
  ].map(([label, score]) => ({ label, score })).sort((a, b) => a.score - b.score || a.label.localeCompare(b.label));
}

function estimateHoursToReady(missingKnowledge, missingPractice, toolingGaps, frictionRisks) {
  return missingKnowledge.length * 2 + missingPractice.length * 3 + toolingGaps.length * 1.5 + frictionRisks.length;
}

function nextSteps(missingKnowledge, missingPractice, toolingGaps, frictionRisks, scores) {
  const steps = [];
  if (missingKnowledge.length) steps.push(`Study and practice the first missing knowledge node: ${missingKnowledge[0]}.`);
  if (toolingGaps.length) steps.push(`Verify or install the most important missing tool: ${toolingGaps[0]}.`);
  if (frictionRisks.length) steps.push(`Read the recovery path for likely blocker: ${frictionRisks[0]}.`);
  if (missingPractice.length && steps.length < 3) steps.push(`Complete one small practice task tied to ${missingPractice[0]}.`);
  if (steps.length < 3) steps.push(`Build the smallest possible version and stop after one working slice.`);
  if (scores.status === "defer_for_now") steps.unshift("Shrink the target project before continuing; choose a one-feature version.");
  return steps.slice(0, 3);
}

function skipList(profile, goals, scores) {
  const skips = ["Skip product-specific buying decisions until the workload is measured."];
  if (scores.knowledge_score < 60) skips.push("Skip advanced architecture until the missing foundations are practiced.");
  if (profile.constraints.join(" ").toLowerCase().includes("avoid docker")) skips.push("Skip Docker until the first local app runs without it.");
  if (goals.length > 2) skips.push("Skip parallel deep dives; finish one vertical slice before branching.");
  return skips;
}

function aiContext(profile, goals, scores, missingKnowledge, toolingGaps, hardwareConcerns) {
  return [
    `I am trying to achieve these goals: ${goals.map((goal) => goal.title).join(", ")}.`,
    `My current readiness is ${scores.status} with an overall score of ${scores.overall_score}/100.`,
    `My missing knowledge is: ${missingKnowledge.slice(0, 8).join(", ") || "none identified"}.`,
    `My hardware/tooling constraints are: ${[...toolingGaps.slice(0, 5), ...hardwareConcerns.slice(0, 3)].join("; ") || "none identified"}.`,
    "Please help me with the next step only."
  ].join(" ");
}

function buildSummary(reports) {
  const allCategories = reports.flatMap((report) => categoryScores(report.score_breakdown));
  const categoryAverages = {};
  for (const label of ["knowledge", "practice", "tooling", "hardware", "friction", "momentum", "time"]) {
    categoryAverages[label] = round(average(reports.map((report) => report.score_breakdown[`${label}_score`])));
  }
  const sortedCategories = Object.entries(categoryAverages).sort((a, b) => a[1] - b[1] || a[0].localeCompare(b[0]));

  return {
    readiness_examples_processed: reports.length,
    average_readiness_score: round(average(reports.map((report) => report.readiness_score))),
    weakest_readiness_category: { category: sortedCategories[0][0], score: sortedCategories[0][1] },
    strongest_readiness_category: { category: sortedCategories[sortedCategories.length - 1][0], score: sortedCategories[sortedCategories.length - 1][1] },
    status_counts: countStatuses(reports),
    reports: reports.map((report) => ({
      readiness_id: report.profile_summary.readiness_id,
      score: report.readiness_score,
      status: report.readiness_status,
      weakest_areas: report.weakest_areas,
      strongest_areas: report.strongest_areas
    }))
  };
}

function countStatuses(reports) {
  const counts = {};
  for (const report of reports) counts[report.readiness_status] = (counts[report.readiness_status] || 0) + 1;
  return counts;
}

function toMarkdown(report) {
  const lines = [
    `# Readiness Report: ${report.profile_summary.readiness_id}`,
    "",
    `Profile: ${report.profile_summary.profile_id}`,
    `Desired output: ${report.profile_summary.desired_output}`,
    `Readiness score: ${report.readiness_score}/100`,
    `Readiness status: ${report.readiness_status}`,
    "",
    "## Score Breakdown",
    "",
    ...Object.entries(report.score_breakdown).map(([key, value]) => `- ${key}: ${value}`),
    "",
    "## Strongest Areas",
    "",
    ...formatList(report.strongest_areas),
    "",
    "## Weakest Areas",
    "",
    ...formatList(report.weakest_areas),
    "",
    "## Missing Knowledge",
    "",
    ...formatList(report.missing_knowledge),
    "",
    "## Missing Practice",
    "",
    ...formatList(report.missing_practice),
    "",
    "## Tooling Gaps",
    "",
    ...formatList(report.tooling_gaps),
    "",
    "## Hardware Concerns",
    "",
    ...formatList(report.hardware_concerns),
    "",
    "## Likely Friction Risks",
    "",
    ...formatList(report.likely_friction_risks),
    "",
    "## Estimated Hours To Ready",
    "",
    `${report.estimated_hours_to_ready} hours`,
    "",
    "## Recommended Next 3 Steps",
    "",
    ...formatList(report.recommended_next_3_steps),
    "",
    "## What To Skip For Now",
    "",
    ...formatList(report.what_to_skip_for_now),
    "",
    "## AI-Ready Context",
    "",
    report.ai_ready_context_summary
  ];
  return `${lines.join("\n")}\n`;
}

function toSummaryMarkdown(summary) {
  const lines = [
    "# Atlas Readiness Report",
    "",
    `Readiness examples processed: ${summary.readiness_examples_processed}`,
    `Average readiness score: ${summary.average_readiness_score}`,
    `Weakest readiness category: ${summary.weakest_readiness_category.category} (${summary.weakest_readiness_category.score})`,
    `Strongest readiness category: ${summary.strongest_readiness_category.category} (${summary.strongest_readiness_category.score})`,
    "",
    "## Status Counts",
    "",
    ...Object.entries(summary.status_counts).map(([status, count]) => `- ${status}: ${count}`),
    "",
    "## Reports",
    "",
    ...summary.reports.map((report) => `- ${report.readiness_id}: ${report.score}/100 (${report.status})`)
  ];
  return `${lines.join("\n")}\n`;
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function clamp(value) {
  return Math.max(0, Math.min(100, value));
}

main();
