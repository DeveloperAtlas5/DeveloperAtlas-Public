# Atlas Canon Report

Total Canon entries: 50
Average score: 72.6

## Status Counts

- candidate: 28
- gold_candidate: 22

## Gold Nodes

- None

## Candidate Nodes

- CANON-021: CSS display block vs inline vs inline-block
- CANON-023: Laravel migration vs model vs factory vs seeder
- CANON-024: SQL GROUP BY decision guide
- CANON-026: Git commit vs branch vs merge
- CANON-027: npm vs pnpm vs yarn
- CANON-028: REST API route vs controller vs service
- CANON-029: SQL primary key vs foreign key
- CANON-030: CSS margin vs padding
- CANON-CANDIDATE-JS-001: let vs const
- CANON-CANDIDATE-JS-002: array.map vs array.forEach
- CANON-CANDIDATE-JS-003: array.filter vs array.find
- CANON-CANDIDATE-JS-004: truthy and falsy values
- CANON-CANDIDATE-JS-005: template literals vs string concatenation
- CANON-CANDIDATE-VUE-001: ref vs reactive
- CANON-CANDIDATE-VUE-002: v-if vs v-show
- CANON-CANDIDATE-VUE-003: v-for keys
- CANON-CANDIDATE-VUE-004: computed vs methods
- CANON-CANDIDATE-VUE-005: props vs local state
- CANON-CANDIDATE-VUE-006: emit events vs mutating props
- CANON-CANDIDATE-VUE-007: v-model in components
- CANON-CANDIDATE-BROWSER-001: localStorage vs sessionStorage recovery patterns
- CANON-CANDIDATE-BROWSER-002: JSON.stringify vs JSON.parse
- CANON-CANDIDATE-BROWSER-003: browser console errors vs warnings
- CANON-CANDIDATE-TOOLING-001: npm install vs npm run dev
- CANON-CANDIDATE-TOOLING-002: package.json scripts
- CANON-CANDIDATE-TOOLING-003: project root vs src folder
- CANON-CANDIDATE-AI-001: prompt scope vs feature creep
- CANON-CANDIDATE-AI-002: accepting vs rejecting AI-generated code

## Missing Proof Of Superiority Files

- None

## Missing Scorecards

- None

## Release Batches

- 2026.1-batch-01: output/canon/canon-batch-01-release.md
- 2026.1-batch-02: output/canon/canon-batch-02-release.md
- 2026.1-batch-03: output/canon/canon-batch-03-release.md
- 2026.1-batch-04: output/canon/canon-batch-04-release.md
