# State in Vue vs Laravel

## Shared idea

State is data the app uses to decide what to show or do next.

## Laravel side

Laravel often reads state from the request, session, authenticated user, cache, or database models.

## Vue side

Vue often keeps state in refs, reactive objects, computed values, or stores while the user interacts with the page.

## Main difference

Vue state usually lives in the browser for the current experience. Laravel state usually comes from the server request or stored data.

## Related concepts

ref, reactive, Request, Model, Session
