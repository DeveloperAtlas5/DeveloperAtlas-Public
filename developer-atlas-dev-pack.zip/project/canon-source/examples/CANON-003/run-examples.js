const examples = [
  ["ref primitive example", require("./ref-primitive")],
  ["reactive object example", require("./reactive-object")],
  ["mistake: forgetting .value", require("./mistake-forgetting-value")],
  ["destructuring reactive object pitfall and safe alternative", require("./destructure-reactive-pitfall")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-003 example(s).`);
