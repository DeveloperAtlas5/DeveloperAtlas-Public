const { renderRows } = require("./keyed-patch-simulator");

module.exports = function runIndexKeyBreaksIdentityAfterReorder() {
  const initialItems = [
    { id: "a", label: "Ada" },
    { id: "g", label: "Grace" },
    { id: "k", label: "Katherine" }
  ];

  const firstRender = renderRows(initialItems, (_item, index) => index);
  const reorderedItems = [initialItems[2], initialItems[0], initialItems[1]];
  const secondRender = renderRows(reorderedItems, (_item, index) => index, firstRender.stateByKey);

  const katherineRow = secondRender.rows[0];

  if (katherineRow.itemId !== "k") {
    throw new Error("Test setup should put Katherine in the first row after reorder.");
  }

  if (katherineRow.state.createdFor !== "a") {
    throw new Error("Index key should demonstrate state staying with position 0 after reorder.");
  }

  return secondRender.rows;
};
