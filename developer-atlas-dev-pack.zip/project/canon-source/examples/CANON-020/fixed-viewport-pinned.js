const assert = require("node:assert/strict");
const { fixedPosition } = require("./layout-simulator");

module.exports = function runFixedViewportPinnedExample() {
  const beforeScroll = fixedPosition({
    viewport: { width: 1200, height: 800 },
    top: 24,
    right: 24,
    width: 160
  });

  const afterScroll = fixedPosition({
    viewport: { width: 1200, height: 800 },
    top: 24,
    right: 24,
    width: 160
  });

  assert.deepEqual(afterScroll, beforeScroll);
  assert.equal(beforeScroll.anchor, "viewport");
  assert.equal(beforeScroll.visualLeft, 1016);
  assert.equal(beforeScroll.keepsLayoutSpace, false);
};
