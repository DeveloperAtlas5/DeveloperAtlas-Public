# Canon Benchmark Template

Canon ID:
Node ID:
Benchmark Date:

## Compared Sources

- Official documentation:
- Common tutorial:
- AI assistant answer:
- Existing Atlas node:

## Benchmark Questions

- Does it explain the syntax?
- Does it explain when to use the concept?
- Does it explain when not to use it?
- Does it show production examples?
- Does it prevent common mistakes?
- Does it explain trade-offs?
- Does it support AI retrieval and code generation?

## Result

- Atlas advantage:
- Remaining weakness:
- Required improvement:

