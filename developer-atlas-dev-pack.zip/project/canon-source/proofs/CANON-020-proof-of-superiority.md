# CANON-020 Proof Of Superiority

Canon ID: CANON-020
Node ID: canon.css.layout.position-relative-absolute-fixed-sticky
Title: CSS position relative vs absolute vs fixed vs sticky

## What Official Docs Explain Well

MDN and the CSS Positioned Layout specification explain the `position` property, positioned layout, containing blocks, sticky behavior, and inset offsets.

## What Developers Still Struggle With

Developers often know the property values but cannot predict layout behavior:

- `relative` moves visually while keeping its original layout space.
- `absolute` uses the nearest positioned ancestor, not necessarily the nearest visual parent.
- `absolute` and `fixed` leave normal document flow.
- `fixed` can cover content because it is viewport-pinned.
- `sticky` requires a scroll context and threshold.
- Positioning is used as a substitute for Flexbox, Grid, or normal flow.

These mistakes create overlapping UI, misplaced badges, broken sticky headers, and fragile layouts.

## How Atlas Improves The Explanation

Atlas frames positioning as a flow-and-anchor decision:

- Start from normal document flow.
- Ask whether the element keeps layout space.
- Ask what the element is positioned relative to.
- Use positioning only for offsets, anchors, overlays, viewport UI, and sticky behavior.
- Prefer Flexbox, Grid, or normal flow for main layout structure.

## What Decision Support Atlas Adds

The node routes developers through normal flow, `relative`, `absolute`, `fixed`, and `sticky` based on intent. It also explains when not to use positioning and how to debug containing blocks, sticky failures, overlap, and stacking issues.

## What Production Guidance Atlas Adds

The node includes practical card badge, fixed support button, sticky toolbar, and relative offset examples. It also covers accessible caution around overlays, viewport coverage, visual order, and layout maintainability.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct CSS generation rules:

- Ask what the anchor should be.
- Use `relative` on the intended container before `absolute` children.
- Do not generate absolute-positioned page layouts.
- Include sticky thresholds.
- Warn when fixed UI may cover content.
- Prefer Grid or Flexbox for structural layout.

## Why This Deserves Gold Candidate Status

CANON-020 deserves Gold Candidate status because it converts confusing CSS positioning values into a reliable layout decision model with official evidence, deterministic examples, production debugging guidance, and AI generation guardrails. It still needs named reviewer sign-off before final Gold approval.
