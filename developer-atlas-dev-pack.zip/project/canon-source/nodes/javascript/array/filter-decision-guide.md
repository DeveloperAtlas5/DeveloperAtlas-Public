# Array.prototype.filter() Decision Guide

## Status Metadata

- Canon ID: CANON-009
- Node ID: canon.javascript.array.filter-decision-guide
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript arrays
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `filter()` when an array should become a new array containing only the items that match a condition.

The decision is about keeping items, not changing them:

- `filter()` keeps matching items.
- `find()` returns the first matching item.
- `map()` transforms every item.
- `reduce()` combines many items into one result.

## What Problem This Solves

Developers often know the word "filter" but still use it for the wrong result shape:

- `filter()[0]` when they need one item.
- `filter().map()` when the filter condition is unclear.
- `filter()` callbacks that return transformed objects instead of true/false decisions.
- `reduce()` or manual loops for simple subset selection.

This node solves a daily JavaScript decision: choose `filter()` when the output is a subset of the original array.

## Mental Model

Start with the output shape.

Think of `filter()` as a gate. Every item walks up to the gate. If the callback returns a truthy value, the item passes through into the new array. If the callback returns a falsy value, the item is left out.

```js
const activeUsers = users.filter((user) => user.active);
```

The method contract is:

> I am keeping some original items and discarding the rest.

| Desired result | Best fit |
| --- | --- |
| New array with fewer or equal original items | `filter()` |
| First matching item | `find()` |
| New array with transformed items | `map()` |
| One final value, group, lookup, or total | `reduce()` |
| Yes/no: at least one match | `some()` |
| Yes/no: all items match | `every()` |
| Side effect for each item | `forEach()` or `for...of` |

## Beginner Explanation

Use `filter()` when you want to keep only some items.

If you have users and want only active users:

```js
const activeUsers = users.filter((user) => user.active);
```

The output is still an array of users. It may be shorter, but the items are the same kind of thing.

Beginner rule:

1. If you want fewer items, use `filter()`.
2. If you want one item, use `find()`.
3. If you want changed items, use `map()`.
4. If you want one final summary, use `reduce()`.

## Professional Explanation

`Array.prototype.filter()` creates a shallow copy containing elements for which the predicate returns a truthy value. It preserves item order and keeps the original item references. It does not transform item shape.

In production code, `filter()` is strongest when the predicate clearly expresses a domain condition:

- `user.status === "active"`
- `product.stock > 0`
- `order.totalCents >= minimumTotalCents`
- `permission.roles.includes(currentRole)`

The key review question is not "Can this condition be written in a callback?" It is "Does this callback clearly decide whether the original item belongs in the result?"

Sparse-array note: `filter()` skips empty slots in sparse arrays. The returned array is dense for visited items that pass the predicate.

## Syntax

```js
const result = array.filter((item, index, array) => {
  return shouldKeepItem;
});
```

Common forms:

```js
const activeUsers = users.filter((user) => user.active);
```

```js
const visibleProducts = products.filter((product) =>
  product.name.toLowerCase().includes(searchText.toLowerCase())
);
```

Callback arguments:

| Argument | Meaning |
| --- | --- |
| `item` | The current array item |
| `index` | The current item index |
| `array` | The original array |
| callback return | Truthy keeps the item, falsy removes it |

## Decision Guide

Ask these questions in order:

1. Do I need a new array with only matching original items?
   Use `filter()`.
2. Do I need exactly the first matching item?
   Use `find()`.
3. Do I only need to know whether a match exists?
   Use `some()`.
4. Do I need to transform every item?
   Use `map()`.
5. Do I need to filter and transform?
   Use `filter().map()` when the two steps are clear.
6. Do I need one final value, group, or lookup?
   Use `reduce()`.
7. Is the predicate hard to read?
   Extract it into a named function.

Use `filter()` when the sentence sounds like:

- "Keep active users."
- "Show products matching this search."
- "Return orders above this total."
- "Remove invalid form fields from this list."

Avoid it when the sentence sounds like:

- "Get the selected product." Use `find()`.
- "Convert products to cards." Use `map()`.
- "Count matching products." Use `filter().length` for simple cases or `reduce()` for complex summaries.

## Comparison Table

| Choice | Best For | Returns | Trade-Off |
| --- | --- | --- | --- |
| `filter()` | Keeping matching original items | New array | Wrong for one item or transformed output |
| `find()` | First matching item | Item or `undefined` | Does not return all matches |
| `map()` | One transformed output per input | New array | Does not remove items by itself |
| `reduce()` | Aggregation, grouping, lookup | Any value | Can be harder to read for simple subsets |
| `some()` | At least one match | Boolean | Does not return items |
| `every()` | All items match | Boolean | Does not return items |

## When To Use The Primary Option

Use `filter()` when:

- The output should be an array.
- The output items should be original items from the input array.
- The output length may be smaller than the input length.
- The callback is a true/false keep decision.
- The predicate has a clear business meaning.

```js
const eligibleOrders = orders.filter((order) => {
  return order.status === "paid" && order.totalCents >= 5000;
});
```

## When To Use The Alternative

Use `find()` when you need one item:

```js
const selectedProduct = products.find((product) => product.id === selectedId);
```

Use `map()` when you need transformed values:

```js
const productCards = products.map((product) => ({
  id: product.id,
  title: product.name
}));
```

Use `reduce()` when many items become one summary:

```js
const countByStatus = orders.reduce((counts, order) => {
  counts[order.status] = (counts[order.status] || 0) + 1;
  return counts;
}, {});
```

## When Not To Use This Decision

Do not use `filter()` when:

- You need only the first match. Use `find()`.
- You need a boolean answer. Use `some()` or `every()`.
- You need to transform item shape. Use `map()`.
- You need to group, count, or build a lookup. Use `reduce()`.
- You are performing side effects. Use `forEach()` or `for...of`.
- You are relying on `filter(Boolean)` without considering valid falsy values like `0` or `""`.
- The condition is so complex that a named predicate or earlier normalization would be clearer.

## Alternatives

### find()

Use `find()` for one matching item.

```js
const admin = users.find((user) => user.role === "admin");
```

### map()

Use `map()` for transformation.

```js
const names = users.map((user) => user.name);
```

### reduce()

Use `reduce()` for grouping, counting, or building a lookup.

```js
const usersById = users.reduce((lookup, user) => {
  lookup[user.id] = user;
  return lookup;
}, {});
```

### some()

Use `some()` for existence checks.

```js
const hasOverdueInvoice = invoices.some((invoice) => invoice.status === "overdue");
```

### every()

Use `every()` when all items must pass.

```js
const allTasksDone = tasks.every((task) => task.done);
```

## Production Examples

### Permission-Aware Navigation

```js
const visibleNavItems = navItems.filter((item) => {
  return item.requiredRoles.some((role) => currentUser.roles.includes(role));
});
```

Why `filter()` fits: the result is still navigation items, but only the items the user is allowed to see.

### Product Search Results

```js
const matchingProducts = products.filter((product) => {
  const query = searchText.trim().toLowerCase();
  const searchableText = `${product.name} ${product.sku} ${product.category}`.toLowerCase();

  return product.isActive && searchableText.includes(query);
});
```

Why `filter()` fits: the product list becomes a smaller product list.

### Valid Upload Files

```js
const allowedFiles = files.filter((file) => {
  const allowedType = ["image/png", "image/jpeg"].includes(file.type);
  const underSizeLimit = file.size <= 5 * 1024 * 1024;

  return allowedType && underSizeLimit;
});
```

Why `filter()` fits: the upload workflow keeps only files that satisfy validation rules.

### Filter Then Map For UI Cards

```js
const productCards = products
  .filter((product) => product.stock > 0)
  .map((product) => ({
    id: product.id,
    title: product.name,
    priceLabel: `$${(product.priceCents / 100).toFixed(2)}`
  }));
```

Why this chain fits: `filter()` decides which products stay; `map()` changes the kept products into card data.

## Common Mistakes

- Using `filter()[0]` instead of `find()`.
- Returning transformed objects from the callback and assuming `filter()` transforms them.
- Returning strings or objects accidentally instead of a clear boolean condition.
- Using `filter(Boolean)` when `0`, `false`, or `""` are valid values.
- Using `filter()` only for side effects.
- Forgetting that the original items are shared references.
- Writing predicates with too many hidden business rules.

```js
// Mistake: scans for all matches, then takes one
const selectedUser = users.filter((user) => user.id === selectedId)[0];
```

```js
// Better
const selectedUser = users.find((user) => user.id === selectedId);
```

```js
// Mistake: filter does not transform names
const names = users.filter((user) => user.name);
```

```js
// Better
const names = users.map((user) => user.name);
```

## Debugging Checklist

- If the result has too many items, is the predicate returning truthy values accidentally?
- If the result is empty, is the comparison type or casing wrong?
- If you expected one item, should this be `find()`?
- If you expected changed item shape, should this be `map()`?
- If `filter(Boolean)` removed valid values, should the predicate be explicit?
- If the predicate is hard to read, should it be a named function?
- If performance is poor on repeated searches, should the search text or indexed data be normalized earlier?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-009/`.

Verification command:

```sh
npm run canon:verify:009
```

The verification suite checks:

- Filtering active users.
- Filtering products by search text.
- The anti-pattern of using `filter()` when `find()` is needed.
- The anti-pattern of using `filter()` for transformation instead of `map()`.

## Performance Notes

`filter()` creates a new array and visits each present item. That is the right trade-off for clear subset selection in normal application code.

For very large arrays or repeated searches, normalize search fields, debounce user input, paginate data, or move filtering closer to the data source. If you need early exit, use `find()`, `some()`, or a loop. If you need a count only, `reduce()` or a loop can avoid allocating a filtered array, but readability should lead unless profiling says otherwise.

## AI Coding Guidance

When generating code:

- Use `filter()` only when the result should be a subset array.
- Make the predicate a clear keep/remove decision.
- Prefer `find()` when only one item is needed.
- Prefer `map()` when the result changes item shape.
- Prefer `reduce()` for grouping, lookup objects, totals, or complex counts.
- Do not generate `filter()[0]` for first-match lookup.
- Be careful with `filter(Boolean)` when falsy values may be valid.
- Explain the choice using output shape: "same item type, fewer items."

Bad AI output:

```js
const selectedUser = users.filter((user) => user.id === selectedId)[0];
```

Good AI output:

```js
const selectedUser = users.find((user) => user.id === selectedId);
```

Good `filter()` output:

```js
const activeUsers = users.filter((user) => user.status === "active");
```

## Teaching Notes

Teach `filter()` as a decision, not just syntax:

1. Start with "keep matching items."
2. Show that the output is still an array.
3. Show that the item shape does not change.
4. Compare with `find()` for one item.
5. Compare with `map()` for transformation.
6. End with a realistic `filter().map()` chain.

Useful teaching phrase:

> `filter()` changes how many items you have, not what each item is.

## Interview Questions

1. What does `filter()` return?
2. What should the callback return?
3. When is `find()` better than `filter()`?
4. When is `map()` better than `filter()`?
5. What is risky about `filter(Boolean)`?
6. Does `filter()` clone the objects inside the array?
7. How would you filter products by search text?
8. How would you refactor `filter()[0]`?

## Exercises

### Beginner

Filter an array of users to keep only active users.

### Intermediate

Filter products by search text, category, and in-stock status.

### Advanced

Refactor code that uses `filter()` for first-match lookup and transformation into clearer `find()`, `filter()`, and `map()` steps.

## Related Atlas Nodes

- `javascript.array.filter`
- `javascript.array.find`
- `javascript.array.map`
- `javascript.array.reduce`
- `javascript.array.some`
- `javascript.array.every`
- `javascript.array.foreach`

## Evidence And Sources

- MDN Web Docs: Array.prototype.filter(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
- ECMAScript specification: Array.prototype.filter: https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array.prototype.filter

## Proof Of Superiority Summary

Official references explain how `filter()` executes. This Canon node explains when to choose it, when to reject it, how to reason about subset selection, how it compares with `find()`, `map()`, and `reduce()`, what production predicates look like, and how AI assistants should generate readable array filtering code.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
