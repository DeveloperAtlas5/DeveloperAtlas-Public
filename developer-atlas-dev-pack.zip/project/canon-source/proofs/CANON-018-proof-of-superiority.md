# CANON-018 Proof Of Superiority

Canon ID: CANON-018
Node ID: canon.laravel.architecture.controller-vs-form-request-vs-service
Title: Laravel Controller vs Form Request vs Service

## What Official Docs Explain Well

Laravel documentation explains controllers, validation, Form Request validation, authorization, and the service container.

## What Developers Still Struggle With

Developers often know the framework features but still misplace responsibilities:

- Controllers become long methods that validate, authorize, persist, send mail, and return responses.
- Form Requests are skipped even when the request contract deserves a name.
- Business workflow leaks into request validation classes.
- Services are created for one-line Eloquent calls.
- AI-generated Laravel code creates generic service classes by habit.

These mistakes create bloated controllers, duplicated validation, vague abstractions, and unclear testing boundaries.

## How Atlas Improves The Explanation

Atlas turns the topic into an ownership decision:

- Controller owns HTTP coordination.
- Form Request owns validation and authorization boundary.
- Service owns reusable business workflow.
- Simple actions should stay simple.
- Services should be extracted only when they reduce real complexity.

## What Decision Support Atlas Adds

The node asks whether the logic is HTTP-specific, request-contract-specific, or reusable business workflow. It routes developers toward Form Requests, services, policies, jobs, custom rules, actions, model methods, or keeping the code in the controller depending on the responsibility.

## What Production Guidance Atlas Adds

The node includes practical Laravel examples for a simple controller action, a Form Request with validation and authorization, a reusable invitation workflow service, and the anti-pattern of a service that only wraps one Eloquent line.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct generation rules:

- Do not generate services by default.
- Ask whether the code is HTTP coordination, request validation/authorization, or reusable business workflow.
- Use Form Requests for meaningful request contracts.
- Keep simple controller actions simple.
- Name services by business operation.
- Do not pass raw `Request` into services by default.

## Why This Deserves Gold Candidate Status

CANON-018 deserves Gold Candidate status because it converts a common Laravel architecture debate into a clear responsibility model with official evidence, deterministic examples, production guidance, and AI code-generation guardrails. It still needs named reviewer sign-off before final Gold approval.
