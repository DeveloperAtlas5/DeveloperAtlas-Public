# Relationship Specification

Relationships turn Knowledge Nodes into a Knowledge Graph.

## Purpose

Relationships describe how nodes connect, depend on, replace, teach, solve, or compare to each other. The graph should support AI reasoning, semantic search, recommendations, learning paths, troubleshooting, visualization, and future product surfaces.

## Relationship Shape

Each relationship has:

- `source`
- `target`
- `type`

Optional metadata:

- `reason`
- `priority`
- `weight`
- `confidence`

## Relationship Types

- `alternative`
- `uses`
- `used_in`
- `requires`
- `required_by`
- `extends`
- `implements`
- `parent`
- `child`
- `next`
- `previous`
- `compares_to`
- `similar_to`
- `solves`
- `causes`
- `fixes`
- `optimizes`
- `teaches`
- `part_of`
- `workflow_step`
- `recipe_step`
- `project_step`
- `security_note`
- `performance_note`
- `deprecated_by`
- `replaced_by`
- `introduced_in`
- `removed_in`

## Graph Rules

- Graph edges should target existing node ids.
- External alternatives may be preserved as metadata but should not become graph edges unless represented by nodes.
- Relationship reasons should explain why traversal is useful.
- Higher confidence and weight should improve future ranking.
