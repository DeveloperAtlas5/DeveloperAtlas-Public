const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const hardwareDir = path.join(rootDir, "hardware");
const hardwareExamplesDir = path.join(hardwareDir, "examples");
const hardwareWorkloadsDir = path.join(hardwareDir, "workloads");
const hardwareMachineProfilesDir = path.join(hardwareDir, "machine-profiles");
const hardwareHintsDir = path.join(hardwareDir, "hints");
const hardwareOutputDir = path.join(rootDir, "output", "hardware");

function ensureHardwareOutputDir() {
  fs.mkdirSync(hardwareOutputDir, { recursive: true });
}

function readJsonFiles(dir, dataKey) {
  if (!fs.existsSync(dir)) return [];

  return fs.readdirSync(dir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(dir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        [dataKey]: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function readHardwareNodes() {
  return readJsonFiles(hardwareExamplesDir, "node");
}

function readWorkloadProfiles() {
  return readJsonFiles(hardwareWorkloadsDir, "workload");
}

function readMachineProfiles() {
  return readJsonFiles(hardwareMachineProfilesDir, "profile");
}

function readContextualHardwareHints() {
  return readJsonFiles(hardwareHintsDir, "hint");
}

function countValues(values) {
  const counts = new Map();

  for (const value of values) {
    counts.set(value, (counts.get(value) || 0) + 1);
  }

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

function average(values) {
  return values.length
    ? values.reduce((total, value) => total + Number(value || 0), 0) / values.length
    : 0;
}

function round(value) {
  return Number(value.toFixed(2));
}

module.exports = {
  hardwareDir,
  hardwareExamplesDir,
  hardwareWorkloadsDir,
  hardwareMachineProfilesDir,
  hardwareHintsDir,
  hardwareOutputDir,
  ensureHardwareOutputDir,
  readHardwareNodes,
  readWorkloadProfiles,
  readMachineProfiles,
  readContextualHardwareHints,
  countValues,
  average,
  round
};
