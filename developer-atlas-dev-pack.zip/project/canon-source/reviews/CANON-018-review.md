# Canon Review Template

Canon ID: CANON-018
Node ID: canon.laravel.architecture.controller-vs-form-request-vs-service
Reviewer: Pending Gold Review Panel
Date: 2026-07-03
Stage: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Gold-candidate draft aligns with Laravel controller, validation, Form Request, authorization, and container documentation.
- Edge cases: Covers simple controller actions, Form Request extraction, service extraction, unnecessary services, policies, jobs, custom rules, and raw request leakage.
- Version concerns: Guidance targets modern Laravel conventions without relying on a specific application skeleton.
- Evidence quality: Direct official Laravel URLs are included.

## Educational Review

- Beginner clarity: Strong "controller, gatekeeper, workflow owner" mental model.
- Mental model: Ownership is explained before folder structure.
- Exercise quality: Beginner, intermediate, and advanced exercises are present.
- Common mistake coverage: Covers bloated controllers, duplicated validation, generic services, Form Request misuse, and premature abstraction.

## AI Review

- Structured enough for retrieval: Yes.
- Code generation guidance: Strong and specific.
- Ambiguity risks: AI should ask whether the workflow is reused or business-specific before generating services.
- Related node quality: Related Canon and content graph IDs are included.

## Engineering Review

- Decision support: Strong.
- Production realism: Examples cover simple controller flow, request contracts, reusable invitation workflow, and unnecessary service anti-patterns.
- Trade-offs: Good coverage of maintainability, testability, transaction boundaries, side effects, and ceremony cost.
- Anti-pattern coverage: Strong enough for Gold-candidate review.

## Decision

- Approved stage: Gold Candidate
- Required changes: Add named reviewer sign-off before Gold approval.
- Score: 95
