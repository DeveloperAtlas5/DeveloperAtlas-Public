function innerJoin(leftRows, rightRows, predicate, project) {
  const rows = [];
  for (const left of leftRows) {
    for (const right of rightRows) {
      if (predicate(left, right)) rows.push(project(left, right));
    }
  }
  return rows;
}

function leftJoin(leftRows, rightRows, predicate, project) {
  const rows = [];
  for (const left of leftRows) {
    const matches = rightRows.filter((right) => predicate(left, right));
    if (matches.length === 0) {
      rows.push(project(left, null));
      continue;
    }
    for (const right of matches) rows.push(project(left, right));
  }
  return rows;
}

const users = [
  { id: 1, email: "ada@example.com" },
  { id: 2, email: "grace@example.com" },
  { id: 3, email: "linus@example.com" }
];

const orders = [
  { id: 101, user_id: 1, total_cents: 5000 },
  { id: 102, user_id: 1, total_cents: 2500 },
  { id: 103, user_id: 2, total_cents: 7500 }
];

function userOrderProjection(user, order) {
  return {
    user_id: user.id,
    email: user.email,
    order_id: order ? order.id : null,
    total_cents: order ? order.total_cents : null
  };
}

function userMatchesOrder(user, order) {
  return user.id === order.user_id;
}

module.exports = {
  innerJoin,
  leftJoin,
  users,
  orders,
  userOrderProjection,
  userMatchesOrder
};
