module.exports = async function runPromiseAllRejects() {
  let rejected = false;

  try {
    await Promise.all([
      Promise.resolve("ok"),
      Promise.reject(new Error("permissions failed")),
      Promise.resolve("still started")
    ]);
  } catch (error) {
    rejected = error.message === "permissions failed";
  }

  if (!rejected) {
    throw new Error("Expected Promise.all() to reject with the failing reason");
  }
};
