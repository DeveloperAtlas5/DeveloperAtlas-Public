const { orders, groupByCustomer } = require("./query-simulator");

module.exports = function runHavingFiltersCountGreaterThanOne() {
  const groups = groupByCustomer(orders);
  const repeatCustomers = groups.filter((group) => group.count > 1);

  if (repeatCustomers.length !== 2) {
    throw new Error("HAVING COUNT(*) > 1 should keep customer groups with more than one order.");
  }

  if (!repeatCustomers.some((group) => group.customer_id === "c1")) {
    throw new Error("Customer c1 should pass the HAVING count threshold.");
  }

  return repeatCustomers;
};
