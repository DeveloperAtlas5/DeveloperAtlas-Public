module.exports = async function runAntiPatternAllWhenPartialSuccessOk() {
  const tasks = [
    Promise.resolve({ id: "email_1", delivered: true }),
    Promise.reject(new Error("email_2 failed")),
    Promise.resolve({ id: "email_3", delivered: true })
  ];

  let allLostPartialReport = false;
  try {
    await Promise.all(tasks);
  } catch {
    allLostPartialReport = true;
  }

  const report = await Promise.allSettled([
    Promise.resolve({ id: "email_1", delivered: true }),
    Promise.reject(new Error("email_2 failed")),
    Promise.resolve({ id: "email_3", delivered: true })
  ]);

  const deliveredCount = report.filter((result) => result.status === "fulfilled").length;
  const failedCount = report.filter((result) => result.status === "rejected").length;

  if (!allLostPartialReport) {
    throw new Error("Expected Promise.all() to reject and lose aggregate partial report");
  }

  if (deliveredCount !== 2 || failedCount !== 1) {
    throw new Error(`Expected 2 delivered and 1 failed, got ${deliveredCount}/${failedCount}`);
  }
};
