# AI Prompt Pack

Use this only if AI helps you code.
This file is optional. Normal learners can start with `mission/today-mission-surface.md`.
Use AI to explain, suggest small examples, and check your understanding. Do not use AI to skip the mission for you.

## Rule

One mission at a time.
Edit the learner's Vue todo project, not the Atlas package.
Ask for small, scoped, explainable changes.
AI should help explain and give examples. It should not take over the learning.

Before helping with code, check the relevant AI Standard nodes: AI Code Readability Standard, AI Small Patch Standard, AI Explain-Before-Change Standard, AI Human Review Standard, AI Concept Check Standard, and AI No-Scope-Creep Standard. Use these standards to explain, narrow, and verify the answer. Do not use them to take over the learner's work.
## Universal Atlas AI preamble

Paste this before any AI coding request if you are not using a `.vibe.md` mission file:

I am using Developer Atlas.
Help me with one mission at a time.
Before writing code, ask which mission I am on if I did not say it.
Do not make the app production-ready, cleaner, more reusable, or more architectural unless the current mission explicitly asks for that.
Use the smallest useful patch.
Edit my Vue todo project, not the Atlas package.
Use clear headings, file names before code, small code blocks, and verification steps.

## Mission 1 prompt
```txt
You are helping me with Developer Atlas Mission 1.
Edit my Vue todo project, not the Atlas package.
Goal: make my todos survive page refresh.
Use the smallest useful change.
Keep todo state in `src/App.vue`.
Use localStorage only for persistence.
Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, new components, or a new architecture.
After the change, explain what changed and how I can verify it.
```

## Mission 2 prompt
```txt
You are helping me with Developer Atlas Mission 2.
Edit my Vue todo project, not the Atlas package.
Goal: extract one `TodoItem.vue` component.
Create `src/components/TodoItem.vue`.
Keep todo list state and localStorage in `src/App.vue`.
Use props to pass one todo down.
Use events to ask the parent to toggle or remove a todo.
Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, extra components, or a new architecture.
After the change, explain what changed and how I can verify it.
```

## Mission 3 prompt
```txt
You are helping me with Developer Atlas Mission 3.
Edit my Vue todo project, not the Atlas package.
Goal: add a display-only `TodoStats.vue` component.
Create `src/components/TodoStats.vue`.
Keep todo list state and localStorage in `src/App.vue`.
Pass total, completed, and remaining values as props.
Do not add emits for this mission.
Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture.
After the change, explain what changed and how I can verify it.
```

## Smaller patch prompt
Please make a smaller patch. Only change the files needed for the current mission.

## Before accepting an AI answer
Reject it if it:
- changes more than the mission asks for
- edits the Atlas package
- adds new architecture
- skips explanation or verification

## If AI overbuilds
Please make a smaller patch. Only change the files needed for the current mission.

## If AI suggests a cleaner improvement
That sounds useful later, but it is outside this mission. Please park it and return to the smallest current-mission patch.

## Format the answer clearly
Ask AI to use:
- clear headings
- file names before code
- small code blocks
- short explanations
- verification steps
Please format your answer clearly with headings, spacing, file names, small code blocks, and verification steps so I can understand it and troubleshoot it later.

## Explain it back prompt
Explain what changed in plain language before I accept it.

## Reject overbuild prompt
Undo the extra architecture and return to the smallest solution for this mission.

## Verify before continuing
Compare your answer to the mission checklist and tell me whether it stays inside scope.
Stay on the current mission. Do not continue to the next mission until I ask.
Do not ask for fastest answer with no explanation in Atlas. Ask for a small readable answer with verification.
