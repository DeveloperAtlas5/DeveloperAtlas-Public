const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const outputDir = path.join(rootDir, "output", "demo");

function readJson(relativePath, fallback) {
  const fullPath = path.join(rootDir, relativePath);
  if (!fs.existsSync(fullPath)) return fallback;
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function readText(relativePath, fallback = "") {
  const fullPath = path.join(rootDir, relativePath);
  if (!fs.existsSync(fullPath)) return fallback;
  return fs.readFileSync(fullPath, "utf8");
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function first(items, fallback = null) {
  return Array.isArray(items) && items.length ? items[0] : fallback;
}

function list(items, mapper = (item) => item, empty = "- None") {
  if (!Array.isArray(items) || !items.length) return [empty];
  return items.map(mapper);
}

function extractLine(text, prefix, fallback = "Unknown") {
  const line = text.split(/\r?\n/).find((item) => item.startsWith(prefix));
  return line ? line.replace(prefix, "").trim() : fallback;
}

function formatLabel(value) {
  return String(value || "unknown").replace(/_/g, " ");
}

function trimTrailingPeriod(value) {
  return String(value || "").replace(/\.+$/, "");
}

function buildManifest() {
  const canonIndex = readJson("canon/canon-index.json", { entries: [] });
  const canonReport = readText("output/canon/canon-report.md");
  const readiness = readJson("output/readiness/readiness-report.json", {});
  const capabilityFit = readJson("output/capability/project-fit-report.json", {});
  const pathway = readJson("output/capability/capability-pathway.json", {});
  const momentum = readJson("output/momentum/momentum-report.json", {});
  const frictionNodes = readJson("output/friction/friction-nodes.json", []);
  const goalOverlap = readJson("output/goals/goal-overlap-report.json", {});
  const aiContextQuality = readJson("output/ai-context/ai-context-quality-report.json", {});
  const teamContextQuality = readJson("output/team-context/team-context-quality-report.json", {});
  const flowReport = readJson("output/flow/flow-report.json", {});

  const canonEntries = canonIndex.entries || [];
  const goldCandidates = canonEntries.filter((entry) => entry.status === "gold_candidate");
  const readyToday = first(capabilityFit.ready_today, {});
  const weekOne = first(pathway.weeks, {});
  const highestFriction = [...frictionNodes].sort((a, b) => (b.friction_score || 0) - (a.friction_score || 0))[0] || {};

  return {
    generated_at: new Date().toISOString(),
    demo_title: "Developer Atlas MVP Demo Pack",
    positioning: "Learn with confidence. Build with purpose. Grow without getting lost.",
    proof_points: {
      canon_nodes: canonEntries.length,
      gold_candidate_nodes: goldCandidates.length,
      canon_average_score: extractLine(canonReport, "Average score:"),
      readiness_profiles: readiness.readiness_examples_processed || 0,
      average_readiness_score: readiness.average_readiness_score || 0,
      ready_today_projects: (capabilityFit.ready_today || []).length,
      mostly_ready_projects: (capabilityFit.mostly_ready || []).length,
      deferred_projects: (capabilityFit.defer || []).length,
      momentum_sessions: momentum.sessions_processed || 0,
      estimated_minutes_saved: momentum.estimated_time_saved || 0,
      confidence_improvement: momentum.confidence_improvement || 0,
      friction_nodes: frictionNodes.length,
      ai_context_packs_scored: aiContextQuality.total_context_packs_scored || 0,
      ai_context_average_score: aiContextQuality.average_overall_score || 0,
      team_contexts_scored: teamContextQuality.contexts_scored || 0,
      team_context_average_score: teamContextQuality.average_score || 0,
      flows_generated: flowReport.flows_generated || 0,
      average_flow_quality_score: flowReport.average_flow_quality_score || 0
    },
    featured_demo: {
      ready_today_project: readyToday.title || "No ready-today project",
      week_one_project: weekOne.project?.title || "No week one project",
      strongest_goal_overlap: goalOverlap.strongest_overlap || null,
      highest_friction_node: highestFriction.id || null,
      highest_friction_title: highestFriction.title || null,
      best_ai_context_pack: aiContextQuality.highest_quality_pack?.request_id || null,
      best_team_context: teamContextQuality.highest_quality_context?.project_id || null,
      first_recommended_flow: flowReport.first_recommended_flow || null
    },
    source_outputs: [
      "output/canon/canon-report.md",
      "output/readiness/readiness-report.md",
      "output/capability/project-fit-report.md",
      "output/capability/capability-pathway.md",
      "output/friction/friction-report.md",
      "output/setup-advisor/setup-advisor-report.md",
      "output/recovery-advisor/recovery-advisor-report.md",
      "output/momentum/momentum-report.md",
      "output/explainability/why-this-roadmap.md",
      "output/ai-context/ai-context-quality-report.md",
      "output/team-context/team-context-quality-report.md",
      "output/flow/flow-report.md"
    ]
  };
}

function renderMainPack(manifest) {
  const readiness = readJson("output/readiness/readiness-report.json", {});
  const capabilityFit = readJson("output/capability/project-fit-report.json", {});
  const pathway = readJson("output/capability/capability-pathway.json", {});
  const momentum = readJson("output/momentum/momentum-report.json", {});
  const goalOverlap = readJson("output/goals/goal-overlap-report.json", {});
  const aiContextQuality = readJson("output/ai-context/ai-context-quality-report.json", {});
  const teamContextQuality = readJson("output/team-context/team-context-quality-report.json", {});

  const proof = manifest.proof_points;
  const readyToday = first(capabilityFit.ready_today, {});
  const weekOne = first(pathway.weeks, {});

  return [
    "# Developer Atlas MVP Demo Pack",
    "",
    "**Developer Atlas**  ",
    "**Learn with confidence. Build with purpose. Grow without getting lost.**",
    "",
    "Developer Atlas is an Engineering Progress Platform. It helps developers learn, build, fix, improve, and grow with structured knowledge, personal roadmaps, setup and recovery support, and AI-ready context.",
    "",
    "This demo pack is generated from local Atlas data. It does not require a website, chatbot, external API, or LLM call.",
    "",
    "## Executive Snapshot",
    "",
    `- Canon nodes: ${proof.canon_nodes}`,
    `- Review-ready Canon nodes: ${proof.gold_candidate_nodes}`,
    `- Canon average score: ${proof.canon_average_score}`,
    `- Readiness profiles processed: ${proof.readiness_profiles}`,
    `- Average readiness score: ${proof.average_readiness_score}`,
    `- Ready-today projects: ${proof.ready_today_projects}`,
    `- Momentum sessions: ${proof.momentum_sessions}`,
    `- Estimated minutes saved: ${proof.estimated_minutes_saved}`,
    `- AI context quality average: ${proof.ai_context_average_score}`,
    `- Team context quality average: ${proof.team_context_average_score}`,
    `- Atlas flows generated: ${proof.flows_generated}`,
    `- Average flow quality score: ${proof.average_flow_quality_score}`,
    "",
    "## What The Demo Proves",
    "",
    "1. Atlas can turn knowledge into reviewable decision guides.",
    "2. Atlas can detect when someone is not ready yet without shaming them or stopping momentum.",
    "3. Atlas can recommend a realistic project for this week.",
    "4. Atlas can identify setup and recovery risks before they waste time.",
    "5. Atlas can produce concise AI context packs without locking users into a model.",
    "6. Atlas can help teams share consistent context with explicit AI safety rules.",
    "7. Atlas can make progress feel visible instead of overwhelming.",
    "",
    "## Featured User Story",
    "",
    `Start the demo after the landing page with the first recommended flow: **${manifest.featured_demo.first_recommended_flow || "No flow generated"}**.`,
    "",
    `A rookie learner wants to build something real. Atlas checks readiness, detects that the learner still needs foundations, and still finds a realistic project: **${readyToday.title || "No ready-today project"}**.`,
    "",
    `Week 1 recommendation: **${weekOne.project?.title || "No week 1 project"}**.`,
    `Estimated time: ${weekOne.project?.estimated_hours || "Unknown"} hours.`,
    `Output artifact: ${trimTrailingPeriod(weekOne.project?.output_artifact || "Unknown")}.`,
    "",
    "Atlas does not simply say the learner is behind. It shows the smallest useful project, the missing knowledge, the likely blockers, and the next practice tasks.",
    "",
    "## Readiness And Capability",
    "",
    `Average readiness score is ${readiness.average_readiness_score || "unknown"}. The weakest category is ${readiness.weakest_readiness_category?.category || "unknown"} at ${readiness.weakest_readiness_category?.score || "unknown"}.`,
    "",
    "Project fit summary:",
    ...list(capabilityFit.project_fits, (fit) => `- ${fit.title}: ${formatLabel(fit.fit_level)} (${fit.fit_score})`),
    "",
    "## Momentum And Friction",
    "",
    `Across ${momentum.sessions_processed || 0} momentum sessions, Atlas estimates ${momentum.estimated_time_saved || 0} minutes saved and a confidence improvement of ${momentum.confidence_improvement || 0}.`,
    "",
    "Most common blockers:",
    ...list(momentum.most_common_blockers, (item) => `- ${item.value}: ${item.count}`),
    "",
    "## Goal Overlap",
    "",
    `Strongest overlap: ${goalOverlap.strongest_overlap?.value || "Unknown"} (${goalOverlap.strongest_overlap?.type || "unknown"}, ${goalOverlap.strongest_overlap?.count || 0} goals).`,
    "",
    "Top overlapping knowledge:",
    ...list((goalOverlap.overlapping_knowledge_nodes || []).slice(0, 5), (item) => `- ${item.value}: ${item.count}`),
    "",
    "## AI And Team Context",
    "",
    `AI context packs scored: ${aiContextQuality.total_context_packs_scored || 0}. Average score: ${aiContextQuality.average_overall_score || 0}.`,
    `Best AI context pack: ${aiContextQuality.highest_quality_pack?.request_id || "None"}.`,
    "",
    `Team contexts scored: ${teamContextQuality.contexts_scored || 0}. Average score: ${teamContextQuality.average_score || 0}.`,
    `Best team context: ${teamContextQuality.highest_quality_context?.project_id || "None"}.`,
    "",
    "## Inspectable Evidence",
    "",
    ...manifest.source_outputs.map((file) => `- ${file}`),
    ""
  ].join("\n");
}

function renderWalkthrough(manifest) {
  const pathway = readJson("output/capability/capability-pathway.json", {});
  return [
    "# Developer Atlas Demo Walkthrough",
    "",
    "Use this walkthrough when showing the MVP from files only.",
    "",
    "## 1. Open The Demo Pack",
    "",
    "Start with `output/demo/mvp-demo-pack.md`. Explain that this is generated from structured Atlas data, not handwritten marketing copy.",
    "",
    "## 2. Show Atlas Flow",
    "",
    "Open `output/flow/rookie-vue-todo-flow.md` first. Show how Atlas turns separate reports into one calm journey from goal to next step.",
    "",
    "## 3. Show Canon Quality",
    "",
    "Open `output/canon/canon-report.md`. Point to the Canon node count, average score, and release batches.",
    "",
    "## 4. Show The Project Recommendation",
    "",
    "Open `output/capability/project-fit-report.md`. Show the ready-today project and the deferred project. This proves Atlas can say both yes and not yet.",
    "",
    "## 5. Show The Four-Week Ladder",
    "",
    "Open `output/capability/capability-pathway.md`. The ladder moves from a small Vue app toward larger full-stack work.",
    "",
    "Weeks in the generated pathway:",
    ...list(pathway.weeks, (week) => `- Week ${week.week}: ${week.project?.title || "Unknown"} (${formatLabel(week.fit_level)})`),
    "",
    "## 6. Show Friction Recovery",
    "",
    "Open `output/recovery-advisor/recovery-advisor-report.md`. Show that Atlas can respond to common blockers like npm install failures, Vite startup issues, Composer PATH problems, and missing Laravel artisan files.",
    "",
    "## 7. Show AI Context",
    "",
    "Open `output/ai-context/rookie-vue-next-step.md` and `output/ai-context/ai-context-quality-report.md`. The point is portability: Atlas gives the user better context for any AI assistant.",
    "",
    "## 8. Show Team Context",
    "",
    "Open `output/team-context/team-context-quality-report.md`. This shows Atlas can evaluate shared team context for alignment, onboarding clarity, AI safety, and drift risk.",
    "",
    "## Closing Line",
    "",
    "Developer Atlas is not just a knowledge base. It is a deterministic progress layer that helps developers decide what to learn, what to build, what to fix, and what context to give humans or AI next.",
    "",
    `Generated at: ${manifest.generated_at}`,
    ""
  ].join("\n");
}

function renderAiBrief(manifest) {
  const proof = manifest.proof_points;
  const featured = manifest.featured_demo;
  return [
    "# AI Demo Brief",
    "",
    "Use this brief as context for an external AI assistant when asking it to explain or present Developer Atlas.",
    "",
    "## Role",
    "",
    "You are helping present Developer Atlas as an Engineering Progress Platform. Stay grounded in the supplied generated outputs. Do not invent features, UI, API behavior, pricing, or live LLM integration.",
    "",
    "## Current Demo Metrics",
    "",
    `- Canon nodes: ${proof.canon_nodes}`,
    `- Review-ready Canon nodes: ${proof.gold_candidate_nodes}`,
    `- Readiness profiles: ${proof.readiness_profiles}`,
    `- Ready-today projects: ${proof.ready_today_projects}`,
    `- Friction nodes: ${proof.friction_nodes}`,
    `- Estimated minutes saved in momentum examples: ${proof.estimated_minutes_saved}`,
    `- AI context average score: ${proof.ai_context_average_score}`,
    `- Team context average score: ${proof.team_context_average_score}`,
    `- Flows generated: ${proof.flows_generated}`,
    `- Average flow quality score: ${proof.average_flow_quality_score}`,
    "",
    "## Best Demo Thread",
    "",
    `Start with the ready-today project: ${featured.ready_today_project}.`,
    `Show the first recommended flow: ${featured.first_recommended_flow}.`,
    `Then show the week-one project ladder: ${featured.week_one_project}.`,
    `Then show the highest friction example: ${featured.highest_friction_title}.`,
    `Then show AI context pack quality: ${featured.best_ai_context_pack}.`,
    `Then show team context quality: ${featured.best_team_context}.`,
    "",
    "## Constraints",
    "",
    "- Do not describe Atlas as a finished app.",
    "- Do not imply there are live AI calls.",
    "- Do not add product hype.",
    "- Explain the trade-off: the MVP is less flashy than an app, but more inspectable and deterministic.",
    "",
    "## Desired Explanation Style",
    "",
    "Direct, practical, and evidence-based. Explain how the generated files prove the system works.",
    ""
  ].join("\n");
}

function main() {
  ensureDir(outputDir);
  const manifest = buildManifest();

  fs.writeFileSync(path.join(outputDir, "demo-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "mvp-demo-pack.md"), renderMainPack(manifest));
  fs.writeFileSync(path.join(outputDir, "demo-walkthrough.md"), renderWalkthrough(manifest));
  fs.writeFileSync(path.join(outputDir, "ai-demo-brief.md"), renderAiBrief(manifest));

  console.log("Generated output/demo/mvp-demo-pack.md.");
  console.log("Generated output/demo/demo-walkthrough.md.");
  console.log("Generated output/demo/ai-demo-brief.md.");
  console.log("Generated output/demo/demo-manifest.json.");
}

main();
