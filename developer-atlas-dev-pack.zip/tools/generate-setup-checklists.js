const fs = require("fs");
const path = require("path");
const {
  toolkitOutputDir,
  ensureToolkitOutputDir,
  readTools,
  readSetupProfiles
} = require("./toolkit-utils");

function main() {
  const tools = new Map(readTools().map((record) => [record.data.id, record.data]));
  const profiles = readSetupProfiles().map((record) => record.data);

  ensureToolkitOutputDir();
  fs.writeFileSync(
    path.join(toolkitOutputDir, "setup-checklists.md"),
    toMarkdown(profiles, tools)
  );

  console.log(`Generated output/toolkit/setup-checklists.md for ${profiles.length} setup profile(s).`);
}

function toMarkdown(profiles, tools) {
  const lines = ["# Atlas Setup Checklists", ""];

  for (const profile of profiles) {
    lines.push(`## ${profile.audience}`);
    lines.push("");
    lines.push(`- Profile ID: ${profile.profile_id}`);
    lines.push(`- Operating system: ${profile.operating_system}`);
    lines.push(`- Stack: ${profile.stack.join(", ")}`);
    lines.push("");

    lines.push("### Required Tools", "");
    lines.push(...formatToolList(profile.required_tools, tools));
    lines.push("", "### Recommended Extensions", "");
    lines.push(...formatToolList(profile.recommended_extensions, tools));
    lines.push("", "### Optional Tools", "");
    lines.push(...formatToolList(profile.optional_tools, tools));

    lines.push("", "### Setup Order", "");
    lines.push(...profile.setup_order.map((step, index) => `${index + 1}. ${step}`));
    lines.push("", "### Verification Checklist", "");
    lines.push(...profile.verification_checklist.map((item) => `- [ ] ${item}`));
    lines.push("", "### Common Friction Nodes", "");
    lines.push(...profile.common_friction_nodes.map((id) => `- ${id}`));
    lines.push("");
  }

  return `${lines.join("\n")}\n`;
}

function formatToolList(ids, tools) {
  if (!ids.length) return ["- None"];

  return ids.map((id) => {
    const tool = tools.get(id);
    return tool ? `- ${tool.name} (${id})` : `- ${id}`;
  });
}

main();
