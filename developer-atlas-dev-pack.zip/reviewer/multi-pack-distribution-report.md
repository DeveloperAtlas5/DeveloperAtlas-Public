# Multi-Pack Distribution Report

## Purpose

Phase 116 creates three audience-specific packages so different users receive different package weight.

Use `which-pack-should-i-send.md` to choose a pack, then `pack-send-checklist.md` before sending it.

Phase 119 simplified the Rookie Pack into a non-AI Mission 1 first-reaction test.

First tester signal: the Rookie Pack start was clear, but Mission 1 needed better laptop readability.

Second tester signal: the Rookie Pack assumes the learner already has a basic Vue project. It is not a zero-install or zero-project setup pack.

Real tester feedback is tracked in `reviewer/real-feedback-register.md`. Keep it separate from simulated feedback.

## Pack Summary

| Pack | Audience | Dashboard variant | File count | Manifest entries |
|---|---|---|---:|---:|
| Rookie Pack | Complete beginners and first-time testers | Rookie Mission 1 dashboard | 5 | 4 |
| Full Pack | Normal learners, Rookie-to-Junior learners, and AI-assisted builders | Full learner dashboard | 99 | 10 |
| Dev Pack | Maintainers, reviewers, contributors, and future AI editing sessions | Full dashboard plus maintainer context | 718 | 16 |

## Included Folders

- Rookie Pack: `mission/`, `help/`.
- Full Pack: `mission/`, `help/`, `ai/`, `reference/`, `concepts/`, `project-start/`, `reviewer/`.
- Dev Pack: Full Pack plus `tools/`, `docs/`, `content/`, `schemas/`, source context, generated concept output, and generated experience output.

## Intentional Exclusions

- Rookie Pack excludes AI, reference, Concept Library, Project Start Guides, Mission 2, Mission 3, feedback templates, reviewer files, tools, docs, content, and dev material.
- Full Pack keeps reviewer files under `reviewer/` and keeps them out of the default learner path.
- Dev Pack excludes `node_modules/`, `.git/`, and old zip artifacts.

## Validation Summary

- Pack manifests clarify that they list primary files and directories, not every nested file.
- Pack-specific dashboards avoid links to files not included in that pack.
- Rookie Pack keeps Mission 1 as the first visible action.
- Full Pack keeps Mission 1 -> Mission 2 -> Mission 3 available.
- Dev Pack includes maintainer context without adding learner scope.

## Recommended Distribution Usage

- Send Rookie Pack to complete beginners and first-time testers only when they already have a basic Vue project and you need a Mission 1 first reaction.
- Send Full Pack to normal learners, AI-assisted builders, and learners testing Missions 1-3.
- Send Dev Pack to maintainers, reviewers, contributors, or future AI editing sessions.
- Use `reviewer/real-feedback-register.md` to separate real tester feedback from simulated or internal feedback.

Future Atlas flow idea: Goal -> Build or Learn -> Solo or AI Help -> Concept Library / Mission Path.
