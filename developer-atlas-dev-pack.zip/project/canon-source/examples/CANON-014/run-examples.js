const examples = [
  ["controller inline validation", require("./controller-inline-validation")],
  ["Form Request-style validation structure", require("./form-request-style-validation-structure")],
  ["mistake: trusting frontend validation only", require("./mistake-trusting-frontend-validation-only")],
  ["mistake: unique scope and nullable/required use", require("./mistake-unique-scope-and-nullable-required")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-014 example(s).`);
