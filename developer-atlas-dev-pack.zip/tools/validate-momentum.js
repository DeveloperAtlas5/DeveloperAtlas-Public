const fs = require("fs");
const path = require("path");
const {
  momentumDir,
  readMomentumSessions
} = require("./momentum-utils");

const requiredSchemaFiles = [
  "momentum-session.schema.json",
  "momentum-report.schema.json"
];

const requiredSessionFields = [
  "session_id",
  "learner_profile",
  "setup_request_id",
  "recovery_request_ids",
  "learning_plan_id",
  "blockers_encountered",
  "estimated_time_lost_without_atlas",
  "estimated_time_lost_with_atlas",
  "confidence_before",
  "confidence_after",
  "completed_steps",
  "next_steps"
];

const arrayFields = [
  "recovery_request_ids",
  "blockers_encountered",
  "completed_steps",
  "next_steps"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemaFiles(errors);

  let records = [];
  try {
    records = readMomentumSessions();
  } catch (error) {
    errors.push(`momentum/examples: unable to read sessions (${error.message})`);
  }

  const seenIds = new Set();
  for (const record of records) {
    validateSession(record, seenIds, errors, warnings);
  }

  console.log("Atlas Momentum validation");
  console.log(`Momentum sessions: ${records.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemaFiles(errors) {
  for (const fileName of requiredSchemaFiles) {
    const schemaPath = path.join(momentumDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`momentum/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`momentum/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateSession(record, seenIds, errors, warnings) {
  const { session, relativePath } = record;

  for (const field of requiredSessionFields) {
    if (session[field] === undefined || session[field] === null || session[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }

  if (typeof session.session_id === "string") {
    if (seenIds.has(session.session_id)) errors.push(`${relativePath}: duplicate session_id ${session.session_id}`);
    seenIds.add(session.session_id);
  }

  for (const field of arrayFields) {
    validateStringArray(relativePath, session, field, errors);
  }

  validateNonNegativeNumber(relativePath, session, "estimated_time_lost_without_atlas", errors);
  validateNonNegativeNumber(relativePath, session, "estimated_time_lost_with_atlas", errors);
  validateConfidence(relativePath, session, "confidence_before", errors);
  validateConfidence(relativePath, session, "confidence_after", errors);

  if (session.estimated_time_lost_with_atlas > session.estimated_time_lost_without_atlas) {
    warnings.push(`${relativePath}: Atlas-assisted time exceeds baseline estimate`);
  }
  if (session.confidence_after < session.confidence_before) {
    warnings.push(`${relativePath}: confidence decreased after Atlas support`);
  }
}

function validateStringArray(relativePath, data, field, errors) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }

  for (const value of data[field]) {
    if (typeof value !== "string" || !value.trim()) {
      errors.push(`${relativePath}: ${field} contains a non-string entry`);
    }
  }
}

function validateNonNegativeNumber(relativePath, data, field, errors) {
  if (typeof data[field] !== "number" || data[field] < 0) {
    errors.push(`${relativePath}: ${field} should be a non-negative number`);
  }
}

function validateConfidence(relativePath, data, field, errors) {
  if (typeof data[field] !== "number" || data[field] < 0 || data[field] > 1) {
    errors.push(`${relativePath}: ${field} should be a number from 0 to 1`);
  }
}

main();
