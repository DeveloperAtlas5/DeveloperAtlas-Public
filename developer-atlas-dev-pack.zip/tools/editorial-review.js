const fs = require("fs");
const path = require("path");
const {
  outputDir,
  loadCanonEntries,
  reviewEntry,
  average,
  ensureEditorialOutputDir,
  weakestSections,
  strongestSections
} = require("./editorial-utils");

function main() {
  ensureEditorialOutputDir();
  const entries = loadCanonEntries();
  const reviews = entries.map(reviewEntry);
  const publication = {
    generated_at: new Date().toISOString(),
    average_editorial_score: Number(average(reviews, (review) => review.score).toFixed(1)),
    entries: reviews.map((review) => ({
      canon_id: review.canon_id,
      node_id: review.node_id,
      title: review.title,
      score: review.score,
      canon_score: review.canon_score,
      publication_status: review.publication_status,
      warnings: review.warnings
    }))
  };

  fs.writeFileSync(path.join(outputDir, "editorial-review.json"), `${JSON.stringify(reviews, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "editorial-report.md"), toEditorialReport(reviews));
  fs.writeFileSync(path.join(outputDir, "publication-score.json"), `${JSON.stringify(publication, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "publication-report.md"), toPublicationReport(publication));
  fs.writeFileSync(path.join(outputDir, "canon-health.md"), toCanonHealth(reviews));

  const warningCount = reviews.reduce((sum, review) => sum + review.warnings.length, 0);
  console.log(`Editorial review complete for ${reviews.length} Canon node(s).`);
  console.log(`Average editorial score: ${publication.average_editorial_score}`);
  console.log(`Editorial warnings: ${warningCount}`);
}

function toEditorialReport(reviews) {
  const dimensionKeys = Object.keys(reviews[0]?.dimensions || {});
  const lines = [
    "# Editorial Report",
    "",
    `Canon nodes reviewed: ${reviews.length}`,
    `Average editorial score: ${Number(average(reviews, (review) => review.score).toFixed(1))}`,
    "",
    "## Dimension Averages",
    ""
  ];

  for (const key of dimensionKeys) {
    lines.push(`- ${key}: ${Number(average(reviews, (review) => review.dimensions[key]).toFixed(1))}`);
  }

  lines.push("", "## Teaching Review", "");
  for (const review of reviews) {
    lines.push(`- ${review.canon_id}: teaching quality ${review.dimensions.teaching_quality}/12, readability ${review.dimensions.readability}/4`);
  }

  lines.push("", "## Decision Review", "");
  for (const review of reviews) {
    lines.push(`- ${review.canon_id}: decision support ${review.dimensions.decision_support}/12, production readiness ${review.dimensions.production_readiness}/10`);
  }

  lines.push("", "## AI Review", "");
  for (const review of reviews) {
    lines.push(`- ${review.canon_id}: AI readiness ${review.dimensions.ai_readiness}/10, relationships ${review.dimensions.relationships}/8`);
  }

  lines.push("", "## Warnings", "");
  const warningRows = reviews.filter((review) => review.warnings.length);
  if (warningRows.length) {
    for (const review of warningRows) lines.push(`- ${review.canon_id}: ${review.warnings.join("; ")}`);
  } else {
    lines.push("- None");
  }

  return `${lines.join("\n")}\n`;
}

function toPublicationReport(publication) {
  const lines = [
    "# Publication Report",
    "",
    `Average editorial score: ${publication.average_editorial_score}`,
    "",
    "## Publication Readiness",
    ""
  ];

  for (const entry of publication.entries) {
    lines.push(`- ${entry.canon_id}: ${entry.publication_status} (${entry.score}/100)`);
  }

  lines.push("", "## Warning Counts", "");
  for (const entry of publication.entries) {
    lines.push(`- ${entry.canon_id}: ${entry.warnings.length}`);
  }

  return `${lines.join("\n")}\n`;
}

function toCanonHealth(reviews) {
  const averageScore = Number(average(reviews, (review) => review.score).toFixed(1));
  const backlog = reviews
    .filter((review) => review.warnings.length > 0 || review.publication_status !== "Gold Candidate")
    .sort((a, b) => a.score - b.score);
  const readinessCounts = {};
  for (const review of reviews) readinessCounts[review.publication_status] = (readinessCounts[review.publication_status] || 0) + 1;

  const lines = [
    "# Canon Health Report",
    "",
    `Average Canon score: ${averageScore}`,
    "",
    "## Weakest Sections",
    ""
  ];

  const weak = weakestSections(reviews);
  if (weak.length) for (const [section, count] of weak) lines.push(`- ${section}: ${count}`);
  else lines.push("- None");

  lines.push("", "## Strongest Sections", "");
  for (const [section, count] of strongestSections(reviews).slice(0, 10)) {
    lines.push(`- ${section}: present in ${count}/${reviews.length}`);
  }

  lines.push("", "## Review Backlog", "");
  if (backlog.length) {
    for (const review of backlog) lines.push(`- ${review.canon_id}: ${review.title} (${review.score}/100, ${review.warnings.length} warning(s))`);
  } else {
    lines.push("- None");
  }

  lines.push("", "## Publication Readiness", "");
  for (const [status, count] of Object.entries(readinessCounts).sort()) {
    lines.push(`- ${status}: ${count}`);
  }

  return `${lines.join("\n")}\n`;
}

main();
