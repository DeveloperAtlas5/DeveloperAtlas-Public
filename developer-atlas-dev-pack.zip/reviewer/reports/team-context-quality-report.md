# Atlas Team Context Quality Report

Contexts scored: 3
Average score: 99.2
Highest quality context: project.junior_vue_laravel_onboarding (100)
Lowest quality context: project.personal_fullstack_to_team (97.6)
Highest drift risk: project.junior_vue_laravel_onboarding (drift safety score 100)

## Most Common Missing Context

- None

## Scores

### project.junior_vue_laravel_onboarding

Overall: 100
Alignment: 100
Onboarding clarity: 100
AI safety: 100
Context specificity: 100
Drift risk score: 100
Forbidden assumptions: 100
Tooling clarity: 100

Recommended improvements:
- None

### project.inventory_vue_laravel

Overall: 100
Alignment: 100
Onboarding clarity: 100
AI safety: 100
Context specificity: 100
Drift risk score: 100
Forbidden assumptions: 100
Tooling clarity: 100

Recommended improvements:
- None

### project.personal_fullstack_to_team

Overall: 97.6
Alignment: 100
Onboarding clarity: 100
AI safety: 100
Context specificity: 100
Drift risk score: 100
Forbidden assumptions: 80
Tooling clarity: 100

Recommended improvements:
- None

