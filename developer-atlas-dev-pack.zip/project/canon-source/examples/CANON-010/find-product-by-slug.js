module.exports = function runFindProductBySlug() {
  const products = [
    { id: "p1", slug: "black-t-shirt", name: "Black T-shirt" },
    { id: "p2", slug: "white-mug", name: "White Mug" }
  ];

  const product = products.find((item) => item.slug === "white-mug");

  if (!product || product.id !== "p2") {
    throw new Error("Expected find() to return the product with slug white-mug");
  }
};
