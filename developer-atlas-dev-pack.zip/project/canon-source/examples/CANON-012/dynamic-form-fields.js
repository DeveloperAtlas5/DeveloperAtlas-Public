const assert = require("assert");

function run() {
  const touchedFields = {
    email: true,
    password: true,
    company: false
  };
  const formErrors = {
    email: "Enter a valid email.",
    password: "Password must be at least 12 characters."
  };

  const visibleErrors = Object.keys(touchedFields)
    .filter((fieldName) => touchedFields[fieldName] && formErrors[fieldName])
    .map((fieldName) => ({
      fieldName,
      message: formErrors[fieldName]
    }));

  assert.deepStrictEqual(visibleErrors, [
    { fieldName: "email", message: "Enter a valid email." },
    { fieldName: "password", message: "Password must be at least 12 characters." }
  ]);
}

module.exports = run;

