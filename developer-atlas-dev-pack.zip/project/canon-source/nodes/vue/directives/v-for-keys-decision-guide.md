# v-for keys decision guide

## Status Metadata

- Canon ID: CANON-013
- Node ID: canon.vue.directive.v-for-keys
- Status: Gold Candidate
- Score: 95
- Version: 2026.1
- Source family: Vue Directives
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use stable, unique keys in `v-for` when list items can move, be inserted, be removed, contain component state, or contain user-editable DOM state. Index keys are only acceptable for static, never-reordered lists where the rendered content has no local state. Keys are not decoration; they tell Vue which rendered node belongs to which data item.

## What Problem This Solves

Vue can update unkeyed or index-keyed lists in ways that look correct for plain text but break identity-sensitive UI. The common failure is subtle: an input value, checkbox state, focused row, animation, or child component instance appears attached to the wrong item after sorting, filtering, inserting, or deleting.

This node answers:

- Why keys exist.
- Why stable item IDs are the default.
- When index keys are acceptable.
- Why index keys become dangerous in dynamic lists.
- How keys preserve component and DOM state correctly.

## Mental Model

Think of a Vue key as a name tag for a rendered item.

Without a real name tag, Vue can say, "the first row is still the first row," even if the data item in that position changed. That is efficient, but it can reuse the wrong state.

With a stable key, Vue can say, "this rendered row belongs to user `u-42`." If `u-42` moves from position 3 to position 1, Vue moves or reuses that row as the same identity.

The key should answer: "Which real thing is this?"

Good:

```vue
<UserRow v-for="user in users" :key="user.id" :user="user" />
```

Risky for dynamic lists:

```vue
<UserRow v-for="(user, index) in users" :key="index" :user="user" />
```

## Beginner Explanation

When Vue renders a list, it needs to match old items with new items after the list changes. The `key` helps Vue keep track of each item.

If every user has an `id`, use that `id`:

```vue
<li v-for="user in users" :key="user.id">
  {{ user.name }}
</li>
```

Do not use the array index when the list can change order:

```vue
<!-- Risky if users can be sorted, filtered, added, or removed -->
<li v-for="(user, index) in users" :key="index">
  {{ user.name }}
</li>
```

Beginner rule:

1. If the item has an ID, use it.
2. If the list can change, do not use the index.
3. If the row has inputs or child components, use a stable key.
4. If the list is static text that never changes, an index key can be acceptable.

## Professional Explanation

Vue uses keys as hints for its virtual DOM diffing algorithm. A key gives a vnode stable identity across renders. Without keys, Vue may patch elements in place to minimize movement. With keys, Vue can reorder, reuse, remove, or recreate nodes according to key identity.

The production concern is not only rendering speed. It is correctness of identity. In dynamic lists, index keys encode position, not item identity. When an item moves, the index stays attached to the position, so local DOM state or component state can appear to move to the wrong data item.

Stable keys should be primitive values such as strings, numbers, or symbols. They must be unique among siblings under the same parent. Duplicates break the identity contract and can cause render errors or unpredictable patching.

Use index keys only when all of these are true:

- The list is static for the lifetime of the component.
- Items are never inserted, removed, filtered, sorted, or reordered.
- Rows do not contain local component state, inputs, focus, transitions, or animations.
- The index is not being used to model business identity.

## Syntax

```vue
<li v-for="item in items" :key="item.id">
  {{ item.label }}
</li>
```

With a component:

```vue
<TodoRow
  v-for="todo in todos"
  :key="todo.id"
  :todo="todo"
/>
```

With `<template v-for>`:

```vue
<template v-for="section in sections" :key="section.id">
  <h2>{{ section.title }}</h2>
  <p>{{ section.summary }}</p>
</template>
```

## Decision Guide

1. Does each item have a stable ID from the database, API, route, or domain model?
   Use it.
2. Can the list be sorted, filtered, inserted into, removed from, paginated, or reordered?
   Do not use the index.
3. Does each row contain inputs, child components, focus state, animations, or local state?
   Use a stable item key.
4. Is the list static, read-only, never reordered, and state-free?
   An index key is acceptable, though a stable semantic key is still clearer.
5. Are keys duplicated?
   Fix the data or derive a unique stable key before rendering.

## Comparison Table

| Key Choice | Best For | Trade-Off |
| --- | --- | --- |
| Stable ID, such as `item.id` | Dynamic lists and stateful rows | Requires the data model to provide unique identity. |
| Stable domain key, such as `item.slug` | Lists where the domain key is unique and immutable | Dangerous if the value can change or collide. |
| Composite stable key | Items unique only by a combination of fields | Must remain stable and primitive after composition. |
| Index key | Static, read-only, never-reordered lists | Breaks identity when order or membership changes. |
| No key | Very simple state-free output where default patching is intentional | Easy to outgrow and often unclear in code review. |

## When To Use The Primary Option

Use stable keys when item identity matters.

- Lists from a database or API with IDs.
- Sortable tables.
- Filtered search results.
- Drag-and-drop lists.
- Editable rows with inputs.
- Rows rendered as child components.
- Lists with transitions or animations.
- Lists where preserving focus, selection, or local row state matters.

## When To Use Stable Keys

Stable keys are the default for production `v-for` lists.

```vue
<OrderRow
  v-for="order in visibleOrders"
  :key="order.id"
  :order="order"
/>
```

Why this fits: if orders are filtered or sorted, each rendered row still belongs to the same order identity.

## When To Use The Alternative

Use an index key only when the list is static and state-free.

Acceptable:

```vue
<li v-for="(step, index) in onboardingSteps" :key="index">
  {{ step }}
</li>
```

This is acceptable when `onboardingSteps` is a fixed local array of plain strings, never sorted, never filtered, never edited, and never rendered as stateful child components.

## When Index Keys Are Acceptable

Index keys can be acceptable for:

- Static copy lists.
- Fixed legal disclaimers.
- Hard-coded feature bullet lists.
- State-free decorative repeated elements.
- Generated placeholders that never reorder or preserve local state.

They become less acceptable as soon as the list starts acting like real data.

## When Index Keys Are Dangerous

Index keys are dangerous when:

- The list can be sorted.
- The list can be filtered.
- Items can be inserted or removed.
- Rows contain form inputs.
- Rows contain child components with local state.
- Rows can be animated or transitioned.
- The UI preserves focus, open/closed state, selection, or validation state.

```vue
<!-- Dangerous: row state can attach to the wrong todo after reorder -->
<TodoRow
  v-for="(todo, index) in sortedTodos"
  :key="index"
  :todo="todo"
/>
```

## When Not To Use This Decision

- Do not use keys to fix missing data identity in the domain model. Fix the identity problem upstream.
- Do not use random values such as `Math.random()` for keys; they force unnecessary recreation and destroy state.
- Do not use objects as keys; use primitive values.
- Do not use array index keys to silence linter warnings in dynamic lists.
- Do not use duplicate keys among siblings.
- Do not combine `v-if` and `v-for` on the same element as a filtering strategy. Use a computed filtered list.

## Alternatives

- Add a real stable ID to the data model.
- Use a stable domain value such as slug, SKU, or code when it is truly unique.
- Use a composite primitive key such as ``${order.id}:${line.id}``.
- Filter or sort in a computed property before rendering.
- Split stateful rows into keyed child components.

## Production Examples

### Editable User Table

```vue
<UserRow
  v-for="user in sortedUsers"
  :key="user.id"
  :user="user"
  v-model:role="roleDrafts[user.id]"
/>
```

Why stable keys fit: sorting the table should not move one user's draft role selection onto another user.

### Notification List With Transitions

```vue
<TransitionGroup name="notification" tag="ul">
  <li v-for="notification in notifications" :key="notification.id">
    {{ notification.message }}
  </li>
</TransitionGroup>
```

Why stable keys fit: transitions need real identity so entering, leaving, and moving items animate correctly.

### Static Policy Checklist

```vue
<li v-for="(rule, index) in passwordRules" :key="index">
  {{ rule }}
</li>
```

Why an index key can be acceptable: the list is fixed, text-only, state-free, and never reordered.

### Template v-for With One Key

```vue
<template v-for="section in helpSections" :key="section.slug">
  <h2>{{ section.title }}</h2>
  <p>{{ section.body }}</p>
</template>
```

Why this fits: the key belongs on the `<template>` container when the loop renders multiple sibling nodes per item.

## Common Mistakes

- Using `:key="index"` on sortable or filterable lists.
- Using duplicate keys such as category names that are not unique.
- Using `Math.random()` or `Date.now()` as keys and forcing every item to recreate.
- Using an object as the key instead of a primitive.
- Omitting keys on child components rendered by `v-for`.
- Assuming a key improves performance by itself rather than preserving identity.
- Putting `key` on the wrong element when using `<template v-for>`.
- Using `v-if` and `v-for` on the same element instead of rendering a computed filtered list.

## Debugging Checklist

- If input values appear under the wrong row, are you using index keys?
- If expanded/collapsed state moves to another item after sorting, is the key stable?
- If animations are wrong, are keys unique and stable?
- If a component does not reset when it should, is the key too stable for a new identity?
- If every row remounts on each render, are keys random or changing?
- If Vue reports duplicate keys, does the data contain collisions?
- If a list is filtered in the template, should the filtered array be computed before `v-for`?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-013/`.

Run:

```bash
npm run canon:verify:013
```

The examples verify:

- Stable ID keys preserve item identity after reorder.
- Index keys attach state to positions after reorder.
- Index keys are acceptable for static state-free lists.
- Duplicate keys are detected as invalid identity.

## Performance Notes

Keys are mainly about correct identity. They also influence Vue's patching strategy.

- Stable keys allow Vue to reorder existing nodes instead of guessing by position.
- Index keys can look efficient but produce incorrect state reuse in dynamic lists.
- Random keys are usually worse because they force remounting and destroy state.
- For huge lists, consider virtualization, pagination, or windowing in addition to correct keys.

Do not choose index keys for performance unless the list is intentionally static and state-free.

## AI Coding Guidance

When generating Vue `v-for` code:

- Prefer `:key="item.id"` when an item ID exists.
- If no ID exists, ask whether the list can reorder, filter, insert, or delete.
- Do not generate `:key="index"` for dynamic lists, inputs, or child components.
- Do not generate random keys.
- Warn about duplicate keys.
- Put the key on `<template v-for>` when the loop renders multiple sibling nodes.
- Use computed properties for filtered or sorted lists before rendering.
- Explain the choice in terms of item identity and state preservation.

Bad AI output:

```vue
<UserRow v-for="(user, index) in sortedUsers" :key="index" :user="user" />
```

Good AI output:

```vue
<UserRow v-for="user in sortedUsers" :key="user.id" :user="user" />
```

## Teaching Notes

Teach keys with state, not only text. A plain text list can hide the bug because the visible words update. A list of inputs makes the identity problem obvious.

Progression:

1. Render a list with stable IDs.
2. Sort the list and show identity stays attached.
3. Repeat with index keys and show state follows positions.
4. Explain the acceptable static-list exception.
5. Show duplicate keys as an invalid identity map.

Useful teaching phrase:

> A key should identify the item, not its current seat.

## Interview Questions

1. Why does Vue use keys in `v-for`?
2. Why can `:key="index"` be dangerous after sorting?
3. When is an index key acceptable?
4. What happens if sibling keys are duplicated?
5. Why are random keys usually a bug?
6. Where should the key go when using `<template v-for>`?
7. How do keys affect component state preservation?

## Exercises

### Beginner

Render a todo list with `:key="todo.id"` and explain what the key identifies.

### Intermediate

Build a sortable list of editable user rows. Verify that input state stays with the same user after sorting.

### Advanced

Review a Vue component that uses index keys in several lists. Classify each list as static safe, dynamic dangerous, or needing a new domain ID.

## Related Atlas Nodes

- `vue.directive.v-for`
- `vue.directive.v-if`
- `vue.directive.v-model`
- `CANON-007`
- `CANON-003`
- `CANON-006`

## Evidence And Sources

- Vue Guide: List Rendering - https://vuejs.org/guide/essentials/list
- Vue Guide: Maintaining State with `key` - https://vuejs.org/guide/essentials/list.html#maintaining-state-with-key
- Vue API: Special Attribute `key` - https://vuejs.org/api/built-in-special-attributes.html#key

## Proof Of Superiority Summary

Official Vue docs explain that keys help Vue identify list nodes. This Canon node turns that behavior into a production decision model: stable identity by default, index keys only for static state-free lists, duplicate/random key warnings, state-preservation debugging, performance trade-offs, deterministic verification, and AI-specific generation rules.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
