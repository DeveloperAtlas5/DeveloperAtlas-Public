function classifyEndpoint(endpoint) {
  const recommendations = ["controller"];

  if (
    endpoint.validationRules > 3 ||
    endpoint.hasAuthorization ||
    endpoint.hasCustomMessages ||
    endpoint.routeAwareValidation
  ) {
    recommendations.push("form_request");
  }

  if (
    endpoint.reusedWorkflow ||
    endpoint.modelOperations > 1 ||
    endpoint.needsTransaction ||
    endpoint.hasExternalSideEffects ||
    endpoint.usedOutsideHttp
  ) {
    recommendations.push("service");
  }

  return recommendations;
}

function shouldAvoidService(endpoint) {
  return (
    endpoint.modelOperations <= 1 &&
    !endpoint.reusedWorkflow &&
    !endpoint.needsTransaction &&
    !endpoint.hasExternalSideEffects &&
    !endpoint.usedOutsideHttp
  );
}

module.exports = {
  classifyEndpoint,
  shouldAvoidService
};
