const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readFrictionNodes } = require("./friction-utils");
const { readTools } = require("./toolkit-utils");
const { readMachineProfiles, readWorkloadProfiles } = require("./hardware-utils");
const {
  personalRoadmapsOutputDir,
  ensureGoalsOutputDirs,
  readGoals,
  readGoalProfiles,
  countValues,
  unique
} = require("./goal-utils");

const foundationOrder = [
  "html.",
  "css.",
  "javascript.",
  "vue.",
  "php.",
  "laravel.",
  "sql."
];

function main() {
  const goals = readGoals().map((record) => record.goal);
  const profiles = readGoalProfiles().map((record) => record.profile);
  const context = readContext();

  ensureGoalsOutputDirs();

  for (const profile of profiles) {
    const roadmap = buildRoadmap(profile, goals, context);
    const baseName = profile.profile_id.replace(/^profile\./, "").replace(/\./g, "-");
    fs.writeFileSync(
      path.join(personalRoadmapsOutputDir, `${baseName}.json`),
      `${JSON.stringify(roadmap, null, 2)}\n`
    );
    fs.writeFileSync(
      path.join(personalRoadmapsOutputDir, `${baseName}.md`),
      toMarkdown(roadmap)
    );
  }

  console.log(`Generated ${profiles.length} personal roadmap(s).`);
}

function readContext() {
  const canonIndex = JSON.parse(fs.readFileSync(path.join(rootDir, "canon", "canon-index.json"), "utf8"));
  const tools = readTools().map((record) => record.data);
  const frictionNodes = readFrictionNodes().map((record) => record.node);
  const machineProfiles = readMachineProfiles().map((record) => record.profile);
  const workloads = readWorkloadProfiles().map((record) => record.workload);

  return {
    canonById: new Map(canonIndex.entries.map((entry) => [entry.canon_id, entry])),
    toolsById: new Map(tools.map((tool) => [tool.id, tool])),
    frictionById: new Map(frictionNodes.map((node) => [node.id, node])),
    machineById: new Map(machineProfiles.map((profile) => [profile.profile_id, profile])),
    workloadsById: new Map(workloads.map((workload) => [workload.workload_id, workload]))
  };
}

function buildRoadmap(profile, allGoals, context) {
  const goalMap = new Map(allGoals.map((goal) => [goal.goal_id, goal]));
  const selectedGoals = profile.goals.map((goalId) => goalMap.get(goalId)).filter(Boolean);
  const orderedGoals = orderGoals(profile, selectedGoals);
  const known = new Set(profile.current_known_nodes || []);
  const machineProfile = context.machineById.get(profile.machine_profile_id);

  const knowledgeCounts = countValues(selectedGoals.flatMap((goal) => goal.required_knowledge_nodes));
  const canonCounts = countValues(selectedGoals.flatMap((goal) => goal.recommended_canon_nodes));
  const toolCounts = countValues(selectedGoals.flatMap((goal) => [...goal.required_tools, ...goal.recommended_tools]));
  const frictionCounts = countValues(selectedGoals.flatMap((goal) => goal.common_friction_nodes));

  const sharedFoundations = knowledgeCounts
    .filter((item) => item.count > 1 && !known.has(item.value))
    .map((item) => item.value);
  const goalSpecificNodes = unique(orderedGoals.flatMap((goal) => goal.required_knowledge_nodes))
    .filter((nodeId) => !sharedFoundations.includes(nodeId) && !known.has(nodeId));

  const learningOrder = sortKnowledge([...sharedFoundations, ...goalSpecificNodes]);
  const overlappingCanon = canonCounts.filter((item) => item.count > 1).map((item) => item.value);
  const overlappingTools = toolCounts.filter((item) => item.count > 1).map((item) => item.value);
  const overlappingFriction = frictionCounts.filter((item) => item.count > 1).map((item) => item.value);
  const estimatedTotalHours = selectedGoals.reduce((total, goal) => {
    return total + goal.estimated_learning_hours + goal.estimated_practice_hours;
  }, 0);

  const roadmap = {
    profile_summary: {
      profile_id: profile.profile_id,
      learner_level: profile.learner_level,
      available_hours_per_week: profile.available_hours_per_week,
      preferred_stack: profile.preferred_stack,
      machine_profile_id: profile.machine_profile_id,
      constraints: profile.constraints
    },
    selected_goals: orderedGoals.map((goal) => goal.goal_id),
    shared_foundations: sharedFoundations,
    overlapping_canon_nodes: overlappingCanon,
    overlapping_tools: overlappingTools,
    overlapping_friction_risks: overlappingFriction,
    recommended_learning_order: learningOrder,
    milestones: buildMilestones(orderedGoals, learningOrder, overlappingCanon, overlappingTools, overlappingFriction),
    estimated_total_hours: estimatedTotalHours,
    weekly_plan: buildWeeklyPlan(profile, estimatedTotalHours),
    first_7_days: buildFirstSevenDays(overlappingTools, overlappingFriction, learningOrder),
    first_30_days: buildFirstThirtyDays(orderedGoals, learningOrder),
    setup_checklist: buildSetupChecklist(overlappingTools, orderedGoals, context),
    hardware_considerations: buildHardwareNotes(orderedGoals, machineProfile, context),
    projects_to_build: unique(orderedGoals.flatMap((goal) => goal.output_projects)),
    mastery_checkpoints: buildMasteryCheckpoints(orderedGoals, overlappingCanon, context),
    what_to_skip_for_now: buildSkipList(profile, orderedGoals),
    next_recommended_goals: buildNextGoals(profile, allGoals)
  };

  return roadmap;
}

function orderGoals(profile, selectedGoals) {
  const priority = new Map((profile.priority_order || []).map((goalId, index) => [goalId, index]));
  return [...selectedGoals].sort((a, b) => {
    return (priority.get(a.goal_id) ?? 999) - (priority.get(b.goal_id) ?? 999);
  });
}

function sortKnowledge(nodes) {
  return unique(nodes).sort((a, b) => {
    const aIndex = foundationOrder.findIndex((prefix) => a.startsWith(prefix));
    const bIndex = foundationOrder.findIndex((prefix) => b.startsWith(prefix));
    return normalizeIndex(aIndex) - normalizeIndex(bIndex) || a.localeCompare(b);
  });
}

function normalizeIndex(index) {
  return index === -1 ? 999 : index;
}

function buildMilestones(goals, learningOrder, canonNodes, tools, frictionRisks) {
  const milestones = [
    {
      title: "Foundation and setup",
      focus: "Install shared tools, confirm environment health, and review known basics.",
      learning_nodes: learningOrder.slice(0, 8),
      canon_nodes: canonNodes.slice(0, 3),
      tools,
      friction_prevention: frictionRisks
    },
    {
      title: "First vertical slice",
      focus: "Build one small feature that connects UI, logic, and data where relevant.",
      learning_nodes: learningOrder.slice(8, 18),
      canon_nodes: canonNodes.slice(3, 7),
      projects: goals.slice(0, 2).flatMap((goal) => goal.output_projects.slice(0, 1))
    }
  ];

  for (const goal of goals) {
    milestones.push({
      title: goal.title,
      focus: goal.success_criteria[0],
      learning_nodes: goal.required_knowledge_nodes.slice(0, 8),
      canon_nodes: goal.recommended_canon_nodes,
      projects: goal.output_projects
    });
  }

  return milestones;
}

function buildWeeklyPlan(profile, totalHours) {
  const weeks = Math.max(1, Math.ceil(totalHours / profile.available_hours_per_week));
  return [
    `${profile.available_hours_per_week} hours per week for about ${weeks} weeks.`,
    "Use 60% of time for building, 25% for focused learning, and 15% for review and debugging.",
    "Reserve one short session each week for friction cleanup: versions, dependencies, storage, and notes."
  ];
}

function buildFirstSevenDays(tools, frictionRisks, learningOrder) {
  return [
    "Install or verify shared tools before starting new frameworks.",
    ...tools.slice(0, 4).map((tool) => `Verify ${tool}.`),
    ...frictionRisks.slice(0, 3).map((risk) => `Read prevention notes for ${risk}.`),
    `Study first foundation nodes: ${learningOrder.slice(0, 5).join(", ")}.`
  ];
}

function buildFirstThirtyDays(goals, learningOrder) {
  return [
    `Complete foundation pass: ${learningOrder.slice(0, 12).join(", ")}.`,
    `Build: ${goals[0]?.output_projects[0] || "one small project"}.`,
    "Write a short review after each project: what broke, what fixed it, and what to repeat.",
    "Delay niche branches until the first end-to-end project works."
  ];
}

function buildSetupChecklist(tools, goals, context) {
  const selectedTools = unique([
    ...tools,
    ...goals.flatMap((goal) => goal.required_tools)
  ]);

  return selectedTools.map((toolId) => {
    const tool = context.toolsById.get(toolId);
    return tool
      ? `${tool.name}: ${tool.verification_steps[0] || "verify installation"}`
      : `${toolId}: verify required setup`;
  });
}

function buildHardwareNotes(goals, machineProfile, context) {
  const workloadIds = unique(goals.flatMap((goal) => goal.hardware_considerations));
  const notes = workloadIds.map((workloadId) => {
    const workload = context.workloadsById.get(workloadId);
    return workload
      ? `${workloadId}: ${workload.local_vs_cloud_guidance}`
      : `${workloadId}: review hardware requirements.`;
  });

  if (machineProfile) {
    notes.unshift(`Current machine profile: ${machineProfile.profile_id}, ${machineProfile.system_ram_gb} GB RAM, ${machineProfile.gpu_vram_gb} GB VRAM, ${machineProfile.storage_free_gb}/${machineProfile.storage_total_gb} GB free.`);
    if (machineProfile.system_ram_gb <= 8) notes.push("RAM may be the first practical constraint for multitasking, Docker, and local services.");
    if (machineProfile.gpu_vram_gb < 12 && workloadIds.some((id) => id.includes("llm"))) notes.push("For local AI, validate model size and VRAM needs before recommending products.");
  }

  return notes;
}

function buildMasteryCheckpoints(goals, canonNodes, context) {
  const checkpoints = [];

  for (const canonId of canonNodes) {
    const canon = context.canonById.get(canonId);
    if (canon?.learning?.mastery_criteria?.length) {
      checkpoints.push(`${canonId}: ${canon.learning.mastery_criteria[0]}`);
    }
  }

  for (const goal of goals) {
    checkpoints.push(`${goal.goal_id}: ${goal.success_criteria[0]}`);
  }

  return unique(checkpoints);
}

function buildSkipList(profile, goals) {
  const skips = ["Skip product-specific hardware shopping until workload constraints are measured."];
  if (profile.learner_level.includes("rookie")) skips.push("Skip Docker-heavy setup until the first local app works.");
  if (goals.length > 3) skips.push("Skip deep specialization until the shared full-stack foundation is stable.");
  return skips;
}

function buildNextGoals(profile, allGoals) {
  const selected = new Set(profile.goals);
  return allGoals
    .filter((goal) => !selected.has(goal.goal_id))
    .slice(0, 3)
    .map((goal) => goal.goal_id);
}

function toMarkdown(roadmap) {
  const lines = [
    `# Personal Roadmap: ${roadmap.profile_summary.profile_id}`,
    "",
    `Learner level: ${roadmap.profile_summary.learner_level}`,
    `Available hours per week: ${roadmap.profile_summary.available_hours_per_week}`,
    `Machine profile: ${roadmap.profile_summary.machine_profile_id}`,
    "",
    "## Selected Goals",
    "",
    ...formatList(roadmap.selected_goals),
    "",
    "## Shared Foundations",
    "",
    ...formatList(roadmap.shared_foundations),
    "",
    "## Overlaps",
    "",
    `Canon: ${roadmap.overlapping_canon_nodes.join(", ") || "None"}`,
    `Tools: ${roadmap.overlapping_tools.join(", ") || "None"}`,
    `Friction risks: ${roadmap.overlapping_friction_risks.join(", ") || "None"}`,
    "",
    "## Recommended Learning Order",
    "",
    ...formatList(roadmap.recommended_learning_order),
    "",
    "## Milestones",
    "",
    ...roadmap.milestones.flatMap(formatMilestone),
    "",
    "## Estimated Time",
    "",
    `Estimated total hours: ${roadmap.estimated_total_hours}`,
    "",
    "## Weekly Plan",
    "",
    ...formatList(roadmap.weekly_plan),
    "",
    "## First 7 Days",
    "",
    ...formatList(roadmap.first_7_days),
    "",
    "## First 30 Days",
    "",
    ...formatList(roadmap.first_30_days),
    "",
    "## Setup Checklist",
    "",
    ...formatList(roadmap.setup_checklist),
    "",
    "## Hardware Considerations",
    "",
    ...formatList(roadmap.hardware_considerations),
    "",
    "## Projects To Build",
    "",
    ...formatList(roadmap.projects_to_build),
    "",
    "## Mastery Checkpoints",
    "",
    ...formatList(roadmap.mastery_checkpoints),
    "",
    "## What To Skip For Now",
    "",
    ...formatList(roadmap.what_to_skip_for_now),
    "",
    "## Next Recommended Goals",
    "",
    ...formatList(roadmap.next_recommended_goals)
  ];

  return `${lines.join("\n")}\n`;
}

function formatMilestone(milestone) {
  return [
    `### ${milestone.title}`,
    "",
    milestone.focus,
    "",
    ...(milestone.learning_nodes?.length ? ["Learning:", ...formatList(milestone.learning_nodes), ""] : []),
    ...(milestone.canon_nodes?.length ? ["Canon:", ...formatList(milestone.canon_nodes), ""] : []),
    ...(milestone.tools?.length ? ["Tools:", ...formatList(milestone.tools), ""] : []),
    ...(milestone.friction_prevention?.length ? ["Friction prevention:", ...formatList(milestone.friction_prevention), ""] : []),
    ...(milestone.projects?.length ? ["Projects:", ...formatList(milestone.projects), ""] : [])
  ];
}

function formatList(items) {
  return items?.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
