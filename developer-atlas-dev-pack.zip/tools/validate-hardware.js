const fs = require("fs");
const path = require("path");
const {
  hardwareDir,
  readHardwareNodes,
  readWorkloadProfiles
} = require("./hardware-utils");

const requiredSchemaFiles = [
  "hardware-node.schema.json",
  "workload-profile.schema.json",
  "hardware-decision-guide.schema.json",
  "local-vs-cloud.schema.json"
];

const requiredNodeFields = [
  "id",
  "title",
  "category",
  "description",
  "helps_with",
  "important_specs",
  "beginner_explanation",
  "professional_notes",
  "recommended_for",
  "avoid_when",
  "tradeoffs",
  "related_workloads",
  "related_toolkit_nodes",
  "related_friction_nodes",
  "cost_sensitivity",
  "upgrade_priority",
  "future_proofing_score",
  "evidence_level",
  "confidence"
];

const requiredWorkloadFields = [
  "workload_id",
  "goal",
  "audience",
  "minimum_requirements",
  "recommended_requirements",
  "priority_order",
  "local_vs_cloud_guidance",
  "common_mistakes",
  "upgrade_path",
  "estimated_risk_of_wrong_purchase"
];

const nodeArrayFields = [
  "helps_with",
  "important_specs",
  "recommended_for",
  "avoid_when",
  "tradeoffs",
  "related_workloads",
  "related_toolkit_nodes",
  "related_friction_nodes"
];

const workloadArrayFields = [
  "priority_order",
  "common_mistakes",
  "upgrade_path"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemaFiles(errors);

  let nodes = [];
  let workloads = [];
  try {
    nodes = readHardwareNodes();
    workloads = readWorkloadProfiles();
  } catch (error) {
    errors.push(`hardware: unable to read JSON files (${error.message})`);
  }

  const workloadIds = new Set(workloads.map((record) => record.workload.workload_id));
  validateNodes(nodes, workloadIds, errors, warnings);
  validateWorkloads(workloads, nodes, errors, warnings);

  console.log("Atlas Hardware validation");
  console.log(`Hardware nodes: ${nodes.length}`);
  console.log(`Workload profiles: ${workloads.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemaFiles(errors) {
  for (const fileName of requiredSchemaFiles) {
    const schemaPath = path.join(hardwareDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`hardware/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`hardware/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateNodes(nodes, workloadIds, errors, warnings) {
  const seenIds = new Set();

  for (const { node, relativePath } of nodes) {
    validateRequiredFields(relativePath, node, requiredNodeFields, errors);

    if (typeof node.id === "string") {
      if (seenIds.has(node.id)) errors.push(`${relativePath}: duplicate id ${node.id}`);
      seenIds.add(node.id);
    }

    for (const field of nodeArrayFields) {
      validateStringArray(relativePath, node, field, errors, field.startsWith("related_"));
    }

    validateRange(relativePath, node, "cost_sensitivity", 1, 5, errors);
    validateRange(relativePath, node, "upgrade_priority", 1, 5, errors);
    validateRange(relativePath, node, "future_proofing_score", 0, 100, errors);
    validateRange(relativePath, node, "confidence", 0, 1, errors);

    for (const workloadId of node.related_workloads || []) {
      if (!workloadIds.has(workloadId)) {
        warnings.push(`${relativePath}: related workload ${workloadId} does not exist`);
      }
    }
  }
}

function validateWorkloads(workloads, nodes, errors, warnings) {
  const seenIds = new Set();

  for (const { workload, relativePath } of workloads) {
    validateRequiredFields(relativePath, workload, requiredWorkloadFields, errors);

    if (typeof workload.workload_id === "string") {
      if (seenIds.has(workload.workload_id)) {
        errors.push(`${relativePath}: duplicate workload_id ${workload.workload_id}`);
      }
      seenIds.add(workload.workload_id);
    }

    validateObject(relativePath, workload, "minimum_requirements", errors);
    validateObject(relativePath, workload, "recommended_requirements", errors);
    for (const field of workloadArrayFields) validateStringArray(relativePath, workload, field, errors);
    validateRange(relativePath, workload, "estimated_risk_of_wrong_purchase", 0, 100, errors);

    const hasRelatedHardware = nodes.some((record) => {
      return (record.node.related_workloads || []).includes(workload.workload_id);
    });
    if (!hasRelatedHardware) {
      warnings.push(`${relativePath}: no hardware node references this workload`);
    }
  }
}

function validateRequiredFields(relativePath, data, fields, errors) {
  for (const field of fields) {
    if (data[field] === undefined || data[field] === null || data[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }
}

function validateStringArray(relativePath, data, field, errors, allowEmpty = false) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }

  if (!allowEmpty && data[field].length === 0) {
    errors.push(`${relativePath}: ${field} should not be empty`);
  }

  for (const value of data[field]) {
    if (typeof value !== "string" || !value.trim()) {
      errors.push(`${relativePath}: ${field} contains a non-string entry`);
    }
  }
}

function validateObject(relativePath, data, field, errors) {
  if (!data[field] || typeof data[field] !== "object" || Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an object`);
    return;
  }

  if (Object.keys(data[field]).length === 0) {
    errors.push(`${relativePath}: ${field} should not be empty`);
  }
}

function validateRange(relativePath, data, field, min, max, errors) {
  if (typeof data[field] !== "number" || data[field] < min || data[field] > max) {
    errors.push(`${relativePath}: ${field} should be a number from ${min} to ${max}`);
  }
}

main();

