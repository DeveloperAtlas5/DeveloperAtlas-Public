module.exports = function runAntiPatternReduceWhereMapFilterClearer() {
  const users = [
    { id: 1, name: "Ari", active: true },
    { id: 2, name: "Bea", active: false },
    { id: 3, name: "Cal", active: true }
  ];

  const reducedNames = users.reduce((names, user) => {
    if (user.active) names.push(user.name);
    return names;
  }, []);

  const clearerNames = users
    .filter((user) => user.active)
    .map((user) => user.name);

  if (JSON.stringify(reducedNames) !== JSON.stringify(clearerNames)) {
    throw new Error("Expected reduce anti-pattern result to match filter().map()");
  }

  if (clearerNames.join(",") !== "Ari,Cal") {
    throw new Error(`Expected active names Ari,Cal, got ${clearerNames.join(",")}`);
  }
};
