# Make Your Vue Todo List Remember Tasks

A calm daily mission from Developer Atlas.

- Estimated duration: 6 hours 35 minutes
- Difficulty: guided
- Confidence score: 85.72/100

## Why This Mission Matters

Persistence is the moment a small app starts feeling real. This mission keeps the scope tiny: no backend, no auth, no routing, just one useful improvement that makes your Vue todo list survive a refresh.

## Today's Objective

Your todo list currently resets after refresh. Today you will make it remember non-sensitive tasks using the right browser storage choice.

## What Atlas Already Checked

- You already have the right first project: a small Vue todo app.
- This mission adds one persistence feature without expanding into backend, auth, routing, or state management.
- The setup and recovery steps are ready in case the local app or stored data behaves unexpectedly.
- A focused AI context pack is available if you want help without explaining everything from scratch.

## What To Do First

Run the first setup verification: git --version works.

## Today's Learning Focus

- Vue reactivity: choosing simple state
- Vue conditional display
- Stable keys for list rows
- Browser storage: localStorage vs sessionStorage

## Browser Storage Choice

- localStorage survives browser restarts for the same site until the user, browser, or app clears it.
- sessionStorage survives refresh, but it is tied to the current tab/session and should disappear when that session ends.
- Neither localStorage nor sessionStorage is a safe place for sensitive data like passwords, access tokens, or private personal information.
- Vue state and browser storage are separate concerns: Vue state drives the screen now; browser storage remembers small values for later.
- Use JSON.stringify() before saving a todo array and JSON.parse() with a safe fallback when loading it.

## Recommended Next Learning

- Browser storage: localStorage vs sessionStorage - Recommended now: make non-sensitive todos survive refresh.
- Component communication: props, emits, and model - Optional later: useful when splitting the app into reusable components.

After the basic todo app works, persistence is the recommended next step: localStorage can remember non-sensitive todos across browser restarts, sessionStorage only lasts for the current tab session, and Vue state is separate from browser storage. Component communication comes after that when the app grows into reusable parts.

## Today's Project

- Add persistence to the Vue todo app.
- Save the todo array after changes.
- Load saved todos when the app starts.
- Refresh the page to prove the list is remembered.

## Today's Setup Check

Run: git --version works

## Likely Blocker

- npm install fails

## Today's Recovery Plan

If storage behaves unexpectedly, start with the simplest checks before changing the app design.

- If the list resets after refresh, confirm you save after every add, delete, complete, and filter-relevant todo change.
- If saved todos load as broken text or [object Object], check that you used JSON.stringify() when saving and JSON.parse() when loading.
- If JSON.parse() throws, clear the old todos value and reload with an empty-array fallback.
- If data disappears after closing the tab, confirm you used localStorage instead of sessionStorage.
- If you accidentally stored sensitive data, remove it immediately and do not use browser storage for secrets.

Setup recovery is also prepared if the local dev server blocks you:

- If blocked by npm install fails, start with: Use the project-supported Node version
- Verify: npm install or npm ci exits with code 0
- Verify: npm run validate or project test command starts successfully

## Today's AI Context

Use the focused AI context pack if you want help adding browser storage without expanding the project scope: `output/ai-context/rookie-vue-next-step.md`

## Ignore Today

- Avoid Build Full-Stack Inventory System until blockers are reduced.
- Skip product-specific buying decisions until the workload is measured.
- Skip advanced architecture until the missing foundations are practiced.
- Skip Docker until the first local app runs without it.

## Visible Win

You can refresh the page and your non-sensitive todo tasks are still there.

## Next Mission Preview

- Prepare for Build Laravel CRUD API
- Why: After persistence works, the next mission can split the todo app into small reusable components without crowding today.

## Confidence First

You are not trying to build a full product today. You are making one small app remember one small piece of state.
