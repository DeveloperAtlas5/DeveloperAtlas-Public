# Canon Candidate Backlog Report

## Summary

20 Canon candidate nodes were added for future Rookie-to-Junior frontend growth.

These nodes are candidate backlog items only. They are not Gold Candidate, not reviewer-approved, and not integrated into the current public alpha mission.

## Why This Exists

The current public alpha stays focused on the Rookie Vue Todo mission. This backlog prepares future coverage for JavaScript, Vue, browser fundamentals, setup confidence, and AI-assisted building without expanding the learner-facing scope today.

## Candidate Groups

- JavaScript fundamentals: 5 candidates.
- Vue Rookie path: 7 candidates.
- Browser/frontend fundamentals: 3 candidates.
- Tooling/setup: 3 candidates.
- AI-assisted building: 2 candidates.

## Candidate Rule

- Status remains `candidate`.
- Score remains 55.
- No reviewer sign-off is claimed.
- No public alpha mission output should reference these backlog candidates.

## When To Harden

Harden these candidates only when real tester feedback justifies them. The likely trigger is repeated confusion in the current Rookie-to-Junior frontend path.

## Product Owner Check

- Knowledge backlog grew.
- User-facing scope stayed focused.
- Optional help remains grouped under `help/`.
- Mission files remain under `mission/`.
- Reviewer files remain under `reviewer/`.
