# Developer Atlas Starter

A structured knowledge base for a complete developer handbook.

## Goal

Write each topic once as Markdown with YAML front matter, then generate:

- Pocket guides
- Developer handbook
- Website
- Search index
- Flashcards
- Quizzes
- VS Code extension data

## Folder structure

- `content/` — all handbook entries
- `schemas/` — JSON schema for entries
- `templates/` — reusable content templates
- `tools/` — generators and validators
- `output/` — generated files

## Entry ID format

Use lowercase dotted IDs:

```txt
technology.category.name
```

Examples:

```txt
javascript.array.map
vue.reactivity.ref
css.property.display
sql.command.select
laravel.routing.route_get
```

## Next step

Add 50 core entries:

- HTML: 10
- CSS: 10
- JavaScript: 10
- Vue: 5
- PHP: 5
- SQL: 5
- Laravel: 5
