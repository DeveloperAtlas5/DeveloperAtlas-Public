const fs = require("fs");
const path = require("path");
const { readEntries, rootDir } = require("./content-utils");

const brainDir = path.join(rootDir, "brain");
const graphPath = path.join(rootDir, "output", "graph", "knowledge-graph.json");

function findJsonFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) return findJsonFiles(fullPath);
    return entry.isFile() && entry.name.endsWith(".json") ? [fullPath] : [];
  });
}

function main() {
  const files = findJsonFiles(brainDir);
  const errors = [];
  const parsedFiles = [];

  for (const file of files) {
    try {
      parsedFiles.push({ file, data: JSON.parse(fs.readFileSync(file, "utf8")) });
    } catch (error) {
      errors.push(`${path.relative(rootDir, file)}: invalid JSON (${error.message})`);
    }
  }

  const nodeIds = loadNodeIds();
  for (const parsed of parsedFiles) {
    const missing = findMissingSupportingNodes(parsed.data, nodeIds);
    for (const nodeId of missing) {
      errors.push(`${path.relative(rootDir, parsed.file)}: supporting node does not exist: ${nodeId}`);
    }
  }

  console.log("Atlas Brain validation");
  console.log(`Brain JSON files: ${files.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);

  if (errors.length > 0) process.exitCode = 1;
}

function loadNodeIds() {
  if (fs.existsSync(graphPath)) {
    const graph = JSON.parse(fs.readFileSync(graphPath, "utf8"));
    return new Set(graph.nodes.map((node) => node.id));
  }
  return new Set(readEntries().map((entry) => entry.frontMatter.id));
}

function findMissingSupportingNodes(value, nodeIds) {
  const missing = new Set();
  walk(value, (key, item) => {
    if (!["supporting_nodes", "next_learning_nodes", "related_nodes"].includes(key)) return;
    if (!Array.isArray(item)) return;
    for (const nodeId of item) {
      if (typeof nodeId === "string" && nodeId.includes(".") && !nodeIds.has(nodeId)) missing.add(nodeId);
    }
  });
  return [...missing];
}

function walk(value, visitor, key = "") {
  visitor(key, value);
  if (Array.isArray(value)) {
    for (const item of value) walk(item, visitor, key);
    return;
  }
  if (value && typeof value === "object") {
    for (const [childKey, childValue] of Object.entries(value)) walk(childValue, visitor, childKey);
  }
}

main();
