# CANON-012 Proof Of Superiority

## What Official Docs Explain Well

MDN and the ECMAScript specification explain that `Object.keys()`, `Object.values()`, and `Object.entries()` return arrays derived from an object's own enumerable string-keyed properties.

## What Developers Still Struggle With

Developers still struggle with result shape: choosing `keys()` and then repeatedly reading `object[key]`, choosing `values()` and later needing the key, or expecting inherited, non-enumerable, or symbol properties to appear.

## How Atlas Improves The Explanation

Atlas frames the decision as "names, values, or pairs." That gives beginners a simple model and gives professionals a review signal for noisy object-iteration code.

## What Decision Support Atlas Adds

The Canon node gives a decision guide, comparison table, when-to-use sections, alternatives, debugging checklist, and practical routing to `Object.fromEntries()`, `Object.hasOwn()`, `Reflect.ownKeys()`, and `Map`.

## What Production Guidance Atlas Adds

The node includes dynamic form fields, statistics, label/value rendering, object-shape transformation, inherited-property debugging, property order cautions, and allocation notes.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants explicit generation rules: use `keys()` only for property names, `values()` only when keys are irrelevant, `entries()` when key and value are both used, and warn about inherited, symbol, and non-enumerable properties when relevant.

## Why This Deserves Gold Status

This node deserves Gold-candidate status because it turns three related object helpers into a clear decision model with official evidence, production examples, runnable verification, teaching guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.

