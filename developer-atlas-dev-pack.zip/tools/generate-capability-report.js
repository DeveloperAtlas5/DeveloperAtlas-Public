const fs = require("fs");
const path = require("path");
const {
  capabilityOutputDir,
  ensureCapabilityOutputDir,
  readCapabilities,
  countValues,
  unique
} = require("./capability-utils");

function main() {
  const capabilities = readCapabilities().map((record) => record.capability);
  const projectFit = readProjectFit();
  const report = buildReport(capabilities, projectFit);

  ensureCapabilityOutputDir();
  fs.writeFileSync(
    path.join(capabilityOutputDir, "capability-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(capabilityOutputDir, "capability-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/capability/capability-report.json with ${capabilities.length} capability item(s).`);
  console.log("Generated output/capability/capability-report.md.");
}

function readProjectFit() {
  const file = path.join(capabilityOutputDir, "project-fit-report.json");
  return fs.existsSync(file)
    ? JSON.parse(fs.readFileSync(file, "utf8"))
    : { project_fits: [], ready_today: [], mostly_ready: [], defer: [] };
}

function buildReport(capabilities, projectFit) {
  const bestSmall = bestSmallProject(projectFit.project_fits);
  return {
    total_capabilities: capabilities.length,
    capabilities_by_category: countValues(capabilities.map((capability) => capability.category)),
    capabilities_ready_today: projectFit.ready_today,
    capabilities_mostly_ready: projectFit.mostly_ready,
    capabilities_to_defer: projectFit.defer,
    best_small_project_this_week: bestSmall,
    blockers_by_capability: projectFit.project_fits.map((fit) => ({
      capability_id: fit.capability_id,
      blockers: fit.blockers
    })),
    missing_knowledge: unique(projectFit.project_fits.flatMap((fit) => fit.missing_knowledge)).slice(0, 20),
    missing_tools: unique(projectFit.project_fits.flatMap((fit) => fit.missing_tools)),
    hardware_concerns: unique(projectFit.project_fits.flatMap((fit) => fit.hardware_concerns)),
    ai_ready_project_prompts: projectFit.project_fits.map((fit) => ({
      capability_id: fit.capability_id,
      prompt: fit.ai_ready_project_prompt
    }))
  };
}

function bestSmallProject(fits) {
  const candidates = fits
    .filter((fit) => fit.estimated_hours <= 8 && fit.fit_level !== "defer")
    .sort((a, b) => b.fit_score - a.fit_score || a.estimated_hours - b.estimated_hours);
  return candidates[0] || fits.sort((a, b) => b.fit_score - a.fit_score || a.estimated_hours - b.estimated_hours)[0] || null;
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Capability Report",
    "",
    `Total capabilities: ${report.total_capabilities}`,
    `Ready today: ${report.capabilities_ready_today.length}`,
    `Mostly ready: ${report.capabilities_mostly_ready.length}`,
    `Deferred: ${report.capabilities_to_defer.length}`,
    "",
    "## Capabilities by Category",
    "",
    ...report.capabilities_by_category.map((item) => `- ${item.value}: ${item.count}`),
    "",
    "## Best Small Project This Week",
    "",
    report.best_small_project_this_week
      ? `- ${report.best_small_project_this_week.title} (${report.best_small_project_this_week.fit_level}, ${report.best_small_project_this_week.estimated_hours} hours)`
      : "- None",
    "",
    "## Ready Today",
    "",
    ...formatFits(report.capabilities_ready_today),
    "",
    "## Mostly Ready",
    "",
    ...formatFits(report.capabilities_mostly_ready),
    "",
    "## Defer For Now",
    "",
    ...formatFits(report.capabilities_to_defer),
    "",
    "## Missing Knowledge",
    "",
    ...formatList(report.missing_knowledge),
    "",
    "## Missing Tools",
    "",
    ...formatList(report.missing_tools),
    "",
    "## Hardware Concerns",
    "",
    ...formatList(report.hardware_concerns),
    "",
    "## AI-Ready Project Prompts",
    "",
    ...report.ai_ready_project_prompts.flatMap((item) => [
      `### ${item.capability_id}`,
      "",
      item.prompt,
      ""
    ])
  ];

  return `${lines.join("\n")}\n`;
}

function formatFits(fits) {
  return fits.length
    ? fits.map((fit) => `- ${fit.title}: ${fit.fit_score}/100 via ${fit.best_readiness_match}`)
    : ["- None"];
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
