# Flexbox vs Grid

## Status Metadata

- Canon ID: CANON-004
- Node ID: canon.css.layout.flexbox-vs-grid
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: CSS layout
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use Flexbox when the layout problem is mainly one-dimensional: arranging items in a row or a column and distributing space along one axis. Use Grid when the layout problem is two-dimensional: controlling rows and columns together.

The everyday rule:

- Flexbox aligns and distributes items along one main axis.
- Grid defines tracks and places items across rows and columns.
- Real interfaces often use both: Grid for the page or section, Flexbox inside components.

## What Problem This Solves

Developers often choose the layout tool they remember first instead of the tool that matches the layout shape. That creates brittle CSS:

- Flexbox is forced to act like a two-dimensional grid.
- Grid is used for a simple inline button group.
- Extra wrappers appear because the layout model is fighting the design.
- AI-generated CSS picks `display: flex` for every layout because it is common.

This node solves the decision by teaching layout shape before properties.

## Mental Model

Start with axes.

Flexbox asks: "How should items flow and align along one main axis?"

```text
Main axis:      item item item
Cross axis:     alignment
```

Grid asks: "What rows and columns does this layout need?"

```text
row 1:  card card card
row 2:  card card card
```

The key question is not "Which one is newer?" or "Which one is more powerful?" The key question is "Do I need one axis or two?"

| Desired layout shape | Better default |
| --- | --- |
| Navbar, toolbar, button group | Flexbox |
| Center one item | Flexbox |
| Distribute items in one row or column | Flexbox |
| Card gallery with rows and columns | Grid |
| Page shell with header, sidebar, main, footer | Grid |
| Dashboard with aligned rows and columns | Grid |
| Grid outside, aligned controls inside | Grid + Flexbox |

## Beginner Explanation

Use Flexbox when items are standing in a line.

```css
.nav {
  display: flex;
  align-items: center;
  gap: 1rem;
}
```

Use Grid when items need seats in rows and columns.

```css
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
  gap: 1rem;
}
```

Beginner rule:

1. One row or one column? Try Flexbox.
2. Rows and columns together? Try Grid.
3. Whole page or major section layout? Usually Grid.
4. Aligning content inside one component? Usually Flexbox.

## Professional Explanation

Flexbox is a one-dimensional formatting model. Its strength is distributing available space, aligning items, handling intrinsic content sizes, and adapting along a main axis. It is excellent for component internals where content size matters.

Grid is a two-dimensional layout model. Its strength is defining explicit or responsive tracks, aligning items across both axes, and expressing layout structure without source-order hacks or wrapper-heavy markup.

In production CSS, the choice affects maintainability:

- Flexbox communicates alignment and flow.
- Grid communicates structure and placement.
- Wrong choices create fragile breakpoints and unnecessary wrappers.
- Combining them is normal: Grid for macro layout, Flexbox for micro layout.

Do not treat Grid as "better Flexbox." They answer different layout questions.

## Syntax

Flexbox:

```css
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
```

Grid:

```css
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
  gap: 1rem;
}
```

Combined:

```css
.page {
  display: grid;
  grid-template-columns: 16rem 1fr;
}

.actions {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
```

## Decision Guide

Ask these questions in order:

1. Is the layout mainly a row or a column?
   Use Flexbox.
2. Do items need to align across both rows and columns?
   Use Grid.
3. Is this a page, dashboard, gallery, or card layout?
   Use Grid.
4. Is this a nav, toolbar, form row, or button group?
   Use Flexbox.
5. Are you adding wrappers just to force alignment?
   Reconsider the layout model.
6. Do you need both section structure and internal alignment?
   Use Grid outside and Flexbox inside.

## Comparison Table

| Feature | Flexbox | Grid |
| --- | --- | --- |
| Layout dimension | One-dimensional | Two-dimensional |
| Best mental model | Flow along an axis | Rows and columns |
| Best for | Navbars, toolbars, centering, inline controls | Galleries, dashboards, page shells, complex sections |
| Content sizing | Very good | Good, but track-driven |
| Explicit placement | Limited | Strong |
| Responsive card layouts | Possible, often awkward | Natural |
| Simple alignment | Excellent | Often overkill |
| Common mistake | Forcing rows and columns | Overbuilding simple alignment |

## When To Use The Primary Option

Use Flexbox when:

- Items need to sit in one row or one column.
- You need alignment along a main axis and cross axis.
- Content sizes should influence distribution.
- You are building navbars, toolbars, button groups, badges, form rows, or media objects.
- You need simple centering.

```css
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
```

## When To Use The Alternative

Use Grid when:

- The layout needs rows and columns together.
- Items should line up across both axes.
- You are building a card grid, dashboard, page shell, product listing, or image gallery.
- You want responsive tracks such as `repeat(auto-fit, minmax(...))`.
- Placement matters more than natural flow.

```css
.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(14rem, 1fr));
  gap: 1rem;
}
```

## When Not To Use This Decision

Do not reach for Flexbox or Grid automatically.

Avoid both when:

- Normal document flow already solves the layout.
- Text layout is the real problem.
- A simple block stack with margins is clearer.
- You are using layout CSS to compensate for poor HTML structure.
- You need masonry behavior; Grid may help only depending on current browser support and the exact requirement.
- You are changing visual order in a way that harms keyboard or screen-reader flow.

## Alternatives

- Normal block flow for article and form structure.
- Inline layout for text-level content.
- Multi-column layout for flowing text columns.
- Container queries for adapting components to available space.
- Positioning for overlays, popovers, and anchored UI.

## Production Examples

### Navbar With Flexbox

```css
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

.navbar__links {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}
```

Why Flexbox fits: the navbar is primarily a horizontal alignment problem.

### Card Grid With CSS Grid

```css
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
  gap: 1rem;
}
```

Why Grid fits: cards need responsive rows and columns.

### App Shell With Grid And Flexbox

```css
.app-shell {
  display: grid;
  grid-template-columns: 16rem 1fr;
  min-height: 100vh;
}

.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
```

Why both fit: Grid defines the major page regions, while Flexbox aligns controls inside the topbar.

## Common Mistakes

- Using Flexbox for a true two-dimensional card layout.
- Using Grid for a simple inline alignment problem.
- Adding wrappers because the chosen layout model is fighting the design.
- Using `order` or grid placement to create a visual order that differs from meaningful source order.
- Forgetting `gap` and compensating with uneven margins.
- Expecting Flexbox rows to align columns across wrapped lines.
- Using fixed column widths where responsive tracks would be better.

## Debugging Checklist

- Is the layout one-dimensional or two-dimensional?
- Which axis is the main axis?
- Do wrapped Flexbox rows need column alignment? If yes, should this be Grid?
- Are you preserving meaningful source order?
- Are gaps controlled by `gap` instead of scattered margins?
- Are Grid tracks too rigid for the container?
- Are you using Flexbox inside a Grid item when internal alignment is the real problem?
- Would normal block flow be simpler?

## Mechanical Verification

Runnable deterministic examples live in `canon/examples/CANON-004/`.

Verification command:

```sh
npm run canon:verify:004
```

The verification suite checks:

- Navbar with Flexbox.
- Card grid with CSS Grid.
- Mistake: using Flexbox for a true two-dimensional layout.
- Mistake: using Grid for simple inline alignment.

## Performance Notes

Layout clarity usually matters more than theoretical performance. Most Flexbox/Grid performance problems come from excessive DOM size, deeply nested layout, layout thrashing from JavaScript, or overly complex responsive rules.

Practical guidance:

- Use the model that expresses the layout directly.
- Avoid unnecessary wrappers.
- Keep responsive rules predictable.
- Test complex layouts at realistic content lengths.

## AI Coding Guidance

When generating CSS:

- Use Flexbox for navbars, toolbars, button rows, centering, and one-axis alignment.
- Use Grid for card layouts, galleries, dashboards, page shells, and two-axis placement.
- Do not use Flexbox when wrapped rows must align as columns.
- Do not use Grid for a simple inline icon-and-label alignment.
- Prefer `gap` over ad hoc child margins.
- Preserve source order unless there is a strong accessibility reason.
- Combine Grid outside with Flexbox inside when both layout scales are present.
- Explain the choice using "one-dimensional" or "two-dimensional" layout.

Bad AI output:

```css
.cards {
  display: flex;
  flex-wrap: wrap;
}
```

when the requirement is a true aligned card grid.

Good AI output:

```css
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
  gap: 1rem;
}
```

## Teaching Notes

Teach layout shape before property names.

Recommended teaching order:

1. Draw one row: teach Flexbox.
2. Draw rows and columns: teach Grid.
3. Show a navbar.
4. Show a card grid.
5. Combine Grid page layout with Flexbox component alignment.
6. Discuss source order and accessibility.

Useful teaching phrase:

> Flexbox arranges a line; Grid designs a map.

## Interview Questions

1. What does one-dimensional layout mean?
2. What does two-dimensional layout mean?
3. Why is Grid better for aligned card rows and columns?
4. Why is Flexbox better for a toolbar?
5. When would you combine Grid and Flexbox?
6. Why can visual reordering be an accessibility risk?

## Exercises

### Beginner

Build a navbar with a brand on the left and links on the right using Flexbox.

### Intermediate

Build a responsive card grid with `repeat(auto-fit, minmax(...))`.

### Advanced

Build an app shell with Grid, then align topbar actions inside it with Flexbox.

## Related Atlas Nodes

- `css.property.flex`
- `css.property.grid-template-columns`
- `css.property.justify-content`
- `css.property.align-items`
- `css.property.gap`
- `css.property.width`
- `css.property.height`

## Evidence And Sources

- MDN: Basic concepts of flexbox: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Flexible_box_layout/Basic_concepts
- MDN: CSS grid layout: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Grid_layout
- W3C: CSS Flexible Box Layout Module Level 1: https://www.w3.org/TR/css-flexbox-1/
- W3C: CSS Grid Layout Module Level 1: https://www.w3.org/TR/css-grid-1/
- CSS-Tricks: A Complete Guide to Flexbox, informative reference: https://css-tricks.com/snippets/css/a-guide-to-flexbox/

## Proof Of Superiority Summary

Official CSS references explain Flexbox and Grid features. This Canon node explains how to choose between them based on layout shape, how to avoid common layout misuse, how to combine them in production interfaces, how AI should generate layout CSS, and how to debug layouts that are fighting the wrong model.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
