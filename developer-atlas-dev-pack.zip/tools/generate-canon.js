const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const indexPath = path.join(rootDir, "canon", "canon-index.json");
const outputDir = path.join(rootDir, "output", "canon");
const nodesOutputDir = path.join(outputDir, "nodes");
const releasesDir = path.join(rootDir, "canon", "releases");

function main() {
  const index = JSON.parse(fs.readFileSync(indexPath, "utf8"));
  const entries = index.entries || [];
  const statusCounts = {};
  const missingProofs = [];
  const missingScorecards = [];
  const goldNodes = [];
  const candidateNodes = [];
  const publishedSections = [];
  const releaseBatches = [];

  fs.mkdirSync(nodesOutputDir, { recursive: true });
  fs.mkdirSync(outputDir, { recursive: true });

  for (const entry of entries) {
    statusCounts[entry.status] = (statusCounts[entry.status] || 0) + 1;

    // Final Gold is intentionally separate from Gold Candidate release readiness.
    if (entry.status === "gold" || entry.status === "gold_approved" || entry.status === "canon_published") goldNodes.push(entry);
    if (entry.status === "candidate") candidateNodes.push(entry);

    const proofPath = path.join(rootDir, entry.proof_of_superiority_path || "");
    if (!entry.proof_of_superiority_path || !fs.existsSync(proofPath)) missingProofs.push(entry.canon_id);

    const scorecardPath = path.join(rootDir, "canon", "scorecards", `${entry.canon_id}-scorecard.json`);
    if (!fs.existsSync(scorecardPath)) missingScorecards.push(entry.canon_id);

    const sourcePath = path.join(rootDir, entry.source_node_path);
    const markdown = fs.readFileSync(sourcePath, "utf8");
    const nodeOutputPath = path.join(rootDir, entry.output_path);
    fs.mkdirSync(path.dirname(nodeOutputPath), { recursive: true });
    fs.writeFileSync(nodeOutputPath, markdown.endsWith("\n") ? markdown : `${markdown}\n`);
    publishedSections.push(toCanonSection(entry, markdown));
  }

  for (const release of readReleaseBatches()) {
    const releaseOutputPath = path.join(outputDir, release.outputName);
    fs.writeFileSync(releaseOutputPath, release.markdown.endsWith("\n") ? release.markdown : `${release.markdown}\n`);
    releaseBatches.push({
      id: release.id,
      sourcePath: release.sourcePath,
      outputPath: path.relative(rootDir, releaseOutputPath).replace(/\\/g, "/")
    });
  }

  fs.writeFileSync(path.join(outputDir, "atlas-canon.md"), toAtlasCanon(index, publishedSections));
  fs.writeFileSync(path.join(outputDir, "canon-report.md"), toReport({
    entries,
    statusCounts,
    missingProofs,
    missingScorecards,
    goldNodes,
    candidateNodes,
    releaseBatches
  }));

  console.log(`Generated output/canon/atlas-canon.md with ${entries.length} Canon entr${entries.length === 1 ? "y" : "ies"}.`);
  for (const release of releaseBatches) {
    console.log(`Generated ${release.outputPath}.`);
  }
  console.log("Generated output/canon/canon-report.md.");
}

function toCanonSection(entry, markdown) {
  return [
    `<!-- ${entry.canon_id}: ${entry.node_id} -->`,
    markdown.trim(),
    ""
  ].join("\n");
}

function toAtlasCanon(index, sections) {
  return `${[
    "# Atlas Canon",
    "",
    `Version: ${index.version}`,
    "",
    "The Atlas Canon is the curated publication layer for Developer Atlas Gold Standard knowledge nodes.",
    "",
    ...sections
  ].join("\n")}\n`;
}

function toReport(data) {
  const averageScore = data.entries.length
    ? (data.entries.reduce((sum, entry) => sum + Number(entry.score || 0), 0) / data.entries.length).toFixed(1)
    : "0.0";
  const lines = [
    "# Atlas Canon Report",
    "",
    `Total Canon entries: ${data.entries.length}`,
    `Average score: ${averageScore}`,
    "",
    "## Status Counts",
    ""
  ];

  for (const [status, count] of Object.entries(data.statusCounts).sort()) {
    lines.push(`- ${status}: ${count}`);
  }

  lines.push("", "## Gold Nodes", "");
  if (data.goldNodes.length) {
    for (const entry of data.goldNodes) lines.push(`- ${entry.canon_id}: ${entry.title} (${entry.score})`);
  } else {
    lines.push("- None");
  }

  lines.push("", "## Candidate Nodes", "");
  if (data.candidateNodes.length) {
    for (const entry of data.candidateNodes) lines.push(`- ${entry.canon_id}: ${entry.title}`);
  } else {
    lines.push("- None");
  }

  lines.push("", "## Missing Proof Of Superiority Files", "");
  if (data.missingProofs.length) {
    for (const canonId of data.missingProofs) lines.push(`- ${canonId}`);
  } else {
    lines.push("- None");
  }

  lines.push("", "## Missing Scorecards", "");
  if (data.missingScorecards.length) {
    for (const canonId of data.missingScorecards) lines.push(`- ${canonId}`);
  } else {
    lines.push("- None");
  }

  lines.push("", "## Release Batches", "");
  if (data.releaseBatches.length) {
    for (const release of data.releaseBatches) {
      lines.push(`- ${release.id}: ${release.outputPath}`);
    }
  } else {
    lines.push("- None");
  }

  return `${lines.join("\n")}\n`;
}

function readReleaseBatches() {
  if (!fs.existsSync(releasesDir)) return [];

  return fs.readdirSync(releasesDir)
    .filter((fileName) => fileName.endsWith(".md"))
    .sort()
    .map((fileName) => {
      const id = path.basename(fileName, ".md");
      const sourcePath = path.join(releasesDir, fileName);
      const batchMatch = id.match(/^(\d{4}\.\d)-batch-(\d{2})$/);
      const outputName = batchMatch
        ? `canon-batch-${batchMatch[2]}-release.md`
        : `${id}-release.md`;

      return {
        id,
        sourcePath: path.relative(rootDir, sourcePath).replace(/\\/g, "/"),
        outputName,
        markdown: fs.readFileSync(sourcePath, "utf8")
      };
    });
}

main();
