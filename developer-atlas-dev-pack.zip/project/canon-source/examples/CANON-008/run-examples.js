const examples = [
  ["Promise.all() succeeds when all promises resolve", require("./promise-all-success")],
  ["Promise.all() rejects when one promise fails", require("./promise-all-rejects")],
  ["Promise.allSettled() returns mixed success/failure results", require("./promise-allsettled-mixed-results")],
  ["anti-pattern: Promise.all() when partial success is acceptable", require("./anti-pattern-all-when-partial-success-ok")]
];

(async () => {
  for (const [name, run] of examples) {
    await run();
    console.log(`PASS ${name}`);
  }

  console.log(`Verified ${examples.length} CANON-008 example(s).`);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
