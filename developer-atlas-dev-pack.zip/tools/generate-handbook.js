const fs = require("fs");
const path = require("path");
const { readEntries, compareEntries, rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "handbook");
const outputPath = path.join(outputDir, "developer-handbook.md");

function main() {
  const entries = readEntries().sort(compareEntries);
  const lines = [
    "# Developer Atlas Handbook",
    "",
    "A structured beginner-friendly handbook generated from Markdown entries.",
    ""
  ];

  let currentTechnology = "";
  let currentCategory = "";

  for (const entry of entries) {
    const data = entry.frontMatter;

    if (data.technology !== currentTechnology) {
      currentTechnology = data.technology;
      currentCategory = "";
      lines.push(`## ${currentTechnology}`, "");
    }

    if (data.category !== currentCategory) {
      currentCategory = data.category;
      lines.push(`### ${currentCategory}`, "");
    }

    lines.push(`#### ${data.title}`);
    lines.push("");
    addField(lines, "Summary", data.summary);
    lines.push(`- Difficulty: ${data.difficulty}`);
    lines.push(`- Importance: ${data.importance || "n/a"}`);
    lines.push(`- Frequency: ${data.frequency || "n/a"}`);
    lines.push(`- Confidence: ${data.confidence || "n/a"}`);
    lines.push(`- Evidence level: ${data.evidence_level || "n/a"}`);
    lines.push("");
    addField(lines, "Problem", data.problem);
    addField(lines, "Solution", data.solution);
    addCode(lines, "Syntax", data.syntax);
    addList(lines, "When to use", data.when_to_use);
    addList(lines, "When not to use", data.when_not_to_use);
    addList(lines, "Examples", data.examples);
    addList(lines, "Common mistakes", data.common_mistakes);
    addList(lines, "Best practices", data.best_practices);
    addList(lines, "Related topics", data.related);
    lines.push(`Source: \`${entry.relativePath}\``);
    lines.push("");
  }

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${lines.join("\n")}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)} with ${entries.length} entries.`);
}

function addField(lines, label, value) {
  if (!hasValue(value)) return;
  lines.push(`**${label}:** ${value}`);
  lines.push("");
}

function addCode(lines, label, value) {
  if (!hasValue(value)) return;
  lines.push(`**${label}:** \`${value}\``);
  lines.push("");
}

function addList(lines, label, value) {
  if (!hasValue(value)) return;
  lines.push(`**${label}:**`);
  const items = Array.isArray(value) ? value : [value];
  for (const item of items) lines.push(`- ${item}`);
  lines.push("");
}

function hasValue(value) {
  return value !== undefined && value !== "" && (!Array.isArray(value) || value.length > 0);
}

main();
