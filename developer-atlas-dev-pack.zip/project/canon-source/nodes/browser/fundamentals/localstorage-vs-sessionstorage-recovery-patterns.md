# localStorage vs sessionStorage recovery patterns

## Status Metadata

- Canon ID: CANON-CANDIDATE-BROWSER-001
- Node ID: canon.browser.storage.localstorage-sessionstorage-recovery-patterns
- Status: candidate
- Score: 55
- Version: 2026.1
- Source family: Browser
- Level: rookie/junior
- Audience: future Rookie-to-Junior frontend path
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

localStorage can restore simple data after browser restarts. sessionStorage can restore data during the current tab session. This candidate supports future Rookie-to-Junior frontend coverage and is not part of the current public alpha mission.

## What Problem This Solves

This reduces beginner confusion around localStorage vs sessionStorage recovery patterns by turning the topic into a small decision with practical recovery guidance.

## Mental Model

localStorage can restore simple data after browser restarts. sessionStorage can restore data during the current tab session.

## Beginner Explanation

localStorage can restore simple data after browser restarts. sessionStorage can restore data during the current tab session. The goal is not to memorize a rule; the goal is to choose the option that matches what the code is trying to do.

## Professional Explanation

Use this decision to make intent visible in reviews, keep generated code scoped, and reduce hidden maintenance costs. The production signal is code that another developer can explain without reverse-engineering the author's guess.

## Syntax

```text
localStorage.getItem("todos");
sessionStorage.getItem("draft");
```

## Decision Guide

1. Name the task in plain language.
2. Choose localStorage recovery when: Use localStorage for non-sensitive preferences or todo drafts that should survive restart.
3. Choose sessionStorage recovery when it communicates the intent better.
4. If neither fits, pause and look for a prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| localStorage recovery | Use localStorage for non-sensitive preferences or todo drafts that should survive restart. | Can confuse beginners when used by habit. |
| sessionStorage recovery | A clearer fit when the primary option does not match the task | Can add noise if the project does not need it. |

## When To Use The Primary Option

- Use localStorage for non-sensitive preferences or todo drafts that should survive restart.
- Use it when it makes the code easier to explain.
- Use it when it matches the surrounding project convention.

## When To Use The Alternative

- Use it when localStorage recovery would hide the real intent.
- Use it when the alternative gives the learner or reviewer a clearer signal.
- Use it when existing project code already follows that pattern.

## When Not To Use This Decision

- Do not store secrets, tokens, passwords, or private data in browser storage.
- Do not expand the current Rookie Vue alpha mission just to use this candidate.
- Do not treat this candidate as fully reviewed evidence.

## Alternatives

- Use an existing Gold Candidate node when this topic overlaps one.
- Use a smaller prerequisite concept when the learner is blocked earlier.

## Production Examples

### Beginner Example

```text
const saved = localStorage.getItem("todos");
```

### Review Example

```text
Before accepting the code, explain why localStorage recovery or sessionStorage recovery matches the task.
```

## Common Mistakes

- Assuming Vue state and browser storage are the same thing.
- Copying generated code without checking whether it matches the task.
- Treating the candidate as final before examples and sources are hardened.

## Debugging Checklist

- If data disappears after closing a tab, check whether sessionStorage was used.
- Compare the current behavior with the intended choice.
- Ask whether a smaller prerequisite concept would unblock the learner faster.

## Mechanical Verification

Runnable or deterministic examples should be added during a future hardening sprint. This candidate intentionally has no runnable example folder yet.

## Performance Notes

No performance claim is finalized for this candidate. Future hardening should separate real runtime concerns from readability and learning concerns.

## AI Coding Guidance

- Ask AI to include safe parsing and sensitive-data warnings when adding storage.
- Ask for a small, scoped change.
- Ask the assistant to explain the trade-off before producing code.

## Teaching Notes

Start with the plain-language model, show the beginner example, then ask the learner to explain the choice back in one sentence. Keep this candidate optional until a mission needs it.

## Interview Questions

1. When would you choose localStorage recovery?
2. What mistake would make sessionStorage recovery or another concept clearer?

## Exercises

### Beginner

Save a non-sensitive todo list to localStorage and reload it safely.

### Junior

Find one example in a small project and explain whether it uses the clearer option.

## Related Atlas Nodes

- CANON-022
- CANON-CANDIDATE-BROWSER-002

## Evidence And Sources

- Candidate backlog entry only. Official source links must be added during hardening.
- Evidence level: candidate draft.
- Confidence: medium.

## Proof Of Superiority Summary

This candidate has a draft improvement hypothesis only. It should not be treated as reviewed or publication-ready.

## Scorecard Placeholder

- Current score: 55
- Status: candidate
- Needs official sources, stronger examples, verification, editorial review, and reviewer sign-off before any Gold consideration.
