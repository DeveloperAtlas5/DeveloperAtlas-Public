const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readCapabilities } = require("./capability-utils");

const flowExamplesDir = path.join(rootDir, "flow", "examples");
const outputDir = path.join(rootDir, "output", "flow");

const readinessByProfile = {
  "profile.rookie_webdev": "readiness.rookie_vue_app",
  "profile.career_switcher_fullstack": "readiness.career_switcher_fullstack",
  "profile.jefry_fullstack_ai_game_dev": "readiness.jefry_ai_game_fullstack"
};

const aiContextByProfile = {
  "profile.rookie_webdev": "rookie-vue-next-step",
  "profile.career_switcher_fullstack": "laravel-api-debugging",
  "profile.jefry_fullstack_ai_game_dev": "jefry-fullstack-ai-game-dev"
};

const setupByProfile = {
  "profile.rookie_webdev": "beginner-vue-windows",
  "profile.career_switcher_fullstack": "fullstack-vue-laravel-windows",
  "profile.jefry_fullstack_ai_game_dev": "fullstack-vue-laravel-windows"
};

const recoveryByFriction = {
  "friction.javascript.npm.install_fails": "npm-install-fails",
  "friction.javascript.vite.not_starting": "vite-not-starting-windows",
  "friction.php.composer.not_recognized": "composer-not-recognized-windows",
  "friction.laravel.artisan_missing": "laravel-artisan-missing"
};

function main() {
  fs.mkdirSync(outputDir, { recursive: true });

  const requests = readJsonFiles(flowExamplesDir).map((record) => record.data);
  const context = loadContext();
  const flows = requests.map((request) => buildFlow(request, context));

  for (const flow of flows) {
    fs.writeFileSync(path.join(outputDir, `${flow.flow_id}.json`), `${JSON.stringify(flow, null, 2)}\n`);
    fs.writeFileSync(path.join(outputDir, `${flow.flow_id}.md`), renderFlowMarkdown(flow));
  }

  const report = buildReport(flows);
  fs.writeFileSync(path.join(outputDir, "flow-report.json"), `${JSON.stringify(report, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "flow-report.md"), renderReportMarkdown(report, flows));

  console.log(`Generated ${flows.length} Atlas flow${flows.length === 1 ? "" : "s"}.`);
  console.log("Generated output/flow/flow-report.md.");
}

function loadContext() {
  return {
    goalProfiles: readJsonFiles(path.join(rootDir, "goals", "profiles")).map((record) => record.data),
    goals: readJsonFiles(path.join(rootDir, "goals", "examples")).map((record) => record.data),
    machineProfiles: readJsonFiles(path.join(rootDir, "hardware", "machine-profiles")).map((record) => record.data),
    readinessReport: readJson("output/readiness/readiness-report.json", { reports: [] }),
    projectFit: readJson("output/capability/project-fit-report.json", { project_fits: [], ready_today: [], mostly_ready: [], defer: [] }),
    capabilitiesById: new Map(readCapabilities().map((record) => [record.capability.capability_id, record.capability])),
    pathway: readJson("output/capability/capability-pathway.json", { weeks: [], what_to_avoid_for_now: [] }),
    practicePack: readJson("output/learning/practice-pack.json", { tasks: [] }),
    hardwareHints: normalizeArray(readJson("output/hardware/contextual-hardware-hints.json", []), "hints"),
    setupReportDir: path.join(rootDir, "output", "setup-advisor"),
    recoveryReportDir: path.join(rootDir, "output", "recovery-advisor"),
    aiContextDir: path.join(rootDir, "output", "ai-context"),
    explainability: readJson("output/explainability/why-this-roadmap.json", {}),
    toolkit: readJson("output/toolkit/toolkit-index.json", { tools: [] }),
    frictionNodes: readJson("output/friction/friction-nodes.json", [])
  };
}

function buildFlow(request, context) {
  const profile = context.goalProfiles.find((item) => item.profile_id === request.profile_id) || {};
  const machine = context.machineProfiles.find((item) => item.profile_id === request.machine_profile_id) || {};
  const goalRecords = request.goals.map((goalId) => context.goals.find((goal) => goal.goal_id === goalId)).filter(Boolean);
  const readinessId = readinessByProfile[request.profile_id];
  const readiness = context.readinessReport.reports.find((report) => report.readiness_id === readinessId) || context.readinessReport.reports[0] || {};
  const setupId = setupByProfile[request.profile_id];
  const setup = request.include_setup ? readJson(`output/setup-advisor/${setupId}.json`, null) : null;
  const aiContextId = aiContextByProfile[request.profile_id];
  const aiContext = request.include_ai_context ? readJson(`output/ai-context/${aiContextId}.json`, null) : null;
  const bestProject = chooseBestProject(request, readiness, context.projectFit);
  const bestCapability = context.capabilitiesById.get(bestProject.capability_id) || {};
  const nextProject = chooseNextProject(bestProject, context.projectFit);
  const frictionRisks = collectFrictionRisks(request, bestProject, setup, context.frictionNodes);
  const recovery = request.include_recovery ? chooseRecovery(request, frictionRisks) : null;
  const hardwareNotes = request.include_hardware ? buildHardwareNotes(machine, bestProject, context.hardwareHints) : [];
  const learnNow = unique([...(bestProject.missing_knowledge || []), ...firstWeekKnowledge(context.pathway)]).slice(0, 8);
  const skipNow = unique([
    ...(context.pathway.what_to_avoid_for_now || []),
    ...goalRecords.flatMap((goal) => goal.common_mistakes || [])
  ]).slice(0, 6);
  const setupChecklist = setup ? setup.verification_checklist || [] : [];
  const sourceOutputs = buildSourceOutputs(request, setupId, aiContextId, recovery);

  const flow = {
    flow_id: request.flow_id,
    generated_at: new Date().toISOString(),
    profile_summary: {
      profile_id: request.profile_id,
      learner_level: request.learner_level,
      available_hours_per_week: request.available_hours_per_week,
      preferred_stack: request.preferred_stack,
      desired_output: request.desired_output,
      constraints: profile.constraints || []
    },
    selected_goals: goalRecords.map((goal) => ({
      goal_id: goal.goal_id,
      title: goal.title,
      category: goal.category,
      estimated_hours: (goal.estimated_learning_hours || 0) + (goal.estimated_practice_hours || 0)
    })),
    readiness_status: {
      readiness_id: readiness.readiness_id || readinessId,
      status: readiness.status || "unknown",
      score: readiness.score || 0
    },
    strongest_areas: readiness.strongest_areas || [],
    weakest_areas: readiness.weakest_areas || [],
    hardware_notes: hardwareNotes,
    setup_checklist: setupChecklist,
    likely_friction_risks: frictionRisks,
    what_to_learn_now: learnNow,
    recommended_next_knowledge: bestCapability.recommended_next_canon_nodes || [],
    optional_knowledge_note: bestCapability.optional_canon_note || "",
    what_to_skip_for_now: skipNow,
    best_project_now: projectSummary(bestProject),
    next_project_later: projectSummary(nextProject),
    recovery_fallback: recoverySummary(recovery),
    why_this_path: buildWhyThisPath(request, readiness, bestProject, setup, aiContext),
    ai_ready_context_pointer: aiContext ? `output/ai-context/${aiContextId}.md` : null,
    smallest_useful_next_step: buildSmallestStep(bestProject, setupChecklist, learnNow),
    confidence_building_message: buildConfidenceMessage(request, bestProject),
    flow_steps: buildSteps(request, readiness, machine, setup, frictionRisks, bestProject, nextProject, recovery, aiContext),
    source_outputs: sourceOutputs
  };

  const score = scoreFlow(flow, request);
  flow.flow_quality_score = score.score;
  flow.flow_warnings = score.warnings;
  flow.flow_improvements = score.improvements;

  return flow;
}

function chooseBestProject(request, readiness, projectFit) {
  const readinessId = readiness.readiness_id;
  const all = projectFit.project_fits || [];
  const matching = all.filter((project) => project.best_readiness_match === readinessId);
  const ready = matching.find((project) => project.fit_level === "ready_today");
  if (ready) return ready;
  const mostly = matching.find((project) => project.fit_level === "mostly_ready");
  if (mostly) return mostly;
  return matching[0] || (projectFit.ready_today || [])[0] || all[0] || {};
}

function chooseNextProject(bestProject, projectFit) {
  const all = projectFit.project_fits || [];
  return all.find((project) => project.capability_id !== bestProject.capability_id && project.fit_level === "mostly_ready")
    || all.find((project) => project.capability_id !== bestProject.capability_id)
    || {};
}

function collectFrictionRisks(request, bestProject, setup, frictionNodes) {
  const rawIds = [
    ...(request.current_blockers || []),
    ...(bestProject.blockers || []).map((item) => cleanFrictionId(String(item).match(/friction\.[a-z0-9_.]+/)?.[0])).filter(Boolean),
    ...((setup && setup.likely_friction_problems) || []).map((item) => item.id)
  ];

  return unique(rawIds).map((id) => {
    const node = frictionNodes.find((item) => item.id === id) || {};
    return {
      id,
      title: node.title || id,
      friction_score: node.friction_score || null,
      estimated_recovery_time: node.estimated_recovery_time || null
    };
  }).slice(0, 5);
}

function chooseRecovery(request, frictionRisks) {
  const firstId = (request.current_blockers || [])[0] || (frictionRisks[0] && frictionRisks[0].id);
  const recoveryId = recoveryByFriction[firstId];
  if (!recoveryId) return null;
  return readJson(`output/recovery-advisor/${recoveryId}.json`, null);
}

function buildHardwareNotes(machine, bestProject, hints) {
  const notes = [];
  if (machine.profile_id) {
    notes.push(`${machine.profile_id}: ${machine.system_ram_gb} GB RAM, ${machine.storage_type}, ${machine.storage_free_gb}/${machine.storage_total_gb} GB free.`);
    if (machine.system_ram_gb <= 8) notes.push("Keep the first project light; avoid Docker until the local app already runs.");
    if (machine.current_pain_points && machine.current_pain_points.length) notes.push(`Watch: ${machine.current_pain_points[0]}.`);
  }
  for (const concern of bestProject.hardware_concerns || []) notes.push(concern);
  const relevantHint = (hints || []).find((hint) => (hint.related_workloads || []).some((id) => (bestProject.hardware_concerns || []).join(" ").includes(id)));
  if (relevantHint) notes.push(relevantHint.message_rookie || relevantHint.message_professional);
  return unique(notes).slice(0, 5);
}

function firstWeekKnowledge(pathway) {
  const firstWeek = (pathway.weeks || [])[0] || {};
  return firstWeek.required_knowledge || [];
}

function projectSummary(project = {}) {
  return {
    capability_id: project.capability_id || null,
    title: project.title || "No project selected",
    fit_level: project.fit_level || "unknown",
    fit_score: project.fit_score || 0,
    estimated_hours: project.estimated_hours || 0,
    blockers: project.blockers || []
  };
}

function recoverySummary(recovery) {
  if (!recovery) {
    return {
      matched_friction_node: null,
      safest_first_fix: "No recovery fallback selected.",
      estimated_recovery_time: 0,
      source: null
    };
  }

  return {
    matched_friction_node: recovery.matched_friction_node,
    safest_first_fix: recovery.safest_first_fix,
    verification_steps: recovery.verification_steps || [],
    estimated_recovery_time: recovery.estimated_recovery_time || 0,
    source: `output/recovery-advisor/${recovery.request_id}.md`
  };
}

function cleanFrictionId(value) {
  return value ? value.replace(/[.]+$/, "") : value;
}

function buildWhyThisPath(request, readiness, bestProject, setup, aiContext) {
  return [
    `The selected goals point toward ${request.preferred_stack.join(", ")} and the requested output is specific.`,
    `Readiness is ${readiness.status || "unknown"} at ${readiness.score || 0}, so the path starts with a finishable project instead of a large roadmap.`,
    `${bestProject.title || "The selected project"} is the best current fit because it is ${bestProject.fit_level || "available"} and estimated at ${bestProject.estimated_hours || "unknown"} hours.`,
    setup ? "Setup is included because local verification prevents avoidable friction." : "Setup is skipped by request.",
    aiContext ? "AI context is included so a helper can stay scoped and avoid overcomplicating the task." : "AI context is skipped by request."
  ];
}

function buildSmallestStep(bestProject, setupChecklist, learnNow) {
  if (setupChecklist.length) return `Run the first setup verification: ${setupChecklist[0]}.`;
  if (learnNow.length) return `Study and practice ${learnNow[0]} before expanding scope.`;
  return `Start the smallest version of ${bestProject.title || "the selected project"}.`;
}

function buildConfidenceMessage(request, bestProject) {
  return `You do not need the whole roadmap today. Finish the next small win: ${bestProject.title || request.desired_output}. That is enough to create visible progress.`;
}

function buildSteps(request, readiness, machine, setup, frictionRisks, bestProject, nextProject, recovery, aiContext) {
  const steps = [
    ["goal_summary", "Goal summary", "Goal Intelligence", `Focus on ${request.desired_output}.`, true, "flow request"],
    ["readiness_snapshot", "Readiness snapshot", "Readiness Intelligence", `Status: ${readiness.status || "unknown"} (${readiness.score || 0}).`, true, "output/readiness/readiness-report.json"],
    ["hardware_fit", "Hardware/machine fit", "Hardware Intelligence", machine.profile_id ? `Use ${machine.profile_id}; avoid hardware decisions until workload demands it.` : "No machine profile matched.", Boolean(request.include_hardware), "hardware/machine-profiles"],
    ["setup_fit", "Toolkit/setup fit", "Setup Advisor", setup ? `Use ${setup.recommended_setup_profile}; verify tools before project work.` : "Setup was not included.", Boolean(request.include_setup), "output/setup-advisor"],
    ["friction_risks", "Friction risks", "Friction Intelligence", `${frictionRisks.length} likely blocker(s) identified.`, true, "output/friction/friction-nodes.json"],
    ["learning_gaps", "Learning gaps", "Learning Intelligence", "Learn only the nodes needed for the selected project.", true, "output/learning"],
    ["capability", "Capability recommendation", "Capability Intelligence", `Build ${bestProject.title || "the selected project"} now.`, true, "output/capability/project-fit-report.json"],
    ["project_pathway", "Project pathway", "Capability Pathway", `Next project later: ${nextProject.title || "not selected"}.`, false, "output/capability/capability-pathway.json"],
    ["recovery_fallback", "Recovery fallback", "Recovery Advisor", recovery ? `If blocked, start with: ${recovery.safest_first_fix}.` : "No recovery fallback selected.", Boolean(request.include_recovery), "output/recovery-advisor"],
    ["explainability", "Explainability summary", "Explainability Intelligence", "The path favors shortest acceptable progress over broad coverage.", false, "output/explainability"],
    ["ai_context", "AI context export", "AI Context Pack", aiContext ? `Use ${aiContext.request_id} when asking an AI assistant for help.` : "AI context was not included.", Boolean(request.include_ai_context), "output/ai-context"],
    ["smallest_next_step", "Smallest useful next step", "Flow Engine", buildSmallestStep(bestProject, setup ? setup.verification_checklist || [] : [], bestProject.missing_knowledge || []), true, "generated flow"]
  ];

  return steps.map(([stepId, title, system, summary, outputFirst, source], index) => ({
    order: index + 1,
    step_id: stepId,
    title,
    system,
    summary,
    output_first: outputFirst,
    source
  }));
}

function buildSourceOutputs(request, setupId, aiContextId, recovery) {
  const outputs = [
    "output/goals/personal-roadmaps",
    "output/readiness/readiness-report.json",
    "output/hardware/machine-profile-report.md",
    "output/toolkit/setup-checklists.md",
    "output/capability/project-fit-report.json",
    "output/capability/capability-pathway.json",
    "output/explainability/why-this-roadmap.md",
    "output/learning/practice-pack.md"
  ];

  if (request.include_setup) outputs.push(`output/setup-advisor/${setupId}.md`);
  if (request.include_recovery && recovery && recovery.request_id) outputs.push(`output/recovery-advisor/${recovery.request_id}.md`);
  if (request.include_ai_context) outputs.push(`output/ai-context/${aiContextId}.md`);
  return outputs;
}

function scoreFlow(flow, request) {
  const dimensions = {
    clarity: flow.smallest_useful_next_step ? 15 : 8,
    usefulness: flow.best_project_now.capability_id ? 15 : 7,
    next_step_quality: flow.smallest_useful_next_step.length > 20 ? 15 : 8,
    no_overwhelm: flow.what_to_learn_now.length <= 8 && flow.what_to_skip_for_now.length <= 6 ? 15 : 9,
    system_coverage: Math.min(15, flow.flow_steps.filter((step) => step.output_first || step.summary).length),
    ai_context_usefulness: request.include_ai_context && flow.ai_ready_context_pointer ? 10 : request.include_ai_context ? 4 : 8,
    confidence_support: flow.confidence_building_message ? 15 : 5
  };

  const score = Object.values(dimensions).reduce((sum, value) => sum + value, 0);
  const warnings = [];
  const improvements = [];

  if (!flow.best_project_now.capability_id) warnings.push("No capability recommendation was selected.");
  if (flow.what_to_learn_now.length > 8) warnings.push("Learning list may overwhelm the user.");
  if (request.include_ai_context && !flow.ai_ready_context_pointer) warnings.push("AI context was requested but no context pointer was found.");
  if (!flow.recovery_fallback.matched_friction_node && request.include_recovery) warnings.push("Recovery was requested but no fallback matched.");
  if (!flow.setup_checklist.length && request.include_setup) improvements.push("Add setup verification checklist for this flow.");
  if (!flow.hardware_notes.length && request.include_hardware) improvements.push("Add clearer hardware fit notes.");
  if (!warnings.length) improvements.push("Keep this flow current as upstream Atlas reports change.");

  return {
    score,
    warnings,
    improvements
  };
}

function buildReport(flows) {
  const average = flows.length
    ? round(flows.reduce((sum, flow) => sum + flow.flow_quality_score, 0) / flows.length)
    : 0;
  const firstRecommended = flows.find((flow) => flow.flow_id === "rookie-vue-todo-flow") || flows[0] || null;

  return {
    generated_at: new Date().toISOString(),
    flows_generated: flows.length,
    average_flow_quality_score: average,
    first_recommended_flow: firstRecommended ? firstRecommended.flow_id : null,
    flow_scores: flows.map((flow) => ({
      flow_id: flow.flow_id,
      score: flow.flow_quality_score,
      warnings: flow.flow_warnings.length
    })),
    generated_files: flows.flatMap((flow) => [
      `output/flow/${flow.flow_id}.md`,
      `output/flow/${flow.flow_id}.json`
    ]).concat([
      "output/flow/flow-report.md",
      "output/flow/flow-report.json"
    ])
  };
}

function renderFlowMarkdown(flow) {
  const hasStorageStep = flow.recommended_next_knowledge.includes("CANON-022")
    || flow.profile_summary.desired_output.toLowerCase().includes("storage")
    || flow.profile_summary.desired_output.toLowerCase().includes("remember");

  return [
    `# ${titleFromId(flow.flow_id)}`,
    "",
    "A guided Atlas journey for one small Vue win.",
    "",
    "## Profile Summary",
    "",
    `- Level: ${flow.profile_summary.learner_level}`,
    `- Available time: ${flow.profile_summary.available_hours_per_week} hours/week`,
    `- Desired output: ${flow.profile_summary.desired_output}`,
    "",
    "## Selected Goals",
    "",
    ...list(flow.selected_goals, (goal) => `- ${goal.title}`),
    "",
    "## Readiness",
    "",
    `- Status: ${flow.readiness_status.status}`,
    "- Today starts with a small guided project, not a full roadmap.",
    "",
    "Strongest areas:",
    ...list(flow.strongest_areas, (item) => `- ${item}`),
    "",
    "Weakest areas:",
    ...list(flow.weakest_areas, (item) => `- ${item}`),
    "",
    "## Hardware Notes",
    "",
    ...list(flow.hardware_notes, (item) => `- ${item}`),
    "",
    "## Setup Checklist",
    "",
    ...list(flow.setup_checklist, (item) => `- [ ] ${item}`),
    "",
    "## Likely Friction Risks",
    "",
    ...list(flow.likely_friction_risks, (risk) => `- ${risk.title}`),
    "",
    "## Learn Now",
    "",
    ...list(flow.what_to_learn_now, (item) => `- ${friendlyKnowledge(item)}`),
    "",
    "## Recommended Next Knowledge",
    "",
    ...list(flow.recommended_next_knowledge, (item) => `- ${friendlyKnowledge(item)}`),
    flow.optional_knowledge_note ? `\n${flow.optional_knowledge_note}` : "",
    "",
    ...(hasStorageStep ? [
      "## Browser Storage Next Step",
      "",
      "Your todo list currently resets after refresh. Make it remember non-sensitive tasks with `localStorage` after the basic app works.",
      "",
      "- Use `localStorage` when the user expects the list to survive browser restarts.",
      "- Use `sessionStorage` only for tab-scoped temporary drafts.",
      "- Use neither for sensitive data.",
      "- Keep Vue state and browser storage separate: state updates the screen now; storage remembers small values for later.",
      ""
    ] : []),
    "## Skip For Now",
    "",
    ...list(flow.what_to_skip_for_now, (item) => `- ${item}`),
    "",
    "## Best Project Now",
    "",
    `- ${flow.best_project_now.title}`,
    `- Fit: ${flow.best_project_now.fit_level.replace(/_/g, " ")}`,
    `- Estimated time: ${flow.best_project_now.estimated_hours} hours`,
    "",
    "## Next Project Later",
    "",
    `- ${flow.next_project_later.title}`,
    `- Fit: ${flow.next_project_later.fit_level.replace(/_/g, " ")}`,
    "",
    "## Recovery Fallback",
    "",
    `- Safest first fix: ${flow.recovery_fallback.safest_first_fix}`,
    ...list(flow.recovery_fallback.verification_steps || [], (item) => `- Verify: ${item}`, "- No verification steps selected."),
    ...(hasStorageStep ? [
      "- If stored todos load incorrectly, clear the saved `todos` value and reload with an empty-array fallback.",
      "- If todos disappear after closing the tab, check whether you used `sessionStorage` instead of `localStorage`.",
      "- If objects save as `[object Object]`, save with `JSON.stringify()` and load with `JSON.parse()`."
    ] : []),
    "",
    "## Why This Path",
    "",
    ...list(flow.why_this_path, (item) => `- ${item}`),
    "",
    "## AI Context",
    "",
    flow.ai_ready_context_pointer ? `Use this focused context pack if you want AI help without expanding scope: \`${flow.ai_ready_context_pointer}\`` : "AI context was not requested.",
    "",
    "## Smallest Useful Next Step",
    "",
    flow.smallest_useful_next_step,
    "",
    "## Confidence Note",
    "",
    flow.confidence_building_message,
    "",
    ""
  ].join("\n");
}

function renderReportMarkdown(report, flows) {
  return [
    "# Atlas Flow Report",
    "",
    `Flows generated: ${report.flows_generated}`,
    `Average flow quality score: ${report.average_flow_quality_score}`,
    `First recommended flow: ${report.first_recommended_flow}`,
    "",
    "## Flow Scores",
    "",
    ...flows.map((flow) => `- ${flow.flow_id}: ${flow.flow_quality_score}/100 (${flow.flow_warnings.length} warning${flow.flow_warnings.length === 1 ? "" : "s"})`),
    "",
    "## Generated Files",
    "",
    ...report.generated_files.map((file) => `- ${file}`),
    ""
  ].join("\n");
}

function readJsonFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const filePath = path.join(dir, fileName);
      return {
        fileName,
        data: JSON.parse(fs.readFileSync(filePath, "utf8"))
      };
    });
}

function readJson(relativePath, fallback) {
  const filePath = path.join(rootDir, relativePath);
  if (!fs.existsSync(filePath)) return fallback;
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function normalizeArray(value, key) {
  if (Array.isArray(value)) return value;
  if (value && Array.isArray(value[key])) return value[key];
  return [];
}

function list(items, mapper, empty = "- None") {
  return Array.isArray(items) && items.length ? items.map(mapper) : [empty];
}

function round(value) {
  return Number(value.toFixed(2));
}

function titleFromId(id) {
  return id.split("-").map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
}

function friendlyKnowledge(id) {
  const labels = {
    "CANON-003": "Vue reactivity: choosing simple state",
    "CANON-007": "Vue conditional display",
    "CANON-009": "Filtering visible items",
    "CANON-013": "Stable keys for list rows",
    "CANON-022": "Browser storage: localStorage vs sessionStorage",
    "CANON-025": "Component communication: props, emits, and model"
  };
  return labels[id] || id;
}

main();
