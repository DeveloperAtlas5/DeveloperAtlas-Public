# v-if vs v-show

## Status Metadata

- Canon ID: CANON-007
- Node ID: canon.vue.directive.v-if-vs-v-show
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: Vue directives
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `v-if` when content should be conditionally created and destroyed. Use `v-show` when content should stay mounted and only toggle CSS visibility.

The everyday rule:

- `v-if` controls existence.
- `v-show` controls visibility.
- Toggle frequency and state preservation decide many real cases.

## What Problem This Solves

Vue developers often choose `v-if` or `v-show` by habit. The component still works, but the wrong choice can create subtle problems:

- Forms lose local state after toggling.
- Expensive panels render even when hidden.
- DOM queries find hidden elements unexpectedly.
- AI-generated code hides instead of removing sensitive or role-gated content.
- Frequently toggled UI pays repeated mount and teardown costs.

This node turns the choice into a practical decision about existence, visibility, performance, and state.

## Mental Model

Think in doors and light switches.

`v-if` is a door. When the condition is false, the room is not there. Vue does not create the element or component. When the condition becomes true, Vue creates it.

```vue
<AdminPanel v-if="isAdmin" />
```

`v-show` is a light switch. The room is still there, but the lights are off. Vue renders the element and toggles CSS `display`.

```vue
<DetailsPanel v-show="isOpen" />
```

The key question is not "Which directive is faster?" It is "Should this thing exist right now, or should it exist but be hidden?"

| Question | Better default |
| --- | --- |
| Should it not be in the DOM until needed? | `v-if` |
| Is it expensive and rarely shown? | `v-if` |
| Does it toggle very often? | `v-show` |
| Should local DOM/component state survive hiding? | `v-show` |
| Is this route-level navigation? | Router |
| Is this only a style change? | Class binding |

## Beginner Explanation

Use `v-if` when Vue should decide whether the element exists.

```vue
<p v-if="hasError">Something went wrong.</p>
```

If `hasError` is false, the paragraph is not created.

Use `v-show` when Vue should create the element once and then hide or show it.

```vue
<HelpPanel v-show="isHelpOpen" />
```

If `isHelpOpen` is false, the panel is still there, but CSS hides it.

Beginner rule:

1. Rarely shown or may never be shown? Start with `v-if`.
2. Toggled often and should keep state? Consider `v-show`.
3. Page navigation? Use the router.
4. Pure styling? Use class binding.

## Professional Explanation

`v-if` is real conditional rendering. When false, Vue does not render the block. For components, that means component setup, mounted hooks, watchers, child components, and DOM nodes are not active. Toggling from false to true creates them; toggling back destroys them.

`v-show` always renders the element and controls CSS display. It has higher initial render cost if the condition starts false, but lower toggle cost after creation. It also preserves DOM state and component instance state across visibility changes.

In production code, the choice affects:

- Initial render cost.
- Toggle cost.
- Component lifecycle behavior.
- Form input preservation.
- Accessibility and focus behavior.
- Whether hidden DOM still exists.
- Whether sensitive or role-gated content should be rendered at all.

Prefer `v-if` for conditional existence and expensive or rarely used content. Prefer `v-show` for frequent visibility toggles where preserving state is desirable.

## Syntax

```vue
<AdminPanel v-if="user.role === 'admin'" />
```

```vue
<FilterPanel v-show="filtersOpen" />
```

With branches:

```vue
<SuccessState v-if="status === 'success'" />
<ErrorState v-else-if="status === 'error'" />
<LoadingState v-else />
```

## Decision Guide

Ask these questions in order:

1. Should the element or component not exist unless the condition is true?
   Use `v-if`.
2. Is the content expensive and rarely shown?
   Use `v-if`.
3. Does the UI toggle frequently?
   Use `v-show`.
4. Should local state, focus position, form input, or component instance state survive hiding?
   Use `v-show`.
5. Is the condition about route-level screens?
   Use routing instead.
6. Is the condition only changing visual styling?
   Use class or style binding instead.
7. Is the content sensitive or permission-gated?
   Prefer `v-if`, and still enforce security on the server.

## Comparison Table

| Feature | `v-if` | `v-show` |
| --- | --- | --- |
| Main intent | Conditional existence | Conditional visibility |
| DOM when false | Not rendered | Rendered but hidden |
| Mechanism | Create/destroy | CSS `display` toggle |
| Initial false cost | Lower | Higher |
| Toggle cost | Higher | Lower |
| Component state | Reset on destroy | Preserved |
| Lifecycle hooks | Re-run on remount | Not re-run just for visibility |
| Best for | Rare, expensive, permission-gated content | Tabs, accordions, dropdowns, frequent toggles |
| Main risk | Accidental state reset | Hidden content still exists |

## When To Use The Primary Option

Use `v-if` when:

- Content should not exist unless the condition is true.
- The component is expensive and may never be opened.
- The condition is permission, role, or feature-flag based.
- You want lifecycle setup to happen only when visible.
- Resetting local state on close is correct.
- Hidden DOM should not be discoverable by scripts, tests, or browser search.

```vue
<BillingSettings v-if="canManageBilling" />
```

## When To Use The Alternative

Use `v-show` when:

- The element toggles often.
- You want to preserve form input or local component state.
- The initial render cost is acceptable.
- The user is switching between panels, tabs, filters, or collapsible details.
- You want fast show/hide after the first render.

```vue
<FiltersPanel v-show="filtersOpen" />
```

## When Not To Use This Decision

Do not use `v-if` or `v-show` as a replacement for the right UI or architecture tool.

Avoid both when:

- The user is changing pages. Use Vue Router.
- The change is only color, spacing, or active styling. Use class binding.
- The content should be conditionally loaded from the server. Enforce that outside the template.
- The element should remain accessible to screen readers while visually hidden. Use an accessibility-specific pattern.
- You need animations. Consider `<Transition>` with the appropriate directive.
- You are hiding sensitive data and assuming that is security. Client-side hiding is not authorization.

## Alternatives

### Class Binding

Use class binding for visual state.

```vue
<button :class="{ active: selected }">Details</button>
```

### Dynamic Components

Use dynamic components when switching between component types.

```vue
<component :is="currentPanel" />
```

### Router Views

Use routing for page-level view changes.

### Transition

Use `<Transition>` when the show/hide behavior needs animation.

## Production Examples

### Permission-Gated Admin Panel With v-if

```vue
<AdminBillingPanel
  v-if="currentUser.permissions.includes('billing:manage')"
  :account-id="account.id"
/>
```

Why `v-if` fits: the billing panel should not be created for users who cannot manage billing. Server-side permission checks are still required; `v-if` only controls client rendering.

### Frequently Toggled Filter Drawer With v-show

```vue
<ProductFilters
  v-show="filtersOpen"
  v-model:category="selectedCategory"
  v-model:price-range="selectedPriceRange"
/>
```

Why `v-show` fits: users may open and close filters repeatedly, and the selected local filter state should stay intact.

### Rare Expensive Report With v-if

```vue
<RevenueForecastChart
  v-if="showForecast"
  :account-id="account.id"
  :date-range="dateRange"
/>
```

Why `v-if` fits: the chart may be expensive to initialize and may never be opened during a session.

### Tab Panels With v-show

```vue
<ProfileTab v-show="activeTab === 'profile'" />
<SecurityTab v-show="activeTab === 'security'" />
<BillingTab v-show="activeTab === 'billing'" />
```

Why `v-show` fits: tab content is already part of the current view and should switch quickly without resetting local state.

## Common Mistakes

- Using `v-if` for frequently toggled tabs and resetting local state every time.
- Using `v-show` for expensive content that may never be used.
- Assuming `v-show` removes an element from the DOM.
- Using `v-show` for permission-gated content that should not be rendered.
- Forgetting that lifecycle hooks run again when a `v-if` component is recreated.
- Using `v-if` and `v-for` together without understanding priority and readability concerns.
- Using either directive for simple active styling.

```vue
<!-- Mistake: form input resets every time this closes -->
<SearchFilters v-if="filtersOpen" />
```

```vue
<!-- Better when state should survive frequent toggles -->
<SearchFilters v-show="filtersOpen" />
```

```vue
<!-- Mistake: expensive chart renders even when never opened -->
<HeavyChart v-show="showChart" />
```

```vue
<!-- Better when it may never be opened -->
<HeavyChart v-if="showChart" />
```

## Debugging Checklist

- If state resets after hiding, are you using `v-if` where `v-show` fits better?
- If initial render is slow, are hidden `v-show` components doing expensive work?
- If lifecycle hooks fire repeatedly, is the component being recreated by `v-if`?
- If tests find hidden elements, are they hidden with `v-show` rather than removed by `v-if`?
- If permission-gated content appears in the DOM, should it be guarded with `v-if` and server authorization?
- If screen reader behavior is wrong, do you need an accessibility-specific hiding pattern?
- If the condition only changes styling, should this be a class binding?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-007/`.

Verification command:

```sh
npm run canon:verify:007
```

The verification suite checks:

- `v-if` creates and removes an element.
- `v-show` keeps an element mounted and toggles display.
- The anti-pattern of using `v-if` for frequently toggled UI.
- The anti-pattern of using `v-show` for expensive initial render.

## Performance Notes

`v-if` is lazy when false. It avoids initial render work for content that may never appear, but it pays create/destroy cost every time the condition toggles.

`v-show` pays initial render cost whether visible or not, but toggling is cheap because Vue mostly changes CSS display. This makes it suitable for frequent toggles with moderate or low initial render cost.

Performance rule:

- Low initial probability, high setup cost: prefer `v-if`.
- High toggle frequency, state should survive: prefer `v-show`.

Measure real bottlenecks before optimizing around this choice alone.

## AI Coding Guidance

When generating Vue template code:

- Use `v-if` for conditional existence.
- Use `v-if` for permission-gated, feature-flagged, rare, or expensive content.
- Use `v-show` for frequent toggles where the element should stay mounted.
- Do not use `v-show` when hidden content should not exist in the DOM.
- Do not use `v-if` when local form state must survive frequent open/close toggles.
- Prefer class binding for active styling.
- Prefer Vue Router for page-level navigation.
- Explain the choice using existence, visibility, toggle frequency, and state preservation.

Bad AI output:

```vue
<AdminSecrets v-show="isAdmin" />
```

Good AI output:

```vue
<AdminSecrets v-if="isAdmin" />
```

## Teaching Notes

Teach in this order:

1. `v-if` means existence.
2. `v-show` means visibility.
3. Show DOM behavior when false.
4. Explain state reset versus state preservation.
5. Add performance: initial cost versus toggle cost.
6. Mention that client-side hiding is not security.

Useful teaching phrase:

> `v-if` removes the room; `v-show` turns off the lights.

## Interview Questions

1. What happens to the DOM when `v-if` is false?
2. What happens to the DOM when `v-show` is false?
3. Why can `v-if` reset local component state?
4. Why can `v-show` be better for frequently toggled UI?
5. Why can `v-show` be bad for expensive content that starts hidden?
6. Would you use `v-show` for permission-gated content? Why or why not?
7. What would you use for page-level navigation instead?

## Exercises

### Beginner

Create an error message that appears only when `hasError` is true. Explain why `v-if` fits.

### Intermediate

Build a filter drawer that opens and closes frequently while preserving selected filter values. Explain why `v-show` fits.

### Advanced

Refactor a settings page that uses `v-show` for several expensive charts. Decide which panels should use `v-if`, which should use `v-show`, and what trade-off each decision makes.

## Related Atlas Nodes

- `vue.directive.v-if`
- `vue.directive.v-for`
- `vue.directive.v-model`
- `vue.reactivity.ref`
- `vue.reactivity.computed`
- `vue.reactivity.watch`

## Evidence And Sources

- Vue Guide: Conditional Rendering: https://vuejs.org/guide/essentials/conditional.html
- Vue API: Built-in Directives, `v-if`: https://vuejs.org/api/built-in-directives.html#v-if
- Vue API: Built-in Directives, `v-show`: https://vuejs.org/api/built-in-directives.html#v-show

## Proof Of Superiority Summary

Official Vue docs explain what `v-if` and `v-show` do. This Canon node explains how to choose between them in production code, why state preservation and initial render cost matter, how permission and accessibility concerns affect the decision, how AI should generate safe template code, and when routing, class binding, transitions, or dynamic components are better tools.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
