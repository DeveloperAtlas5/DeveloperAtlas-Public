const fs = require("fs");
const path = require("path");
const {
  outputDir,
  loadCanonEntries,
  ensureEditorialOutputDir
} = require("./editorial-utils");

function main() {
  ensureEditorialOutputDir();
  const entries = loadCanonEntries();
  const benchmarks = entries.map(benchmarkEntry);

  fs.writeFileSync(path.join(outputDir, "benchmark-review.json"), `${JSON.stringify(benchmarks, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "benchmark-report.md"), toBenchmarkReport(benchmarks));

  const warnings = benchmarks.reduce((sum, item) => sum + item.warnings.length, 0);
  console.log(`Benchmark review complete for ${benchmarks.length} Canon node(s).`);
  console.log(`Benchmark warnings: ${warnings}`);
}

function benchmarkEntry(entry) {
  const markdown = entry.markdown;
  const hasOfficialDocs = /MDN|Vue|PostgreSQL|MySQL|SQLite|W3C|ECMAScript|official/i.test(markdown) && /https?:\/\//.test(markdown);
  const hasIndustryReferences = /CSS-Tricks|industry|production|realistic|practical/i.test(markdown);
  const hasAtlasImprovement = /Atlas should|This Canon node|Atlas node|Proof Of Superiority Summary|Atlas improves/i.test(markdown);
  const warnings = [];

  if (!hasOfficialDocs) warnings.push("missing official docs comparison");
  if (!hasIndustryReferences) warnings.push("missing industry reference or production comparison");
  if (!hasAtlasImprovement) warnings.push("missing Atlas improvement claim");

  return {
    canon_id: entry.canon_id,
    title: entry.title,
    official_docs: hasOfficialDocs ? "present" : "missing",
    industry_references: hasIndustryReferences ? "present" : "missing",
    atlas_improvement: hasAtlasImprovement ? "present" : "missing",
    warnings
  };
}

function toBenchmarkReport(benchmarks) {
  const lines = [
    "# Benchmark Report",
    "",
    "Each Canon node is compared against official docs, industry references, and Atlas-specific improvement.",
    "",
    "## Results",
    ""
  ];

  for (const item of benchmarks) {
    lines.push(`### ${item.canon_id}: ${item.title}`);
    lines.push("");
    lines.push(`- Official docs: ${item.official_docs}`);
    lines.push(`- Industry references: ${item.industry_references}`);
    lines.push(`- Atlas improvement: ${item.atlas_improvement}`);
    lines.push(`- Warnings: ${item.warnings.length ? item.warnings.join("; ") : "None"}`);
    lines.push("");
  }

  return `${lines.join("\n")}\n`;
}

main();
