# async vs await vs Promise.then()

## Status Metadata

- Canon ID: CANON-011
- Node ID: canon.javascript.promise.async-await-vs-promise-then
- Status: Gold Candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript Async
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `async` and `await` when asynchronous code reads best as a normal sequence of steps. Use `Promise.then()` when an explicit promise chain is clearer, especially for compact transformations, callback-style APIs, or returning a promise without entering a larger imperative flow. Both tools work with promises; the real decision is readability, error handling, and control-flow shape.

## What Problem This Solves

Developers often treat `async`/`await` and `Promise.then()` as style-only choices. That causes hidden errors: unreturned promises, `try/catch` blocks that do not catch async failures, nested chains, unnecessary `await`, or code that hides whether work runs sequentially or concurrently.

This node gives a practical decision model:

- `async` marks a function as returning a promise.
- `await` pauses inside an async function until a promise settles.
- `Promise.then()` attaches a continuation and returns a new promise.
- The best choice is the one that makes ordering, errors, and returned values obvious.

## Mental Model

Think of asynchronous code as a handoff.

`async`/`await` lets you write the handoff like a checklist: do this, wait for the result, then do the next thing. It is best when the reader should follow the story from top to bottom.

`Promise.then()` lets you write the handoff like a pipeline: when this promise resolves, pass its result into the next function. It is best when each step is a small transformation and the chain itself is the point.

The important rule: neither style makes asynchronous work synchronous. They are two ways to describe what should happen after a promise settles.

## Beginner Explanation

`async` goes before a function. It means the function always gives back a promise, even if you return a plain value.

`await` goes before a promise inside an async function. It lets you write:

```js
const user = await loadUser();
```

instead of:

```js
loadUser().then((user) => {
  // use user here
});
```

For most beginner application code, start with `async`/`await` because it is easier to read and easier to wrap in `try/catch`. Reach for `Promise.then()` when you are already returning a simple chain or when a framework/API specifically expects a promise callback.

## Professional Explanation

`async` functions always return promises. A returned value becomes a fulfilled promise, and a thrown error becomes a rejected promise. `await` unwraps a fulfilled promise value or throws the rejection reason inside the async function, which makes sequential control flow and local error handling easier to review.

`Promise.then(onFulfilled, onRejected)` registers continuation handlers and returns a new promise resolved from the handler result. It is useful for composing promise-returning functions without introducing local variables, for keeping lazy chains returnable, and for APIs where promise callbacks are the natural integration point.

The code review signal is not "never use `.then()`." The signal is: does the chosen style make dependency order, concurrency, return value, and error propagation explicit? If the code has several dependent awaits, `async`/`await` is usually clearer. If the code is a short, returnable transformation chain, `.then()` can be clean. If the code has independent work, decide concurrency separately with `Promise.all()`, `Promise.allSettled()`, or a sequential loop.

## Syntax

```js
async function loadProfile(userId) {
  const user = await fetchUser(userId);
  return normalizeUser(user);
}

function loadProfile(userId) {
  return fetchUser(userId).then(normalizeUser);
}
```

## Decision Guide

1. If the code has multiple dependent steps, local branching, or local `try/catch`, prefer `async`/`await`.
2. If the code is a short promise-to-value transformation that can be returned directly, `Promise.then()` is acceptable.
3. If the code starts multiple independent async tasks, choose the concurrency strategy first; do not accidentally make parallel work sequential with unnecessary `await`.
4. If errors must be handled locally, prefer `try/catch` with `await` or return a chain with a clear `.catch()`.
5. If an API expects a promise callback or fluent chain, use the style that matches the API boundary.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| `async` function | Marking a function that performs async work and returns a promise | Every return is wrapped in a promise, so callers must handle async behavior. |
| `await` | Reading dependent async steps top to bottom | Can accidentally serialize independent work if used too early. |
| `Promise.then()` | Returning compact promise transformations | Can become hard to debug when nested or when callbacks forget to return. |
| `Promise.catch()` | Handling promise-chain errors at the chain boundary | Can hide where recovery happens if chained casually. |

## When To Use The Primary Option

Use `async`/`await` when sequential readability is the main value.

- A function loads data, validates it, then saves it.
- A controller or handler needs `try/catch` around async work.
- The code has branches, loops, or early returns.
- A local variable name makes the step easier to understand.
- A beginner or mixed-skill team needs the clearest control-flow story.

## When To Use async/await

- You need to wait for one result before computing the next step.
- You need local `try/catch/finally` behavior.
- You need `for...of` with `await` for intentional sequential work.
- You need to make async code look like ordinary imperative code without hiding that it returns a promise.

## When To Use The Alternative

Use `Promise.then()` when the promise chain itself is the cleanest shape.

- A function simply returns a promise transformation.
- You want to pass named functions through a short pipeline.
- You are inside an API that is already promise-chain oriented.
- You do not need local variables, branches, or `try/catch`.

## When To Use Promise.then()

- You are returning a compact chain from a function:

```js
return fetchUser(id).then(normalizeUser);
```

- You are adapting a promise result into another promise-returning helper.
- You want the return value to remain visibly promise-based.
- You are composing functions where each step is a small continuation.

## When Not To Use This Decision

- Do not use either style to solve parallel coordination by habit. Use `Promise.all()` or `Promise.allSettled()` when multiple promises should run together.
- Do not use `forEach(async () => ...)` when the caller needs completion. Use `for...of` with `await` for sequential work or `map()` plus `Promise.all()` for parallel work.
- Do not use `await` on values just to make code look async.
- Do not use `.then()` chains when a few named local variables would make the code obvious.
- Do not use async syntax to hide a missing loading state, cancellation rule, retry rule, or error policy.

## Alternatives

- `Promise.all()` for required parallel work where all tasks must succeed.
- `Promise.allSettled()` for independent async work where partial success is useful.
- `for...of` with `await` for intentional sequential async loops.
- `Promise.catch()` for chain-level error handling.
- Event emitters, queues, or streams for ongoing async events rather than one promise result.

## Production Examples

### API Handler With Clear Sequential Steps

```js
async function updateCustomerEmail(customerId, email) {
  try {
    const customer = await findCustomer(customerId);
    const normalizedEmail = normalizeEmail(email);

    await saveCustomerEmail(customer.id, normalizedEmail);

    return {
      id: customer.id,
      email: normalizedEmail,
      status: "updated"
    };
  } catch (error) {
    return {
      status: "failed",
      message: error.message
    };
  }
}
```

Why `async`/`await` fits: each step depends on the previous step, and the local `try/catch` explains the failure boundary.

### Compact Promise Transformation

```js
function loadCustomerSummary(customerId) {
  return fetchCustomer(customerId)
    .then(toCustomerSummary)
    .then(addDisplayLabels);
}
```

Why `Promise.then()` fits: the function is a small transformation pipeline. Each handler receives the previous result and returns the next one.

### Avoid Accidental Sequential Work

```js
async function loadDashboard(accountId) {
  const [profile, invoices, alerts] = await Promise.all([
    loadProfile(accountId),
    loadInvoices(accountId),
    loadAlerts(accountId)
  ]);

  return { profile, invoices, alerts };
}
```

Why this matters: `await` is still used, but not until the independent promises have been started together.

### Safe Sequential Loop

```js
async function sendEmailsInOrder(messages) {
  const sent = [];

  for (const message of messages) {
    sent.push(await sendEmail(message));
  }

  return sent;
}
```

Why this matters: this loop is intentionally sequential. A `.forEach(async ...)` callback would not give the caller a reliable completion point.

## Common Mistakes

- Forgetting that an `async` function always returns a promise.
- Using `try/catch` around a promise without `await` or without returning the chain.
- Forgetting to return from a `.then()` callback, causing the next step to receive `undefined`.
- Nesting `.then()` calls instead of returning the inner promise.
- Adding `await` too early and accidentally turning independent work into sequential work.
- Mixing `await` and `.then()` in the same expression without a clear reason.
- Using `forEach(async () => ...)` and assuming the outer function waits.

## Debugging Checklist

- Does every async function caller handle the returned promise?
- If `try/catch` is expected to catch a rejection, is the promise actually awaited?
- Does every `.then()` callback return the value or promise needed by the next step?
- Are independent tasks started before the shared `await`?
- Is the code intentionally sequential, or did `await` serialize it by accident?
- Is a rejection converted into a useful error, logged, retried, or intentionally rethrown?
- Would named local variables make a chain easier to read?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-011/`.

Run:

```bash
npm run canon:verify:011
```

The examples verify:

- `async`/`await` for readable sequential flow.
- `Promise.then()` for a compact transformation chain.
- The mistake of forgetting to return from a `.then()` callback.
- The mistake of expecting `try/catch` to catch an unawaited promise rejection.

## Performance Notes

The syntax choice is rarely the performance bottleneck. The meaningful performance decision is whether work is sequential or concurrent.

- `await` inside a loop is correct for required ordering, rate limits, or dependency.
- `await` before starting independent tasks can make code slower.
- `.then()` is not inherently faster in a way that should drive ordinary application decisions.
- Prefer readable async control first; optimize concurrency only when the task shape demands it.

## AI Coding Guidance

- Default to `async`/`await` for multi-step application code, handlers, and examples meant for rookies.
- Use `.then()` only when the chain is short, returned directly, and easier than local variables.
- Always return from `.then()` callbacks when the next step needs the result.
- Use `try/catch` only around awaited promises or inside an async function.
- Do not generate `forEach(async () => ...)` when completion matters.
- For independent async work, generate `Promise.all()` or `Promise.allSettled()` instead of sequential awaits.
- Explain whether the code is sequential or concurrent.

## Teaching Notes

Teach `async` first as "this function returns a promise." Teach `await` second as "pause here inside the async function until the promise settles." Then teach `.then()` as "attach the next step to a promise."

Do not frame `.then()` as obsolete. Frame it as lower-level promise composition that is still valid when it keeps the code compact and explicit.

Progression:

1. Show one promise-returning helper.
2. Consume it with `await`.
3. Consume it with `.then()`.
4. Compare error handling.
5. Add concurrency with `Promise.all()`.

## Interview Questions

1. What does an `async` function return?
2. What happens when an awaited promise rejects?
3. When is `.then()` clearer than `async`/`await`?
4. Why does `try/catch` not catch a promise rejection if the promise is not awaited or returned?
5. How would you avoid accidentally making three independent requests sequential?
6. Why is `forEach(async () => ...)` usually a warning sign?

## Exercises

### Beginner

Rewrite a small `.then()` chain as an `async` function and explain what `await` is waiting for.

### Intermediate

Take three independent promise-returning functions and load them with `Promise.all()` instead of three sequential awaits.

### Advanced

Review an async data-loading function and identify whether each async operation should be sequential, parallel, chained, retried, or handled with a local error boundary.

## Related Atlas Nodes

- `CANON-001`
- `CANON-008`
- `CANON-002`
- `javascript.function.fetch`
- `javascript.promise.all`

## Evidence And Sources

- MDN: async function - https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function
- MDN: await - https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/await
- MDN: Promise.prototype.then() - https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/then
- ECMAScript: Async Function Definitions - https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-async-function-definitions
- ECMAScript: Await - https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#await
- ECMAScript: Promise.prototype.then - https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.prototype.then

## Proof Of Superiority Summary

Official references explain syntax and promise behavior. This Canon node adds the production decision model: sequential readability versus compact promise composition, local error handling, returned-chain discipline, concurrency warnings, debugging checks, runnable examples, and AI generation rules.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
