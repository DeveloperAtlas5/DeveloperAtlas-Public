# CANON-006 Proof Of Superiority

## What Official Docs Explain Well

Vue's official documentation explains computed properties, watchers, and the reactivity fundamentals that make both APIs work.

## What Developers Still Struggle With

Developers still struggle with choosing between derived state and side-effect reactions. Common mistakes include mirrored state, watcher chains, side effects inside computed getters, broad watchers, and watchers used for submit actions.

## How Atlas Improves The Explanation

Atlas frames the choice as formula versus alarm: `computed()` makes a value, while `watch()` starts a reaction. This makes the decision easier for beginners and more reviewable for professionals.

## What Decision Support Atlas Adds

The Canon node gives a decision guide, comparison table, when-to-use sections, alternatives, and debugging checklist that route developers to `computed()`, `watch()`, methods, lifecycle hooks, props, emits, or store actions.

## What Production Guidance Atlas Adds

The node includes product-list view models, search-query API reactions, local storage persistence, async watcher warnings, and side-effect boundary guidance.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants explicit generation rules: use `computed()` for derived state, keep computed getters pure, use `watch()` only for side effects, watch narrow sources, and avoid mirrored derived refs.

## Why This Deserves Gold Status

This node deserves Gold-candidate status because it turns a common Vue confusion into a practical production decision model with official evidence, examples, mechanical verification, teaching guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.
