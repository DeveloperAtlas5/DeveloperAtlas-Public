const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readGoals } = require("./goal-utils");
const { readTools } = require("./toolkit-utils");
const { readWorkloadProfiles } = require("./hardware-utils");
const {
  explainabilityOutputDir,
  ensureExplainabilityOutputDir,
  readExplanations,
  readJsonIfExists,
  unique
} = require("./explainability-utils");

function main() {
  const context = readContext();
  const roadmap = buildRoadmapJustification(context);

  ensureExplainabilityOutputDir();
  fs.writeFileSync(
    path.join(explainabilityOutputDir, "why-this-roadmap.json"),
    `${JSON.stringify(roadmap, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(explainabilityOutputDir, "why-this-roadmap.md"),
    toMarkdown(roadmap)
  );

  console.log("Generated output/explainability/why-this-roadmap.json.");
  console.log("Generated output/explainability/why-this-roadmap.md.");
}

function readContext() {
  return {
    explanations: readExplanations().map((record) => record.explanation),
    pathway: readJsonIfExists(path.join(rootDir, "output", "capability", "capability-pathway.json"), { weeks: [] }),
    capabilityReport: readJsonIfExists(path.join(rootDir, "output", "capability", "capability-report.json"), {}),
    readinessReport: readJsonIfExists(path.join(rootDir, "output", "readiness", "readiness-report.json"), { reports: [] }),
    goalsById: new Map(readGoals().map((record) => [record.goal.goal_id, record.goal])),
    toolsById: new Map(readTools().map((record) => [record.data.id, record.data])),
    workloadsById: new Map(readWorkloadProfiles().map((record) => [record.workload.workload_id, record.workload])),
    canonLearningById: readCanonLearningById()
  };
}

function readCanonLearningById() {
  const canonIndex = readJsonIfExists(path.join(rootDir, "canon", "canon-index.json"), { entries: [] });
  return new Map(canonIndex.entries.map((entry) => [entry.canon_id, entry.learning || {}]));
}

function buildRoadmapJustification(context) {
  const explanationByGoal = mapExplanationsByGoal(context.explanations);
  const weeks = (context.pathway.weeks || []).map((week) => justifyWeek(week, explanationByGoal, context));

  return {
    generated_at: new Date().toISOString(),
    roadmap_id: "explainability.why_this_capability_pathway",
    profile_summary: context.pathway.profile_summary || {},
    roadmap_justifications: weeks,
    shortest_acceptable_path: shortestPath(weeks),
    safe_to_defer: context.explanations
      .filter((item) => item.importance === "defer" || item.can_learn_later)
      .map((item) => ({
        recommendation: item.recommendation,
        reason: item.shortest_acceptable_path
      })),
    ai_ready_explanation_blocks: weeks.map((week) => ({
      week: week.week,
      project: week.project,
      block: `Week ${week.week} recommends ${week.project} because ${week.why_this_project}. If skipped: ${week.skip_impact}. Shortest path: ${week.shortest_acceptable_path}`
    }))
  };
}

function justifyWeek(week, explanationByGoal, context) {
  const relatedExplanations = explanationsForWeek(week, explanationByGoal, context);
  const projectReason = projectReasonFor(week);
  const skipImpact = relatedExplanations[0]?.skip_impact || "Skipping this week delays the project ladder and reduces the feedback loop from real building.";

  return {
    week: week.week,
    project: week.project.title,
    capability_id: week.project.capability_id,
    fit_level: week.fit_level,
    why_this_project: projectReason,
    related_explanations: relatedExplanations.map((item) => ({
      explanation_id: item.explanation_id,
      recommendation: item.recommendation,
      importance: item.importance,
      why_recommended: item.why_recommended,
      can_learn_later: item.can_learn_later,
      shortest_acceptable_path: item.shortest_acceptable_path
    })),
    what_depends_on_it: unique(relatedExplanations.flatMap((item) => item.what_depends_on_it)),
    skip_impact: skipImpact,
    shortest_acceptable_path: shortestPathForWeek(week, relatedExplanations),
    supports_goals: unique(relatedExplanations.flatMap((item) => item.related_goals))
  };
}

function explanationsForWeek(week, explanationByGoal, context) {
  const capability = findCapabilityById(week.project.capability_id);
  const goalMatches = (capability?.required_goals || []).flatMap((goal) => explanationByGoal.get(goal) || []);
  const text = [
    week.project.title,
    ...(week.required_knowledge || []),
    ...(week.required_tools || []),
    ...(week.hardware_notes || [])
  ].join(" ").toLowerCase();

  const keywordMatches = context.explanations.filter((item) => {
    const recommendation = item.recommendation.toLowerCase();
    return recommendation.split(/\W+/).some((word) => word.length > 4 && text.includes(word));
  });

  return uniqueById([...goalMatches, ...keywordMatches]).slice(0, 4);
}

function findCapabilityById(capabilityId) {
  const dir = path.join(rootDir, "capability", "examples");
  if (!fs.existsSync(dir)) return null;
  for (const fileName of fs.readdirSync(dir).filter((name) => name.endsWith(".json"))) {
    const capability = JSON.parse(fs.readFileSync(path.join(dir, fileName), "utf8"));
    if (capability.capability_id === capabilityId) return capability;
  }
  return null;
}

function projectReasonFor(week) {
  if (week.week === 1) return "it is the smallest ready-today project and creates a fast feedback loop.";
  if (week.week === 2) return "it builds on the first win while adding targeted prep instead of a large jump.";
  if (week.week === 3) return "it stretches capability while keeping the scope smaller than the deferred project.";
  return "it prepares the deferred stretch goal without pretending it is ready today.";
}

function shortestPathForWeek(week, explanations) {
  const explanationPath = explanations[0]?.shortest_acceptable_path;
  if (explanationPath) return explanationPath;
  return `Complete ${week.project.title} with only the listed success criteria and no extra features.`;
}

function shortestPath(weeks) {
  return weeks.map((week) => `Week ${week.week}: ${week.shortest_acceptable_path}`);
}

function mapExplanationsByGoal(explanations) {
  const map = new Map();
  for (const explanation of explanations) {
    for (const goal of explanation.related_goals) {
      if (!map.has(goal)) map.set(goal, []);
      map.get(goal).push(explanation);
    }
  }
  return map;
}

function uniqueById(items) {
  const seen = new Set();
  const result = [];
  for (const item of items) {
    if (!item?.explanation_id || seen.has(item.explanation_id)) continue;
    seen.add(item.explanation_id);
    result.push(item);
  }
  return result;
}

function toMarkdown(roadmap) {
  const lines = [
    "# Why This Roadmap",
    "",
    `Roadmap: ${roadmap.roadmap_id}`,
    `Readiness profile: ${roadmap.profile_summary.readiness_profile || "unknown"}`,
    ""
  ];

  for (const week of roadmap.roadmap_justifications) {
    lines.push(
      `## Week ${week.week}: ${week.project}`,
      "",
      `Why this project: ${week.why_this_project}`,
      `Fit level: ${week.fit_level}`,
      `Skip impact: ${week.skip_impact}`,
      `Shortest acceptable path: ${week.shortest_acceptable_path}`,
      "",
      "What depends on it:",
      ...formatList(week.what_depends_on_it),
      "",
      "Related explanations:",
      ...week.related_explanations.map((item) => `- ${item.recommendation} (${item.importance}): ${item.why_recommended}`),
      ""
    );
  }

  lines.push(
    "## Safe to Defer",
    "",
    ...roadmap.safe_to_defer.map((item) => `- ${item.recommendation}: ${item.reason}`),
    "",
    "## AI-Ready Explanation Blocks",
    "",
    ...roadmap.ai_ready_explanation_blocks.flatMap((item) => [
      `### Week ${item.week}`,
      "",
      item.block,
      ""
    ])
  );

  return `${lines.join("\n")}\n`;
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
