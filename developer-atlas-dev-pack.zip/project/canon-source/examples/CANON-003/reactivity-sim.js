function ref(initialValue) {
  return { value: initialValue };
}

function reactive(initialObject) {
  return new Proxy(initialObject, {
    get(target, key) {
      return target[key];
    },
    set(target, key, value) {
      target[key] = value;
      return true;
    }
  });
}

function toRefs(object) {
  return Object.fromEntries(
    Object.keys(object).map((key) => [
      key,
      {
        get value() {
          return object[key];
        },
        set value(nextValue) {
          object[key] = nextValue;
        }
      }
    ])
  );
}

module.exports = { ref, reactive, toRefs };
