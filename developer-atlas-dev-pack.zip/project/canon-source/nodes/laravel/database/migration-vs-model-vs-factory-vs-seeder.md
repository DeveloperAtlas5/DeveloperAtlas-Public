# Laravel migration vs model vs factory vs seeder

## Status Metadata

- Canon ID: CANON-023
- Node ID: canon.laravel.database.migration-vs-model-vs-factory-vs-seeder
- Status: candidate
- Score: 55
- Version: 2026.1
- Batch: 05
- Level: junior/intermediate
- Source family: Laravel
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

This candidate explains when to choose migration/model/factory/seeder workflow and when to choose single-file database changes. It is intentionally draft-level and exists to broaden Atlas coverage before a future Gold hardening sprint.

## What Problem This Solves

Laravel beginners often mix schema, application data access, fake data, and seed data into the wrong layer.

## Mental Model

Migrations shape tables, models represent records, factories create fake records, and seeders put known data into the database.

## Beginner Explanation

Start by asking what job the code or concept is doing. If it matches migration/model/factory/seeder workflow, keep the decision simple; if the shape points toward single-file database changes, choose the alternative intentionally instead of guessing.

## Professional Explanation

In production, this decision affects readability, reviewability, and future changes. The best choice should make intent obvious, reduce hidden coupling, and match the conventions of the surrounding stack.

## Syntax

```text
php artisan make:migration create_posts_table
php artisan make:model Post
php artisan make:factory PostFactory
php artisan make:seeder PostSeeder
```

## Decision Guide

1. Identify the immediate problem being solved.
2. Choose migration/model/factory/seeder workflow when it matches the primary behavior.
3. Choose single-file database changes when the trade-off is clearer or the primary option would hide intent.
4. If neither option fits, step back and choose a simpler architecture or prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| migration/model/factory/seeder workflow | The main use case for this decision | Can be misused when the problem is actually different |
| single-file database changes | The most common alternative path | Can add confusion if chosen only by habit |

## When To Use The Primary Option

- Use it when the goal matches the primary behavior directly.
- Use it when it keeps the surrounding code easier to review.
- Use it when beginners can explain the result without hidden rules.

## When To Use The Alternative

- Use it when the primary option would force awkward workarounds.
- Use it when the alternative better communicates intent to the next developer.
- Use it when the project convention already points there.

## When Not To Use This Decision

- Do not use this decision as a substitute for understanding the underlying system.
- Do not choose either side just because an AI assistant suggested it without context.
- Do not harden this candidate until official sources, examples, and verification are added.

## Alternatives

- Use an adjacent Canon node when the real issue is a prerequisite concept.
- Use project conventions when both options are technically acceptable.

## Production Examples

### Example 1

```text
Draft example: apply this decision in a small production-like feature before hardening.
```

### Example 2

```text
Draft example: show the most common misuse and the clearer alternative.
```

## Common Mistakes

- Choosing by habit instead of intent.
- Copying an answer without checking project constraints.
- Treating this candidate as Gold before evidence and verification are complete.

## Debugging Checklist

- Confirm the current behavior matches the intended decision.
- Check whether a simpler related node explains the confusion first.
- Look for hidden assumptions in generated or copied code.

## Mechanical Verification

Runnable examples should live in `canon/examples/CANON-023/` during a future hardening sprint. This candidate intentionally has no runnable examples yet.

## Performance Notes

Performance guidance is not finalized for this candidate. Future hardening should separate real performance concerns from premature optimization.

## AI Coding Guidance

- Ask for the user's goal before choosing between migration/model/factory/seeder workflow and single-file database changes.
- Prefer the option that makes the code easiest to explain and maintain.
- Mention trade-offs instead of presenting one side as universally better.

## Teaching Notes

Teach the mental model first, then show the decision table, then practice with one small realistic task. Keep the first exercise narrow enough that the learner can finish it without context switching.

## Interview Questions

1. What problem does migration/model/factory/seeder workflow solve better than the alternative?
2. What mistake would make single-file database changes the better choice?

## Exercises

### Beginner

Explain the difference in one paragraph and identify one safe beginner use case.

### Intermediate

Refactor a small example where the wrong choice hides intent.

### Advanced

Write a short review note explaining the trade-off to another developer.

## Related Atlas Nodes

- `CANON-014`
- `CANON-018`
- `laravel.migration`

## Evidence And Sources

- Official source URL to be added during Gold hardening.

## Proof Of Superiority Summary

Atlas should improve on normal documentation by turning reference facts into a practical decision, but this candidate still needs evidence, verification, and editorial review.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 12 |
| beginner_teaching | 15 | 8 |
| professional_depth | 15 | 7 |
| decision_guidance | 15 | 9 |
| production_examples | 10 | 5 |
| ai_readiness | 10 | 5 |
| evidence | 5 | 2 |
| relationships | 5 | 3 |
| exercises | 3 | 2 |
| readability | 2 | 2 |
| Total | 100 | 55 |
