const examples = [
  ["filter active users", require("./filter-active-users")],
  ["filter products by search text", require("./filter-products-by-search-text")],
  ["mistake: using filter() when find() is needed", require("./mistake-filter-when-find-needed")],
  ["mistake: using filter() for transformation instead of map()", require("./mistake-filter-for-transformation")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-009 example(s).`);
