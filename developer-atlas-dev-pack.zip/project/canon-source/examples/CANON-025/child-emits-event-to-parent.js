const assert = require("assert");

module.exports = function childEmitsEventToParent() {
  const parentState = {
    todo: { id: 1, text: "Practice emits", done: false }
  };

  function emit(eventName, payload) {
    if (eventName === "toggle") {
      parentState.todo.done = payload.done;
    }
  }

  function TodoItem(props, emitEvent) {
    emitEvent("toggle", { id: props.todo.id, done: !props.todo.done });
  }

  TodoItem({ todo: parentState.todo }, emit);

  assert.strictEqual(parentState.todo.done, true);
};
