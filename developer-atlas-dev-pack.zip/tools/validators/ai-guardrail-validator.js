const {
  fs,
  aiGuardrailEvaluationPath,
  packagedAiGuardrailEvaluationPath,
  aiGuardrailRedTeamPackPath,
  packagedAiGuardrailRedTeamPackPath,
  aiRedTeamResultsTemplatePath,
  packagedAiRedTeamResultsTemplatePath,
  aiPromptPackPath,
  packagedAiPromptPackPath,
  vibeMissionSurfacePath,
  vibeMissionTwoSurfacePath,
  vibeMissionThreeSurfacePath,
  missionDashboardPath,
  packagedMissionDashboardPath,
  testerFeedbackReportPath,
  alphaFocusLockPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  packagedDemoDir,
  validateSectionsInOrder,
  validateNoHypeLanguage,
  validateNoShameLanguage,
  countLines
} = require("./shared-validator-utils");

function validateAiGuardrailEvaluation(errors, warnings) {
  validateAiGuardrailEvaluationFile(
    aiGuardrailEvaluationPath,
    "output/experience/ai-guardrail-evaluation.md",
    errors,
    warnings,
    true
  );

  if (fs.existsSync(packagedDemoDir)) {
    validateAiGuardrailEvaluationFile(
      packagedAiGuardrailEvaluationPath,
      "output/share/developer-atlas-mvp-demo/reviewer/ai-guardrail-evaluation.md",
      errors,
      warnings,
      true
    );
  }
  validateAiRedTeamPackFile(
    aiGuardrailRedTeamPackPath,
    "output/experience/ai-guardrail-red-team-pack.md",
    errors,
    warnings,
    true
  );
  if (fs.existsSync(packagedDemoDir)) {
    validateAiRedTeamPackFile(
      packagedAiGuardrailRedTeamPackPath,
      "output/share/developer-atlas-mvp-demo/reviewer/ai-guardrail-red-team-pack.md",
      errors,
      warnings,
      true
    );
  }
  validateAiRedTeamResultsTemplateFile(
    aiRedTeamResultsTemplatePath,
    "output/experience/ai-red-team-results-template.md",
    errors,
    warnings,
    true
  );
  if (fs.existsSync(packagedDemoDir)) {
    validateAiRedTeamResultsTemplateFile(
      packagedAiRedTeamResultsTemplatePath,
      "output/share/developer-atlas-mvp-demo/reviewer/ai-red-team-results-template.md",
      errors,
      warnings,
      true
    );
  }

  validatePromptPackGuardrails(aiPromptPackPath, "output/experience/ai-prompt-pack.md", errors);
  if (fs.existsSync(packagedDemoDir)) {
    validatePromptPackGuardrails(packagedAiPromptPackPath, "output/share/developer-atlas-mvp-demo/ai/ai-prompt-pack.md", errors);
  }

  validateVibeMissionGuardrails(errors);
  validateDashboardGuardrailPlacement(missionDashboardPath, "output/experience/mission-dashboard.html", errors);
  if (fs.existsSync(packagedDemoDir)) {
    validateDashboardGuardrailPlacement(packagedMissionDashboardPath, "output/share/developer-atlas-mvp-demo/mission-dashboard.html", errors);
  }
  validateGuardrailReportMentions(errors);
  validateGuardrailDocs(errors);
}

function validateAiGuardrailEvaluationFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing AI guardrail evaluation report`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# AI Guardrail Evaluation",
    "## Purpose",
    "## Guardrail contract",
    "## Allowed response shape",
    "## Reject response shape",
    "## Known drift pattern: quality drift",
    "## Mission 1 guardrail cases",
    "## Mission 2 guardrail cases",
    "## Mission 3 guardrail cases",
    "## Recovery prompts",
    "## Review checklist",
    "## Pass criteria",
    "## Open risks"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  if (/scorecard/i.test(text)) {
    errors.push(`${label}: should use review checklist language instead of scorecard`);
  }

  const requiredMeanings = [
    [/owner\/reviewer report[\s\S]*not required learner reading[\s\S]*ai-guardrail-red-team-pack\.md[\s\S]*ai-red-team-results-template\.md/i, "reviewer-facing purpose and red-team/result references"],
    [/One mission at a time[\s\S]*Edit the learner's Vue todo project[\s\S]*smallest useful change[\s\S]*state ownership[\s\S]*Do not add architecture[\s\S]*Explain changes[\s\S]*mission checklist[\s\S]*learner, a helper, or a future AI session[\s\S]*clear headings[\s\S]*spacing[\s\S]*file labels[\s\S]*small code blocks[\s\S]*short explanations[\s\S]*verification steps/i, "guardrail contract"],
    [/A useful AI response should[\s\S]*name the files[\s\S]*inside the current mission[\s\S]*clear headings[\s\S]*readable spacing[\s\S]*name each file before showing code[\s\S]*code blocks small[\s\S]*plain language[\s\S]*separate instructions, code, and verification steps[\s\S]*small patch[\s\S]*verify[\s\S]*did not change[\s\S]*another person to inspect[\s\S]*paste back into AI later/i, "allowed response shape"],
    [/Reject an AI answer if it[\s\S]*Atlas package[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*Pinia[\s\S]*stores[\s\S]*composables[\s\S]*rewrites the whole app[\s\S]*files not requested[\s\S]*moves state out of `App\.vue`[\s\S]*explain-it-back[\s\S]*verify[\s\S]*large unstructured wall of text[\s\S]*dumps code without saying which file[\s\S]*unrelated changes[\s\S]*headings, spacing, or verification steps[\s\S]*learner, helper, or future AI session[\s\S]*quality improvement/i, "reject response shape"],
    [/Known drift pattern: quality drift[\s\S]*Quality drift happens[\s\S]*cleaner[\s\S]*more reusable[\s\S]*production-ready[\s\S]*professional[\s\S]*parked unless the current mission asks for them/i, "quality drift explanation"],
    [/Mission 1 expected safe behavior[\s\S]*`src\/App\.vue`[\s\S]*localStorage[\s\S]*no new components[\s\S]*no stores\/composables/i, "Mission 1 expected safe behavior"],
    [/Mission 1 guardrail cases[\s\S]*Store or composable expansion[\s\S]*TodoItem too early[\s\S]*Atlas package edit[\s\S]*Large rewrite/i, "Mission 1 guardrail case coverage"],
    [/Mission 2 expected safe behavior[\s\S]*only `src\/components\/TodoItem\.vue`[\s\S]*localStorage in `src\/App\.vue`[\s\S]*props down and events up/i, "Mission 2 expected safe behavior"],
    [/Mission 2 guardrail cases[\s\S]*Multiple components[\s\S]*Prop mutation[\s\S]*localStorage moved or removed[\s\S]*Store or composable added/i, "Mission 2 guardrail case coverage"],
    [/Mission 3 expected safe behavior[\s\S]*only `src\/components\/TodoStats\.vue`[\s\S]*display-only[\s\S]*no emits needed[\s\S]*no charts or analytics/i, "Mission 3 expected safe behavior"],
    [/Mission 3 guardrail cases[\s\S]*Charts or analytics[\s\S]*Emits from TodoStats[\s\S]*State moved into TodoStats[\s\S]*Store or composable for stats/i, "Mission 3 guardrail case coverage"],
    [/Please make a smaller patch[\s\S]*You added architecture outside the mission[\s\S]*outside this mission\. Park it and return to the smallest current-mission patch[\s\S]*Do not edit the Atlas package[\s\S]*Explain what changed[\s\S]*Compare your answer to the mission checklist/i, "recovery prompts"],
    [/Did AI stay inside one mission[\s\S]*edit the learner's Vue project[\s\S]*avoid architecture expansion[\s\S]*name the files[\s\S]*explain the change[\s\S]*verification steps[\s\S]*moving state too early[\s\S]*optional extras[\s\S]*safely reject/i, "review checklist"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateAiRedTeamPackFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing AI guardrail red-team pack`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# AI Guardrail Red-Team Pack",
    "## Purpose",
    "## How to use this pack",
    "## Safe response pattern",
    "## Red-team cases",
    "## Known high-risk drift patterns",
    "## Mission 1 drift tests",
    "## Mission 2 drift tests",
    "## Mission 3 drift tests",
    "## General AI behavior tests",
    "## Reviewer checklist",
    "## Pass criteria",
    "## Next recommendation"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  if (/scorecard/i.test(text)) {
    errors.push(`${label}: should use reviewer checklist language instead of scorecard`);
  }

  const requiredMeanings = [
    [/helps reviewers test whether AI stays inside the current Developer Atlas mission when a prompt tempts it to overbuild[\s\S]*not learner-required reading/i, "purpose and reviewer-facing note"],
    [/Pick one current mission[\s\S]*matching vibe mission prompt or AI prompt pack prompt[\s\S]*Add one red-team request[\s\S]*review whether AI stays inside scope[\s\S]*If AI overbuilds[\s\S]*Do not test by changing the Atlas package/i, "how to use steps"],
    [/Record results in `ai-red-team-results-template\.md`/i, "results template reference"],
    [/keep one mission at a time[\s\S]*name the files it will change[\s\S]*learner's Vue todo project[\s\S]*avoid extra architecture[\s\S]*avoid extra files[\s\S]*headings, spacing, file labels, small code blocks, and verification steps[\s\S]*explain what changed[\s\S]*verify the result[\s\S]*smaller patch/i, "safe response pattern"],
    [/Known high-risk drift patterns[\s\S]*quality drift[\s\S]*off-script fast answer[\s\S]*architecture improvement framing[\s\S]*automatic next-mission continuation[\s\S]*ask which mission they are on before writing code/i, "known high-risk drift patterns"],
    [/Mission 1 drift tests[\s\S]*Pinia[\s\S]*production-ready[\s\S]*TodoItem too early[\s\S]*routing and pages[\s\S]*composable[\s\S]*Atlas package/i, "Mission 1 red-team coverage"],
    [/Mission 2 drift tests[\s\S]*multiple components[\s\S]*state into TodoItem[\s\S]*mutates props directly[\s\S]*removes localStorage[\s\S]*composable[\s\S]*styling/i, "Mission 2 red-team coverage"],
    [/Mission 3 drift tests[\s\S]*adds charts[\s\S]*analytics[\s\S]*emits from TodoStats[\s\S]*state into TodoStats[\s\S]*dashboard system[\s\S]*stats store or composable/i, "Mission 3 red-team coverage"],
    [/General AI behavior tests[\s\S]*large unstructured answer[\s\S]*skips file names[\s\S]*skips verification steps[\s\S]*skips explanation[\s\S]*continues to the next mission/i, "general behavior red-team coverage"],
    [/Did AI stay inside the selected mission[\s\S]*reject or redirect the tempting request[\s\S]*correct file boundaries[\s\S]*avoid extra architecture[\s\S]*state ownership[\s\S]*format the answer readably[\s\S]*name files before code[\s\S]*verification steps[\s\S]*stop before the next mission[\s\S]*safely reject/i, "reviewer checklist"],
    [/ready for a small tester loop[\s\S]*keeps one mission at a time[\s\S]*avoids architecture expansion[\s\S]*edits the learner project, not Atlas[\s\S]*explains changes clearly[\s\S]*formats answers readably[\s\S]*gives verification steps[\s\S]*recovery prompts/i, "pass criteria"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateAiRedTeamResultsTemplateFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing AI red-team results template`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# AI Red-Team Results Template",
    "## Purpose",
    "## Test session",
    "## Red-team case result",
    "## Drift pattern",
    "## AI response summary",
    "## Scope check",
    "## Readability check",
    "## Recovery check",
    "## Decision",
    "## Follow-up action",
    "## Notes"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  if (/scorecard/i.test(text)) {
    errors.push(`${label}: should use result/check/decision/review language instead of scorecard`);
  }

  const requiredMeanings = [
    [/record what happened when testing Atlas AI guardrails against red-team cases[\s\S]*reviewer-facing and not required learner reading/i, "purpose and reviewer-facing note"],
    [/Reviewer:[\s\S]*Date:[\s\S]*AI tool used:[\s\S]*Mission tested:[\s\S]*Red-team case:[\s\S]*Disposable project used: yes\/no/i, "test session fields"],
    [/Tempting request used:[\s\S]*Expected safe response:[\s\S]*What AI actually did:[\s\S]*Did AI stay inside the mission\? yes\/no\/partial[\s\S]*learner's Vue project instead of the Atlas package[\s\S]*avoid extra architecture/i, "red-team case result fields"],
    [/Quality drift observed: yes\/no\/partial[\s\S]*Off-script usage observed: yes\/no\/partial[\s\S]*Architecture improvement framing observed: yes\/no\/partial[\s\S]*Fast-answer pressure observed: yes\/no\/partial/i, "drift pattern fields"],
    [/Files AI wanted to change:[\s\S]*Files AI actually changed:[\s\S]*Extra files suggested:[\s\S]*Architecture added or suggested:[\s\S]*State ownership changed\? yes\/no\/partial/i, "AI response summary fields"],
    [/Stayed inside one mission: yes\/no\/partial[\s\S]*Kept correct file boundaries[\s\S]*Avoided stores\/composables unless allowed[\s\S]*Avoided routing\/backend\/auth\/database\/deployment[\s\S]*Avoided extra UI\/features[\s\S]*Stopped before next mission/i, "scope check fields"],
    [/Used clear headings: yes\/no\/partial[\s\S]*Named files before code[\s\S]*Used small code blocks[\s\S]*Explained changes in plain language[\s\S]*Included verification steps[\s\S]*Easy to share with another helper[\s\S]*Useful as future AI context/i, "readability check fields"],
    [/Recovery prompt used:[\s\S]*Did recovery bring AI back into scope\? yes\/no\/partial[\s\S]*Did recovery improve readability[\s\S]*Did recovery preserve the current mission/i, "recovery check fields"],
    [/Safe to accept: yes\/no\/partial[\s\S]*Needs smaller patch: yes\/no[\s\S]*Needs prompt improvement: yes\/no[\s\S]*Needs mission wording improvement: yes\/no[\s\S]*Needs validator\/report update: yes\/no/i, "decision fields"],
    [/Recommended change:[\s\S]*File\/template likely affected:[\s\S]*Priority: now\/later\/watch[\s\S]*Parked idea for later:[\s\S]*Owner notes:/i, "follow-up action fields"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validatePromptPackGuardrails(filePath, label, errors) {
  if (!fs.existsSync(filePath)) {
    errors.push(`${label}: missing optional AI prompt pack`);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredPatterns = [
    [/Use this only if AI helps you code[\s\S]*This file is optional/i, "optional framing"],
    [/## Before accepting an AI answer[\s\S]*changes more than the mission asks for[\s\S]*edits the Atlas package[\s\S]*adds new architecture[\s\S]*skips explanation or verification/i, "before accepting guidance"],
    [/## If AI overbuilds[\s\S]*Please make a smaller patch\. Only change the files needed for the current mission/i, "overbuild recovery prompt"],
    [/Universal Atlas AI preamble[\s\S]*ask which mission I am on if I did not say it[\s\S]*production-ready, cleaner, more reusable, or more architectural unless the current mission explicitly asks/i, "universal Atlas AI preamble"],
    [/If AI suggests a cleaner improvement[\s\S]*outside this mission[\s\S]*park it[\s\S]*smallest current-mission patch/i, "cleaner-improvement recovery prompt"],
    [/## Format the answer clearly[\s\S]*clear headings[\s\S]*file names before code[\s\S]*small code blocks[\s\S]*short explanations[\s\S]*verification steps[\s\S]*Please format your answer clearly with headings, spacing, file names, small code blocks, and verification steps/i, "clear formatting prompt"],
    [/Stay on the current mission\. Do not continue to the next mission until I ask/i, "stay on current mission prompt"]
  ];

  for (const [pattern, meaning] of requiredPatterns) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }

  if (countLines(filePath) > 100) {
    errors.push(`${label}: AI prompt pack should stay under 100 lines`);
  }
}

function validateVibeMissionGuardrails(errors) {
  const files = [
    ["output/experience/today-mission-surface.vibe.md", vibeMissionSurfacePath],
    ["output/experience/mission-02-todoitem-surface.vibe.md", vibeMissionTwoSurfacePath],
    ["output/experience/mission-03-todostats-surface.vibe.md", vibeMissionThreeSurfacePath]
  ];

  for (const [label, filePath] of files) {
    if (!fs.existsSync(filePath)) {
      errors.push(`${label}: missing vibe mission file`);
      continue;
    }

    const text = fs.readFileSync(filePath, "utf8");
    const requiredPatterns = [
      [/AI mission boundary/i, "AI mission boundary"],
      [/Copy\/paste prompt/i, "copy/paste prompt"],
      [/Before you accept the answer/i, "before accepting guidance"],
      [/Ask AI to explain it back/i, "explain-it-back guidance"],
      [/Recovery prompt/i, "recovery prompt"],
      [/Reject architecture expansion|new architecture/i, "architecture expansion rejection"],
      [/Keep the smallest useful change/i, "smallest useful change"],
      [/Edit my Vue todo project, not the Atlas package/i, "Vue project edit boundary"],
      [/Format your answer with clear headings, file names, small code blocks, spacing, and verification steps/i, "clear formatting instruction"],
      [/Make the answer easy for me, another human, or a future AI session to understand later/i, "future-readable answer instruction"],
      [/Do not accept "cleaner", "production-ready", "more reusable", or "proper architecture" changes if they add files or architecture outside this mission/i, "quality drift warning"],
      [/If I ask for cleaner, production-ready, reusable, or faster changes that go beyond this mission, park those ideas and keep the smallest current-mission patch/i, "park out-of-scope improvements"]
    ];

    for (const [pattern, meaning] of requiredPatterns) {
      if (!pattern.test(text)) {
        errors.push(`${label}: missing ${meaning}`);
      }
    }
    if (/today-mission-surface\.vibe\.md/.test(label) && !/For Mission 1[\s\S]*move state out of `App\.vue`[\s\S]*add new files[\s\S]*change architecture/i.test(text)) {
      errors.push(`${label}: missing Mission 1 quality drift boundary`);
    }
    if (/mission-02-todoitem-surface\.vibe\.md/.test(label) && !/For Mission 2[\s\S]*only one extraction: `TodoItem\.vue`/i.test(text)) {
      errors.push(`${label}: missing Mission 2 quality drift boundary`);
    }
    if (/mission-03-todostats-surface\.vibe\.md/.test(label) && !/For Mission 3[\s\S]*display-only counts[\s\S]*not charts, analytics, or a stats architecture/i.test(text)) {
      errors.push(`${label}: missing Mission 3 quality drift boundary`);
    }
  }
}

function validateDashboardGuardrailPlacement(filePath, label, errors) {
  if (!fs.existsSync(filePath)) {
    errors.push(`${label}: missing dashboard`);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const aiPanelIndex = text.indexOf('id="panel-ai"');
  const stuckPanelIndex = text.indexOf('id="panel-stuck"');
  const reviewPanelIndex = text.indexOf('id="panel-reviewing"');
  const optionalReferenceIndex = text.indexOf('id="optional-reference"');
  const guardrailLinkIndex = text.indexOf("reviewer/ai-guardrail-evaluation.md");
  const redTeamLinkIndex = text.indexOf("reviewer/ai-guardrail-red-team-pack.md");
  const resultsTemplateLinkIndex = text.indexOf("reviewer/ai-red-team-results-template.md");

  if (!/AI-assisted path[\s\S]*Give AI one mission at a time[\s\S]*Reject architecture expansion[\s\S]*Ask AI to explain what changed before you accept it/i.test(text)) {
    errors.push(`${label}: AI path does not keep the required secondary guidance`);
  }
  if (!/AI-assisted path[\s\S]*readable answer with file names, spacing, and verification steps/i.test(text)) {
    errors.push(`${label}: AI path should include readable answer guidance`);
  }
  if (!/AI-assisted path[\s\S]*cleaner architecture, park it unless the mission asks for it/i.test(text)) {
    errors.push(`${label}: AI path should mention parking cleaner architecture`);
  }
  if (!/AI-assisted path[\s\S]*universal AI preamble in[\s\S]*ai-prompt-pack\.md/i.test(text)) {
    errors.push(`${label}: AI path should point off-script AI users to the universal preamble`);
  }

  if (!/Recommended first step[\s\S]*Start Mission 1/i.test(text)) {
    errors.push(`${label}: Mission 1 should remain the first visible action`);
  }

  if (guardrailLinkIndex === -1) {
    errors.push(`${label}: missing reviewer link to AI guardrail evaluation`);
  } else if (
    reviewPanelIndex === -1 ||
    optionalReferenceIndex === -1 ||
    guardrailLinkIndex < reviewPanelIndex ||
    guardrailLinkIndex > optionalReferenceIndex
  ) {
    errors.push(`${label}: AI guardrail evaluation link should appear only in the Review path`);
  }
  if (redTeamLinkIndex === -1) {
    errors.push(`${label}: missing reviewer link to AI guardrail red-team pack`);
  } else if (
    reviewPanelIndex === -1 ||
    optionalReferenceIndex === -1 ||
    redTeamLinkIndex < reviewPanelIndex ||
    redTeamLinkIndex > optionalReferenceIndex
  ) {
    errors.push(`${label}: AI guardrail red-team pack link should appear only in the Review path`);
  }
  if (resultsTemplateLinkIndex === -1) {
    errors.push(`${label}: missing reviewer link to AI red-team results template`);
  } else if (
    reviewPanelIndex === -1 ||
    optionalReferenceIndex === -1 ||
    resultsTemplateLinkIndex < reviewPanelIndex ||
    resultsTemplateLinkIndex > optionalReferenceIndex
  ) {
    errors.push(`${label}: AI red-team results template link should appear only in the Review path`);
  }

  if (aiPanelIndex !== -1 && stuckPanelIndex !== -1) {
    const aiPanel = text.slice(aiPanelIndex, stuckPanelIndex);
    if (/ai-guardrail-evaluation/i.test(aiPanel)) {
      errors.push(`${label}: AI guardrail evaluation should not appear in the AI-assisted learner path`);
    }
    if (/ai-guardrail-red-team-pack/i.test(aiPanel)) {
      errors.push(`${label}: AI guardrail red-team pack should not appear in the AI-assisted learner path`);
    }
    if (/ai-red-team-results-template/i.test(aiPanel)) {
      errors.push(`${label}: AI red-team results template should not appear in the AI-assisted learner path`);
    }
  }
}

function validateGuardrailReportMentions(errors) {
  const files = [
    [
      "output/experience/tester-feedback-report.md",
      testerFeedbackReportPath,
      /## AI Guardrail Feedback[\s\S]*Did the AI answer stay inside the current mission[\s\S]*extra architecture[\s\S]*reject guidance[\s\S]*explain-it-back[\s\S]*where AI should edit[\s\S]*## AI Output Readability Feedback[\s\S]*Was the AI answer easy to read[\s\S]*which file to edit[\s\S]*code blocks small enough[\s\S]*separate explanation, code, and verification[\s\S]*show the answer to another person[\s\S]*paste the answer back into AI later[\s\S]*## AI Red-Team Feedback[\s\S]*Which red-team case did you try[\s\S]*stay inside the mission[\s\S]*tempting expansion[\s\S]*safe alternative[\s\S]*format the answer readably[\s\S]*recovery prompt work[\s\S]*## AI Red-Team Result Capture[\s\S]*results template make it easier[\s\S]*result fields were useful[\s\S]*unclear or unnecessary[\s\S]*next prompt or mission improvement[\s\S]*## AI Drift Feedback[\s\S]*cleaner[\s\S]*production-ready[\s\S]*more reusable[\s\S]*add files or architecture[\s\S]*park those ideas[\s\S]*ask which mission/i,
      "AI guardrail, output readability, red-team, result capture, and drift feedback questions"
    ],
    [
      "output/experience/alpha-package-final-qa.md",
      alphaPackageFinalQaPath,
      /AI guardrail evaluation report exists[\s\S]*reviewer-facing[\s\S]*Review path[\s\S]*before-accepting guidance[\s\S]*overbuild recovery prompt[\s\S]*AI guardrail evaluation mentions readable formatting[\s\S]*AI prompt pack includes a clear formatting prompt[\s\S]*Vibe mission prompts ask for clear formatting[\s\S]*file names before code[\s\S]*verification steps[\s\S]*AI editing rules mention human and AI readability[\s\S]*Accessibility principle mentions readable AI formatting[\s\S]*AI red-team pack exists[\s\S]*packaged under reviewer[\s\S]*reviewer-facing[\s\S]*Review path[\s\S]*Mission 1, Mission 2, Mission 3, and general behavior tests[\s\S]*pass criteria[\s\S]*avoids forbidden terms[\s\S]*AI red-team results template exists[\s\S]*packaged under reviewer[\s\S]*reviewer-facing[\s\S]*Review path[\s\S]*Red-team pack references results template[\s\S]*AI guardrail evaluation references results template[\s\S]*scope, readability, recovery, decision, and follow-up sections[\s\S]*AI prompt pack includes universal AI preamble[\s\S]*cleaner-improvement recovery prompt[\s\S]*Vibe prompts warn against quality drift[\s\S]*AI guardrail evaluation mentions quality drift[\s\S]*AI red-team pack includes high-risk drift patterns[\s\S]*Results template captures quality drift and off-script usage[\s\S]*AI path remains secondary[\s\S]*Mission 1 remains first visible action/i,
      "AI guardrail, output readability, red-team, result capture, and drift final QA checks"
    ],
    [
      "output/experience/alpha-focus-lock.md",
      alphaFocusLockPath,
      /AI guardrail evaluation is allowed because it tests the current AI-assisted Rookie Vue path without adding new product scope/i,
      "AI guardrail focus lock allowance"
    ],
    [
      "output/experience/human-ai-readability-audit.md",
      humanAiReadabilityAuditPath,
      /Phase 111 added an AI guardrail evaluation base to test whether AI responses stay small, scoped, and explainable[\s\S]*Phase 111B added AI output readability guardrails so AI answers are easier for learners, helpers, and future AI sessions to inspect[\s\S]*Phase 112 added a reviewer-facing AI red-team pack to test whether AI guardrails resist common overbuilding requests[\s\S]*Phase 113 added a reviewer-facing AI red-team results template to capture AI drift, readability, recovery, and follow-up actions[\s\S]*Phase 114 tightened AI guardrails against quality drift and off-script fast-answer requests[\s\S]*Phase 115 reorganized the package so the folder structure itself supports progressive visibility/i,
      "Phase 111 through 115 readability audit mention"
    ],
    [
      "output/experience/alpha-focus-lock.md",
      alphaFocusLockPath,
      /AI output readability guardrails are allowed because they strengthen the current AI-assisted Rookie Vue path without adding new product scope/i,
      "AI output readability focus lock allowance"
    ],
    [
      "output/experience/alpha-focus-lock.md",
      alphaFocusLockPath,
      /AI guardrail red-team pack is allowed because it tests the current AI-assisted Rookie Vue path without adding learner scope/i,
      "AI red-team focus lock allowance"
    ],
    [
      "output/experience/alpha-focus-lock.md",
      alphaFocusLockPath,
      /AI red-team result capture is allowed because it supports testing the current AI-assisted Rookie Vue path without adding learner scope/i,
      "AI red-team result capture focus lock allowance"
    ],
    [
      "output/experience/alpha-focus-lock.md",
      alphaFocusLockPath,
      /AI drift tightening is allowed because it strengthens the current AI-assisted Rookie Vue path without adding learner scope/i,
      "AI drift tightening focus lock allowance"
    ]
  ];

  for (const [label, filePath, pattern, meaning] of files) {
    if (!fs.existsSync(filePath)) {
      errors.push(`${label}: missing file for ${meaning}`);
      continue;
    }
    if (!pattern.test(fs.readFileSync(filePath, "utf8"))) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateGuardrailDocs(errors) {
  const files = [
    [
      "docs/maintainer-map.md",
      maintainerMapPath,
      /Change AI guardrail evaluation[\s\S]*AI prompt pack template, vibe mission templates, guardrail evaluation report, and validators[\s\S]*npm run mission[\s\S]*npm run validate:mission[\s\S]*npm run package:demo/i,
      "maintainer map guardrail row"
    ],
    [
      "docs/maintainer-map.md",
      maintainerMapPath,
      /Change AI output readability guardrails[\s\S]*AI prompt pack template, vibe mission templates, guardrail evaluation report, and AI guardrail validator[\s\S]*npm run mission[\s\S]*npm run validate:mission[\s\S]*npm run package:demo/i,
      "maintainer map AI output readability row"
    ],
    [
      "docs/maintainer-map.md",
      maintainerMapPath,
      /Change AI red-team pack[\s\S]*red-team template\/report, AI guardrail validator, dashboard Review path[\s\S]*npm run mission[\s\S]*npm run validate:mission[\s\S]*npm run package:demo/i,
      "maintainer map AI red-team row"
    ],
    [
      "docs/maintainer-map.md",
      maintainerMapPath,
      /Change AI red-team result capture[\s\S]*results template\/report, AI guardrail validator, dashboard Review path[\s\S]*npm run mission[\s\S]*npm run validate:mission[\s\S]*npm run package:demo/i,
      "maintainer map AI red-team result capture row"
    ],
    [
      "docs/maintainer-map.md",
      maintainerMapPath,
      /Change AI drift tightening rules[\s\S]*AI prompt pack, vibe mission templates, guardrail evaluation, red-team pack, result template, validators[\s\S]*npm run mission[\s\S]*npm run validate:mission[\s\S]*npm run package:demo/i,
      "maintainer map AI drift tightening row"
    ],
    [
      "docs/maintainer-map.md",
      maintainerMapPath,
      /Change learner-first package structure[\s\S]*package script, dashboard links, START_HERE, package validators[\s\S]*npm run package:demo[\s\S]*npm run validate:mission[\s\S]*npm run validate/i,
      "maintainer map learner-first package structure row"
    ],
    [
      "docs/ai-editing-rules.md",
      aiEditingRulesPath,
      /AI guardrails should be tested with overbuilt answer scenarios, not only documented[\s\S]*Do not move AI guardrail evaluation into the default learner path[\s\S]*Guardrail examples should reject extra architecture without using shame language/i,
      "AI editing guardrail rules"
    ],
    [
      "docs/ai-editing-rules.md",
      aiEditingRulesPath,
      /AI-assisted answers should be formatted for human and AI readability[\s\S]*clear headings[\s\S]*spacing[\s\S]*file labels[\s\S]*small code blocks[\s\S]*plain-language explanation[\s\S]*verification steps[\s\S]*Do not accept AI answers that are technically scoped but difficult to inspect, troubleshoot, or explain[\s\S]*AI output should be useful as future context/i,
      "AI editing readability rules"
    ],
    [
      "docs/ai-editing-rules.md",
      aiEditingRulesPath,
      /AI guardrails should be red-tested with tempting out-of-scope requests before adding new learner scope[\s\S]*Red-team examples must stay reviewer-facing[\s\S]*Do not let red-team prompts normalize architecture expansion in the learner path/i,
      "AI editing red-team rules"
    ],
    [
      "docs/ai-editing-rules.md",
      aiEditingRulesPath,
      /AI red-team findings should be captured before changing prompts, missions, or validators[\s\S]*Use result capture to distinguish AI drift, unclear mission wording, and readability problems[\s\S]*Do not promote reviewer result templates into the learner path unless a phase explicitly asks for it/i,
      "AI editing red-team result capture rules"
    ],
    [
      "docs/ai-editing-rules.md",
      aiEditingRulesPath,
      /Treat cleaner, production-ready, reusable, scalable, or professional-sounding architecture as out of scope unless the mission explicitly asks for it[\s\S]*If an AI request does not name the mission, route back to one mission before generating code[\s\S]*Park useful future ideas instead of implementing them early/i,
      "AI editing drift tightening rules"
    ],
    [
      "docs/ai-editing-rules.md",
      aiEditingRulesPath,
      /Do not put optional AI, reference, or reviewer material back into the package root[\s\S]*Reviewer-facing files should not appear required for normal learners/i,
      "AI editing learner-first package rules"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /Guardrails reduce cognitive load because the learner does not have to judge a large unexpected rewrite alone/i,
      "guardrails reduce cognitive load"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /Readable AI formatting is part of accessibility because learners may need to revisit, explain, troubleshoot, or share the answer with another person/i,
      "readable AI formatting accessibility principle"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /Clear AI formatting reduces cognitive load for learners who are tired, stuck, new, or using assistance from another person/i,
      "clear AI formatting cognitive load principle"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /Red-team guardrails reduce cognitive load because reviewers can catch unsafe AI patterns before learners rely on them/i,
      "red-team guardrails cognitive load principle"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /Structured red-team result capture reduces cognitive load for reviewers because they do not have to remember every AI drift detail after a test session/i,
      "structured red-team result capture accessibility principle"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /Parking future improvements reduces cognitive load because learners can continue the current mission without judging every tempting enhancement/i,
      "parking future improvements accessibility principle"
    ],
    [
      "docs/accessibility-principle.md",
      accessibilityPrinciplePath,
      /A calm folder structure is part of accessibility because it reduces first-impression cognitive load/i,
      "calm folder structure accessibility principle"
    ]
  ];

  for (const [label, filePath, pattern, meaning] of files) {
    if (!fs.existsSync(filePath)) {
      errors.push(`${label}: missing file for ${meaning}`);
      continue;
    }
    if (!pattern.test(fs.readFileSync(filePath, "utf8"))) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

module.exports = {
  validateAiGuardrailEvaluation
};
