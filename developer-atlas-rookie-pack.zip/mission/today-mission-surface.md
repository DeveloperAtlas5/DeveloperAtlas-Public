# Mission 1 - Make your to-do list stay saved after you refresh the page

## Before you start

This Rookie Pack starts after your basic Vue to-do project already exists.

You need a basic Vue to-do project already open in VS Code.

If your Vue project is not created yet, stop here and get the starter project first.

Atlas is where you read.

Your Vue project is where you code.

First action: open your Vue project.

In normal text, this guide says "to-do". In code, you may see `todo` or `todos` as variable names.

## What you will do

- Find where your to-do items are stored.
- Save to-do items to `localStorage` when they change.
- Load saved to-do items when the app starts.
- Refresh the browser and check that a to-do item is still there.

## Where you will code

You will make the change in your Vue project, not in the Atlas files.

For many small Vue projects, the first file to check is `src/App.vue`.

## Step 1 - Open your Vue project

Open your Vue project.

Open `src/App.vue`.

Find where your to-do items are stored. In code, this may look like `ref([])`, `reactive(...)`, or a variable named `todos`.

Do not move files around for this mission.

## Step 2 - Save to-do items

After your app adds, removes, edits, or completes a to-do item, save the current list.

Use one storage key, for example:

```js
localStorage.setItem("todos", JSON.stringify(todos.value))
```

If your code does not use the name `todos`, use your app's actual variable name.

## Step 3 - Load to-do items after refresh

When the app starts, read the saved value before showing the list.

Use a safe fallback so the app still opens when nothing is saved yet.

```js
const savedTodos = localStorage.getItem("todos")
const todos = ref(savedTodos ? JSON.parse(savedTodos) : [])
```

Match this to your existing code. The exact line may need to change if your app already creates the list differently.

## Check your work

- Run `npm run dev` if the app is not already running.
- Add one to-do item.
- Refresh the browser.
- Confirm the to-do item is still visible.
- Complete or remove a to-do item if your app supports it.
- Refresh again.

Visible win: your to-do list stays saved after you refresh the page.

## If you get stuck

- To-do items disappear after refresh: make sure you load once when the app starts and save again after each list change.
- `[object Object]` appears: use `JSON.stringify()` before saving arrays or objects.
- JSON error: clear the saved value in the browser and try again.
- Terminal feels confusing: open `help/terminal-confidence-guide.md`.

## Extra context

Vue state is the data your page is using right now. If the state changes, the page updates.

For this mission, your to-do items are in Vue state while the page is open. `localStorage` lets them stay saved after refresh.

`localStorage` is browser storage for small, non-sensitive data.

Use it here because your to-do items should still be there after refresh.

Do not store passwords, tokens, secrets, or private personal information in browser storage.
