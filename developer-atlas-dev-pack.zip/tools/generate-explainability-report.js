const fs = require("fs");
const path = require("path");
const {
  explainabilityOutputDir,
  ensureExplainabilityOutputDir,
  readExplanations,
  countValues
} = require("./explainability-utils");

function main() {
  const explanations = readExplanations().map((record) => record.explanation);
  const report = buildReport(explanations);

  ensureExplainabilityOutputDir();
  fs.writeFileSync(
    path.join(explainabilityOutputDir, "explainability-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(explainabilityOutputDir, "explainability-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/explainability/explainability-report.json with ${explanations.length} explanation(s).`);
  console.log("Generated output/explainability/explainability-report.md.");
}

function buildReport(explanations) {
  const highestSkipImpact = [...explanations].sort(bySkipImpact)[0] || null;
  const safestToDefer = explanations
    .filter((item) => item.importance === "defer" || item.can_learn_later)
    .sort((a, b) => importanceRank(a.importance) - importanceRank(b.importance) || b.confidence - a.confidence)[0] || null;

  return {
    explanations_created: explanations.length,
    counts_by_importance: countValues(explanations.map((item) => item.importance)),
    counts_by_type: countValues(explanations.map((item) => item.recommendation_type)),
    recommendations_with_highest_skip_impact: highestSkipImpact ? [summarize(highestSkipImpact)] : [],
    recommendations_safe_to_defer: safestToDefer ? [summarize(safestToDefer)] : [],
    ai_ready_explanation_blocks: explanations.map((item) => ({
      explanation_id: item.explanation_id,
      block: `${item.recommendation} is ${item.importance}. Why: ${item.why_recommended} Skip impact: ${item.skip_impact} Shortest path: ${item.shortest_acceptable_path}`
    }))
  };
}

function summarize(item) {
  return {
    explanation_id: item.explanation_id,
    recommendation: item.recommendation,
    importance: item.importance,
    skip_impact: item.skip_impact,
    shortest_acceptable_path: item.shortest_acceptable_path,
    confidence: item.confidence
  };
}

function bySkipImpact(a, b) {
  return importanceRank(b.importance) - importanceRank(a.importance) || b.confidence - a.confidence;
}

function importanceRank(level) {
  return { defer: 0, optional: 1, recommended: 2, essential: 3 }[level] ?? 0;
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Explainability Report",
    "",
    `Explanations created: ${report.explanations_created}`,
    "",
    "## Counts by Importance",
    "",
    ...formatCounts(report.counts_by_importance),
    "",
    "## Counts by Type",
    "",
    ...formatCounts(report.counts_by_type),
    "",
    "## Highest Skip Impact",
    "",
    ...formatSummaries(report.recommendations_with_highest_skip_impact),
    "",
    "## Safe to Defer",
    "",
    ...formatSummaries(report.recommendations_safe_to_defer),
    "",
    "## AI-Ready Explanation Blocks",
    "",
    ...report.ai_ready_explanation_blocks.flatMap((item) => [
      `### ${item.explanation_id}`,
      "",
      item.block,
      ""
    ])
  ];

  return `${lines.join("\n")}\n`;
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

function formatSummaries(items) {
  return items.length
    ? items.map((item) => `- ${item.recommendation}: ${item.importance}. ${item.skip_impact}`)
    : ["- None"];
}

main();
