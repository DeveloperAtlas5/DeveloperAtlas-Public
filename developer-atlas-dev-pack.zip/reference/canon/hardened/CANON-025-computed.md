# CANON-025 - computed()

Status: Hardened

## Core idea

computed is for derived display values.

Use it for totals, completed count, and remaining count.

Do not use computed for side effects.

## Use this when

Use this in Mission 3 when TodoStats needs counts from todos.

## Basic pattern

Return a value based on existing state.

## Common friction

Computed values should describe data, not save data.

## Small example

```js
const remainingCount = computed(() => todos.value.filter((todo) => !todo.done).length);
```

## Check yourself

- Does the computed value return display data?
- Are saves handled somewhere else?

## Related Canon nodes

- CANON-024
- CANON-027
