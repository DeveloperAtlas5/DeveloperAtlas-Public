# Atlas Concept Library

Use this when you see a term in a mission and want a quick explanation.

Need to start a project first? See [Project Start Guides](../project-start/index.md).

A learner should be able to look up a concept without leaving the mission flow.

Atlas should explain recurring programming ideas across technologies, not make learners relearn the same idea from zero every time.

## Laravel

- [Laravel Route](laravel/route.md)
- [Laravel Controller](laravel/controller.md)
- [Laravel Model](laravel/model.md)
- [Laravel Migration](laravel/migration.md)
- [Laravel Factory](laravel/factory.md)
- [Laravel Seeder](laravel/seeder.md)
- [Laravel Relationship](laravel/relationship.md)
- [Laravel Eloquent](laravel/eloquent.md)
- [Laravel Request](laravel/request.md)
- [Laravel Validation](laravel/validation.md)
- [Laravel Middleware](laravel/middleware.md)
- [Laravel Blade](laravel/blade.md)
- [Laravel API Resource](laravel/api-resource.md)

## Vue

- [Vue Component](vue/component.md)
- [Vue Props](vue/props.md)
- [Vue Emits](vue/emits.md)
- [Vue v-model](vue/v-model.md)
- [Vue ref](vue/ref.md)
- [Vue reactive](vue/reactive.md)
- [Vue computed](vue/computed.md)
- [Vue watch](vue/watch.md)
- [Vue Router](vue/router.md)
- [Vue Store / Pinia](vue/store-pinia.md)

## Comparisons

- [Routing in Laravel vs Vue](comparisons/routing-laravel-vue.md)
- [State in Vue vs Laravel](comparisons/state-vue-laravel.md)
- [Database Relationships vs Frontend Data Relationships](comparisons/relationships-database-frontend.md)

## AI Standards

Use these when AI is helping with code.

They explain how AI should keep changes readable, small, reviewable, and aligned with the goal.

- [AI Code Readability Standard](ai-standards/ai-code-readability-standard.md)
- [AI Small Patch Standard](ai-standards/ai-small-patch-standard.md)
- [AI Explain-Before-Change Standard](ai-standards/ai-explain-before-change-standard.md)
- [AI Human Review Standard](ai-standards/ai-human-review-standard.md)
- [AI Concept Check Standard](ai-standards/ai-concept-check-standard.md)
- [AI No-Scope-Creep Standard](ai-standards/ai-no-scope-creep-standard.md)

## How to use this library

Open one card when a term blocks your current mission. Read the simple meaning first, then return to the mission.
