# CANON-013 Proof Of Superiority

Canon ID: CANON-013
Node ID: canon.vue.directive.v-for-keys
Title: v-for keys decision guide

## What Official Docs Explain Well

Vue documentation explains `v-for`, the `key` special attribute, and the need to maintain state with keys when list order changes.

## What Developers Still Struggle With

Developers often understand the syntax but miss the identity model. The visible list may look correct while hidden state is attached to the wrong item. Common production failures include:

- Form input values moving to the wrong row after sorting.
- Expanded row state following the index rather than the item.
- Duplicate keys causing unstable rendering.
- Random keys forcing remounts and destroying useful state.
- Index keys being used to silence warnings in dynamic lists.

## How Atlas Improves The Explanation

Atlas frames keys as item identity, not template decoration. It explains that stable keys identify real items, while index keys identify positions. That one distinction makes the decision teachable and reviewable.

## What Decision Support Atlas Adds

The node gives specific rules for:

- Stable ID keys.
- Stable domain keys.
- Composite primitive keys.
- Index-key exceptions.
- Duplicate and random key mistakes.
- `<template v-for>` placement.

It also explains when key choice is not enough and the data model needs real identity.

## What Production Guidance Atlas Adds

The node includes production examples for editable tables, notification transitions, static lists, and `<template v-for>`. It includes debugging checks for state drift, wrong animations, unwanted remounts, duplicate keys, and template filtering mistakes.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct generation rules:

- Prefer `:key="item.id"` when available.
- Avoid `:key="index"` for dynamic lists.
- Do not generate random keys.
- Warn about duplicate keys.
- Put keys on `<template v-for>` when appropriate.
- Explain list identity and state preservation.

## Why This Deserves Gold Candidate Status

CANON-013 deserves Gold Candidate status because it turns a subtle Vue rendering behavior into a practical identity decision model with official evidence, deterministic examples, debugging guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.
