const assert = require("node:assert/strict");

module.exports = async function runTryCatchAwaitedRejectionExample() {
  async function loadUser() {
    throw new Error("network unavailable");
  }

  let result;

  try {
    result = await loadUser();
  } catch (error) {
    result = {
      status: "failed",
      message: error.message
    };
  }

  assert.deepEqual(result, {
    status: "failed",
    message: "network unavailable"
  });
};
