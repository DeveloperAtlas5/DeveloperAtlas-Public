const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const aiContextDir = path.join(rootDir, "ai-context");
const aiContextExamplesDir = path.join(aiContextDir, "examples");
const aiContextOutputDir = path.join(rootDir, "output", "ai-context");

function ensureAiContextOutputDir() {
  fs.mkdirSync(aiContextOutputDir, { recursive: true });
}

function readAiContextRequests() {
  if (!fs.existsSync(aiContextExamplesDir)) return [];

  return fs.readdirSync(aiContextExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(aiContextExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        request: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function readJsonIfExists(file, fallback) {
  return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, "utf8")) : fallback;
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

module.exports = {
  aiContextDir,
  aiContextExamplesDir,
  aiContextOutputDir,
  ensureAiContextOutputDir,
  readAiContextRequests,
  readJsonIfExists,
  unique
};
