const assert = require("node:assert/strict");
const { innerJoin, users, orders, userMatchesOrder, userOrderProjection } = require("./join-sim");

function run() {
  const rows = innerJoin(users, orders, userMatchesOrder, userOrderProjection);

  assert.deepEqual(rows, [
    { user_id: 1, email: "ada@example.com", order_id: 101, total_cents: 5000 },
    { user_id: 1, email: "ada@example.com", order_id: 102, total_cents: 2500 },
    { user_id: 2, email: "grace@example.com", order_id: 103, total_cents: 7500 }
  ]);

  return rows;
}

module.exports = run;

if (require.main === module) run();
