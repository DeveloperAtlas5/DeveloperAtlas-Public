const assert = require("node:assert/strict");

module.exports = function runTryCatchSyncErrorExample() {
  function parseBrokenJson() {
    return JSON.parse("{bad json");
  }

  let message = "";

  try {
    parseBrokenJson();
  } catch (error) {
    message = `parse failed: ${error.name}`;
  }

  assert.equal(message, "parse failed: SyntaxError");
};
