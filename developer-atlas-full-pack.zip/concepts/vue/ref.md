# Vue ref

Technology: Vue

## Simple meaning

`ref` creates one reactive value.

## Why it exists

It lets Vue update the page when that value changes.

## Where you use it

Inside `<script setup>` or setup functions.

## When to use it

Use `ref` for a string, number, boolean, array, or object that the template should react to.

## Tiny example

`const count = ref(0)`

## Common beginner confusion

In script code, read or write a ref with `.value`. In the template, Vue unwraps it for you.

## Related concepts

- reactive
- computed
- watch

## Similar idea in another technology

A Laravel model property can hold data on the server; a Vue ref holds reactive data in the browser.
