module.exports = function runMistakeFilterForTransformation() {
  const users = [
    { id: 1, name: "Ada" },
    { id: 2, name: "Grace" }
  ];

  const wrongNames = users.filter((user) => user.name);
  const rightNames = users.map((user) => user.name);

  if (wrongNames[0].name !== "Ada") {
    throw new Error("Expected filter() to keep original user objects, not transform names");
  }

  if (rightNames.join(",") !== "Ada,Grace") {
    throw new Error(`Expected map() to transform to names, got ${rightNames.join(",")}`);
  }
};
