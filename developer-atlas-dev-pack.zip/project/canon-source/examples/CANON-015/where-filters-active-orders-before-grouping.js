const { orders, groupByCustomer } = require("./query-simulator");

module.exports = function runWhereFiltersActiveOrdersBeforeGrouping() {
  const filteredRows = orders.filter((order) => order.active && order.status === "paid");
  const groups = groupByCustomer(filteredRows);

  const c1 = groups.find((group) => group.customer_id === "c1");
  const c2 = groups.find((group) => group.customer_id === "c2");

  if (filteredRows.length !== 3) {
    throw new Error("WHERE-style row filtering should keep only active paid orders before grouping.");
  }

  if (c1.count !== 2 || c2.count !== 1) {
    throw new Error("Grouped counts should be based only on rows that passed WHERE.");
  }

  return groups;
};
