# Vue reactive

Technology: Vue

## Simple meaning

`reactive` creates a reactive object.

## Why it exists

It lets Vue track changes across object properties.

## Where you use it

Inside Vue setup code.

## When to use it

Use `reactive` when several related fields belong together in one object.

## Tiny example

`const form = reactive({ name: '', email: '' })`

## Common beginner confusion

`reactive` is best for objects. For one simple value, `ref` is often easier.

## Related concepts

- ref
- computed
- watch

## Similar idea in another technology

A Laravel Request can hold several input fields; a Vue reactive object can hold several browser-side fields.
