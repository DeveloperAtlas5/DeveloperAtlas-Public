function fetchOrder() {
  return Promise.resolve({ id: 100, total: 40 });
}

function addTax(order) {
  return { ...order, totalWithTax: order.total * 1.1 };
}

module.exports = async function runMistakeMissingReturnInThen() {
  const broken = await fetchOrder()
    .then((order) => {
      addTax(order);
    })
    .then((order) => order);

  const fixed = await fetchOrder()
    .then((order) => {
      return addTax(order);
    })
    .then((order) => order);

  if (broken !== undefined) {
    throw new Error("Broken chain should pass undefined after missing return.");
  }

  if (fixed.totalWithTax !== 44) {
    throw new Error("Fixed chain should return the transformed order.");
  }

  return { broken, fixed };
};
