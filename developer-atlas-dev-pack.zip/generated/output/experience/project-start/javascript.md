# Start a JavaScript Project

## What this is for

Use this when you want a web page to respond to clicks, input, or data.

## What you need first

You need an HTML file and a JavaScript file in your project.

## Required tools

- A browser
- VS Code or another text editor

## Recommended extensions

- JavaScript language features are built into VS Code

## Start from zero

- Create or open an HTML project.
- Create a file such as `script.js`.
- Link it from HTML with `<script src="script.js"></script>` before the closing `</body>` tag.

## Open an existing project

- Open the project folder in VS Code.
- Find a `.js` file, or create one if the project does not have JavaScript yet.
- Check the HTML file to see which script file is linked.

## Run or preview the project

- Open the HTML page in your browser.
- Open the browser console from Developer Tools.
- Refresh the page after code changes.

## Where you usually code

- JavaScript usually lives in `.js` files.
- Browser examples often connect JavaScript from an HTML file with `<script>`.

## Common first problems

- Nothing happens: check that the script file is linked.
- The console shows an error: read the file name and line number.
- Code runs before the page exists: put the script near the end of the HTML body.

## Next Atlas step

After JavaScript is connected, continue with the mission or look up JavaScript terms in the Concept Library.
