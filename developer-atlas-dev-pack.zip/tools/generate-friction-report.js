const fs = require("fs");
const path = require("path");
const {
  frictionOutputDir,
  ensureFrictionOutputDir,
  readFrictionNodes,
  countValues
} = require("./friction-utils");

function main() {
  const records = readFrictionNodes();
  const nodes = records.map((record) => record.node);

  ensureFrictionOutputDir();
  fs.writeFileSync(
    path.join(frictionOutputDir, "friction-nodes.json"),
    `${JSON.stringify(nodes, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(frictionOutputDir, "friction-report.md"),
    toReport(records)
  );

  console.log(`Generated output/friction/friction-nodes.json with ${nodes.length} friction node(s).`);
  console.log("Generated output/friction/friction-report.md.");
}

function toReport(records) {
  const nodes = records.map((record) => record.node);
  const highestFriction = [...nodes].sort((a, b) => b.friction_score - a.friction_score)[0];
  const averageRecoveryTime = average(nodes.map((node) => node.estimated_recovery_time));
  const diagnosticCoverage = nodes.length
    ? Math.round((nodes.filter(hasDiagnosticCoverage).length / nodes.length) * 100)
    : 0;

  const lines = [
    "# Atlas Friction Report",
    "",
    `Total friction nodes: ${nodes.length}`,
    `Highest friction score: ${highestFriction ? `${highestFriction.friction_score} (${highestFriction.id})` : "None"}`,
    `Average recovery time: ${averageRecoveryTime.toFixed(1)} minutes`,
    `Diagnostic coverage: ${diagnosticCoverage}%`,
    "",
    "## Most Common Affected Tools",
    "",
    ...formatCounts(countValues(records, "affected_tools")),
    "",
    "## Most Common Affected OS",
    "",
    ...formatCounts(countValues(records, "affected_os")),
    "",
    "## Friction Nodes",
    ""
  ];

  for (const node of nodes.sort((a, b) => b.friction_score - a.friction_score || a.id.localeCompare(b.id))) {
    lines.push(`- ${node.id}: ${node.title} (${node.friction_score}/100, recovery ${node.estimated_recovery_time} min)`);
  }

  lines.push("", "## Recommended Next Friction Nodes", "");
  lines.push("- Node version mismatch between project and installed runtime.");
  lines.push("- Permission denied during global package installation.");
  lines.push("- Database connection refused in local Laravel setup.");
  lines.push("- Git command not found or SSH authentication failure.");
  lines.push("- Port already in use for local development servers.");

  return `${lines.join("\n")}\n`;
}

function hasDiagnosticCoverage(node) {
  return (
    Array.isArray(node.symptoms) && node.symptoms.length > 0 &&
    Array.isArray(node.likely_causes) && node.likely_causes.length > 0 &&
    Array.isArray(node.diagnostic_steps) && node.diagnostic_steps.length > 0 &&
    Array.isArray(node.fixes) && node.fixes.length > 0 &&
    Array.isArray(node.verification_steps) && node.verification_steps.length > 0
  );
}

function average(values) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

function formatCounts(items) {
  return items.length
    ? items.map((item) => `- ${item.value}: ${item.count}`)
    : ["- None"];
}

main();
