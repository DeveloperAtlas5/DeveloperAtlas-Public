const fs = require("fs");
const path = require("path");
const {
  hardwareOutputDir,
  ensureHardwareOutputDir,
  readMachineProfiles,
  readContextualHardwareHints,
  countValues
} = require("./hardware-utils");

function main() {
  const profiles = readMachineProfiles().map((record) => record.profile);
  const hints = readContextualHardwareHints().map((record) => record.hint);
  const report = buildReport(profiles, hints);

  ensureHardwareOutputDir();
  fs.writeFileSync(
    path.join(hardwareOutputDir, "machine-profile-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/hardware/machine-profile-report.md for ${profiles.length} machine profile(s).`);
}

function buildReport(profiles, hints) {
  const profileReports = profiles.map((profile) => {
    const bottlenecks = detectBottlenecks(profile);
    return {
      profile_id: profile.profile_id,
      bottlenecks,
      suggested_upgrade_priorities: suggestedUpgradePriorities(profile, bottlenecks),
      ai_ready_prompt: buildAiPrompt(profile)
    };
  });

  return {
    total_machine_profiles: profiles.length,
    total_contextual_hints: hints.length,
    hints_by_workload: countValues(hints.flatMap((hint) => hint.related_workloads)),
    profiles_with_likely_bottlenecks: profileReports.filter((profile) => profile.bottlenecks.length),
    suggested_upgrade_priorities: profileReports.map((profile) => ({
      profile_id: profile.profile_id,
      priorities: profile.suggested_upgrade_priorities
    })),
    ai_ready_hardware_prompts: profileReports.map((profile) => ({
      profile_id: profile.profile_id,
      prompt: profile.ai_ready_prompt
    })),
    strongest_bottleneck_detected: strongestBottleneck(profileReports)
  };
}

function detectBottlenecks(profile) {
  const bottlenecks = [];

  if (profile.system_ram_gb <= 8) {
    bottlenecks.push({ field: "system_ram_gb", severity: 4, reason: "8 GB RAM can be tight for modern editors, browsers, dev servers, and Docker." });
  } else if (profile.system_ram_gb < 16 && hasGoal(profile, ["docker", "laravel", "unity", "llm"])) {
    bottlenecks.push({ field: "system_ram_gb", severity: 3, reason: "This workload benefits from more memory headroom." });
  }

  if (profile.storage_total_gb > 0 && profile.storage_free_gb / profile.storage_total_gb < 0.15) {
    bottlenecks.push({ field: "storage_free_gb", severity: 4, reason: "Low free storage can break installs, caches, images, and builds." });
  }

  if (hasGoal(profile, ["local llm", "AI"]) && profile.gpu_vram_gb < 12) {
    bottlenecks.push({ field: "gpu_vram_gb", severity: 5, reason: "Local LLM experiments are often constrained by available GPU VRAM." });
  }

  if (profile.device_type === "laptop" && hasGoal(profile, ["unity", "local llm"])) {
    bottlenecks.push({ field: "device_type", severity: 3, reason: "Sustained laptop thermals can limit long builds, imports, and inference." });
  }

  if (!/nvme/i.test(profile.storage_type) && hasGoal(profile, ["unity", "docker", "laravel"])) {
    bottlenecks.push({ field: "storage_type", severity: 2, reason: "Large projects and dependency-heavy stacks benefit from NVMe storage." });
  }

  return bottlenecks.sort((a, b) => b.severity - a.severity || a.field.localeCompare(b.field));
}

function suggestedUpgradePriorities(profile, bottlenecks) {
  if (profile.upgrade_budget_level === "none") {
    return ["No purchase path: clean storage, reduce background services, and use cloud or remote environments selectively."];
  }

  const priorities = bottlenecks.map((bottleneck) => {
    if (bottleneck.field === "gpu_vram_gb") return "Validate target model size before considering a GPU/VRAM upgrade.";
    if (bottleneck.field === "system_ram_gb") return "Prioritize RAM headroom before CPU or GPU for this profile.";
    if (bottleneck.field === "storage_free_gb") return "Free space or expand storage before adding heavier tooling.";
    if (bottleneck.field === "storage_type") return "Prefer fast SSD/NVMe storage for active projects.";
    if (bottleneck.field === "device_type") return "Check sustained performance and cooling before assuming peak specs are enough.";
    return `Investigate ${bottleneck.field}.`;
  });

  priorities.push("Avoid product recommendations until goals, current bottlenecks, and budget level are clarified.");
  return [...new Set(priorities)];
}

function buildAiPrompt(profile) {
  return [
    `I have this machine profile: ${profile.device_type} running ${profile.operating_system}, CPU: ${profile.cpu}, GPU: ${profile.gpu}, GPU VRAM: ${profile.gpu_vram_gb} GB, RAM: ${profile.system_ram_gb} GB, storage: ${profile.storage_type} with ${profile.storage_free_gb}/${profile.storage_total_gb} GB free.`,
    `My goals are: ${profile.primary_goals.join(", ")}.`,
    `My current pain points are: ${profile.current_pain_points.join(", ")}.`,
    `My upgrade budget level is: ${profile.upgrade_budget_level}.`,
    "Prioritize specs by workload impact and explain trade-offs. Ask clarifying questions before recommending products. Do not recommend specific stores, prices, or hype-driven purchases."
  ].join(" ");
}

function strongestBottleneck(profileReports) {
  const all = profileReports.flatMap((profile) => {
    return profile.bottlenecks.map((bottleneck) => ({
      profile_id: profile.profile_id,
      ...bottleneck
    }));
  });

  return all.sort((a, b) => b.severity - a.severity || a.profile_id.localeCompare(b.profile_id))[0] || null;
}

function hasGoal(profile, terms) {
  const text = `${profile.primary_goals.join(" ")} ${profile.current_pain_points.join(" ")}`.toLowerCase();
  return terms.some((term) => {
    const normalizedTerm = term.toLowerCase();
    if (normalizedTerm.length <= 3) {
      return new RegExp(`\\b${escapeRegExp(normalizedTerm)}\\b`).test(text);
    }
    return text.includes(normalizedTerm);
  });
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Machine Profile Report",
    "",
    `Total machine profiles: ${report.total_machine_profiles}`,
    `Total contextual hints: ${report.total_contextual_hints}`,
    "",
    "## Hints by Workload",
    "",
    ...formatCounts(report.hints_by_workload),
    "",
    "## Profiles With Likely Bottlenecks",
    "",
    ...formatProfileBottlenecks(report.profiles_with_likely_bottlenecks),
    "",
    "## Suggested Upgrade Priorities",
    "",
    ...report.suggested_upgrade_priorities.flatMap((profile) => [
      `### ${profile.profile_id}`,
      "",
      ...profile.priorities.map((priority) => `- ${priority}`),
      ""
    ]),
    "## AI-Ready Hardware Prompts",
    "",
    ...report.ai_ready_hardware_prompts.flatMap((profile) => [
      `### ${profile.profile_id}`,
      "",
      profile.prompt,
      ""
    ]),
    "## Strongest Bottleneck Detected",
    "",
    report.strongest_bottleneck_detected
      ? `- ${report.strongest_bottleneck_detected.profile_id}: ${report.strongest_bottleneck_detected.field} (${report.strongest_bottleneck_detected.reason})`
      : "- None"
  ];

  return `${lines.join("\n")}\n`;
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

function formatProfileBottlenecks(profiles) {
  if (!profiles.length) return ["- None"];

  return profiles.flatMap((profile) => [
    `### ${profile.profile_id}`,
    "",
    ...profile.bottlenecks.map((bottleneck) => `- ${bottleneck.field}: ${bottleneck.reason}`),
    ""
  ]);
}

main();
