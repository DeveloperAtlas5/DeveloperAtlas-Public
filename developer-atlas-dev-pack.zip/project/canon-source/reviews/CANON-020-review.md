# Canon Review Template

Canon ID: CANON-020
Node ID: canon.css.layout.position-relative-absolute-fixed-sticky
Reviewer: Pending Gold Review Panel
Date: 2026-07-03
Stage: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Gold-candidate draft aligns with MDN and CSS Positioned Layout behavior for relative, absolute, fixed, and sticky positioning.
- Edge cases: Covers normal flow, containing blocks, viewport pinning, sticky thresholds, scroll containers, overflow context, layout space, and overlap.
- Version concerns: Guidance targets standard modern CSS behavior.
- Evidence quality: Direct MDN and W3C CSS Positioned Layout URLs are included.

## Educational Review

- Beginner clarity: Strong "flow and anchor" mental model.
- Mental model: Learners are taught to ask whether the element keeps space and what it is positioned relative to.
- Exercise quality: Beginner, intermediate, and advanced exercises are present.
- Common mistake coverage: Covers wrong ancestor assumptions, sticky failures, fixed overlap, and absolute positioning as fake layout.

## AI Review

- Structured enough for retrieval: Yes.
- Code generation guidance: Strong and specific.
- Ambiguity risks: AI should ask what the anchor is before generating absolute positioning.
- Related node quality: Related Canon and content graph IDs are included.

## Engineering Review

- Decision support: Strong.
- Production realism: Card badges, fixed support buttons, sticky toolbars, and layout debugging are practical.
- Trade-offs: Good coverage of normal flow, Flexbox/Grid alternatives, stacking, accessibility, and scroll behavior.
- Anti-pattern coverage: Strong enough for Gold-candidate review.

## Decision

- Approved stage: Gold Candidate
- Required changes: Add named reviewer sign-off before Gold approval.
- Score: 95
