const assert = require("node:assert/strict");
const { reactive } = require("./reactivity-sim");

function run() {
  const form = reactive({
    email: "",
    password: "",
    rememberMe: false
  });

  form.email = "ada@example.com";
  form.rememberMe = true;

  assert.deepEqual(form, {
    email: "ada@example.com",
    password: "",
    rememberMe: true
  });

  return form;
}

module.exports = run;

if (require.main === module) run();
