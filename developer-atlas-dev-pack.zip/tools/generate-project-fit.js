const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readGoals } = require("./goal-utils");
const { readTools } = require("./toolkit-utils");
const { readFrictionNodes } = require("./friction-utils");
const { readMachineProfiles, readWorkloadProfiles } = require("./hardware-utils");
const {
  capabilityOutputDir,
  ensureCapabilityOutputDir,
  readCapabilities,
  unique
} = require("./capability-utils");

function main() {
  const capabilities = readCapabilities().map((record) => record.capability);
  const context = readContext();
  const fits = capabilities.map((capability) => fitCapability(capability, context));
  const report = {
    project_fits: fits,
    ready_today: fits.filter((fit) => fit.fit_level === "ready_today"),
    mostly_ready: fits.filter((fit) => fit.fit_level === "mostly_ready"),
    defer: fits.filter((fit) => fit.fit_level === "defer")
  };

  ensureCapabilityOutputDir();
  fs.writeFileSync(
    path.join(capabilityOutputDir, "project-fit-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(capabilityOutputDir, "project-fit-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/capability/project-fit-report.json for ${fits.length} project fit(s).`);
  console.log("Generated output/capability/project-fit-report.md.");
}

function readContext() {
  const readinessPath = path.join(rootDir, "output", "readiness", "readiness-report.json");
  const readinessReport = fs.existsSync(readinessPath)
    ? JSON.parse(fs.readFileSync(readinessPath, "utf8"))
    : { reports: [] };

  const readinessDetails = new Map();
  for (const fileName of fs.existsSync(path.join(rootDir, "output", "readiness"))
    ? fs.readdirSync(path.join(rootDir, "output", "readiness")).filter((name) => name.endsWith(".json") && !name.includes("report"))
    : []) {
    const file = path.join(rootDir, "output", "readiness", fileName);
    const report = JSON.parse(fs.readFileSync(file, "utf8"));
    readinessDetails.set(report.profile_summary.readiness_id, report);
  }

  const canonIndex = JSON.parse(fs.readFileSync(path.join(rootDir, "canon", "canon-index.json"), "utf8"));

  return {
    readinessReports: readinessReport.reports || [],
    readinessDetails,
    goalsById: new Map(readGoals().map((record) => [record.goal.goal_id, record.goal])),
    canonIds: new Set(canonIndex.entries.map((entry) => entry.canon_id)),
    toolsById: new Map(readTools().map((record) => [record.data.id, record.data])),
    frictionById: new Map(readFrictionNodes().map((record) => [record.node.id, record.node])),
    machineProfiles: readMachineProfiles().map((record) => record.profile),
    workloadsById: new Map(readWorkloadProfiles().map((record) => [record.workload.workload_id, record.workload]))
  };
}

function fitCapability(capability, context) {
  const readiness = bestReadinessMatch(capability, context);
  const readinessId = readiness?.readiness_id || "none";
  const readinessScore = readiness?.score || 0;
  const detail = context.readinessDetails.get(readinessId);
  const fitScore = calculateFitScore(capability, readinessScore, detail);
  const fitLevel = classifyFit(capability, fitScore);
  const blockers = blockersFor(capability, fitLevel, readinessScore, detail, context);
  const missingKnowledge = detail?.missing_knowledge?.slice(0, 10) || [];
  const missingTools = requiredToolGaps(capability, detail);
  const hardwareConcerns = hardwareConcernsFor(capability, detail, context);

  return {
    capability_id: capability.capability_id,
    title: capability.title,
    fit_level: fitLevel,
    best_readiness_match: readinessId,
    fit_score: fitScore,
    blockers,
    missing_knowledge: missingKnowledge,
    missing_tools: missingTools,
    hardware_concerns: hardwareConcerns,
    estimated_hours: capability.estimated_hours,
    ai_ready_project_prompt: buildPrompt(capability, fitLevel, blockers, readinessId)
  };
}

function bestReadinessMatch(capability, context) {
  return [...context.readinessReports].sort((a, b) => {
    const aScore = matchScore(capability, a, context);
    const bScore = matchScore(capability, b, context);
    return bScore - aScore || b.score - a.score;
  })[0];
}

function matchScore(capability, readiness, context) {
  const detail = context.readinessDetails.get(readiness.readiness_id);
  const targetGoals = new Set(detail?.target_goals || []);
  const overlap = capability.required_goals.filter((goal) => targetGoals.has(goal)).length;
  return overlap * 25 + readiness.score;
}

function calculateFitScore(capability, readinessScore, detail) {
  let score = readinessScore;
  const targetGoals = new Set(detail?.target_goals || []);
  const goalCoverage = capability.required_goals.length
    ? capability.required_goals.filter((goal) => targetGoals.has(goal)).length / capability.required_goals.length
    : 1;
  score += goalCoverage * 15;
  score -= Math.max(0, capability.estimated_hours - 8) * 0.6;
  score -= requiredToolGaps(capability, detail).length * 4;
  score -= hardwareConcernsFor(capability, detail, {}).length * 3;
  return round(clamp(score));
}

function classifyFit(capability, fitScore) {
  if (fitScore >= capability.recommended_readiness_score) return "ready_today";
  if (fitScore >= capability.minimum_readiness_score) return "mostly_ready";
  return "defer";
}

function blockersFor(capability, fitLevel, readinessScore, detail, context) {
  const blockers = [];
  if (readinessScore < capability.minimum_readiness_score) {
    blockers.push(`Readiness score ${readinessScore} is below minimum ${capability.minimum_readiness_score}.`);
  }
  if (fitLevel === "defer") blockers.push("Pick a smaller prerequisite project first.");
  for (const tool of requiredToolGaps(capability, detail).slice(0, 4)) blockers.push(`Tooling gap: ${tool}.`);
  for (const risk of capability.common_friction_nodes || []) {
    if (context.frictionById?.has(risk)) blockers.push(`Likely friction risk: ${risk}.`);
  }
  return unique(blockers);
}

function requiredToolGaps(capability, detail) {
  const toolingGaps = new Set(detail?.tooling_gaps || []);
  return capability.required_tools.filter((tool) => toolingGaps.has(tool));
}

function hardwareConcernsFor(capability, detail) {
  const concerns = detail?.hardware_concerns || [];
  if (!capability.required_hardware_workloads.some((workload) => /llm|unity|docker|fullstack/i.test(workload))) {
    return [];
  }
  return concerns;
}

function buildPrompt(capability, fitLevel, blockers, readinessId) {
  return [
    capability.ai_context_prompt,
    `Current project fit is ${fitLevel} using readiness profile ${readinessId}.`,
    blockers.length ? `Known blockers: ${blockers.join("; ")}.` : "Known blockers: none severe.",
    "Help me choose the smallest finishable version first."
  ].join(" ");
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Project Fit Report",
    "",
    `Project fits: ${report.project_fits.length}`,
    `Ready today: ${report.ready_today.length}`,
    `Mostly ready: ${report.mostly_ready.length}`,
    `Deferred: ${report.defer.length}`,
    "",
    "## Project Fits",
    ""
  ];

  for (const fit of report.project_fits) {
    lines.push(
      `### ${fit.title}`,
      "",
      `Capability: ${fit.capability_id}`,
      `Fit: ${fit.fit_level}`,
      `Fit score: ${fit.fit_score}`,
      `Best readiness match: ${fit.best_readiness_match}`,
      `Estimated hours: ${fit.estimated_hours}`,
      "",
      "Blockers:",
      ...formatList(fit.blockers),
      "",
      "Missing knowledge:",
      ...formatList(fit.missing_knowledge),
      "",
      "Missing tools:",
      ...formatList(fit.missing_tools),
      "",
      "Hardware concerns:",
      ...formatList(fit.hardware_concerns),
      "",
      "AI-ready project prompt:",
      fit.ai_ready_project_prompt,
      ""
    );
  }

  return `${lines.join("\n")}\n`;
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function clamp(value) {
  return Math.max(0, Math.min(100, value));
}

function round(value) {
  return Number(value.toFixed(2));
}

main();

