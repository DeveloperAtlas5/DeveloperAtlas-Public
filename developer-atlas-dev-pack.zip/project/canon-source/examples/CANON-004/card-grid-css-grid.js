const assert = require("node:assert/strict");
const { hasDeclaration } = require("./css-rule-utils");

const css = `
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr));
  gap: 1rem;
}
`;

function run() {
  assert.equal(hasDeclaration(css, ".cards", "display: grid"), true);
  assert.equal(hasDeclaration(css, ".cards", "grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr))"), true);
  assert.equal(hasDeclaration(css, ".cards", "gap: 1rem"), true);

  return css;
}

module.exports = run;

if (require.main === module) run();
