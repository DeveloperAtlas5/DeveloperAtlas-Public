# Atlas Canon

The Atlas Canon is not normal documentation.

It is the highest-quality curated set of 100 engineering knowledge nodes in Developer Atlas. Canon nodes are the standard other nodes learn from, not a place to add volume.

## Purpose

- Set the quality standard for Developer Atlas.
- Train future human contributors.
- Train future AI agents.
- Power books, learning paths, advisor output, review systems, and certification.

## Canon Principle

Quality over quantity.

100 excellent nodes beat 10,000 average nodes.

## What Makes Canon Different

Canon nodes must reduce developer confusion. They must explain the mental model, show practical decisions, name trade-offs, connect related knowledge, cite evidence, and provide AI-readable structure.

Canon is not a copy of official docs. Official docs define the platform truth. Canon explains the practical engineering judgment developers need when official syntax is not enough.

## Reference Template

CANON-001, `Array.prototype.map() vs forEach()`, is the permanent reference template for future Canon nodes.

Future Canon candidates should follow its structure:

- Status metadata.
- Summary.
- Problem.
- Mental model.
- Beginner explanation.
- Professional explanation.
- Syntax.
- Decision guide.
- Comparison table.
- When-to-use and when-not-to-use guidance.
- Alternatives.
- Production examples.
- Common mistakes.
- Debugging checklist.
- Mechanical verification where possible.
- Performance notes.
- AI coding guidance.
- Teaching notes.
- Interview questions.
- Exercises.
- Related Atlas nodes.
- Evidence and sources.
- Proof of superiority summary.
- Scorecard.

The template is frozen as a quality bar, not a prose style cage. Contributors may adapt examples to the topic, but the decision-support structure should remain.
