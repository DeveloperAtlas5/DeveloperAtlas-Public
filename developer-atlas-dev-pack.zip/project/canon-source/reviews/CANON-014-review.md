# CANON-014 Review

Canon ID: CANON-014
Node ID: canon.laravel.validation.validation
Title: Laravel validation
Status: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Explains inline validation, Form Requests, authorization separation, validated payloads, JSON `422`, scoped uniqueness, and nullable/required pitfalls.
- Edge cases: Covers frontend bypass, raw request data, tenant/project uniqueness, database constraints, and API response behavior.
- Evidence: Uses official Laravel validation documentation and direct anchors.
- Verification: Four deterministic Node examples pass.

## Educational Review

- Mental model: Strong request-boundary framing.
- Beginner clarity: Starts with untrusted input, validated data, and simple inline rules.
- Professional depth: Explains production contract design, authorization boundaries, and database integrity.
- Exercises: Covers beginner, intermediate, and advanced validation design.

## AI Readiness Review

- Code generation guidance: Strong rules for `$request->validate()`, Form Requests, `$request->validated()`, and avoiding `$request->all()`.
- Machine readability: Stable Canon headings and scorecard structure.
- Relationship quality: Connects validation to routing, controllers, migrations, and PHP request handling.

## Engineering Review

- Production examples: Includes inline controller, Form Request, API JSON behavior, and frontend validation bypass.
- Debugging support: Checklist maps to common Laravel validation failures.
- Trade-offs: Clear comparison of inline validation, Form Request, custom rules, database constraints, and frontend validation.

## Remaining Gold Gaps

- Named human reviewer sign-off is still required before final Gold status.
