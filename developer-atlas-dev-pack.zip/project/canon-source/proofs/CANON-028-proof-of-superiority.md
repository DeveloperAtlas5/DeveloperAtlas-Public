# CANON-028 Proof Of Superiority Draft

## Status

- Canon ID: CANON-028
- Node ID: canon.backend.api.route-vs-controller-vs-service
- Status: candidate draft
- Current score: 55

## Baseline Compared

Official documentation and common tutorials usually explain individual concepts, but they often do not turn the choice into a beginner-friendly decision record.

## Atlas Improvement Hypothesis

Atlas can improve this topic by connecting mental model, trade-offs, production examples, AI coding guidance, related nodes, and verification into one reviewable Canon node.

## Evidence Still Needed

- Direct official source URLs.
- Runnable or deterministic verification examples when practical.
- Production-quality examples.
- Named reviewer sign-off.

## Current Limitation

This proof is a placeholder for candidate setup only. It should not be used as Gold evidence until the node is hardened.
