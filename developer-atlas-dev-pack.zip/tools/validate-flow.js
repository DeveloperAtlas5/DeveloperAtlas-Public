const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const flowDir = path.join(rootDir, "flow");
const examplesDir = path.join(flowDir, "examples");

const schemaFiles = [
  "flow-request.schema.json",
  "flow-output.schema.json",
  "flow-step.schema.json"
];

const requiredFields = [
  "flow_id",
  "profile_id",
  "goals",
  "learner_level",
  "machine_profile_id",
  "available_hours_per_week",
  "current_blockers",
  "preferred_stack",
  "desired_output",
  "include_ai_context",
  "include_setup",
  "include_recovery",
  "include_hardware",
  "include_team_context"
];

const booleanFields = [
  "include_ai_context",
  "include_setup",
  "include_recovery",
  "include_hardware",
  "include_team_context"
];

function main() {
  const errors = [];
  const warnings = [];

  validateStaticFiles(errors);
  validateExamples(errors, warnings);

  console.log("Atlas Flow validation");
  console.log(`Flow requests: ${readExampleFiles().length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateStaticFiles(errors) {
  for (const fileName of ["README.md", "flow-engine-spec.md", ...schemaFiles]) {
    const filePath = path.join(flowDir, fileName);
    if (!fs.existsSync(filePath)) {
      errors.push(`flow/${fileName}: missing file`);
      continue;
    }
    if (fileName.endsWith(".json")) parseJson(filePath, `flow/${fileName}`, errors);
  }
}

function validateExamples(errors, warnings) {
  const seen = new Set();

  for (const { fileName, relativePath, data } of readExampleFiles(errors)) {
    for (const field of requiredFields) {
      if (data[field] === undefined || data[field] === null || data[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }

    if (seen.has(data.flow_id)) errors.push(`${relativePath}: duplicate flow_id ${data.flow_id}`);
    seen.add(data.flow_id);

    validateArray(relativePath, data, "goals", errors, false);
    validateArray(relativePath, data, "current_blockers", errors, true);
    validateArray(relativePath, data, "preferred_stack", errors, false);

    if (typeof data.available_hours_per_week !== "number" || data.available_hours_per_week < 0) {
      errors.push(`${relativePath}: available_hours_per_week should be a non-negative number`);
    }

    for (const field of booleanFields) {
      if (typeof data[field] !== "boolean") errors.push(`${relativePath}: ${field} should be boolean`);
    }

    if (!fileName.endsWith("-flow.json")) warnings.push(`${relativePath}: flow examples should use -flow.json suffix`);
  }
}

function readExampleFiles(errors = []) {
  if (!fs.existsSync(examplesDir)) return [];

  return fs.readdirSync(examplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const filePath = path.join(examplesDir, fileName);
      return {
        fileName,
        relativePath: path.relative(rootDir, filePath).replace(/\\/g, "/"),
        data: parseJson(filePath, path.relative(rootDir, filePath).replace(/\\/g, "/"), errors)
      };
    })
    .filter((record) => record.data);
}

function parseJson(filePath, label, errors) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    errors.push(`${label}: invalid JSON (${error.message})`);
    return null;
  }
}

function validateArray(relativePath, data, field, errors, allowEmpty) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }
  if (!allowEmpty && data[field].length === 0) errors.push(`${relativePath}: ${field} should not be empty`);
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

main();
