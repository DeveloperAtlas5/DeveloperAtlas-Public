module.exports = function runMistakeFilterWhenFindNeeded() {
  const users = [
    { id: "u1", name: "Ada" },
    { id: "u2", name: "Grace" },
    { id: "u3", name: "Lin" }
  ];
  const targetId = "u2";

  const filterResult = users.filter((user) => user.id === targetId)[0];
  const findResult = users.find((user) => user.id === targetId);

  if (filterResult.name !== "Grace") {
    throw new Error("Expected filter()[0] anti-pattern to find Grace");
  }

  if (findResult !== filterResult) {
    throw new Error("Expected find() to return the same first matching item more directly");
  }
};
