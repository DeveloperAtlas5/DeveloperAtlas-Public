const { orders, groupByCustomer } = require("./query-simulator");

module.exports = function runWhereAndHavingTogether() {
  const paidRows = orders.filter((order) => order.status === "paid");
  const groups = groupByCustomer(paidRows);
  const highValuePaidCustomers = groups.filter((group) => group.total_cents >= 100000);

  if (paidRows.length !== 4) {
    throw new Error("WHERE should first keep paid rows only.");
  }

  if (highValuePaidCustomers.length !== 1 || highValuePaidCustomers[0].customer_id !== "c1") {
    throw new Error("HAVING should then keep only groups meeting the aggregate revenue threshold.");
  }

  return highValuePaidCustomers;
};
