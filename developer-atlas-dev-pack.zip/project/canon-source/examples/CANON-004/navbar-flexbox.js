const assert = require("node:assert/strict");
const { hasDeclaration } = require("./css-rule-utils");

const css = `
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

.navbar__links {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}
`;

function run() {
  assert.equal(hasDeclaration(css, ".navbar", "display: flex"), true);
  assert.equal(hasDeclaration(css, ".navbar", "align-items: center"), true);
  assert.equal(hasDeclaration(css, ".navbar__links", "display: flex"), true);

  return css;
}

module.exports = run;

if (require.main === module) run();
