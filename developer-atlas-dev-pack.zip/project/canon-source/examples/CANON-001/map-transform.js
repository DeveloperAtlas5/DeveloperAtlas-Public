const assert = require("node:assert/strict");

function run() {
  const users = [
    { id: 1, firstName: "Ada", lastName: "Lovelace", active: true },
    { id: 2, firstName: "Grace", lastName: "Hopper", active: false }
  ];

  const viewModels = users.map((user) => ({
    id: user.id,
    displayName: `${user.firstName} ${user.lastName}`,
    statusLabel: user.active ? "Active" : "Inactive"
  }));

  assert.deepEqual(viewModels, [
    { id: 1, displayName: "Ada Lovelace", statusLabel: "Active" },
    { id: 2, displayName: "Grace Hopper", statusLabel: "Inactive" }
  ]);

  return viewModels;
}

module.exports = run;

if (require.main === module) run();
