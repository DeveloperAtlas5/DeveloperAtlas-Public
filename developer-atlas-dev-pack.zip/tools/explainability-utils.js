const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const explainabilityDir = path.join(rootDir, "explainability");
const explainabilityExamplesDir = path.join(explainabilityDir, "examples");
const explainabilityOutputDir = path.join(rootDir, "output", "explainability");

function ensureExplainabilityOutputDir() {
  fs.mkdirSync(explainabilityOutputDir, { recursive: true });
}

function readExplanations() {
  if (!fs.existsSync(explainabilityExamplesDir)) return [];

  return fs.readdirSync(explainabilityExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(explainabilityExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        explanation: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function countValues(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

function readJsonIfExists(file, fallback) {
  return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, "utf8")) : fallback;
}

module.exports = {
  explainabilityDir,
  explainabilityExamplesDir,
  explainabilityOutputDir,
  ensureExplainabilityOutputDir,
  readExplanations,
  countValues,
  unique,
  readJsonIfExists
};
