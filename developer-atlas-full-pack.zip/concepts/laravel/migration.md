# Laravel Migration

Technology: Laravel

## Simple meaning

A migration changes database structure in a repeatable file.

## Why it exists

Migrations let a team create, update, and share database tables safely through code.

## Where you use it

In the `database/migrations` folder.

## When to use it

Use a migration when you need to create a table, add a column, rename a column, or change an index.

## Tiny example

`$table->string('title');` inside a migration creates a text column named `title`.

## Common beginner confusion

A migration changes the shape of the database. It usually does not add everyday app data.

## Related concepts

- Model
- Seeder
- Factory

## Similar idea in another technology

A frontend type or interface can describe data shape in code, but a migration changes the real database shape.
