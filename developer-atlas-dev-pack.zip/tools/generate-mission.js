const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "mission");

function main() {
  fs.mkdirSync(outputDir, { recursive: true });

  const flow = readJson("output/flow/rookie-vue-todo-flow.json");
  const pathway = readJson("output/capability/capability-pathway.json", { weeks: [] });
  const momentum = readJson("output/momentum/momentum-report.json", {});
  const experience = readText("output/experience/experience-report.md", "");
  const canonIndex = readJson("canon/canon-index.json", { entries: [] });

  const mission = buildMission(flow, pathway, momentum, experience, canonIndex);
  const report = buildReport(mission);

  fs.writeFileSync(path.join(outputDir, "today-mission.json"), `${JSON.stringify(mission, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "today-mission.md"), renderMissionMarkdown(mission));
  fs.writeFileSync(path.join(outputDir, "mission-report.json"), `${JSON.stringify(report, null, 2)}\n`);
  fs.writeFileSync(path.join(outputDir, "mission-report.md"), renderReportMarkdown(report));

  console.log("Generated output/mission/today-mission.md.");
  console.log("Generated output/mission/mission-report.md.");
}

function buildMission(flow, pathway, momentum, experience, canonIndex) {
  const weekOne = (pathway.weeks || [])[0] || {};
  const canonIds = unique([
    ...(weekOne.required_knowledge || []).filter((item) => /^CANON-\d+/.test(item)),
    "CANON-022"
  ]).slice(0, 5);
  const recommendedCanonIds = unique((weekOne.recommended_next_knowledge || []).filter((item) => /^CANON-\d+/.test(item))).slice(0, 4);
  const canonLookup = new Map((canonIndex.entries || []).map((entry) => [entry.canon_id, entry]));
  const projectMinutes = Math.round((flow.best_project_now.estimated_hours || 0) * 60);
  const setupMinutes = flow.setup_checklist && flow.setup_checklist.length ? 10 : 0;
  const recoveryMinutes = flow.recovery_fallback.estimated_recovery_time || 0;
  const estimatedDuration = projectMinutes + setupMinutes + recoveryMinutes;
  const confidence = scoreConfidence(flow, momentum);
  const systems = [
    "Goal Intelligence",
    "Readiness",
    "Hardware",
    "Toolkit",
    "Setup",
    "Recovery",
    "Canon",
    "Learning",
    "Capability",
    "Explainability",
    "Momentum",
    "AI Context",
    "Experience",
    "Flow"
  ];

  const mission = {
    mission_id: "mission.today.rookie_vue_todo",
    mission_title: "Make Your Vue Todo List Remember Tasks",
    generated_at: new Date().toISOString(),
    estimated_duration_minutes: estimatedDuration,
    difficulty: difficultyFromReadiness(flow.readiness_status.score),
    confidence_score: confidence,
    today_objective: "Your todo list currently resets after refresh. Today you will make it remember non-sensitive tasks using the right browser storage choice.",
    why_this_mission_matters: "Persistence is the moment a small app starts feeling real. This mission keeps the scope tiny: no backend, no auth, no routing, just one useful improvement that makes your Vue todo list survive a refresh.",
    what_atlas_checked: [
      "You already have the right first project: a small Vue todo app.",
      "This mission adds one persistence feature without expanding into backend, auth, routing, or state management.",
      "The setup and recovery steps are ready in case the local app or stored data behaves unexpectedly.",
      "A focused AI context pack is available if you want help without explaining everything from scratch."
    ],
    what_to_do_first: flow.smallest_useful_next_step || "Run the first setup verification before building.",
    today_canon: canonIds.map((canonId) => ({
      canon_id: canonId,
      title: canonLookup.get(canonId)?.title || canonId,
      status: canonLookup.get(canonId)?.status || "unknown"
    })),
    recommended_next_canon: recommendedCanonIds.map((canonId) => ({
      canon_id: canonId,
      title: canonLookup.get(canonId)?.title || canonId,
      status: canonLookup.get(canonId)?.status || "unknown",
      priority: "recommended_next",
      note: canonId === "CANON-022"
        ? "Recommended now: make non-sensitive todos survive refresh."
        : "Optional later: useful when splitting the app into reusable components."
    })),
    optional_canon_note: weekOne.optional_knowledge_note || "",
    today_project: flow.best_project_now,
    storage_guidance: [
      "localStorage survives browser restarts for the same site until the user, browser, or app clears it.",
      "sessionStorage survives refresh, but it is tied to the current tab/session and should disappear when that session ends.",
      "Neither localStorage nor sessionStorage is a safe place for sensitive data like passwords, access tokens, or private personal information.",
      "Vue state and browser storage are separate concerns: Vue state drives the screen now; browser storage remembers small values for later.",
      "Use JSON.stringify() before saving a todo array and JSON.parse() with a safe fallback when loading it."
    ],
    today_setup_check: flow.setup_checklist[0] || "Open the project and run the first verification command.",
    today_recovery_plan: {
      matched_friction_node: flow.recovery_fallback.matched_friction_node,
      safest_first_fix: flow.recovery_fallback.safest_first_fix,
      verification_steps: flow.recovery_fallback.verification_steps || [],
      estimated_recovery_time: flow.recovery_fallback.estimated_recovery_time || 0
    },
    storage_recovery_plan: [
      "If the list resets after refresh, confirm you save after every add, delete, complete, and filter-relevant todo change.",
      "If saved todos load as broken text or [object Object], check that you used JSON.stringify() when saving and JSON.parse() when loading.",
      "If JSON.parse() throws, clear the old todos value and reload with an empty-array fallback.",
      "If data disappears after closing the tab, confirm you used localStorage instead of sessionStorage.",
      "If you accidentally stored sensitive data, remove it immediately and do not use browser storage for secrets."
    ],
    today_ai_context: flow.ai_ready_context_pointer,
    what_to_ignore_today: flow.what_to_skip_for_now,
    visible_reward_after_completion: "You can refresh the page and your non-sensitive todo tasks are still there.",
    next_mission_preview: {
      title: `Prepare for ${flow.next_project_later.title}`,
      project: flow.next_project_later,
      reason: "After persistence works, the next mission can split the todo app into small reusable components without crowding today."
    },
    systems_orchestrated: systems,
    mission_quality_score: scoreMissionQuality(flow, canonIds, systems),
    confidence_first_message: "You are not trying to build a full product today. You are making one small app remember one small piece of state.",
    flow_source: "output/flow/rookie-vue-todo-flow.json",
    experience_signal: experience.includes("smallest useful next step") ? "Aligned with smallest-useful-next-step experience principle." : "Experience report available.",
    momentum_signal: {
      estimated_minutes_saved: momentum.estimated_time_saved || 0,
      confidence_improvement: momentum.confidence_improvement || 0
    }
  };

  return mission;
}

function scoreConfidence(flow, momentum) {
  const readinessPart = Math.min(30, (flow.readiness_status.score || 0) * 0.35);
  const flowPart = Math.min(35, (flow.flow_quality_score || 0) * 0.35);
  const projectPart = flow.best_project_now.fit_level === "ready_today" ? 25 : 15;
  const momentumPart = momentum.confidence_improvement ? 8 : 5;
  return round(readinessPart + flowPart + projectPart + momentumPart);
}

function scoreMissionQuality(flow, canonIds, systems) {
  let score = 0;
  if (flow.best_project_now.capability_id) score += 15;
  if (flow.smallest_useful_next_step) score += 15;
  if (flow.setup_checklist.length) score += 10;
  if (flow.recovery_fallback.matched_friction_node) score += 10;
  if (flow.ai_ready_context_pointer) score += 10;
  if (canonIds.length) score += 10;
  if (flow.what_to_skip_for_now.length) score += 10;
  if (systems.length >= 12) score += 10;
  if (flow.confidence_building_message) score += 10;
  return score;
}

function buildReport(mission) {
  return {
    generated_at: new Date().toISOString(),
    missions_generated: 1,
    mission_quality: mission.mission_quality_score,
    estimated_completion_time_minutes: mission.estimated_duration_minutes,
    confidence: mission.confidence_score,
    systems_orchestrated: mission.systems_orchestrated,
    next_recommended_mission: mission.next_mission_preview.title,
    generated_files: [
      "output/mission/today-mission.md",
      "output/mission/today-mission.json",
      "output/mission/mission-report.md",
      "output/mission/mission-report.json"
    ]
  };
}

function renderMissionMarkdown(mission) {
  return [
    `# ${mission.mission_title}`,
    "",
    "A calm daily mission from Developer Atlas.",
    "",
    `- Estimated duration: ${formatDuration(mission.estimated_duration_minutes)}`,
    `- Difficulty: ${mission.difficulty}`,
    `- Confidence score: ${mission.confidence_score}/100`,
    "",
    "## Why This Mission Matters",
    "",
    mission.why_this_mission_matters,
    "",
    "## Today's Objective",
    "",
    mission.today_objective,
    "",
    "## What Atlas Already Checked",
    "",
    ...list(mission.what_atlas_checked, (item) => `- ${item}`),
    "",
    "## What To Do First",
    "",
    mission.what_to_do_first,
    "",
    "## Today's Learning Focus",
    "",
    ...list(mission.today_canon, (item) => `- ${friendlyCanonTitle(item)}`),
    "",
    "## Browser Storage Choice",
    "",
    ...list(mission.storage_guidance, (item) => `- ${item}`),
    "",
    "## Recommended Next Learning",
    "",
    ...list(mission.recommended_next_canon, (item) => `- ${friendlyCanonTitle(item)} - ${item.note}`),
    mission.optional_canon_note ? `\n${mission.optional_canon_note}` : "",
    "",
    "## Today's Project",
    "",
    "- Add persistence to the Vue todo app.",
    "- Save the todo array after changes.",
    "- Load saved todos when the app starts.",
    "- Refresh the page to prove the list is remembered.",
    "",
    "## Today's Setup Check",
    "",
    `Run: ${mission.today_setup_check}`,
    "",
    "## Likely Blocker",
    "",
    `- ${mission.today_recovery_plan.matched_friction_node?.title || "Setup friction"}`,
    "",
    "## Today's Recovery Plan",
    "",
    "If storage behaves unexpectedly, start with the simplest checks before changing the app design.",
    "",
    ...list(mission.storage_recovery_plan, (step) => `- ${step}`),
    "",
    "Setup recovery is also prepared if the local dev server blocks you:",
    "",
    `- If blocked by ${mission.today_recovery_plan.matched_friction_node?.title || "setup friction"}, start with: ${mission.today_recovery_plan.safest_first_fix}`,
    ...list(mission.today_recovery_plan.verification_steps, (step) => `- Verify: ${step}`),
    "",
    "## Today's AI Context",
    "",
    mission.today_ai_context ? `Use the focused AI context pack if you want help adding browser storage without expanding the project scope: \`${mission.today_ai_context}\`` : "No AI context needed for this mission.",
    "",
    "## Ignore Today",
    "",
    ...list(mission.what_to_ignore_today, (item) => `- ${item}`),
    "",
    "## Visible Win",
    "",
    mission.visible_reward_after_completion,
    "",
    "## Next Mission Preview",
    "",
    `- ${mission.next_mission_preview.title}`,
    `- Why: ${mission.next_mission_preview.reason}`,
    "",
    "## Confidence First",
    "",
    mission.confidence_first_message,
    ""
  ].join("\n");
}

function renderReportMarkdown(report) {
  return [
    "# Mission Report",
    "",
    `Missions generated: ${report.missions_generated}`,
    `Mission quality: ${report.mission_quality}/100`,
    `Estimated completion time: ${formatDuration(report.estimated_completion_time_minutes)}`,
    `Confidence: ${report.confidence}/100`,
    "",
    "## Systems Orchestrated",
    "",
    ...report.systems_orchestrated.map((system) => `- ${system}`),
    "",
    "## Next Recommended Mission",
    "",
    report.next_recommended_mission,
    "",
    "## Generated Files",
    "",
    ...report.generated_files.map((file) => `- ${file}`),
    ""
  ].join("\n");
}

function difficultyFromReadiness(score) {
  if (score >= 70) return "easy";
  if (score >= 50) return "guided";
  return "foundation";
}

function readJson(relativePath, fallback = null) {
  const filePath = path.join(rootDir, relativePath);
  if (!fs.existsSync(filePath)) {
    if (fallback !== null) return fallback;
    throw new Error(`Missing required input: ${relativePath}`);
  }
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function readText(relativePath, fallback = "") {
  const filePath = path.join(rootDir, relativePath);
  if (!fs.existsSync(filePath)) return fallback;
  return fs.readFileSync(filePath, "utf8");
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function round(value) {
  return Number(value.toFixed(2));
}

function list(items, mapper) {
  return Array.isArray(items) && items.length ? items.map(mapper) : ["- None"];
}

function friendlyCanonTitle(item) {
  const titles = {
    "CANON-003": "Vue reactivity: choosing simple state",
    "CANON-007": "Vue conditional display",
    "CANON-009": "Filtering visible items",
    "CANON-013": "Stable keys for list rows",
    "CANON-022": "Browser storage: localStorage vs sessionStorage",
    "CANON-025": "Component communication: props, emits, and model"
  };
  return titles[item.canon_id] || item.title || "Next learning topic";
}

function formatDuration(minutes) {
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  if (!hours) return `${remainder} minutes`;
  if (!remainder) return `${hours} hours`;
  return `${hours} hours ${remainder} minutes`;
}

main();
