const examples = [
  ["relative offset keeps layout space", require("./relative-keeps-layout-space")],
  ["absolute uses nearest positioned ancestor", require("./absolute-nearest-positioned-ancestor")],
  ["fixed stays viewport-pinned", require("./fixed-viewport-pinned")],
  ["sticky requires scroll container and threshold", require("./sticky-scroll-threshold")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-020 example(s).`);
