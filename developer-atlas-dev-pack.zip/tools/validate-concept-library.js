const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const outputDir = path.join(rootDir, "output", "experience", "concepts");

function read(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

function listMarkdown(dir) {
  if (!fs.existsSync(dir)) return [];
  const files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const entryPath = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...listMarkdown(entryPath));
    else if (/\.md$/i.test(entry.name)) files.push(entryPath);
  }
  return files;
}

function requireExists(target, label, errors) {
  if (!fs.existsSync(target)) errors.push(`${label}: missing`);
}

function requirePattern(filePath, pattern, label, errors) {
  if (!fs.existsSync(filePath)) {
    errors.push(`${label}: missing file`);
    return;
  }
  if (!pattern.test(read(filePath))) errors.push(`${label}: missing expected content`);
}

function validateCardSections(files, errors) {
  const required = [
    "## Simple meaning",
    "## Why it exists",
    "## Where you use it",
    "## When to use it",
    "## Tiny example",
    "## Common beginner confusion",
    "## Related concepts",
    "## Similar idea in another technology"
  ];
  for (const file of files) {
    const text = read(file);
    for (const heading of required) {
      if (!text.includes(heading)) {
        errors.push(`${path.relative(rootDir, file)}: missing ${heading}`);
      }
    }
  }
}

function validateAiStandardSections(files, errors) {
  const required = [
    "## Simple meaning",
    "## Why it exists",
    "## What AI should do",
    "## What AI should avoid",
    "## Before changing code",
    "## While writing code",
    "## After the change",
    "## Human check",
    "## Related Atlas nodes"
  ];
  for (const file of files) {
    const text = read(file);
    for (const heading of required) {
      if (!text.includes(heading)) {
        errors.push(`${path.relative(rootDir, file)}: missing ${heading}`);
      }
    }
  }
}

function main() {
  const errors = [];
  const indexPath = path.join(outputDir, "index.md");
  requireExists(indexPath, "output/experience/concepts/index.md", errors);
  if (fs.existsSync(indexPath)) {
    const index = read(indexPath);
    for (const heading of ["# Atlas Concept Library", "## Laravel", "## Vue", "## Comparisons", "## AI Standards", "## How to use this library"]) {
      if (!index.includes(heading)) errors.push(`output/experience/concepts/index.md: missing ${heading}`);
    }
    if (!/Use this when you see a term in a mission and want a quick explanation/i.test(index)) {
      errors.push("output/experience/concepts/index.md: missing mission-flow usage note");
    }
    if (!/Need to start a project first\? See \[Project Start Guides\]\(\.\.\/project-start\/index\.md\)/i.test(index)) {
      errors.push("output/experience/concepts/index.md: missing Project Start Guides cross-link");
    }
    if (!/## Laravel[\s\S]*## Vue[\s\S]*## Comparisons[\s\S]*## AI Standards[\s\S]*Use these when AI is helping with code/i.test(index)) {
      errors.push("output/experience/concepts/index.md: AI Standards should be secondary after human concept sections");
    }
  }

  const laravelFiles = listMarkdown(path.join(outputDir, "laravel"));
  const vueFiles = listMarkdown(path.join(outputDir, "vue"));
  const comparisonFiles = listMarkdown(path.join(outputDir, "comparisons"));
  const aiStandardFiles = listMarkdown(path.join(outputDir, "ai-standards"));
  if (laravelFiles.length < 8) errors.push(`Concept Library: expected at least 8 Laravel cards, found ${laravelFiles.length}`);
  if (vueFiles.length < 8) errors.push(`Concept Library: expected at least 8 Vue cards, found ${vueFiles.length}`);
  if (comparisonFiles.length < 3) errors.push(`Concept Library: expected at least 3 comparison cards, found ${comparisonFiles.length}`);
  if (aiStandardFiles.length !== 6) errors.push(`AI Standards: expected 6 nodes, found ${aiStandardFiles.length}`);
  validateCardSections([...laravelFiles, ...vueFiles], errors);
  validateAiStandardSections(aiStandardFiles, errors);

  requirePattern(path.join(outputDir, "comparisons", "routing-laravel-vue.md"), /Laravel[\s\S]*Vue[\s\S]*server requests[\s\S]*browser/i, "Routing comparison", errors);
  requirePattern(path.join(outputDir, "laravel", "migration.md"), /migration changes database structure|changes the shape of the database/i, "Migration card", errors);
  requirePattern(path.join(outputDir, "laravel", "model.md"), /model represents data[\s\S]*(database table|records)/i, "Model card", errors);
  requirePattern(path.join(outputDir, "laravel", "factory.md"), /fake, test, or demo data/i, "Factory card", errors);
  requirePattern(path.join(outputDir, "laravel", "seeder.md"), /fills? the database with starting or test data/i, "Seeder card", errors);
  requirePattern(path.join(outputDir, "laravel", "relationship.md"), /hasMany[\s\S]*belongsTo/i, "Relationship card", errors);
  requirePattern(path.join(outputDir, "vue", "router.md"), /browser-side routing/i, "Vue Router card", errors);
  requirePattern(path.join(outputDir, "vue", "props.md"), /Props go down|parent component down to a child/i, "Vue props card", errors);
  requirePattern(path.join(outputDir, "vue", "emits.md"), /emits go up|child component up to a parent/i, "Vue emits card", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-code-readability-standard.md"), /clear names[\s\S]*indentation|indentation[\s\S]*clear names/i, "AI Code Readability names and indentation", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-code-readability-standard.md"), /Comment the why|comment the why/i, "AI Code Readability comments", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-small-patch-standard.md"), /smallest useful change[\s\S]*unrelated|unrelated[\s\S]*smallest useful change/i, "AI Small Patch scope", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-explain-before-change-standard.md"), /Name the file or area being changed/i, "AI Explain Before Change file naming", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-human-review-standard.md"), /human stays in control/i, "AI Human Review control", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-concept-check-standard.md"), /Identify which Atlas concepts apply before answering/i, "AI Concept Check before answering", errors);
  requirePattern(path.join(outputDir, "ai-standards", "ai-no-scope-creep-standard.md"), /Do not add features because they seem useful|Adding auth/i, "AI No Scope Creep unasked features", errors);

  console.log("Atlas Concept Library validation");
  console.log(`Laravel cards: ${laravelFiles.length}`);
  console.log(`Vue cards: ${vueFiles.length}`);
  console.log(`Comparison cards: ${comparisonFiles.length}`);
  console.log(`AI Standard nodes: ${aiStandardFiles.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  if (errors.length) process.exitCode = 1;
}

main();
