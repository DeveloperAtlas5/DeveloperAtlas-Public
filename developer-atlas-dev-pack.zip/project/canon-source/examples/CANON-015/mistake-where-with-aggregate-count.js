const { assertNoAggregateInWhere } = require("./query-simulator");

module.exports = function runMistakeWhereWithAggregateCount() {
  let rejected = false;

  try {
    assertNoAggregateInWhere("COUNT(*) > 1");
  } catch (error) {
    rejected = error.message.includes("HAVING");
  }

  if (!rejected) {
    throw new Error("WHERE with COUNT(*) should be rejected as an aggregate placement mistake.");
  }

  assertNoAggregateInWhere("status = 'paid'");

  return true;
};
