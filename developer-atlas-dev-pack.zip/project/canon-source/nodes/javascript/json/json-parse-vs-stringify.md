# JSON.parse() vs JSON.stringify()

## Status Metadata

- Canon ID: CANON-017
- Node ID: canon.javascript.json.parse-vs-stringify
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript data exchange
- Level: rookie/junior
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `JSON.parse()` when you have JSON text and need a JavaScript value. Use `JSON.stringify()` when you have a JavaScript value and need JSON text for an API, file, log, message, or storage boundary.

This is a direction decision:

- `JSON.parse()` means text -> value.
- `JSON.stringify()` means value -> text.
- JSON is a text data format, not a JavaScript object.

## What Problem This Solves

Beginners often treat JSON and JavaScript objects as the same thing. That causes daily bugs:

- Calling `JSON.parse()` on an object that is already a JavaScript value.
- Sending an object as a request body without stringifying it.
- Saving `[object Object]` instead of JSON text.
- Forgetting that invalid JSON throws.
- Expecting JSON to preserve functions, `undefined`, symbols, dates, maps, sets, or circular references.

This node solves a boundary decision: are you crossing between text and runtime data?

## Mental Model

Think of JSON as a shipping label format for data.

Inside your JavaScript program, you work with runtime values:

```js
const user = { id: 1, name: "Ada" };
```

Across boundaries, data often travels as text:

```js
'{"id":1,"name":"Ada"}'
```

`JSON.stringify()` packs a value into JSON text. `JSON.parse()` unpacks JSON text into a JavaScript value.

```text
JavaScript value -- JSON.stringify() --> JSON text
JSON text        -- JSON.parse()     --> JavaScript value
```

The practical rule is:

> Parse when text enters your program. Stringify when data leaves your program as JSON text.

## Beginner Explanation

JSON looks like a JavaScript object, but it is not the same thing. JSON is text.

This is JSON text:

```js
const text = '{"name":"Ada","active":true}';
```

This is a JavaScript object:

```js
const user = { name: "Ada", active: true };
```

If you want to read `user.name`, you need a JavaScript object:

```js
const user = JSON.parse(text);
console.log(user.name);
```

If you want to store or send the object as JSON text:

```js
const body = JSON.stringify(user);
```

Beginner rule:

1. Have text? Parse it.
2. Have a value? Stringify it before JSON transport or text storage.
3. Not sure? Check `typeof value`.

## Professional Explanation

JSON conversion belongs at system boundaries: HTTP request and response bodies, localStorage, message queues, files, logs, cache payloads, and AI context serialization. Production code should make those boundary crossings explicit.

`JSON.parse()` accepts a JSON string and returns the JavaScript value represented by that string. It throws a `SyntaxError` when the input is not valid JSON. It can also receive a reviver function, but most application code should prefer ordinary parsing followed by explicit validation or normalization.

`JSON.stringify()` converts a JavaScript value to a JSON string. It can receive a replacer and spacing argument. It omits or converts unsupported values depending on location: object properties with `undefined`, functions, or symbols are omitted; unsupported array elements become `null`; `Date` objects serialize through `toJSON()`; circular references throw.

The review signal is simple: parsing should be close to untrusted text input, and stringifying should be close to JSON output. Business logic should mostly work with validated JavaScript values, not raw JSON strings.

## Syntax

```js
const value = JSON.parse(jsonText);
const jsonText = JSON.stringify(value);
```

Common forms:

```js
const settings = JSON.parse(localStorage.getItem("settings") || "{}");
```

```js
await fetch("/api/settings", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(settings)
});
```

```js
const pretty = JSON.stringify(report, null, 2);
```

## Decision Guide

Ask these questions in order:

1. Is the current value a JSON string?
   Use `JSON.parse()`.
2. Is the current value already a JavaScript object, array, number, boolean, or `null`?
   Do not parse it.
3. Do you need to send, store, log, or copy data as JSON text?
   Use `JSON.stringify()`.
4. Does the value contain functions, `undefined`, symbols, dates, maps, sets, bigints, or circular references?
   Check whether JSON is the right format.
5. Did the data come from a user, API, file, localStorage, or AI assistant?
   Parse carefully and validate the result.
6. Are you trying to clone a complex object?
   Do not default to JSON conversion.

## Comparison Table

| Choice | Direction | Best For | Throws Or Loses Data When |
| --- | --- | --- | --- |
| `JSON.parse()` | JSON text -> JavaScript value | Reading API text, localStorage text, config text | Input is not valid JSON |
| `JSON.stringify()` | JavaScript value -> JSON text | API payloads, storage, logs, AI context packs | Value contains circular references, bigints, or unsupported values |
| Validation | Parsed value -> trusted shape | Safe app logic | Schema or expected shape is missing |
| `structuredClone()` | Value -> independent value | Cloning supported runtime values | Value is not cloneable |

## When To Use The Primary Option

Use `JSON.parse()` when:

- You have a string containing JSON text.
- You read from localStorage or another text-only store.
- An API, file, queue, or tool gives you JSON text.
- You need to turn an AI-generated JSON string into a JavaScript value.
- You are at an input boundary and will validate the result.

```js
function readStoredSettings(storage) {
  const raw = storage.getItem("settings");
  return raw ? JSON.parse(raw) : { theme: "light" };
}
```

## When To Use The Alternative

Use `JSON.stringify()` when:

- You need an HTTP JSON request body.
- You save structured data into localStorage.
- You write JSON to a file or message queue.
- You create a compact AI context payload.
- You need readable debug output for plain data.

```js
function saveStoredSettings(storage, settings) {
  storage.setItem("settings", JSON.stringify(settings));
}
```

## When Not To Use This Decision

Do not use `JSON.parse()` or `JSON.stringify()` when:

- The value is already in the right form.
- You need to clone objects with methods, prototypes, maps, sets, dates, regexes, or circular references.
- You need to preserve `undefined`, functions, symbols, or `BigInt`.
- You need secure validation. Parse first, then validate with explicit checks or a schema.
- You are trying to hide a data-shape problem by repeatedly parsing or stringifying.
- You need streaming parsing for very large payloads.

## Alternatives

### Explicit Validation

Use validation after parsing untrusted data.

```js
function isSettings(value) {
  return value && typeof value.theme === "string";
}
```

### structuredClone()

Use `structuredClone()` for supported runtime cloning instead of JSON round-tripping.

```js
const copy = structuredClone(settings);
```

### URLSearchParams

Use `URLSearchParams` for form-like query strings instead of JSON.

```js
const params = new URLSearchParams({ page: "1", sort: "name" });
```

## Production Examples

### Parse API JSON Response String

```js
async function loadProfile(fetchText) {
  const raw = await fetchText("/api/profile");
  const parsed = JSON.parse(raw);

  if (!parsed || typeof parsed.name !== "string") {
    throw new Error("Invalid profile payload");
  }

  return parsed;
}
```

### Stringify API Payload

```js
async function updateProfile(profile) {
  return fetch("/api/profile", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: profile.name,
      timezone: profile.timezone
    })
  });
}
```

### Store User Preferences

```js
const preferences = {
  theme: "dark",
  density: "compact"
};

localStorage.setItem("preferences", JSON.stringify(preferences));

const restored = JSON.parse(localStorage.getItem("preferences"));
```

### AI Context Pack Boundary

```js
const aiContext = JSON.stringify({
  goal: "Build a Vue todo app",
  knownNodes: ["CANON-017"],
  constraints: ["beginner-friendly", "no backend yet"]
});
```

## Common Mistakes

- Parsing a value that is already an object.
- Stringifying a value twice and sending quoted JSON text inside JSON text.
- Forgetting to stringify a request body.
- Assuming `JSON.stringify()` preserves `undefined`, functions, symbols, or class methods.
- Assuming JSON round-tripping is a safe deep clone for all values.
- Not handling `SyntaxError` from invalid JSON.
- Trusting parsed data without validating the shape.

## Debugging Checklist

- Check `typeof value`. JSON text should be a string before parsing.
- Log a small sample of the raw input before parsing.
- If `JSON.parse()` throws, validate quotes, commas, trailing commas, and single quotes.
- If an API receives an empty body, check `JSON.stringify()` and `Content-Type`.
- If data disappears after `JSON.stringify()`, check for `undefined`, functions, symbols, or non-plain objects.
- If stringified output says `[object Object]`, something converted the object with `String()` instead of `JSON.stringify()`.
- If parsing localStorage fails, clear or migrate old stored data.

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-017/`.

Run:

```bash
npm run canon:verify:017
```

Verified examples:

- Parse an API JSON response string.
- Stringify an object for localStorage and API payloads.
- Detect the mistake of parsing an already parsed object.
- Detect circular and unsupported value behavior during stringification.

## Performance Notes

For normal API payloads and settings objects, JSON conversion cost is rarely the main issue. Large payloads can block the main thread during parsing or stringifying, so production systems should consider payload size, streaming formats, pagination, workers, or server-side filtering when data becomes large.

Avoid repeated parse/stringify cycles in hot paths. Convert at the boundary, validate once, then pass JavaScript values through application logic.

## AI Coding Guidance

- Ask whether the data is currently JSON text or a JavaScript value.
- Generate `JSON.parse()` only when the input is a string.
- Generate `JSON.stringify()` for JSON request bodies, localStorage writes, file writes, and structured AI context payloads.
- Add `Content-Type: application/json` when generating a JSON HTTP request body.
- Add validation after parsing untrusted API, file, user, localStorage, or AI-generated data.
- Do not use JSON round-tripping as the default deep clone.
- Warn about circular references and unsupported values when stringifying complex objects.

## Teaching Notes

Teach this with arrows before syntax:

```text
text -> parse -> value
value -> stringify -> text
```

Then show two objects that look similar but behave differently:

```js
'{"name":"Ada"}' // string
{ name: "Ada" }  // object
```

For rookies, emphasize boundary words: receive, read, store, send. For juniors, add failure modes: invalid JSON, double parsing, double stringifying, unsupported values, and validation after parsing.

## Interview Questions

1. What is the difference between JSON text and a JavaScript object?
2. When should you use `JSON.parse()`?
3. When should you use `JSON.stringify()`?
4. What happens when `JSON.parse()` receives invalid JSON?
5. What kinds of values are lost or changed by `JSON.stringify()`?
6. Why is parsing not the same as validating?

## Exercises

### Beginner

Parse this JSON string and read the `name` field:

```js
const raw = '{"id":1,"name":"Ada"}';
```

### Intermediate

Save a settings object to localStorage and restore it with a default fallback when no settings exist.

### Advanced

Write a `safeParseSettings()` helper that catches invalid JSON, validates the shape, and returns a default settings object when needed.

## Related Atlas Nodes

- `javascript.function.fetch`
- `CANON-011`
- `CANON-016`
- `CANON-012`

## Evidence And Sources

- MDN JSON.parse(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse
- MDN JSON.stringify(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
- MDN JSON reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON
- ECMAScript JSON.parse: https://tc39.es/ecma262/multipage/structured-data.html#sec-json.parse
- ECMAScript JSON.stringify: https://tc39.es/ecma262/multipage/structured-data.html#sec-json.stringify

## Proof Of Superiority Summary

Official references explain the APIs accurately. Atlas adds the practical decision layer: identify the boundary, choose the correct conversion direction, validate untrusted parsed data, and avoid JSON conversion when the value is already in the right form or contains unsupported runtime features.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 15 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 1 |
| Total | 100 | 95 |
