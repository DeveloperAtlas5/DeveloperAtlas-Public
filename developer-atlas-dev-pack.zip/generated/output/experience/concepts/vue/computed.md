# Vue computed

Technology: Vue

## Simple meaning

`computed` creates a value derived from other reactive values.

## Why it exists

It keeps derived display logic clear and updates it only when its dependencies change.

## Where you use it

Inside Vue setup code.

## When to use it

Use `computed` when a value can be calculated from existing state.

## Tiny example

`const remaining = computed(() => todos.value.filter(t => !t.done).length)`

## Common beginner confusion

Computed values are for derived values, not for causing side effects such as saving data.

## Related concepts

- ref
- reactive
- watch

## Similar idea in another technology

A database query can calculate filtered results on the server; Vue computed calculates derived values in the browser.
