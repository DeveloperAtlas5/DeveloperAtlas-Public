module.exports = function runFilterProductsBySearchText() {
  const products = [
    { id: "p1", name: "Black T-shirt", sku: "TEE-BLK", active: true },
    { id: "p2", name: "White Mug", sku: "MUG-WHT", active: true },
    { id: "p3", name: "Archived Sticker", sku: "STK-OLD", active: false }
  ];

  const query = "mug";
  const matchingProducts = products.filter((product) => {
    const searchableText = `${product.name} ${product.sku}`.toLowerCase();
    return product.active && searchableText.includes(query);
  });

  if (matchingProducts.length !== 1 || matchingProducts[0].id !== "p2") {
    throw new Error("Expected search text to keep only the active mug product");
  }
};
