# Vue Concept Cards

## How to use this file

This file is optional. Open this only if the mission uses a Vue word that feels unclear.

You do not need to memorize everything today. Use these cards as small reminders while you work through the Rookie Vue mission.

## Vue state

Vue state is the data your app is using right now, such as the current todo list or the text typed into an input.

- State changes when the user interacts with the app.
- The screen updates when state changes.
- Browser storage is separate from Vue state.

## ref()

`ref()` is often used for one reactive value.

Common examples include input text, a filter value, or a boolean toggle. With arrays, beginners may also see `ref([])`.

In script code, you usually read or write the value with `.value`.

```js
const newTodo = ref('')
```

## reactive()

`reactive()` is often used for an object with multiple related fields, such as a form object or settings object.

You usually access fields directly, not with `.value`.

```js
const form = reactive({ title: '', done: false })
```

For the current todo mission, you may not need both `ref()` and `reactive()`.

## v-model

`v-model` connects an input to Vue state.

When the user types, the state updates. When the state changes, the input can update.

```html
<input v-model="newTodo">
```

## v-for

`v-for` repeats part of the template for each item in a list.

In a todo app, it shows one row per todo.

```html
<li v-for="todo in todos">
```

## :key

`:key` gives Vue a stable identity for each repeated item.

It helps Vue update the right item when the list changes. Use a stable id when possible. Avoid using the array index if items can be reordered or deleted.

```html
<li v-for="todo in todos" :key="todo.id">
```

## computed

`computed` creates a derived value from existing state.

Examples include filtered todos, completed count, or remaining count. Use it when the value can be calculated from state.

```js
const remainingTodos = computed(() => todos.value.filter(todo => !todo.done))
```

## localStorage and Vue state

- Vue state controls what the app shows now.
- localStorage remembers simple non-sensitive data after refresh.
- For todos, save the state to localStorage when it changes.
- Load from localStorage when the app starts.
- Use `JSON.stringify()` when saving arrays or objects.
- Use `JSON.parse()` when loading arrays or objects.

Do not store sensitive data in localStorage or sessionStorage.

## What to remember today

- Vue state is the app's current data.
- `ref()` is common for one value.
- `reactive()` is common for an object.
- `v-model` connects inputs to state.
- `v-for` shows lists.
- `:key` helps Vue track list items.
- `computed` calculates values from state.
- localStorage can restore non-sensitive todo data after refresh.
