const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const teamContextDir = path.join(rootDir, "team-context");
const teamContextExamplesDir = path.join(teamContextDir, "examples");
const teamContextOutputDir = path.join(rootDir, "output", "team-context");

function ensureTeamContextOutputDir() {
  fs.mkdirSync(teamContextOutputDir, { recursive: true });
}

function readTeamContexts() {
  if (!fs.existsSync(teamContextExamplesDir)) return [];

  return fs.readdirSync(teamContextExamplesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(teamContextExamplesDir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        context: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function countValues(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

module.exports = {
  teamContextDir,
  teamContextExamplesDir,
  teamContextOutputDir,
  ensureTeamContextOutputDir,
  readTeamContexts,
  countValues,
  unique
};
