const fs = require("fs");
const path = require("path");
const {
  rootDir
} = require("./content-utils");
const {
  readCanonIndex,
  getKnownReferences,
  getSkillArea
} = require("./learning-utils");

const profilesDir = path.join(rootDir, "learning", "profiles");
const levels = new Set(["rookie", "junior", "professional", "ai_tutor"]);

function main() {
  const errors = [];
  const warnings = [];
  const index = readCanonIndex();
  const entries = index.entries || [];
  const knownRefs = getKnownReferences(entries);
  const skillAreas = new Set(entries.map(getSkillArea));
  const profileIds = new Set();
  const profiles = readProfiles(errors);

  for (const profile of profiles) {
    validateProfile(profile, { profileIds, knownRefs, skillAreas }, errors, warnings);
  }

  console.log("Atlas Learner Profile validation");
  console.log(`Profiles: ${profiles.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function readProfiles(errors) {
  if (!fs.existsSync(profilesDir)) return [];
  return fs.readdirSync(profilesDir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const profilePath = path.join(profilesDir, fileName);
      try {
        return JSON.parse(fs.readFileSync(profilePath, "utf8"));
      } catch (error) {
        errors.push(`learning/profiles/${fileName}: invalid JSON (${error.message})`);
        return null;
      }
    })
    .filter(Boolean);
}

function validateProfile(profile, context, errors, warnings) {
  if (!isNonEmptyString(profile.profile_id)) {
    errors.push("profile is missing profile_id");
    return;
  }
  if (context.profileIds.has(profile.profile_id)) errors.push(`${profile.profile_id}: duplicate profile_id`);
  context.profileIds.add(profile.profile_id);

  if (!levels.has(profile.level)) errors.push(`${profile.profile_id}: level must be rookie, junior, professional, or ai_tutor`);
  validateStringArray(profile, "goals", errors);
  validateRefArray(profile, "known_nodes", context.knownRefs, warnings);
  validateRefArray(profile, "weak_nodes", context.knownRefs, warnings);
  validateStringArray(profile, "completed_practice", errors);

  if (!isNonEmptyString(profile.preferred_style)) errors.push(`${profile.profile_id}: preferred_style must be a non-empty string`);
  if (typeof profile.available_minutes !== "number" || profile.available_minutes <= 0) {
    errors.push(`${profile.profile_id}: available_minutes must be a positive number`);
  }
  if (!context.skillAreas.has(profile.target_skill_area)) {
    warnings.push(`${profile.profile_id}: target_skill_area is not currently in the skill tree: ${profile.target_skill_area}`);
  }
  if (!profile.confidence_by_node || typeof profile.confidence_by_node !== "object" || Array.isArray(profile.confidence_by_node)) {
    errors.push(`${profile.profile_id}: confidence_by_node must be an object`);
  } else {
    for (const [nodeId, confidence] of Object.entries(profile.confidence_by_node)) {
      if (!context.knownRefs.has(nodeId)) warnings.push(`${profile.profile_id}: confidence references unknown node ${nodeId}`);
      if (typeof confidence !== "number" || confidence < 0 || confidence > 1) {
        errors.push(`${profile.profile_id}: confidence for ${nodeId} must be from 0 to 1`);
      }
    }
  }
}

function validateStringArray(profile, field, errors) {
  if (!Array.isArray(profile[field])) {
    errors.push(`${profile.profile_id || "profile"}: ${field} must be an array`);
    return;
  }
  for (const item of profile[field]) {
    if (!isNonEmptyString(item)) errors.push(`${profile.profile_id}: ${field} contains a non-string entry`);
  }
}

function validateRefArray(profile, field, knownRefs, warnings) {
  if (!Array.isArray(profile[field])) {
    warnings.push(`${profile.profile_id}: ${field} should be an array`);
    return;
  }
  const seen = new Set();
  for (const ref of profile[field]) {
    if (!isNonEmptyString(ref)) {
      warnings.push(`${profile.profile_id}: ${field} contains a non-string reference`);
      continue;
    }
    if (seen.has(ref)) warnings.push(`${profile.profile_id}: duplicate ${field} reference ${ref}`);
    seen.add(ref);
    if (!knownRefs.has(ref)) warnings.push(`${profile.profile_id}: ${field} references unknown node ${ref}`);
  }
}

function isNonEmptyString(value) {
  return typeof value === "string" && value.trim().length > 0;
}

main();

