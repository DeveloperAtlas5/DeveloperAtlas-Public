function renderRows(items, getKey, previousStateByKey = new Map()) {
  const nextStateByKey = new Map();

  const rows = items.map((item, index) => {
    const key = getKey(item, index);
    const state = previousStateByKey.get(key) || {
      draftValue: `draft:${item.id}`,
      createdFor: item.id
    };

    nextStateByKey.set(key, state);

    return {
      key,
      itemId: item.id,
      label: item.label,
      state
    };
  });

  return { rows, stateByKey: nextStateByKey };
}

function assertUniqueKeys(items, getKey) {
  const seen = new Set();

  for (const [index, item] of items.entries()) {
    const key = getKey(item, index);

    if (seen.has(key)) {
      throw new Error(`Duplicate key detected: ${String(key)}`);
    }

    seen.add(key);
  }

  return true;
}

module.exports = {
  renderRows,
  assertUniqueKeys
};
