# CANON-011 Proof Of Superiority

Canon ID: CANON-011
Node ID: canon.javascript.promise.async-await-vs-promise-then
Title: async vs await vs Promise.then()

## What Official Docs Explain Well

MDN and the ECMAScript specification explain `async` function behavior, `await`, promise continuation semantics, and `Promise.prototype.then()`.

## What Developers Still Struggle With

Developers rarely struggle because they cannot write the syntax. They struggle because the syntax hides decisions:

- Is this work sequential or concurrent?
- Does the caller receive and handle the returned promise?
- Will `try/catch` actually catch this rejection?
- Does the next `.then()` step receive the intended value?
- Is a promise chain compact, or is it hiding control flow that needs names?

These mistakes show up in production as swallowed errors, slow request waterfalls, unhandled promise rejections, and hard-to-review async code.

## How Atlas Improves The Explanation

Atlas turns the topic into a decision guide:

- Use `async`/`await` for readable dependent steps, local branching, and local error boundaries.
- Use `Promise.then()` for compact, returned transformation chains.
- Choose concurrency separately with `Promise.all()` or `Promise.allSettled()`.
- Avoid `forEach(async ...)` when completion matters.

This gives developers a practical review model instead of a style debate.

## What Decision Support Atlas Adds

The node explains the trade-off between checklist-shaped async code and pipeline-shaped promise composition. It also names when neither choice is enough, such as parallel coordination, event streams, queues, or explicit sequential loops.

## What Production Guidance Atlas Adds

The node includes realistic handler, transformation-chain, dashboard-loading, and sequential-loop examples. It covers local error handling, returned-chain discipline, unintentional serialization, and code review warnings.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct generation rules:

- Default to `async`/`await` for multi-step application code.
- Use `.then()` only for short, returned chains.
- Return from `.then()` callbacks.
- Do not rely on `try/catch` without `await` or a returned chain.
- Use `Promise.all()` or `Promise.allSettled()` for independent work.

## Why This Deserves Gold Candidate Status

CANON-011 deserves Gold Candidate status because it converts a common async style debate into a clear production decision model with official evidence, deterministic examples, debugging guidance, and AI generation guardrails. It still needs named reviewer sign-off before final Gold approval.
