const assert = require("node:assert/strict");
const { ref } = require("./reactivity-sim");

function run() {
  const count = ref(0);

  count.value += 1;

  assert.equal(count.value, 1);
  return count.value;
}

module.exports = run;

if (require.main === module) run();
