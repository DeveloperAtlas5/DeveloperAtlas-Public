# CANON-023 - JSON.stringify vs JSON.parse

Status: Hardened

## Core idea

JSON.stringify turns data into a string for saving.

JSON.parse turns saved strings back into usable data.

## Use this when

Use this when saving arrays or objects in localStorage.

## Basic pattern

Stringify before saving. Parse after loading.

## Common friction

Invalid saved data can happen while testing. Recover by using a safe fallback.

## Small example

```js
const fallback = [];
const todos = saved ? JSON.parse(saved) : fallback;
```

## Check yourself

- Did you stringify before saving?
- Did you parse after loading?

## Related Canon nodes

- CANON-022
- CANON-027
