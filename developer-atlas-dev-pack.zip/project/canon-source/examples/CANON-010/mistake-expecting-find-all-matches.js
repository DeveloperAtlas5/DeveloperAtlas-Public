module.exports = function runMistakeExpectingFindAllMatches() {
  const users = [
    { id: 1, role: "admin" },
    { id: 2, role: "member" },
    { id: 3, role: "admin" }
  ];

  const firstAdmin = users.find((user) => user.role === "admin");
  const allAdmins = users.filter((user) => user.role === "admin");

  if (Array.isArray(firstAdmin)) {
    throw new Error("Expected find() to return one item, not an array");
  }

  if (firstAdmin.id !== 1) {
    throw new Error("Expected find() to return the first admin");
  }

  if (allAdmins.length !== 2) {
    throw new Error("Expected filter() to return all admin users");
  }
};
