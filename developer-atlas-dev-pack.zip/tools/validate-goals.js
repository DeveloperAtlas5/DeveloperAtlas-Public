const fs = require("fs");
const path = require("path");
const { readEntries } = require("./content-utils");
const { readFrictionNodes } = require("./friction-utils");
const { readTools } = require("./toolkit-utils");
const { readMachineProfiles, readWorkloadProfiles } = require("./hardware-utils");
const {
  goalsDir,
  readGoals,
  readGoalProfiles
} = require("./goal-utils");

const schemaFiles = [
  "goal.schema.json",
  "goal-profile.schema.json",
  "personal-roadmap.schema.json",
  "goal-overlap.schema.json"
];

const goalFields = [
  "goal_id",
  "title",
  "category",
  "audience",
  "required_knowledge_nodes",
  "recommended_canon_nodes",
  "required_tools",
  "recommended_tools",
  "hardware_considerations",
  "common_friction_nodes",
  "estimated_learning_hours",
  "estimated_practice_hours",
  "beginner_notes",
  "professional_notes",
  "output_projects",
  "success_criteria"
];

const goalArrayFields = [
  "required_knowledge_nodes",
  "recommended_canon_nodes",
  "required_tools",
  "recommended_tools",
  "hardware_considerations",
  "common_friction_nodes",
  "beginner_notes",
  "professional_notes",
  "output_projects",
  "success_criteria"
];

const profileFields = [
  "profile_id",
  "learner_level",
  "goals",
  "current_known_nodes",
  "available_hours_per_week",
  "preferred_stack",
  "machine_profile_id",
  "constraints",
  "priority_order"
];

const profileArrayFields = [
  "goals",
  "current_known_nodes",
  "preferred_stack",
  "constraints",
  "priority_order"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);

  let goals = [];
  let profiles = [];
  try {
    goals = readGoals();
    profiles = readGoalProfiles();
  } catch (error) {
    errors.push(`goals: unable to read JSON files (${error.message})`);
  }

  const knownIds = collectKnownIds();
  validateGoalRecords(goals, knownIds, errors, warnings);
  validateProfileRecords(profiles, goals, knownIds, errors, warnings);

  console.log("Atlas Goal Intelligence validation");
  console.log(`Goals: ${goals.length}`);
  console.log(`Goal profiles: ${profiles.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const schemaPath = path.join(goalsDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`goals/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`goals/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function collectKnownIds() {
  const contentIds = new Set(readEntries().map((entry) => entry.frontMatter.id));
  const canonIndex = JSON.parse(fs.readFileSync(path.join(goalsDir, "..", "canon", "canon-index.json"), "utf8"));
  const canonIds = new Set(canonIndex.entries.map((entry) => entry.canon_id));
  const toolIds = new Set(readTools().map((record) => record.data.id));
  const frictionIds = new Set(readFrictionNodes().map((record) => record.node.id));
  const workloadIds = new Set(readWorkloadProfiles().map((record) => record.workload.workload_id));
  const machineProfileIds = new Set(readMachineProfiles().map((record) => record.profile.profile_id));

  return { contentIds, canonIds, toolIds, frictionIds, workloadIds, machineProfileIds };
}

function validateGoalRecords(goals, knownIds, errors, warnings) {
  const seen = new Set();

  for (const { goal, relativePath } of goals) {
    validateRequired(relativePath, goal, goalFields, errors);
    if (seen.has(goal.goal_id)) errors.push(`${relativePath}: duplicate goal_id ${goal.goal_id}`);
    seen.add(goal.goal_id);

    for (const field of goalArrayFields) validateStringArray(relativePath, goal, field, errors, field === "common_friction_nodes");
    validateNonNegativeNumber(relativePath, goal, "estimated_learning_hours", errors);
    validateNonNegativeNumber(relativePath, goal, "estimated_practice_hours", errors);

    warnUnknown(relativePath, goal.required_knowledge_nodes, knownIds.contentIds, "required_knowledge_nodes", warnings);
    warnUnknown(relativePath, goal.recommended_canon_nodes, knownIds.canonIds, "recommended_canon_nodes", warnings);
    warnUnknown(relativePath, [...goal.required_tools, ...goal.recommended_tools], knownIds.toolIds, "tools", warnings);
    warnUnknown(relativePath, goal.hardware_considerations, knownIds.workloadIds, "hardware_considerations", warnings);
    warnUnknown(relativePath, goal.common_friction_nodes, knownIds.frictionIds, "common_friction_nodes", warnings);
  }
}

function validateProfileRecords(profiles, goals, knownIds, errors, warnings) {
  const seen = new Set();
  const goalIds = new Set(goals.map((record) => record.goal.goal_id));

  for (const { profile, relativePath } of profiles) {
    validateRequired(relativePath, profile, profileFields, errors);
    if (seen.has(profile.profile_id)) errors.push(`${relativePath}: duplicate profile_id ${profile.profile_id}`);
    seen.add(profile.profile_id);

    for (const field of profileArrayFields) validateStringArray(relativePath, profile, field, errors, field === "current_known_nodes");
    validateNonNegativeNumber(relativePath, profile, "available_hours_per_week", errors);

    warnUnknown(relativePath, profile.goals, goalIds, "goals", warnings);
    warnUnknown(relativePath, profile.current_known_nodes, knownIds.contentIds, "current_known_nodes", warnings);
    if (!knownIds.machineProfileIds.has(profile.machine_profile_id)) {
      warnings.push(`${relativePath}: machine_profile_id ${profile.machine_profile_id} does not exist`);
    }
    for (const goalId of profile.priority_order || []) {
      if (!(profile.goals || []).includes(goalId)) warnings.push(`${relativePath}: priority_order includes unselected goal ${goalId}`);
    }
  }
}

function validateRequired(relativePath, data, fields, errors) {
  for (const field of fields) {
    if (data[field] === undefined || data[field] === null || data[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }
}

function validateStringArray(relativePath, data, field, errors, allowEmpty = false) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }
  if (!allowEmpty && data[field].length === 0) errors.push(`${relativePath}: ${field} should not be empty`);
  for (const item of data[field]) {
    if (typeof item !== "string" || !item.trim()) errors.push(`${relativePath}: ${field} contains a non-string entry`);
  }
}

function validateNonNegativeNumber(relativePath, data, field, errors) {
  if (typeof data[field] !== "number" || data[field] < 0) {
    errors.push(`${relativePath}: ${field} should be a non-negative number`);
  }
}

function warnUnknown(relativePath, values = [], knownSet, label, warnings) {
  for (const value of values) {
    if (!knownSet.has(value)) warnings.push(`${relativePath}: ${label} references unknown id ${value}`);
  }
}

main();
