# let vs const

## Status Metadata

- Canon ID: CANON-CANDIDATE-JS-001
- Node ID: canon.javascript.fundamentals.let-vs-const
- Status: candidate
- Score: 55
- Version: 2026.1
- Source family: JavaScript
- Level: rookie/junior
- Audience: future Rookie-to-Junior frontend path
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use const when a variable binding should not be reassigned. Use let when the variable needs to receive a new value later. This candidate supports future Rookie-to-Junior frontend coverage and is not part of the current public alpha mission.

## What Problem This Solves

This reduces beginner confusion around let vs const by turning the topic into a small decision with practical recovery guidance.

## Mental Model

Use const when a variable binding should not be reassigned. Use let when the variable needs to receive a new value later.

## Beginner Explanation

Use const when a variable binding should not be reassigned. Use let when the variable needs to receive a new value later. The goal is not to memorize a rule; the goal is to choose the option that matches what the code is trying to do.

## Professional Explanation

Use this decision to make intent visible in reviews, keep generated code scoped, and reduce hidden maintenance costs. The production signal is code that another developer can explain without reverse-engineering the author's guess.

## Syntax

```text
const name = "Atlas";
let count = 0;
```

## Decision Guide

1. Name the task in plain language.
2. Choose const when: Use const for values that keep the same binding and let for counters, toggles, or step-by-step updates.
3. Choose let when it communicates the intent better.
4. If neither fits, pause and look for a prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| const | Use const for values that keep the same binding and let for counters, toggles, or step-by-step updates. | Can confuse beginners when used by habit. |
| let | A clearer fit when the primary option does not match the task | Can add noise if the project does not need it. |

## When To Use The Primary Option

- Use const for values that keep the same binding and let for counters, toggles, or step-by-step updates.
- Use it when it makes the code easier to explain.
- Use it when it matches the surrounding project convention.

## When To Use The Alternative

- Use it when const would hide the real intent.
- Use it when the alternative gives the learner or reviewer a clearer signal.
- Use it when existing project code already follows that pattern.

## When Not To Use This Decision

- Do not use let by default when the value never gets reassigned, and do not use const if the code needs reassignment.
- Do not expand the current Rookie Vue alpha mission just to use this candidate.
- Do not treat this candidate as fully reviewed evidence.

## Alternatives

- Use an existing Gold Candidate node when this topic overlaps one.
- Use a smaller prerequisite concept when the learner is blocked earlier.

## Production Examples

### Beginner Example

```text
const todos = [];
let visibleCount = todos.length;
```

### Review Example

```text
Before accepting the code, explain why const or let matches the task.
```

## Common Mistakes

- Thinking const makes objects immutable. It only protects the variable binding, not nested object values.
- Copying generated code without checking whether it matches the task.
- Treating the candidate as final before examples and sources are hardened.

## Debugging Checklist

- If reassignment throws an error, check whether the variable was declared with const.
- Compare the current behavior with the intended choice.
- Ask whether a smaller prerequisite concept would unblock the learner faster.

## Mechanical Verification

Runnable or deterministic examples should be added during a future hardening sprint. This candidate intentionally has no runnable example folder yet.

## Performance Notes

No performance claim is finalized for this candidate. Future hardening should separate real runtime concerns from readability and learning concerns.

## AI Coding Guidance

- Ask AI to use const by default and switch to let only when reassignment is required.
- Ask for a small, scoped change.
- Ask the assistant to explain the trade-off before producing code.

## Teaching Notes

Start with the plain-language model, show the beginner example, then ask the learner to explain the choice back in one sentence. Keep this candidate optional until a mission needs it.

## Interview Questions

1. When would you choose const?
2. What mistake would make let or another concept clearer?

## Exercises

### Beginner

Review a small file and change unnecessary let declarations to const.

### Junior

Find one example in a small project and explain whether it uses the clearer option.

## Related Atlas Nodes

- CANON-011
- CANON-CANDIDATE-JS-004

## Evidence And Sources

- Candidate backlog entry only. Official source links must be added during hardening.
- Evidence level: candidate draft.
- Confidence: medium.

## Proof Of Superiority Summary

This candidate has a draft improvement hypothesis only. It should not be treated as reviewed or publication-ready.

## Scorecard Placeholder

- Current score: 55
- Status: candidate
- Needs official sources, stronger examples, verification, editorial review, and reviewer sign-off before any Gold consideration.
