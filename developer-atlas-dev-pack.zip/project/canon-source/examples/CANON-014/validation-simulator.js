function isEmpty(value) {
  return value === undefined || value === null || value === "";
}

function validate(payload, rules, context = {}) {
  const errors = {};
  const validated = {};

  for (const [field, fieldRules] of Object.entries(rules)) {
    const value = payload[field];
    const nullable = fieldRules.includes("nullable");

    for (const rule of fieldRules) {
      if (rule === "nullable" && isEmpty(value)) break;

      if (rule === "required" && isEmpty(value)) {
        addError(errors, field, "required");
      }

      if (rule === "email" && !isEmpty(value) && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value)) {
        addError(errors, field, "email");
      }

      if (rule === "integer" && !Number.isInteger(value)) {
        addError(errors, field, "integer");
      }

      if (typeof rule === "object" && rule.in && !rule.in.includes(value)) {
        addError(errors, field, "in");
      }

      if (typeof rule === "object" && rule.unique) {
        const conflict = context.records.some((record) => {
          const sameValue = record[rule.column] === value;
          const sameScope = !rule.scope || record[rule.scope.column] === rule.scope.value;
          const ignored = rule.ignoreId !== undefined && record.id === rule.ignoreId;
          return sameValue && sameScope && !ignored;
        });

        if (conflict) addError(errors, field, "unique");
      }
    }

    if (!errors[field] && value !== undefined) {
      validated[field] = value;
    }
  }

  return {
    passes: Object.keys(errors).length === 0,
    errors,
    validated
  };
}

function addError(errors, field, message) {
  errors[field] = errors[field] || [];
  errors[field].push(message);
}

module.exports = {
  validate
};
