const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const sourcePath = path.join(rootDir, "content", "concepts", "concept-library.json");
const outputDir = path.join(rootDir, "output", "experience", "concepts");

function slugify(name) {
  return name
    .toLowerCase()
    .replace(/\/+/g, " ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeFile(relativePath, content) {
  const target = path.join(outputDir, relativePath);
  ensureDir(path.dirname(target));
  fs.writeFileSync(target, `${content.trim()}\n`);
}

function renderConceptCard(card) {
  return [
    `# ${card.name}`,
    "",
    `Technology: ${card.technology}`,
    "",
    "## Simple meaning",
    "",
    card.meaning,
    "",
    "## Why it exists",
    "",
    card.why,
    "",
    "## Where you use it",
    "",
    card.where,
    "",
    "## When to use it",
    "",
    card.when,
    "",
    "## Tiny example",
    "",
    card.example,
    "",
    "## Common beginner confusion",
    "",
    card.confusion,
    "",
    "## Related concepts",
    "",
    card.related.map((item) => `- ${item}`).join("\n"),
    "",
    "## Similar idea in another technology",
    "",
    card.similar
  ].join("\n");
}

function renderComparison(card) {
  const laravelHeading = card.slug.includes("routing") ? "## Laravel routing" : "## Laravel side";
  const vueHeading = card.slug.includes("routing") ? "## Vue routing" : "## Vue side";
  return [
    `# ${card.title}`,
    "",
    "## Shared idea",
    "",
    card.shared,
    "",
    laravelHeading,
    "",
    card.laravel,
    "",
    vueHeading,
    "",
    card.vue,
    "",
    "## Main difference",
    "",
    card.difference,
    "",
    "## Related concepts",
    "",
    card.related
  ].join("\n");
}

function renderAiStandard(card) {
  return [
    `# ${card.name}`,
    "",
    "Technology: AI Standard",
    "",
    "## Simple meaning",
    "",
    card.meaning,
    "",
    "## Why it exists",
    "",
    card.why,
    "",
    "## What AI should do",
    "",
    card.should_do.map((item) => `- ${item}`).join("\n"),
    "",
    "## What AI should avoid",
    "",
    card.should_avoid.map((item) => `- ${item}`).join("\n"),
    "",
    "## Before changing code",
    "",
    card.before,
    "",
    "## While writing code",
    "",
    card.while,
    "",
    "## After the change",
    "",
    card.after,
    "",
    "## Human check",
    "",
    card.human_check,
    "",
    "## Related Atlas nodes",
    "",
    card.related.map((item) => `- ${item}`).join("\n")
  ].join("\n");
}

function renderIndex(data) {
  const laravelLinks = data.laravel
    .map((card) => `- [${card.name}](laravel/${slugify(card.name.replace(/^Laravel /, ""))}.md)`)
    .join("\n");
  const vueLinks = data.vue
    .map((card) => `- [${card.name}](vue/${slugify(card.name.replace(/^Vue /, ""))}.md)`)
    .join("\n");
  const comparisonLinks = data.comparisons
    .map((card) => `- [${card.title}](comparisons/${card.slug}.md)`)
    .join("\n");
  const aiStandardLinks = data.ai_standards
    .map((card) => `- [${card.name}](ai-standards/${card.slug}.md)`)
    .join("\n");
  return [
    "# Atlas Concept Library",
    "",
    "Use this when you see a term in a mission and want a quick explanation.",
    "",
    "Need to start a project first? See [Project Start Guides](../project-start/index.md).",
    "",
    "A learner should be able to look up a concept without leaving the mission flow.",
    "",
    "Atlas should explain recurring programming ideas across technologies, not make learners relearn the same idea from zero every time.",
    "",
    "## Laravel",
    "",
    laravelLinks,
    "",
    "## Vue",
    "",
    vueLinks,
    "",
    "## Comparisons",
    "",
    comparisonLinks,
    "",
    "## AI Standards",
    "",
    "Use these when AI is helping with code.",
    "",
    "They explain how AI should keep changes readable, small, reviewable, and aligned with the goal.",
    "",
    aiStandardLinks,
    "",
    "## How to use this library",
    "",
    "Open one card when a term blocks your current mission. Read the simple meaning first, then return to the mission."
  ].join("\n");
}

function main() {
  const data = JSON.parse(fs.readFileSync(sourcePath, "utf8"));
  if (fs.existsSync(outputDir)) fs.rmSync(outputDir, { recursive: true, force: true });
  ensureDir(outputDir);

  for (const card of data.laravel) {
    writeFile(path.join("laravel", `${slugify(card.name.replace(/^Laravel /, ""))}.md`), renderConceptCard(card));
  }
  for (const card of data.vue) {
    writeFile(path.join("vue", `${slugify(card.name.replace(/^Vue /, ""))}.md`), renderConceptCard(card));
  }
  for (const card of data.comparisons) {
    writeFile(path.join("comparisons", `${card.slug}.md`), renderComparison(card));
  }
  for (const card of data.ai_standards) {
    writeFile(path.join("ai-standards", `${card.slug}.md`), renderAiStandard(card));
  }
  writeFile("index.md", renderIndex(data));

  console.log(`Generated output/experience/concepts with ${data.laravel.length} Laravel cards, ${data.vue.length} Vue cards, ${data.comparisons.length} comparison cards, and ${data.ai_standards.length} AI Standard nodes.`);
}

main();
