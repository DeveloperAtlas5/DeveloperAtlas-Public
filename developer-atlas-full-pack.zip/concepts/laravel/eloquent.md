# Laravel Eloquent

Technology: Laravel

## Simple meaning

Eloquent is Laravel's model system for working with database records.

## Why it exists

It lets you query and change data through PHP classes instead of writing raw SQL for every task.

## Where you use it

In model classes and code that uses those models.

## When to use it

Use Eloquent when your app reads, creates, updates, or deletes database records.

## Tiny example

`Post::create(['title' => 'Hello']);`

## Common beginner confusion

Eloquent is not a separate database. It is Laravel's way to talk to the database.

## Related concepts

- Model
- Relationship
- Migration

## Similar idea in another technology

A frontend state helper manages browser data; Eloquent manages database-backed data through models.
