# Laravel Controller

Technology: Laravel

## Simple meaning

A controller is a class that groups request-handling actions.

## Why it exists

Controllers keep route files small and put page or API logic in one organized place.

## Where you use it

Usually in `app/Http/Controllers`.

## When to use it

Use a controller when a route needs more than a tiny response.

## Tiny example

`public function index() { return view('posts.index'); }`

## Common beginner confusion

A controller should not be the whole app. It should coordinate work, then use models, validation, views, or resources.

## Related concepts

- Route
- Request
- Model

## Similar idea in another technology

A Vue component can coordinate UI behavior for part of the page, while a Laravel controller coordinates a server request.
