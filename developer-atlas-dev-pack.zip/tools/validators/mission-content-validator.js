const {
  fs,
  path,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionThreeSurfacePath,
  vibeMissionThreeSurfacePath,
  missionDashboardPath,
  startHerePath,
  firstTimeQuickStartPath,
  aiPromptPackPath,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedFirstTimeQuickStartPath,
  packagedAiPromptPackPath,
  packagedMissionDashboardPath,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  packagedMissionThreeSurfacePath,
  packagedVibeMissionThreeSurfacePath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange,
  countLines
} = require("./shared-validator-utils");

function validateGeneratedMission(errors, warnings) {
  const missionPath = path.join(outputDir, "today-mission.json");
  if (!fs.existsSync(missionPath)) {
    warnings.push("output/mission/today-mission.json has not been generated yet");
    return;
  }

  const mission = parseJson(missionPath, "output/mission/today-mission.json", errors);
  if (!mission) return;

  for (const field of requiredMissionFields) {
    if (mission[field] === undefined || mission[field] === null || mission[field] === "") {
      errors.push(`output/mission/today-mission.json: missing ${field}`);
    }
  }

  if (!Array.isArray(mission.today_canon) || mission.today_canon.length === 0) {
    errors.push("output/mission/today-mission.json: today_canon should contain at least one item");
  }

  if (!Array.isArray(mission.systems_orchestrated) || mission.systems_orchestrated.length < 8) {
    warnings.push("output/mission/today-mission.json: mission should orchestrate at least 8 systems");
  }

  validateRange(mission, "confidence_score", 0, 100, errors);
  validateRange(mission, "mission_quality_score", 0, 100, errors);
}

function validateStartHere(errors, warnings) {
  validateStartHereFile(startHerePath, "output/experience/START_HERE.md", errors, warnings, false);
  validateFirstTimeQuickStartFile(
    firstTimeQuickStartPath,
    "output/experience/first-time-quick-start.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    warnings.push("output/share/developer-atlas-mvp-demo has not been packaged yet");
    return;
  }

  validateStartHereFile(packagedStartHerePath, "output/share/developer-atlas-mvp-demo/START_HERE.md", errors, warnings, true);
  validateFirstTimeQuickStartFile(
    packagedFirstTimeQuickStartPath,
    "output/share/developer-atlas-mvp-demo/first-time-quick-start.md",
    errors,
    warnings,
    true
  );
}

function validateStartHereFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing START_HERE guide`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Developer Atlas Public Alpha Demo",
    "## Start here",
    "## What the folders mean",
    "## Simplest path",
    "## Read here, code there",
    "## Fastest path",
    "## Accessibility note",
    "## Mission path",
    "## Using AI?",
    "## Optional help",
    "## Optional reference",
    "## Give feedback",
    "## What to ignore for now"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/first-time-quick-start\.md/i, "first-time quick start pointer"],
    [/mission-dashboard\.html/i, "mission dashboard pointer"],
    [/You do not need to browse the folders/i, "do-not-browse-folders guidance"],
    [/What the folders mean[\s\S]*`mission\/` is where the learner missions live[\s\S]*`help\/` is optional support[\s\S]*`ai\/` is optional AI-assisted material[\s\S]*`reference\/` is optional concept reference[\s\S]*`reviewer\/` is for testers, mentors, or project reviewers/i, "short folder explanation"],
    [/Simplest path[\s\S]*Open `mission-dashboard\.html`[\s\S]*Start Mission 1[\s\S]*You do not need to browse the folders/i, "START_HERE simplest path guidance"],
    [/Read here, code there[\s\S]*This package guides you[\s\S]*Your Vue todo project is where you write code[\s\S]*Do not edit files inside this Atlas package unless a mission explicitly tells you to/i, "START_HERE read here code there guidance"],
    [/Fastest path[\s\S]*Open `mission-dashboard\.html`[\s\S]*Start Mission 1: `mission\/today-mission-surface\.md`[\s\S]*Use `help\/` only if you get stuck[\s\S]*Answer the reflection questions at the end/i, "fastest path steps"],
    [/Accessibility note[\s\S]*optional read-aloud button[\s\S]*zoom your browser[\s\S]*screen reader or text-to-speech[\s\S]*keyboard/i, "START_HERE accessibility note"],
    [/mission\/today-mission-surface\.md/i, "default learner mission surface"],
    [/Mission 1 is the primary path[\s\S]*mission\/today-mission-surface\.md/i, "Mission 1 primary guidance"],
    [/After Mission 1[\s\S]*mission\/mission-02-todoitem-surface\.md[\s\S]*mission\/mission-03-todostats-surface\.md/i, "Mission 2 and Mission 3 progression guidance"],
    [/matching `.vibe\.md` mission files/i, "AI-assisted mission files guidance"],
    [/Using AI\?[\s\S]*Use the AI mission files or `ai\/ai-prompt-pack\.md`[\s\S]*Give AI one mission at a time/i, "optional AI prompt pack guidance"],
    [/help\/beginner-orientation\.md/i, "beginner orientation pointer"],
    [/help\/terminal-confidence-guide\.md/i, "terminal confidence guide pointer"],
    [/help\/vue-concept-cards\.md/i, "Vue concept cards pointer"],
    [/reference\/canon\/hardened\/[\s\S]*Missions 1-3[\s\S]*optional[\s\S]*not need them to start Mission 1/i, "optional hardened Canon reference guidance"],
    [/mission\/mission-feedback-template\.md/i, "feedback template"],
    [/reviewer\/tester-feedback-report\.md[\s\S]*reviewer\/alpha-package-final-qa\.md[\s\S]*reviewer\/alpha-focus-lock\.md/i, "reviewer feedback files mention"],
    [/Normal testers can ignore reports[\s\S]*package metadata[\s\S]*source code[\s\S]*build scripts[\s\S]*reviewer files/i, "ignore-for-now guidance"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateFirstTimeQuickStartFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing first-time quick start`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredSections = [
    "# First-Time Quick Start",
    "## Open this first",
    "## Where do I work?",
    "## Your only goal",
    "## If you get nervous",
    "## Small success checklist"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  const requiredMeanings = [
    [/Your only goal[\s\S]*Make todos survive refresh/i, "single quick-start goal"],
    [/Open this first[\s\S]*Open `mission-dashboard\.html` first[\s\S]*Start Mission 1[\s\S]*You do not need to browse the folders/i, "dashboard and Mission 1 pointers"],
    [/Where do I work\?[\s\S]*Use Atlas as the guide[\s\S]*Code in your Vue todo project[\s\S]*Do not edit files inside this Atlas package unless a mission explicitly tells you to/i, "quick-start workspace guidance"],
    [/If you get nervous[\s\S]*Use help only if you get stuck[\s\S]*Stay with Mission 1 first/i, "nervous learner guidance"],
    [/I can add a todo[\s\S]*I can refresh the page[\s\S]*My todo is still there[\s\S]*I know where to look if I get stuck/i, "small success checklist"],
    [/My todo is still there/i, "visible win guidance"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }

  if (/reviewer|owner|architecture|Canon|reports/i.test(text)) {
    errors.push(`${label}: quick start should avoid reviewer, owner, Canon, report, or architecture language`);
  }

  const lineCount = countLines(filePath);
  if (lineCount > 35) {
    errors.push(`${label}: first-time quick start should stay under 35 lines`);
  }
}

function validateAiPromptPack(errors, warnings) {
  validateAiPromptPackFile(
    aiPromptPackPath,
    "output/experience/ai-prompt-pack.md",
    errors,
    warnings,
    false
  );

  if (!fs.existsSync(packagedDemoDir)) {
    return;
  }

  validateAiPromptPackFile(
    packagedAiPromptPackPath,
    "output/share/developer-atlas-mvp-demo/ai/ai-prompt-pack.md",
    errors,
    warnings,
    true
  );
}

function validateAiPromptPackFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing optional AI prompt pack`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# AI Prompt Pack",
    "## Rule",
    "## Universal Atlas AI preamble",
    "## Mission 1 prompt",
    "## Mission 2 prompt",
    "## Mission 3 prompt",
    "## Smaller patch prompt",
    "## Before accepting an AI answer",
    "## If AI overbuilds",
    "## If AI suggests a cleaner improvement",
    "## Format the answer clearly",
    "## Explain it back prompt",
    "## Reject overbuild prompt",
    "## Verify before continuing"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/Use this only if AI helps you code[\s\S]*This file is optional/i, "optional AI framing"],
    [/One mission at a time/i, "one mission at a time"],
    [/Universal Atlas AI preamble[\s\S]*ask which mission I am on if I did not say it[\s\S]*Do not make the app production-ready, cleaner, more reusable, or more architectural unless the current mission explicitly asks for that[\s\S]*Edit my Vue todo project, not the Atlas package/i, "universal Atlas AI preamble"],
    [/Mission 1 prompt[\s\S]*Developer Atlas Mission 1[\s\S]*make my todos survive page refresh[\s\S]*Keep todo state in `src\/App\.vue`/i, "Mission 1 prompt"],
    [/Mission 2 prompt[\s\S]*Developer Atlas Mission 2[\s\S]*Create `src\/components\/TodoItem\.vue`[\s\S]*props[\s\S]*events/i, "Mission 2 prompt"],
    [/Mission 3 prompt[\s\S]*Developer Atlas Mission 3[\s\S]*display-only `TodoStats\.vue`[\s\S]*Create `src\/components\/TodoStats\.vue`[\s\S]*Do not add emits/i, "Mission 3 prompt"],
    [/Please make a smaller patch\. Only change the files needed for the current mission/i, "smaller patch prompt"],
    [/Before accepting an AI answer[\s\S]*changes more than the mission asks for[\s\S]*edits the Atlas package[\s\S]*adds new architecture[\s\S]*skips explanation or verification/i, "before accepting an AI answer guidance"],
    [/If AI overbuilds[\s\S]*Please make a smaller patch\. Only change the files needed for the current mission/i, "AI overbuild recovery prompt"],
    [/If AI suggests a cleaner improvement[\s\S]*outside this mission[\s\S]*park it[\s\S]*smallest current-mission patch/i, "cleaner-improvement recovery prompt"],
    [/Format the answer clearly[\s\S]*clear headings[\s\S]*file names before code[\s\S]*small code blocks[\s\S]*verification steps/i, "clear AI answer formatting prompt"],
    [/Explain what changed in plain language before I accept it/i, "explain-it-back prompt"],
    [/Undo the extra architecture and return to the smallest solution for this mission/i, "reject overbuild prompt"],
    [/Compare your answer to the mission checklist and tell me whether it stays inside scope/i, "verify-before-continuing prompt"],
    [/Stay on the current mission\. Do not continue to the next mission until I ask/i, "stay on current mission prompt"],
    [/Do not ask for fastest answer with no explanation in Atlas[\s\S]*small readable answer with verification/i, "fastest answer warning"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }

  const lineCount = countLines(filePath);
  if (lineCount > 100) {
    errors.push(`${label}: AI prompt pack should stay at or below 100 lines`);
  }
}

function validateMissionSurface(errors, warnings) {
  if (!fs.existsSync(missionSurfacePath)) {
    warnings.push("output/experience/today-mission-surface.md has not been generated yet");
    return;
  }

  const text = fs.readFileSync(missionSurfacePath, "utf8");
  const requiredSections = [
    "# Welcome back",
    "## Today's Mission",
    "## Why this matters",
    "## Where this work happens",
    "## Quick Start",
    "## Estimated time",
    "## Difficulty",
    "## Start here",
    "## Where this change belongs",
    "## Check your result",
    "## Completion checklist",
    "## If you get stuck",
    "## Ask AI for help",
    "## Skip today",
    "## Next mission preview",
    "## After the mission"
  ];

  validateSectionsInOrder(text, requiredSections, "output/experience/today-mission-surface.md", errors);
  validateForbiddenTerms(text, "output/experience/today-mission-surface.md", errors);
  validateNoShameLanguage(text, "output/experience/today-mission-surface.md", errors);

  const requiredMeanings = [
    [/Visible win:/i, "visible win"],
    [/Where this work happens[\s\S]*Work in your Vue todo project[\s\S]*Use this mission file as the guide[\s\S]*Do not edit the Atlas package files/i, "workspace clarity"],
    [/Quick Start[\s\S]*Open your Vue project[\s\S]*Open `src\/App\.vue`[\s\S]*todo list state[\s\S]*loading from `localStorage`[\s\S]*saving to `localStorage`[\s\S]*Run `npm run dev`[\s\S]*refresh the page[\s\S]*todo is still there/i, "Quick Start steps"],
    [/Todos disappear after refresh|If you get stuck/i, "recovery guidance"],
    [/I am building a Vue 3 todo app/i, "AI help prompt"],
    [/Skip today/i, "skip-today scope control"],
    [/localStorage/, "localStorage guidance"],
    [/help\/vue-concept-cards\.md/i, "Vue concept cards pointer"],
    [/help\/terminal-confidence-guide\.md/i, "terminal confidence guide pointer"],
    [/Optional help: `help\/vue-concept-cards\.md`/i, "optional Vue help label"],
    [/Optional help: `help\/beginner-orientation\.md`/i, "optional beginner help label"],
    [/Optional help: `help\/terminal-confidence-guide\.md`/i, "optional terminal help label"],
    [/Open help files only when a word or step feels unclear/i, "open-help-only-when-needed guidance"],
    [/sessionStorage/, "sessionStorage guidance"],
    [/sensitive data|secrets|passwords|tokens/i, "sensitive data warning"],
    [/Vue state controls what is visible now/i, "Vue state distinction"],
    [/Browser storage controls what can be restored later/i, "browser storage distinction"],
    [/Where this change belongs[\s\S]*todo list state/i, "placement todo state guidance"],
    [/Where this change belongs[\s\S]*help\/beginner-orientation\.md/i, "placement beginner orientation guidance"],
    [/Where this change belongs[\s\S]*App\.vue/i, "placement App.vue guidance"],
    [/Where this change belongs[\s\S]*code changes belong in your todo app, usually in `src\/App\.vue` for this mission/i, "Vue project placement guidance"],
    [/Where this change belongs[\s\S]*Save todos where todos change/i, "placement save guidance"],
    [/Where this change belongs[\s\S]*Load saved todos when the app starts/i, "placement load guidance"],
    [/Where this change belongs[\s\S]*router[\s\S]*backend[\s\S]*database[\s\S]*auth[\s\S]*deployment[\s\S]*build config/i, "placement no-extra-files guidance"],
    [/Completion checklist[\s\S]*add a todo/i, "checklist add todo"],
    [/Completion checklist[\s\S]*refresh the page/i, "checklist refresh page"],
    [/Completion checklist[\s\S]*todo is still visible/i, "checklist visible after refresh"],
    [/Completion checklist[\s\S]*browser console errors/i, "checklist console errors"],
    [/Completion checklist[\s\S]*localStorage[\s\S]*sessionStorage/i, "checklist storage choice understanding"],
    [/Completion checklist[\s\S]*backend[\s\S]*login[\s\S]*database[\s\S]*routing[\s\S]*deployment/i, "checklist scope control"],
    [/Before you started, how confident did you feel/i, "confidence-before question"],
    [/After finishing or stopping, how confident do you feel now/i, "confidence-after question"],
    [/Did you complete the visible win/i, "visible-win completion feedback"],
    [/Did Atlas help you recover from a blocker/i, "recovery feedback"],
    [/What still feels unclear/i, "remaining-confusion question"]
  ];

  for (const [pattern, label] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`output/experience/today-mission-surface.md: missing ${label}`);
    }
  }
}

function validateVibeMissionSurface(errors, warnings) {
  if (!fs.existsSync(vibeMissionSurfacePath)) {
    warnings.push("output/experience/today-mission-surface.vibe.md has not been generated yet");
    return;
  }

  const text = fs.readFileSync(vibeMissionSurfacePath, "utf8");
  const requiredSections = [
    "# Welcome back",
    "## Today's AI-assisted Mission",
    "## Quick Start With AI",
    "## Goal",
    "## Where this work happens",
    "## AI mission boundary",
    "## Copy/paste prompt",
    "## What to ask AI",
    "## What AI may change",
    "## What AI must not change",
    "## Before you accept the answer",
    "## Ask AI to explain it back",
    "## What to accept",
    "## What to reject",
    "## Recovery prompt",
    "## Files likely to change",
    "## Where AI should place the change",
    "## Files that should not change today",
    "## Test the result",
    "## Completion checklist",
    "## If AI breaks it",
    "## Explain it back",
    "## Skip today",
    "## Next mission preview",
    "## After the mission"
  ];

  validateSectionsInOrder(text, requiredSections, "output/experience/today-mission-surface.vibe.md", errors);
  validateForbiddenTerms(text, "output/experience/today-mission-surface.vibe.md", errors);
  validateNoShameLanguage(text, "output/experience/today-mission-surface.vibe.md", errors);

  const requiredMeanings = [
    [/I am building a Vue 3 todo app/i, "AI prompt"],
    [/AI mission boundary[\s\S]*Goal: make todos survive refresh[\s\S]*Likely file: `src\/App\.vue`[\s\S]*Keep todo state in `App\.vue`[\s\S]*Use localStorage only for persistence[\s\S]*Do not create new components for Mission 1/i, "Mission 1 AI mission boundary"],
    [/Copy\/paste prompt[\s\S]*You are helping me with Developer Atlas Mission 1[\s\S]*Edit my Vue todo project, not the Atlas package[\s\S]*Goal: make my todos survive page refresh[\s\S]*Use the smallest useful change[\s\S]*Keep todo state in `src\/App\.vue`[\s\S]*Use localStorage only for persistence[\s\S]*Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, new components, or a new architecture[\s\S]*After the change, explain what changed and how I can verify it/i, "Mission 1 copy/paste prompt"],
    [/Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture/i, "Mission 1 shared reject rule"],
    [/Keep the smallest useful change/i, "Mission 1 smallest useful change"],
    [/Explain what changed before I accept the answer/i, "Mission 1 explain before accept"],
    [/If the answer changes too much, reject it and ask for a smaller patch/i, "Mission 1 reject overbuild"],
    [/What AI may change[\s\S]*`src\/App\.vue`[\s\S]*Existing todo state logic[\s\S]*localStorage save\/load code/i, "Mission 1 AI may change"],
    [/What AI must not change[\s\S]*Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture[\s\S]*Do not create new components for Mission 1/i, "Mission 1 AI must not change"],
    [/Before you accept the answer[\s\S]*Confirm the change is small[\s\S]*Confirm the likely file is `src\/App\.vue`[\s\S]*Confirm todos survive refresh[\s\S]*Confirm AI explains what changed/i, "Mission 1 before accept"],
    [/Recovery prompt[\s\S]*Please make a smaller patch[\s\S]*Only change the files needed for Developer Atlas Mission 1[\s\S]*Undo the extra architecture/i, "Mission 1 recovery prompt"],
    [/Where this work happens[\s\S]*Work in your Vue todo project[\s\S]*Use this mission file as the guide[\s\S]*Do not edit the Atlas package files/i, "AI workspace clarity"],
    [/Edit my Vue todo project, not the Atlas package[\s\S]*usually in src\/App\.vue/i, "AI prompt workspace boundary"],
    [/Quick Start With AI[\s\S]*Open your Vue project[\s\S]*identify where the todo state currently lives[\s\S]*near the existing todo state[\s\S]*not to create new architecture[\s\S]*smallest needed file or files[\s\S]*Test refresh persistence[\s\S]*explain the final change/i, "Quick Start With AI steps"],
    [/Accept changes that:/i, "what to accept"],
    [/Reject changes that:/i, "what to reject"],
    [/Accept changes that:[\s\S]*minimal[\s\S]*existing todo state[\s\S]*Preserve the current app structure[\s\S]*Explain which files changed[\s\S]*JSON\.stringify\(\)[\s\S]*JSON\.parse\(\)[\s\S]*non-sensitive todo data/i, "strengthened accept rules"],
    [/Reject changes that:[\s\S]*new component structure unless the project already uses it[\s\S]*new store or composable unless it already exists[\s\S]*new architecture[\s\S]*Rewrite the app[\s\S]*Change unrelated files[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*cloud sync[\s\S]*abstractions `for later`/i, "strengthened reject rules"],
    [/Files likely to change/i, "files likely to change"],
    [/Files that should not change today/i, "files that should not change today"],
    [/Do not rewrite the app/i, "AI recovery prompt"],
    [/Explain how Vue state and localStorage work together/i, "explain-it-back guidance"],
    [/localStorage/, "localStorage guidance"],
    [/help\/vue-concept-cards\.md/i, "Vue concept cards pointer"],
    [/Optional help: `help\/beginner-orientation\.md`/i, "optional beginner help label"],
    [/Optional help: `help\/terminal-confidence-guide\.md`/i, "optional terminal help label"],
    [/Optional help: `help\/vue-concept-cards\.md`/i, "optional Vue help label"],
    [/terminal output[\s\S]*command[\s\S]*folder path[\s\S]*last terminal lines/i, "terminal output handling"],
    [/sessionStorage/, "sessionStorage guidance"],
    [/sensitive data|secrets|passwords|tokens/i, "sensitive data warning"],
    [/Vue state controls what the app shows now/i, "Vue state distinction"],
    [/Browser storage controls what can be restored later/i, "browser storage distinction"],
    [/Where AI should place the change[\s\S]*existing todo state/i, "AI placement existing todo state guidance"],
    [/Where AI should place the change[\s\S]*help\/beginner-orientation\.md/i, "AI placement beginner orientation guidance"],
    [/Where AI should place the change[\s\S]*App\.vue/i, "AI placement App.vue guidance"],
    [/Where AI should place the change[\s\S]*Tell AI to edit your Vue todo project, not the Atlas package/i, "AI placement workspace boundary"],
    [/Where AI should place the change[\s\S]*new architecture/i, "AI placement no-new-architecture guidance"],
    [/Where AI should place the change[\s\S]*explain why each changed file/i, "AI placement changed-file explanation"],
    [/Where AI should place the change[\s\S]*unrelated styling/i, "AI placement unrelated-file guidance"],
    [/Completion checklist[\s\S]*todo survives refresh/i, "AI checklist survives refresh"],
    [/Completion checklist[\s\S]*changed only the files needed/i, "AI checklist needed files only"],
    [/Completion checklist[\s\S]*backend[\s\S]*auth[\s\S]*Pinia[\s\S]*routing[\s\S]*database[\s\S]*deployment[\s\S]*new architecture/i, "AI checklist scope control"],
    [/Completion checklist[\s\S]*which file changed and why/i, "AI checklist changed-file understanding"],
    [/Completion checklist[\s\S]*storage key is consistent/i, "AI checklist consistent storage key"],
    [/Completion checklist[\s\S]*JSON\.stringify/i, "AI checklist JSON stringify"],
    [/Completion checklist[\s\S]*JSON\.parse/i, "AI checklist JSON parse"],
    [/Completion checklist[\s\S]*browser console/i, "AI checklist console errors"],
    [/Skip today/i, "scope control"],
    [/Before you asked AI, how confident did you feel/i, "confidence-before question"],
    [/After testing the AI-assisted change, how confident do you feel now/i, "confidence-after question"],
    [/Did the AI change stay inside the mission scope/i, "AI scope feedback"],
    [/Did you reject or undo any unnecessary AI changes/i, "unnecessary AI changes feedback"],
    [/Did Atlas help you recover when AI broke or over-expanded the code/i, "AI recovery feedback"],
    [/What still feels unclear/i, "remaining-confusion question"]
  ];

  for (const [pattern, label] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`output/experience/today-mission-surface.vibe.md: missing ${label}`);
    }
  }

  const requiredRejects = [
    /Reject changes that:[\s\S]*new component structure/i,
    /Reject changes that:[\s\S]*new store or composable/i,
    /Reject changes that:[\s\S]*new architecture/i,
    /Reject changes that:[\s\S]*Rewrite the app/i,
    /Reject changes that:[\s\S]*Change unrelated files/i,
    /Reject changes that:[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*cloud sync/i,
    /Reject changes that:[\s\S]*abstractions `for later`/i
  ];

  for (const pattern of requiredRejects) {
    if (!pattern.test(text)) {
      errors.push("output/experience/today-mission-surface.vibe.md: missing rejection guidance for unnecessary expansion");
    }
  }
}

function validateMissionTwoSurface(errors, warnings) {
  const label = "output/experience/mission-02-todoitem-surface.md";
  if (!fs.existsSync(missionTwoSurfacePath)) {
    errors.push(`${label}: missing Mission 2 default surface`);
    return;
  }

  const text = fs.readFileSync(missionTwoSurfacePath, "utf8");
  const requiredSections = [
    "# Mission 2 - Extract a TodoItem Component",
    "## Today's Mission",
    "## Why this matters",
    "## Where this work happens",
    "## Quick Start",
    "## Estimated time",
    "## Difficulty",
    "## Start here",
    "## Where this change belongs",
    "## Check your result",
    "## Completion checklist",
    "## If you get stuck",
    "## Ask AI for help",
    "## Skip today",
    "## Next mission preview",
    "## After the mission"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/Extract one todo row into a `TodoItem` component while keeping the app behavior the same/i, "mission objective"],
    [/Where this work happens[\s\S]*Work in the same Vue todo project you used for Mission 1[\s\S]*Use this mission file as the guide[\s\S]*Do not edit the Atlas package files/i, "Mission 2 workspace clarity"],
    [/App\.vue[\s\S]*hard to read[\s\S]*Components help split the app into understandable pieces[\s\S]*not adding a new feature[\s\S]*not rewriting the app[\s\S]*one repeated todo item UI/i, "why this matters"],
    [/Quick Start[\s\S]*Open your Vue project[\s\S]*Create `src\/components\/TodoItem\.vue`[\s\S]*Move the markup for one todo row[\s\S]*Pass the todo[\s\S]*prop[\s\S]*Emit an event[\s\S]*Use `TodoItem` inside `App\.vue`[\s\S]*behaves the same/i, "Quick Start steps"],
    [/45-60 minutes/i, "estimated time"],
    [/Guided/i, "difficulty"],
    [/Find the `v-for`[\s\S]*Create `src\/components\/TodoItem\.vue`[\s\S]*props[\s\S]*emits[\s\S]*Import and use[\s\S]*add, complete, filter, delete, and persistence/i, "start here steps"],
    [/### Beginner-safe path[\s\S]*First make `TodoItem\.vue` show the todo text only[\s\S]*connect the complete\/toggle action[\s\S]*connect the remove action[\s\S]*Test after each small step/i, "beginner-safe path"],
    [/### Challenge path[\s\S]*component still behaves correctly with filtering and refresh persistence/i, "challenge path"],
    [/prop lets `App\.vue` give one todo to `TodoItem\.vue`[\s\S]*emit lets `TodoItem\.vue` ask `App\.vue`[\s\S]*parent still owns the todo state/i, "beginner props and emits explanation"],
    [/Create `src\/components\/TodoItem\.vue`[\s\S]*Import `TodoItem` in `src\/App\.vue`[\s\S]*Use `TodoItem` inside the existing todo list `v-for`[\s\S]*Keep the todo array\/list state in `App\.vue`[\s\S]*Keep localStorage loading\/saving in `App\.vue` for now[\s\S]*Do not move all state into `TodoItem\.vue`[\s\S]*Do not create a global store/i, "strengthened placement guidance"],
    [/Create `src\/components\/TodoItem\.vue` inside your Vue todo project, not inside the Atlas package/i, "Mission 2 Vue project placement"],
    [/### Tiny file map[\s\S]*`src\/App\.vue` keeps the todo list state and decides what changes[\s\S]*`src\/components\/TodoItem\.vue` displays one todo item and sends user actions back to `App\.vue`[\s\S]*child component should not own the full todo list/i, "tiny file map"],
    [/### Parent-child communication[\s\S]*`App\.vue` is the parent[\s\S]*`TodoItem\.vue` is the child[\s\S]*parent passes one todo down as a prop[\s\S]*child emits an event[\s\S]*parent updates the todo list/i, "parent-child communication"],
    [/### Tiny parent-child diagram[\s\S]*App\.vue[\s\S]*owns the todo list[\s\S]*owns localStorage[\s\S]*updates todos when events happen[\s\S]*prop: todo down[\s\S]*event: toggle\/remove up[\s\S]*TodoItem\.vue[\s\S]*shows one todo[\s\S]*emits user actions/i, "tiny parent-child diagram"],
    [/Remember: props go down, events go up/i, "props down events up memory phrase"],
    [/### Shape only example[\s\S]*<TodoItem[\s\S]*v-for="todo in todos"[\s\S]*:todo="todo"[\s\S]*@toggle="toggleTodo"[\s\S]*@remove="removeTodo"[\s\S]*defineProps\(\{ todo: Object \}\)[\s\S]*defineEmits\(\['toggle', 'remove'\]\)[\s\S]*only the shape of the connection/i, "shape-only example"],
    [/Do not move the whole app state into a new store[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*database[\s\S]*auth[\s\S]*deployment/i, "scope blocks"],
    [/`TodoItem\.vue` exists[\s\S]*`App\.vue` uses `TodoItem`[\s\S]*Todos still render[\s\S]*Completing or removing[\s\S]*Filtering[\s\S]*localStorage[\s\S]*No browser console errors/i, "result checks"],
    [/Completion checklist[\s\S]*created `src\/components\/TodoItem\.vue`[\s\S]*imports and uses `TodoItem`[\s\S]*todo list still appears[\s\S]*Completing[\s\S]*Removing[\s\S]*Filtering[\s\S]*Refresh persistence[\s\S]*backend[\s\S]*routing[\s\S]*Pinia[\s\S]*database[\s\S]*auth[\s\S]*deployment/i, "completion checklist"],
    [/Component does not show[\s\S]*Import path mismatch[\s\S]*Prop name mismatch[\s\S]*Emit name mismatch[\s\S]*Prop mutation warning[\s\S]*Todo actions no longer work[\s\S]*App state moved too far[\s\S]*localStorage` no longer saves/i, "recovery guidance"],
    [/### If Vue warns about changing a prop[\s\S]*child should not directly change the todo prop[\s\S]*`TodoItem\.vue` should emit an event[\s\S]*`App\.vue` should update the todo list/i, "direct prop mutation warning"],
    [/I am building a Vue 3 todo app[\s\S]*extract one todo row[\s\S]*Keep todo state in App\.vue[\s\S]*Do not add Pinia, routing, backend, auth, database, deployment, or a new architecture/i, "AI help prompt"],
    [/Skip today[\s\S]*Pinia[\s\S]*Routing[\s\S]*Backend[\s\S]*Auth\/login[\s\S]*Database[\s\S]*Deployment[\s\S]*Full app rewrite[\s\S]*Styling overhaul[\s\S]*global store[\s\S]*Adding new features/i, "skip today"],
    [/props vs emits/i, "next mission preview"],
    [/Before you started[\s\S]*After finishing or stopping[\s\S]*visible win[\s\S]*Did recovery help[\s\S]*What still feels unclear/i, "after mission reflection"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateVibeMissionTwoSurface(errors, warnings) {
  const label = "output/experience/mission-02-todoitem-surface.vibe.md";
  if (!fs.existsSync(vibeMissionTwoSurfacePath)) {
    errors.push(`${label}: missing Mission 2 vibe surface`);
    return;
  }

  const text = fs.readFileSync(vibeMissionTwoSurfacePath, "utf8");
  const requiredSections = [
    "# Mission 2 - AI-Assisted TodoItem Extraction",
    "## Today's AI-assisted Mission",
    "## Where this work happens",
    "## AI mission boundary",
    "## Goal",
    "## Quick Start With AI",
    "## Tiny file map",
    "## Tiny parent-child diagram",
    "## Copy/paste prompt",
    "## What to ask AI",
    "## What AI may change",
    "## What AI must not change",
    "## Before you accept the answer",
    "## Ask AI to explain it back",
    "## What to accept",
    "## What to reject",
    "## Recovery prompt",
    "## Files likely to change",
    "## Files that should not change today",
    "## Test the result",
    "## Completion checklist",
    "## If AI breaks it",
    "## Explain it back",
    "## Skip today",
    "## Next mission preview",
    "## After the mission"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/extract one todo row into `TodoItem\.vue`[\s\S]*behavior the same/i, "AI-assisted objective"],
    [/AI mission boundary[\s\S]*Goal: extract `TodoItem\.vue`[\s\S]*Work in the same Vue todo project from Mission 1[\s\S]*Create `src\/components\/TodoItem\.vue`[\s\S]*Keep todo list state and localStorage in `App\.vue`[\s\S]*Use props down and events up[\s\S]*Do not create extra components/i, "Mission 2 AI mission boundary"],
    [/Copy\/paste prompt[\s\S]*You are helping me with Developer Atlas Mission 2[\s\S]*Edit my Vue todo project, not the Atlas package[\s\S]*Goal: extract one `TodoItem\.vue` component[\s\S]*Create `src\/components\/TodoItem\.vue`[\s\S]*Keep todo list state and localStorage in `src\/App\.vue`[\s\S]*Use props to pass one todo down[\s\S]*Use events to ask the parent to toggle or remove a todo[\s\S]*Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, extra components, or a new architecture[\s\S]*After the change, explain what changed and how I can verify it/i, "Mission 2 copy/paste prompt"],
    [/Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture/i, "Mission 2 shared reject rule"],
    [/Keep the smallest useful change/i, "Mission 2 smallest useful change"],
    [/Explain what changed before I accept the answer/i, "Mission 2 explain before accept"],
    [/If the answer changes too much, reject it and ask for a smaller patch/i, "Mission 2 reject overbuild"],
    [/Where this work happens[\s\S]*Work in the same Vue todo project you used for Mission 1[\s\S]*Use this mission file as the guide[\s\S]*Do not edit the Atlas package files/i, "Mission 2 vibe workspace clarity"],
    [/Keep todo state in `App\.vue`[\s\S]*prop[\s\S]*emit actions back to the parent/i, "goal"],
    [/Quick Start With AI[\s\S]*find the markup[\s\S]*create `src\/components\/TodoItem\.vue` in your Vue todo project[\s\S]*keep todo state in `App\.vue`[\s\S]*todo as a prop[\s\S]*emit toggle\/remove events[\s\S]*Reject any new architecture[\s\S]*behaves the same/i, "Quick Start With AI"],
    [/## Tiny file map[\s\S]*`src\/App\.vue`: keeps the todo list state, localStorage behavior, and parent actions[\s\S]*`src\/components\/TodoItem\.vue`: displays one todo and emits user actions/i, "tiny file map"],
    [/## Tiny parent-child diagram[\s\S]*App\.vue owns todos and persistence[\s\S]*TodoItem\.vue displays one todo[\s\S]*AI should pass data down with props[\s\S]*AI should send actions up with emits[\s\S]*Props go down\. Events go up\./i, "tiny parent-child diagram"],
    [/I am building a Vue 3 todo app[\s\S]*Edit my Vue todo project, not the Atlas package[\s\S]*Extract the repeated markup[\s\S]*Tell AI to create `src\/components\/TodoItem\.vue` in your Vue todo project[\s\S]*Create only TodoItem\.vue as the new component[\s\S]*Keep todo state in App\.vue[\s\S]*Keep localStorage in App\.vue[\s\S]*Do not create extra components[\s\S]*Do not create a store or composable for later[\s\S]*Do not reorganize folders[\s\S]*Do not rename unrelated variables[\s\S]*Do not change styling unless needed for the extraction[\s\S]*Do not add Pinia, routing, backend, auth, database, deployment, or a new architecture[\s\S]*Explain each changed file/i, "AI prompt"],
    [/What AI may change[\s\S]*`src\/App\.vue`[\s\S]*`src\/components\/TodoItem\.vue`[\s\S]*parent-child connection/i, "Mission 2 AI may change"],
    [/What AI must not change[\s\S]*Do not add routing, backend, auth, database, deployment, Pinia, stores, composables, extra components, or a new architecture[\s\S]*Do not move todo list state or localStorage out of `src\/App\.vue`/i, "Mission 2 AI must not change"],
    [/Before you accept the answer[\s\S]*Confirm `src\/components\/TodoItem\.vue` was created[\s\S]*Confirm todo list state and localStorage stayed in `src\/App\.vue`[\s\S]*Confirm props go down and events go up[\s\S]*Confirm AI explains what changed/i, "Mission 2 before accept"],
    [/Recovery prompt[\s\S]*Please make a smaller patch[\s\S]*Only change the files needed for Developer Atlas Mission 2[\s\S]*Undo the extra architecture/i, "Mission 2 recovery prompt"],
    [/Accept changes that:[\s\S]*Create only `src\/components\/TodoItem\.vue` as the new component[\s\S]*Update `App\.vue` to use `TodoItem`[\s\S]*Keep todo state in `App\.vue`[\s\S]*Keep localStorage in `App\.vue`[\s\S]*Pass one todo as a prop[\s\S]*Emit toggle\/remove events[\s\S]*Preserve existing behavior[\s\S]*Explain why each changed file was touched/i, "accept list"],
    [/Reject changes that:[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*new architecture[\s\S]*extra components[\s\S]*new folder structure[\s\S]*Move state into `TodoItem\.vue`[\s\S]*Move state out of `App\.vue`[\s\S]*Move persistence out of `App\.vue`[\s\S]*new store[\s\S]*Create a store[\s\S]*composable `for later`[\s\S]*localStorage architecture[\s\S]*Add new features[\s\S]*Rewrite the whole app[\s\S]*styling as a side quest[\s\S]*Change unrelated files[\s\S]*Remove existing features[\s\S]*Mutate props directly[\s\S]*Rename many variables unnecessarily/i, "reject list"],
    [/src\/App\.vue[\s\S]*src\/components\/TodoItem\.vue/i, "files likely to change"],
    [/Router files[\s\S]*Backend files[\s\S]*package\.json[\s\S]*Deployment files[\s\S]*Auth files[\s\S]*Unrelated styling files[\s\S]*Global store files/i, "files that should not change"],
    [/Todos render[\s\S]*toggle works[\s\S]*Remove works[\s\S]*Filters still work[\s\S]*localStorage` still works[\s\S]*console has no errors/i, "test result"],
    [/Completion checklist[\s\S]*Todo state stayed in `App\.vue`[\s\S]*prop[\s\S]*emits[\s\S]*Existing todo behavior[\s\S]*localStorage[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*new architecture/i, "completion checklist"],
    [/Do not rewrite the app[\s\S]*Compare the version before and after[\s\S]*smallest change/i, "recovery prompt"],
    [/Show me the smallest diff that keeps TodoItem\.vue but restores the previous behavior[\s\S]*Do not reorganize folders, rename unrelated variables, or add new components/i, "smallest diff recovery prompt"],
    [/prop name mismatch, emit name mismatch, direct prop mutation, moved state, or moved localStorage behavior/i, "bug source checks"],
    [/Undo any unrelated changes[\s\S]*Keep only the TodoItem extraction/i, "cleanup prompt"],
    [/Explain how props and emits connect App\.vue and TodoItem\.vue[\s\S]*beginner-friendly/i, "explain it back"],
    [/Skip today[\s\S]*Pinia[\s\S]*Routing[\s\S]*Backend[\s\S]*Auth\/login[\s\S]*Database[\s\S]*Deployment[\s\S]*Full app rewrite[\s\S]*Styling overhaul[\s\S]*global store[\s\S]*Adding new features/i, "skip today"],
    [/props vs emits/i, "next mission preview"],
    [/Before you asked AI[\s\S]*After testing[\s\S]*mission scope[\s\S]*unnecessary AI changes[\s\S]*Did recovery help[\s\S]*What still feels unclear/i, "after mission reflection"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateMissionThreeSurface(errors, warnings) {
  validateMissionThreeSurfaceFile(
    missionThreeSurfacePath,
    "output/experience/mission-03-todostats-surface.md",
    errors,
    warnings,
    true
  );

  if (fs.existsSync(packagedDemoDir)) {
    validateMissionThreeSurfaceFile(
      packagedMissionThreeSurfacePath,
      "output/share/developer-atlas-mvp-demo/mission/mission-03-todostats-surface.md",
      errors,
      warnings,
      true
    );
  }
}

function validateMissionThreeSurfaceFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing Mission 3 default surface`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Mission 3 - Create a TodoStats Component",
    "## Today's Mission",
    "## Why this matters",
    "## Where this work happens",
    "## Quick Start",
    "## Estimated time",
    "## Difficulty",
    "## Start here",
    "## Where this change belongs",
    "## Check your result",
    "## Completion checklist",
    "## If you get stuck",
    "## Ask AI for help",
    "## Skip today",
    "## Next mission preview",
    "## After the mission"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/Create a `TodoStats` component that shows total, completed, and remaining todos/i, "Mission 3 objective"],
    [/Where this work happens[\s\S]*Work in the same Vue todo project from Missions 1 and 2[\s\S]*Use this mission file as the guide[\s\S]*Do not edit the Atlas package files/i, "Mission 3 workspace clarity"],
    [/Mission 1 made the app remember todos[\s\S]*Mission 2 extracted one todo row[\s\S]*focused display component[\s\S]*show progress without moving state[\s\S]*display useful information without owning the whole app[\s\S]*reinforces props/i, "Mission 3 why this matters"],
    [/Quick Start[\s\S]*Open your Vue project[\s\S]*Create `src\/components\/TodoStats\.vue`[\s\S]*Keep the todo list state in `App\.vue`[\s\S]*Calculate total, completed, and remaining todos in `App\.vue`[\s\S]*Pass those values into `TodoStats` as props[\s\S]*Show the stats above or near the todo list[\s\S]*Confirm the numbers update when todos change/i, "Mission 3 Quick Start"],
    [/35-50 minutes/i, "Mission 3 estimated time"],
    [/Guided/i, "Mission 3 difficulty"],
    [/Find where your todo list state lives in `App\.vue`[\s\S]*Create `src\/components\/TodoStats\.vue`[\s\S]*total todos[\s\S]*completed todos[\s\S]*remaining todos[\s\S]*Calculate those numbers in `App\.vue`[\s\S]*Import `TodoStats` in `App\.vue`[\s\S]*Pass the numbers as props[\s\S]*add, complete, or remove todos/i, "Mission 3 start here"],
    [/### Tiny file map[\s\S]*`src\/App\.vue` keeps the todo list state and calculates the stats[\s\S]*`src\/components\/TodoStats\.vue` displays the stats it receives/i, "Mission 3 tiny file map"],
    [/### Data flow[\s\S]*`App\.vue` owns the todos[\s\S]*total todos[\s\S]*completed todos[\s\S]*remaining todos[\s\S]*`TodoStats\.vue` receives those values as props and displays them[\s\S]*stats go down as props[\s\S]*does not need to change the todo list/i, "Mission 3 data flow"],
    [/### Shape only example[\s\S]*<TodoStats[\s\S]*:total="totalTodos"[\s\S]*:completed="completedTodos"[\s\S]*:remaining="remainingTodos"[\s\S]*defineProps\(\{[\s\S]*total: Number[\s\S]*completed: Number[\s\S]*remaining: Number[\s\S]*only the shape of the connection/i, "Mission 3 shape-only example"],
    [/todo array\/list stays in `App\.vue`[\s\S]*localStorage loading and saving stay in `App\.vue`[\s\S]*`TodoStats\.vue` should not own or change the todo list[\s\S]*`TodoStats\.vue` should not write to localStorage/i, "Mission 3 state boundary"],
    [/Create `src\/components\/TodoStats\.vue` inside your Vue todo project, not inside the Atlas package/i, "Mission 3 Vue project placement"],
    [/`TodoStats\.vue` exists[\s\S]*`App\.vue` imports and uses `TodoStats`[\s\S]*total todos[\s\S]*completed todos[\s\S]*remaining todos[\s\S]*numbers update[\s\S]*Mission 1 persistence[\s\S]*Mission 2 `TodoItem\.vue`[\s\S]*No browser console errors/i, "Mission 3 result checks"],
    [/Completion checklist[\s\S]*created `src\/components\/TodoStats\.vue`[\s\S]*`App\.vue` imports and uses `TodoStats`[\s\S]*`App\.vue` still owns the todo list[\s\S]*receives numbers as props[\s\S]*Total todos[\s\S]*Completed todos[\s\S]*Remaining todos[\s\S]*add, complete, or remove todos[\s\S]*Refresh persistence[\s\S]*`TodoItem\.vue` still works[\s\S]*backend[\s\S]*routing[\s\S]*Pinia[\s\S]*database[\s\S]*auth[\s\S]*deployment[\s\S]*new architecture/i, "Mission 3 completion checklist"],
    [/Stats not updating[\s\S]*Completed count[\s\S]*Remaining count[\s\S]*Prop name mismatch[\s\S]*Component not showing[\s\S]*Import path mismatch[\s\S]*State moved too far[\s\S]*localStorage no longer saves[\s\S]*Mission 2 component stopped working/i, "Mission 3 recovery list"],
    [/### If stats do not update[\s\S]*calculated from the current todo list in `App\.vue`[\s\S]*copied once instead of calculated from the current todos/i, "Mission 3 stale stats recovery"],
    [/### If TodoStats tries to change todos[\s\S]*only displays numbers[\s\S]*Keep todo changes in `App\.vue` and `TodoItem\.vue`/i, "Mission 3 display-only recovery"],
    [/I am building a Vue 3 todo app[\s\S]*Mission 3 is to create a TodoStats component[\s\S]*total, completed, and remaining todos[\s\S]*Keep the todo list state and localStorage behavior in App\.vue[\s\S]*receive numbers as props and only display them[\s\S]*Do not add Pinia, routing, backend, auth, database, deployment, a store, a composable, or a new architecture/i, "Mission 3 AI help prompt"],
    [/Skip today[\s\S]*Pinia[\s\S]*Routing[\s\S]*Backend[\s\S]*Auth\/login[\s\S]*Database[\s\S]*Deployment[\s\S]*Global store[\s\S]*Composable `for later`[\s\S]*Chart library[\s\S]*Complex analytics[\s\S]*Styling overhaul[\s\S]*Moving todo state into `TodoStats\.vue`[\s\S]*Rewriting Mission 1 or Mission 2/i, "Mission 3 scope blocks"],
    [/practice parent-child communication more deeply by letting a child component ask the parent to update data/i, "Mission 3 next preview"],
    [/Before you started[\s\S]*After finishing or stopping[\s\S]*visible win[\s\S]*Did recovery help[\s\S]*What still feels unclear[\s\S]*Would you continue to the next mission/i, "Mission 3 reflection"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateVibeMissionThreeSurface(errors, warnings) {
  validateVibeMissionThreeSurfaceFile(
    vibeMissionThreeSurfacePath,
    "output/experience/mission-03-todostats-surface.vibe.md",
    errors,
    warnings,
    true
  );

  if (fs.existsSync(packagedDemoDir)) {
    validateVibeMissionThreeSurfaceFile(
      packagedVibeMissionThreeSurfacePath,
      "output/share/developer-atlas-mvp-demo/mission/mission-03-todostats-surface.vibe.md",
      errors,
      warnings,
      true
    );
  }
}

function validateVibeMissionThreeSurfaceFile(filePath, label, errors, warnings, required) {
  if (!fs.existsSync(filePath)) {
    const message = `${label}: missing Mission 3 vibe surface`;
    if (required) errors.push(message);
    else warnings.push(message);
    return;
  }

  const text = fs.readFileSync(filePath, "utf8");
  const requiredSections = [
    "# Mission 3 - AI-Assisted TodoStats Component",
    "## Today's AI-assisted Mission",
    "## Goal",
    "## Where this work happens",
    "## AI mission boundary",
    "## Quick Start With AI",
    "## Tiny file map",
    "## Data flow",
    "## Copy/paste prompt",
    "## What to ask AI",
    "## What AI may change",
    "## What AI must not change",
    "## Before you accept the answer",
    "## Ask AI to explain it back",
    "## What to accept",
    "## What to reject",
    "## Recovery prompt",
    "## Files likely to change",
    "## Files that should not change today",
    "## Test the result",
    "## Completion checklist",
    "## If AI breaks it",
    "## Explain it back",
    "## Skip today",
    "## Next mission preview",
    "## After the mission"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);
  validateForbiddenTerms(text, label, errors);
  validateNoHypeLanguage(text, label, errors);
  validateNoShameLanguage(text, label, errors);

  const requiredMeanings = [
    [/Use AI to help create a `TodoStats` component while keeping the app state and architecture unchanged/i, "Mission 3 vibe objective"],
    [/Show total, completed, and remaining todo counts through a small display component/i, "Mission 3 vibe goal"],
    [/Where this work happens[\s\S]*Work in the same Vue todo project from Missions 1 and 2[\s\S]*Use this mission file as the guide[\s\S]*Do not edit the Atlas package files/i, "Mission 3 vibe workspace clarity"],
    [/AI mission boundary[\s\S]*Goal: add `TodoStats\.vue`[\s\S]*Work in the same Vue todo project from Missions 1 and 2[\s\S]*Create `src\/components\/TodoStats\.vue`[\s\S]*Keep todo list state and localStorage in `App\.vue`[\s\S]*Pass total, completed, and remaining as props[\s\S]*`TodoStats\.vue` is display-only[\s\S]*No emits needed for Mission 3/i, "Mission 3 AI mission boundary"],
    [/Copy\/paste prompt[\s\S]*You are helping me with Developer Atlas Mission 3[\s\S]*Edit my Vue todo project, not the Atlas package[\s\S]*Goal: add a display-only `TodoStats\.vue` component[\s\S]*Create `src\/components\/TodoStats\.vue`[\s\S]*Keep todo list state and localStorage in `src\/App\.vue`[\s\S]*Pass total, completed, and remaining values as props[\s\S]*Do not add emits for this mission[\s\S]*Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture[\s\S]*After the change, explain what changed and how I can verify it/i, "Mission 3 copy/paste prompt"],
    [/Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture/i, "Mission 3 shared reject rule"],
    [/Keep the smallest useful change/i, "Mission 3 smallest useful change"],
    [/Explain what changed before I accept the answer/i, "Mission 3 explain before accept"],
    [/If the answer changes too much, reject it and ask for a smaller patch/i, "Mission 3 reject overbuild"],
    [/Quick Start With AI[\s\S]*find where the todo list state currently lives[\s\S]*create `src\/components\/TodoStats\.vue` in your Vue todo project[\s\S]*keep todo state and localStorage in `App\.vue`[\s\S]*only display numbers passed as props[\s\S]*Reject new stores, composables, routing, backend, charts, analytics, or architecture changes[\s\S]*stats update when todos change[\s\S]*explain the data flow/i, "Mission 3 vibe Quick Start"],
    [/## Tiny file map[\s\S]*`src\/App\.vue`: keeps todos, localStorage, and calculates stats[\s\S]*`src\/components\/TodoStats\.vue`: displays total, completed, and remaining counts/i, "Mission 3 vibe tiny file map"],
    [/## Data flow[\s\S]*`App\.vue` owns the todo list[\s\S]*`total`[\s\S]*`completed`[\s\S]*`remaining`[\s\S]*`TodoStats\.vue` displays those numbers[\s\S]*does not emit events and does not change todos/i, "Mission 3 vibe data flow"],
    [/Edit my Vue todo project, not the Atlas package[\s\S]*Tell AI to create `src\/components\/TodoStats\.vue` in your Vue todo project[\s\S]*display total, completed, and remaining todos[\s\S]*Keep todo state and localStorage behavior in `App\.vue`[\s\S]*Calculate the stats in `App\.vue`[\s\S]*pass them into `TodoStats\.vue` as props[\s\S]*only display the numbers[\s\S]*Do not add Pinia, routing, backend, auth, database, deployment, charts, analytics, a store, a composable, or a new architecture[\s\S]*Do not reorganize folders or rename unrelated variables[\s\S]*Explain each changed file/i, "Mission 3 vibe AI prompt"],
    [/What AI may change[\s\S]*`src\/App\.vue`[\s\S]*`src\/components\/TodoStats\.vue`[\s\S]*display component and prop connection/i, "Mission 3 AI may change"],
    [/What AI must not change[\s\S]*Do not add charts, analytics, routing, backend, auth, database, deployment, Pinia, stores, composables, or a new architecture[\s\S]*Do not move todo list state or localStorage out of `src\/App\.vue`[\s\S]*Do not add emits for this mission/i, "Mission 3 AI must not change"],
    [/Before you accept the answer[\s\S]*Confirm `src\/components\/TodoStats\.vue` was created[\s\S]*Confirm `TodoStats\.vue` is display-only[\s\S]*Confirm no emits were added for this mission[\s\S]*Confirm AI explains what changed/i, "Mission 3 before accept"],
    [/Recovery prompt[\s\S]*Please make a smaller patch[\s\S]*Only change the files needed for Developer Atlas Mission 3[\s\S]*Undo the extra architecture/i, "Mission 3 recovery prompt"],
    [/Accept changes that:[\s\S]*Create `src\/components\/TodoStats\.vue`[\s\S]*Update `App\.vue` to use `TodoStats`[\s\S]*Calculate total, completed, and remaining from the current todos[\s\S]*Pass numbers as props[\s\S]*Keep state in `App\.vue`[\s\S]*Keep localStorage in `App\.vue`[\s\S]*Preserve Mission 1 persistence[\s\S]*Preserve Mission 2 `TodoItem\.vue`[\s\S]*Explain changed files/i, "Mission 3 vibe accept list"],
    [/Reject changes that:[\s\S]*Move state into `TodoStats\.vue`[\s\S]*write to localStorage[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*store[\s\S]*composable for later[\s\S]*charts or analytics[\s\S]*extra components[\s\S]*Reorganize folders[\s\S]*Rename many variables unnecessarily[\s\S]*unrelated styling[\s\S]*Remove Mission 1 persistence[\s\S]*Break Mission 2 `TodoItem\.vue`[\s\S]*Rewrite the app/i, "Mission 3 vibe reject list"],
    [/src\/App\.vue[\s\S]*src\/components\/TodoStats\.vue/i, "Mission 3 vibe files likely to change"],
    [/Router files[\s\S]*Backend files[\s\S]*package\.json[\s\S]*Deployment files[\s\S]*Auth files[\s\S]*Database files[\s\S]*Global store files[\s\S]*Unrelated styling files[\s\S]*`?TodoItem\.vue`? unless needed for a tiny compatibility fix/i, "Mission 3 vibe files not to change"],
    [/Total todos updates[\s\S]*Completed todos updates[\s\S]*Remaining todos updates[\s\S]*Adding todos[\s\S]*Completing todos[\s\S]*Removing todos[\s\S]*Filtering[\s\S]*localStorage[\s\S]*`TodoItem\.vue`[\s\S]*console has no errors/i, "Mission 3 vibe tests"],
    [/Completion checklist[\s\S]*created or helped create `src\/components\/TodoStats\.vue`[\s\S]*`App\.vue` imports and uses `TodoStats`[\s\S]*Stats are calculated from the current todo list[\s\S]*receives numbers as props[\s\S]*only displays numbers[\s\S]*State stays in `App\.vue`[\s\S]*localStorage stays in `App\.vue`[\s\S]*Mission 1 persistence[\s\S]*Mission 2 `TodoItem\.vue`[\s\S]*rejected extra architecture, charts, stores, composables, routing, backend, auth, database, and deployment/i, "Mission 3 vibe completion checklist"],
    [/Show me the smallest diff that restores the previous todo behavior while keeping TodoStats\.vue[\s\S]*Do not reorganize folders, rename unrelated variables, add charts, or add new architecture/i, "Mission 3 vibe smallest diff recovery"],
    [/stale copied stats[\s\S]*prop name mismatch[\s\S]*moving state out of App\.vue[\s\S]*moving localStorage behavior[\s\S]*breaking TodoItem\.vue/i, "Mission 3 vibe bug source checks"],
    [/Explain how App\.vue calculates todo stats and passes them into TodoStats\.vue[\s\S]*beginner-friendly language[\s\S]*three small questions/i, "Mission 3 vibe explain it back"],
    [/Skip today[\s\S]*Pinia[\s\S]*Routing[\s\S]*Backend[\s\S]*Auth\/login[\s\S]*Database[\s\S]*Deployment[\s\S]*Store[\s\S]*Composable for later[\s\S]*Charts[\s\S]*Analytics[\s\S]*Extra components[\s\S]*Folder reorganization[\s\S]*Unrelated renaming[\s\S]*Rewriting the app/i, "Mission 3 vibe skip today"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validatePhase95And96Guardrails(errors) {
  requireText(missionSurfacePath, "output/experience/today-mission-surface.md", "## Quick Start", "Phase 95 Mission 1 Quick Start", errors);
  requireText(vibeMissionSurfacePath, "output/experience/today-mission-surface.vibe.md", "## Quick Start With AI", "Phase 95 Mission 1 vibe Quick Start With AI", errors);
  requireText(startHerePath, "output/experience/START_HERE.md", "## Fastest path", "Phase 95 START_HERE Fastest path", errors);
  requireText(missionDashboardPath, "output/experience/mission-dashboard.html", "Fastest path", "Phase 95 dashboard Fastest path", errors);

  requirePattern(vibeMissionSurfacePath, "output/experience/today-mission-surface.vibe.md", /Reject changes that:[\s\S]*new architecture[\s\S]*Rewrite the app/i, "Phase 95 structural rewrite rejection", errors);
  requirePattern(vibeMissionSurfacePath, "output/experience/today-mission-surface.vibe.md", /Reject changes that:[\s\S]*new component structure/i, "Phase 95 component structure rejection", errors);
  requirePattern(vibeMissionSurfacePath, "output/experience/today-mission-surface.vibe.md", /Reject changes that:[\s\S]*Change unrelated files/i, "Phase 95 unrelated files rejection", errors);

  requireText(missionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.md", "## Quick Start", "Phase 96 Mission 2 default Quick Start", errors);
  requireText(vibeMissionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.vibe.md", "## Quick Start With AI", "Phase 96 Mission 2 vibe Quick Start With AI", errors);
  requireText(missionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.md", "src/components/TodoItem.vue", "Phase 96 TodoItem path", errors);
  requirePattern(missionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.md", /Keep the todo array\/list state in `App\.vue`/i, "Phase 96 state stays in App.vue", errors);
  requirePattern(missionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.md", /prop lets `App\.vue` give one todo to `TodoItem\.vue`[\s\S]*emit lets `TodoItem\.vue` ask `App\.vue`/i, "Phase 96 props and emits guidance", errors);
  requirePattern(missionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.md", /Pinia[\s\S]*routing[\s\S]*backend[\s\S]*database[\s\S]*auth[\s\S]*deployment/i, "Phase 96 scope blocks", errors);
  requirePattern(vibeMissionTwoSurfacePath, "output/experience/mission-02-todoitem-surface.vibe.md", /Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment/i, "Phase 96 vibe scope blocks", errors);
  requirePattern(missionDashboardPath, "output/experience/mission-dashboard.html", /Mission 2[\s\S]*Open after Mission 1|Open after Mission 1[\s\S]*Mission 2/i, "Phase 96 dashboard says Mission 2 is after Mission 1", errors);
  requirePattern(startHerePath, "output/experience/START_HERE.md", /mission\/mission-02-todoitem-surface\.md[\s\S]*next mission after Mission 1/i, "Phase 96 START_HERE says Mission 2 is after Mission 1", errors);
  requirePattern(missionDashboardPath, "output/experience/mission-dashboard.html", /Mission 1 remains the primary tester path/i, "Phase 96 Mission 1 remains primary", errors);
  requireText(missionThreeSurfacePath, "output/experience/mission-03-todostats-surface.md", "## Quick Start", "Phase 103 Mission 3 default Quick Start", errors);
  requireText(vibeMissionThreeSurfacePath, "output/experience/mission-03-todostats-surface.vibe.md", "## Quick Start With AI", "Phase 103 Mission 3 vibe Quick Start With AI", errors);
  requireText(missionThreeSurfacePath, "output/experience/mission-03-todostats-surface.md", "src/components/TodoStats.vue", "Phase 103 TodoStats path", errors);
  requireText(vibeMissionThreeSurfacePath, "output/experience/mission-03-todostats-surface.vibe.md", "src/components/TodoStats.vue", "Phase 103 vibe TodoStats path", errors);
  requirePattern(missionThreeSurfacePath, "output/experience/mission-03-todostats-surface.md", /todo array\/list stays in `App\.vue`/i, "Phase 103 state stays in App.vue", errors);
  requirePattern(missionThreeSurfacePath, "output/experience/mission-03-todostats-surface.md", /localStorage loading and saving stay in `App\.vue`/i, "Phase 103 localStorage stays in App.vue", errors);
  requirePattern(missionThreeSurfacePath, "output/experience/mission-03-todostats-surface.md", /`TodoStats\.vue` receives those values as props and displays them/i, "Phase 103 props display guidance", errors);
  requirePattern(vibeMissionThreeSurfacePath, "output/experience/mission-03-todostats-surface.vibe.md", /Reject changes that:[\s\S]*Pinia[\s\S]*routing[\s\S]*backend[\s\S]*auth[\s\S]*database[\s\S]*deployment[\s\S]*store[\s\S]*composable for later[\s\S]*charts or analytics/i, "Phase 103 vibe scope blocks", errors);
  requirePattern(vibeMissionThreeSurfacePath, "output/experience/mission-03-todostats-surface.vibe.md", /smallest diff/i, "Phase 103 smallest diff recovery", errors);
  requirePattern(missionDashboardPath, "output/experience/mission-dashboard.html", /Mission 3[\s\S]*Open after Mission 2|Open after Mission 2[\s\S]*Mission 3/i, "Phase 103 dashboard says Mission 3 is after Mission 2", errors);
  requirePattern(startHerePath, "output/experience/START_HERE.md", /After Mission 2[\s\S]*mission\/mission-03-todostats-surface\.md[\s\S]*Mission 3 adds a small stats component/i, "Phase 103 START_HERE says Mission 3 is after Mission 2", errors);
}

module.exports = {
  validateGeneratedMission,
  validateStartHere,
  validateMissionSurface,
  validateVibeMissionSurface,
  validateAiPromptPack,
  validateMissionTwoSurface,
  validateVibeMissionTwoSurface,
  validateMissionThreeSurface,
  validateVibeMissionThreeSurface,
  validatePhase95And96Guardrails
};
