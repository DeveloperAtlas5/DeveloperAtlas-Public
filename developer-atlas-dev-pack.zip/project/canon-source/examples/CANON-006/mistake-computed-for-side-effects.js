const { computed, ref } = require("./reactivity-sim");

module.exports = function runMistakeComputedForSideEffects() {
  const users = ref([
    { id: 1, active: true },
    { id: 2, active: false }
  ]);
  const sideEffects = [];

  const activeUsers = computed(() => {
    sideEffects.push("computed getter ran");
    return users.value.filter((user) => user.active);
  });

  activeUsers.value;
  activeUsers.value;

  if (sideEffects.length !== 2) {
    throw new Error(`Expected side effect to run on every simulated computed read, got ${sideEffects.length}`);
  }

  const pureActiveUsers = computed(() => users.value.filter((user) => user.active));

  if (pureActiveUsers.value.length !== 1) {
    throw new Error("Expected pure computed value to return one active user");
  }
};
