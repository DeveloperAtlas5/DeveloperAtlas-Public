const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const { readTools, readSetupProfiles } = require("./toolkit-utils");
const { readFrictionNodes } = require("./friction-utils");
const {
  setupAdvisorOutputDir,
  ensureSetupAdvisorOutputDir,
  readSetupRequests
} = require("./setup-advisor-utils");

function main() {
  const tools = new Map(readTools().map((record) => [record.data.id, record.data]));
  const profiles = readSetupProfiles().map((record) => record.data);
  const frictionNodes = new Map(readFrictionNodes().map((record) => [record.node.id, record.node]));
  const requests = readSetupRequests().map((record) => record.request);
  const adviceRecords = [];

  ensureSetupAdvisorOutputDir();

  for (const request of requests) {
    const advice = buildAdvice(request, profiles, tools, frictionNodes);
    adviceRecords.push(advice);

    fs.writeFileSync(
      path.join(setupAdvisorOutputDir, `${request.request_id}.json`),
      `${JSON.stringify(advice, null, 2)}\n`
    );
    fs.writeFileSync(
      path.join(setupAdvisorOutputDir, `${request.request_id}.md`),
      toAdviceMarkdown(advice)
    );
  }

  fs.writeFileSync(
    path.join(setupAdvisorOutputDir, "setup-advisor-report.md"),
    toReport(adviceRecords)
  );

  console.log(`Generated setup advice for ${adviceRecords.length} request(s).`);
  console.log("Generated output/setup-advisor/setup-advisor-report.md.");
}

function buildAdvice(request, profiles, tools, frictionNodes) {
  const profile = chooseProfile(request, profiles);
  const requiredTools = resolveTools(profile.required_tools, tools);
  const recommendedExtensions = resolveTools(profile.recommended_extensions, tools);
  const likelyFriction = resolveFriction(profile.common_friction_nodes, frictionNodes);
  const recoveryLinks = likelyFriction.map((node) => ({
    id: node.id,
    title: node.title,
    fixes: node.fixes,
    verification_steps: node.verification_steps
  }));

  return {
    request_id: request.request_id,
    learner_level: request.learner_level,
    goal: request.goal,
    recommended_setup_profile: profile.profile_id,
    profile_audience: profile.audience,
    required_tools: requiredTools,
    recommended_extensions: recommendedExtensions,
    install_order: profile.setup_order,
    verification_checklist: profile.verification_checklist,
    likely_friction_problems: likelyFriction.map((node) => ({
      id: node.id,
      title: node.title,
      friction_score: node.friction_score,
      estimated_recovery_time: node.estimated_recovery_time
    })),
    recovery_links: recoveryLinks,
    estimated_setup_time: estimateSetupTime(profile, requiredTools, recommendedExtensions, request),
    beginner_notes: beginnerNotes(request, profile),
    professional_notes: professionalNotes(request, profile),
    what_to_do_first_after_setup: firstStepsAfterSetup(request, profile)
  };
}

function chooseProfile(request, profiles) {
  return [...profiles]
    .map((profile) => ({ profile, score: scoreProfile(request, profile) }))
    .sort((a, b) => b.score - a.score || a.profile.profile_id.localeCompare(b.profile.profile_id))[0].profile;
}

function scoreProfile(request, profile) {
  let score = 0;
  const requestStack = normalizeSet(request.stack);
  const profileStack = normalizeSet(profile.stack);

  if (profile.operating_system.toLowerCase().includes(request.operating_system.toLowerCase())) score += 40;

  for (const item of requestStack) {
    if (profileStack.has(item)) score += 12;
  }

  if (profile.audience.toLowerCase().includes(request.learner_level.toLowerCase())) score += 18;
  if (request.preferred_editor && profile.required_tools.includes("tool.vscode") && /visual studio code|vscode/i.test(request.preferred_editor)) score += 10;

  for (const id of request.known_tools || []) {
    if ([...profile.required_tools, ...profile.recommended_extensions, ...profile.optional_tools].includes(id)) score += 4;
  }

  if (request.available_minutes >= profile.setup_order.length * 10) score += 6;

  return score;
}

function estimateSetupTime(profile, requiredTools, recommendedExtensions, request) {
  const requiredTime = requiredTools.reduce((sum, tool) => sum + Math.max(5, tool.setup_difficulty / 2), 0);
  const extensionTime = recommendedExtensions.reduce((sum, tool) => sum + Math.max(3, tool.setup_difficulty / 3), 0);
  const knownToolDiscount = (request.known_tools || []).length * 5;
  return Math.max(15, Math.round(requiredTime + extensionTime - knownToolDiscount));
}

function resolveTools(ids, tools) {
  return ids.map((id) => tools.get(id)).filter(Boolean).map((tool) => ({
    id: tool.id,
    name: tool.name,
    category: tool.category,
    setup_difficulty: tool.setup_difficulty,
    install_notes: tool.install_notes,
    verification_steps: tool.verification_steps
  }));
}

function resolveFriction(ids, frictionNodes) {
  return ids.map((id) => frictionNodes.get(id)).filter(Boolean);
}

function normalizeSet(values) {
  return new Set((values || []).map((value) => value.toLowerCase()));
}

function beginnerNotes(request, profile) {
  const notes = [
    "Install and verify one tool at a time.",
    "Do not skip verification commands; they tell you exactly where setup broke."
  ];

  if (/beginner/i.test(request.learner_level)) {
    notes.push(`Use the ${profile.profile_id} profile as the main path and avoid optional tools until the first project runs.`);
  }

  return notes;
}

function professionalNotes(request, profile) {
  return [
    "Align runtime and package-manager versions with the project before debugging application code.",
    "Treat repeated setup failures as environment drift and document the recovery path for the team.",
    `Profile selected deterministically from OS, stack, learner level, editor preference, and available time: ${profile.profile_id}.`
  ];
}

function firstStepsAfterSetup(request, profile) {
  const steps = [
    "Run every verification checklist item.",
    "Create or open the target project.",
    "Run the project's first success command."
  ];

  if (profile.stack.some((item) => /Vue|Vite/i.test(item))) steps.push("Start the Vite dev server and open the local URL.");
  if (profile.stack.some((item) => /Laravel|PHP/i.test(item))) steps.push("Run php artisan --version from the Laravel project root.");

  return steps;
}

function toAdviceMarkdown(advice) {
  const lines = [
    `# Setup Advice: ${advice.request_id}`,
    "",
    `Goal: ${advice.goal}`,
    `Recommended setup profile: ${advice.recommended_setup_profile}`,
    `Estimated setup time: ${advice.estimated_setup_time} minutes`,
    "",
    "## Required Tools",
    "",
    ...formatToolList(advice.required_tools),
    "",
    "## Recommended Extensions",
    "",
    ...formatToolList(advice.recommended_extensions),
    "",
    "## Install Order",
    "",
    ...advice.install_order.map((step, index) => `${index + 1}. ${step}`),
    "",
    "## Verification Checklist",
    "",
    ...advice.verification_checklist.map((step) => `- [ ] ${step}`),
    "",
    "## Likely Friction Problems",
    "",
    ...advice.likely_friction_problems.map((item) => `- ${item.id}: ${item.title} (${item.friction_score}/100)`),
    "",
    "## Recovery Links",
    "",
    ...advice.recovery_links.map((item) => `- ${item.id}: ${item.fixes[0]}`),
    "",
    "## Beginner Notes",
    "",
    ...advice.beginner_notes.map((note) => `- ${note}`),
    "",
    "## Professional Notes",
    "",
    ...advice.professional_notes.map((note) => `- ${note}`),
    "",
    "## What To Do First After Setup",
    "",
    ...advice.what_to_do_first_after_setup.map((step) => `- ${step}`)
  ];

  return `${lines.join("\n")}\n`;
}

function toReport(adviceRecords) {
  const frictionCounts = new Map();
  for (const advice of adviceRecords) {
    for (const item of advice.likely_friction_problems) {
      frictionCounts.set(item.id, (frictionCounts.get(item.id) || 0) + 1);
    }
  }

  const lines = [
    "# Setup Advisor Report",
    "",
    `Requests processed: ${adviceRecords.length}`,
    "",
    "## Estimated Setup Times",
    "",
    ...adviceRecords.map((advice) => `- ${advice.request_id}: ${advice.estimated_setup_time} minutes (${advice.recommended_setup_profile})`),
    "",
    "## Top Likely Friction Problems",
    "",
    ...[...frictionCounts.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .map(([id, count]) => `- ${id}: ${count}`),
    "",
    "## Generated Advice Files",
    "",
    ...adviceRecords.map((advice) => `- output/setup-advisor/${advice.request_id}.md`)
  ];

  return `${lines.join("\n")}\n`;
}

function formatToolList(tools) {
  return tools.length
    ? tools.map((tool) => `- ${tool.name} (${tool.id})`)
    : ["- None"];
}

main();
