# Laravel Blade

Technology: Laravel

## Simple meaning

Blade is Laravel's template language for server-rendered HTML.

## Why it exists

It lets PHP data become readable HTML pages with layouts and reusable pieces.

## Where you use it

In files ending with `.blade.php` under `resources/views`.

## When to use it

Use Blade when Laravel renders HTML directly.

## Tiny example

`@foreach ($posts as $post)`

## Common beginner confusion

Blade is server-rendered. Vue components usually run in the browser.

## Related concepts

- Controller
- Route
- View

## Similar idea in another technology

Vue templates also describe UI, but Blade renders through Laravel on the server.
