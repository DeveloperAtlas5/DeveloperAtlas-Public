# Mission Intelligence

Mission Intelligence is the user-facing orchestration layer for Developer Atlas.

Atlas should stop showing systems first. Atlas should start showing missions.

A mission turns Goal Intelligence, Readiness, Hardware, Toolkit, Setup, Recovery, Canon, Learning, Capability, Explainability, Momentum, AI Context, Experience, and Flow into one actionable plan for today.

## Principle

One mission. One clear outcome. No overwhelm. One visible success. Confidence first.

## Commands

- `npm run validate:mission`
- `npm run mission`

## Outputs

- `output/mission/today-mission.md`
- `output/mission/today-mission.json`
- `output/mission/mission-report.md`
- `output/mission/mission-report.json`
