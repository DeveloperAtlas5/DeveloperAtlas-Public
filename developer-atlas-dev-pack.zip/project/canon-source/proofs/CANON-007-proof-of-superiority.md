# CANON-007 Proof Of Superiority

## What Official Docs Explain Well

Vue's official documentation explains that `v-if` conditionally renders a block and that `v-show` toggles the element's display CSS property.

## What Developers Still Struggle With

Developers still struggle with the practical decision: DOM existence, state preservation, lifecycle behavior, initial render cost, toggle cost, permission-gated content, and when routing or class binding is a better tool.

## How Atlas Improves The Explanation

Atlas frames the choice as existence versus visibility: `v-if` removes the room, while `v-show` turns off the lights. This gives beginners a durable mental model and gives professionals a reviewable decision lens.

## What Decision Support Atlas Adds

The Canon node gives a decision guide, comparison table, when-to-use sections, alternatives, and debugging checklist that route developers to `v-if`, `v-show`, class binding, dynamic components, transitions, or router views.

## What Production Guidance Atlas Adds

The node includes permission-gated panels, frequently toggled filter drawers, expensive charts, tab panels, state-preservation trade-offs, lifecycle behavior, and accessibility/security cautions.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants explicit generation rules: use `v-if` for conditional existence and permission-gated content, use `v-show` for frequent toggles that should preserve state, and avoid both for routing or pure styling.

## Why This Deserves Gold Status

This node deserves Gold-candidate status because it turns a common Vue template choice into a practical production decision model with official evidence, examples, deterministic verification, teaching guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.
