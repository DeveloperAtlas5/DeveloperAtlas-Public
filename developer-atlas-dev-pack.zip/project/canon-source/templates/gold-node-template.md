# [Canon Node Title]

## Status Metadata

- Canon ID: CANON-000
- Node ID: canon.technology.topic.slug
- Status: candidate
- Score: 0
- Version: 2026.1
- Source family: [Technology or domain]
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Explain the decision in two or three practical sentences.

## What Problem This Solves

Name the developer confusion this node reduces.

## Mental Model

Teach the reusable model behind the decision.

## Beginner Explanation

Explain it for a rookie without hiding the key idea.

## Professional Explanation

Explain production-level trade-offs, maintainability impact, and review signals.

## Syntax

```text
Add canonical syntax or shape here.
```

## Decision Guide

1. Ask the first decision question.
2. Ask the second decision question.
3. Route to the best choice.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| Option A | Primary use | Main cost |
| Option B | Alternative use | Main cost |

## When To Use The Primary Option

- Add clear use cases.

## When To Use The Alternative

- Add clear use cases.

## When Not To Use This Decision

- Name cases where a different concept is better.

## Alternatives

- Alternative 1.
- Alternative 2.

## Production Examples

### Example 1

```text
Add a realistic example.
```

### Example 2

```text
Add another realistic example.
```

## Common Mistakes

- Mistake 1.
- Mistake 2.

## Debugging Checklist

- Check 1.
- Check 2.

## Mechanical Verification

Runnable examples should live in `canon/examples/CANON-000/` when the topic can be mechanically verified.

## Performance Notes

Name practical performance implications without premature optimization.

## AI Coding Guidance

- Tell AI assistants what to generate.
- Tell AI assistants what to avoid.

## Teaching Notes

Explain how to teach the node.

## Interview Questions

1. Question 1?
2. Question 2?

## Exercises

### Beginner

Add a beginner exercise.

### Intermediate

Add an intermediate exercise.

### Advanced

Add an advanced exercise.

## Related Atlas Nodes

- `technology.node.id`

## Evidence And Sources

- Official source URL.

## Proof Of Superiority Summary

Explain why Atlas improves on normal documentation.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 0 |
| beginner_teaching | 15 | 0 |
| professional_depth | 15 | 0 |
| decision_guidance | 15 | 0 |
| production_examples | 10 | 0 |
| ai_readiness | 10 | 0 |
| evidence | 5 | 0 |
| relationships | 5 | 0 |
| exercises | 3 | 0 |
| readability | 2 | 0 |
| Total | 100 | 0 |
