# try/catch vs Promise.catch()

## Status Metadata

- Canon ID: CANON-016
- Node ID: canon.javascript.error.try-catch-vs-promise-catch
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: JavaScript error handling
- Level: junior/intermediate
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `try/catch` for synchronous errors and for promise rejections that are awaited inside an `async` function. Use `Promise.prototype.catch()` when you are handling rejection at the end of a promise chain or returning a promise with a boundary attached.

This is not a style debate. It is an error-boundary decision:

- `try/catch` catches thrown errors in the code path it actually executes or awaits.
- `.catch()` handles rejection on a specific promise chain.
- Neither tool should silently swallow important failures.

## What Problem This Solves

Developers often know both syntaxes but still place the error boundary in the wrong place:

- Wrapping an unawaited promise in `try/catch` and expecting the rejection to be caught.
- Adding `.catch()` that logs nothing, returns nothing useful, and hides the failure.
- Mixing `await` and `.catch()` in one expression without a clear reason.
- Catching too broadly and making debugging harder.
- Returning fallback data without marking the result as degraded.

This node solves a reliability decision: where should the failure be observed, recovered, logged, or rethrown?

## Mental Model

Think of errors as crossing a checkpoint.

`try/catch` is a checkpoint around a block of code. It catches synchronous throws inside the block. In an `async` function, `await` brings a rejected promise back through that checkpoint as a thrown error.

```js
try {
  const user = await fetchUser(id);
} catch (error) {
  reportError(error);
}
```

`.catch()` is a checkpoint attached to a promise chain.

```js
return fetchUser(id).catch((error) => fallbackUser(error));
```

The key question is:

> Is the failing work inside the boundary, awaited by the boundary, or attached to the promise chain?

## Beginner Explanation

Use `try/catch` when code might throw right here:

```js
try {
  JSON.parse("{bad json");
} catch (error) {
  console.log("Could not parse JSON");
}
```

Use `try/catch` with `await` when async work might fail:

```js
try {
  const user = await loadUser();
} catch (error) {
  console.log("Could not load user");
}
```

Use `.catch()` when you are working with a promise chain:

```js
return loadUser().catch(() => guestUser);
```

Beginner rule:

1. Synchronous throw? `try/catch`.
2. `await` inside an async function? `try/catch`.
3. Promise chain returned directly? `.catch()`.
4. Caught an error? Log it, recover intentionally, or rethrow it.

## Professional Explanation

`try/catch` handles exceptions thrown during evaluation of the guarded block. In async functions, `await` converts a rejected awaited promise into a thrown error at the await point, allowing local `try/catch/finally` behavior. This makes it strong for multi-step workflows, local cleanup, fallback decisions, and user-facing error boundaries.

`Promise.prototype.catch(onRejected)` is equivalent to attaching a rejection handler through `then(undefined, onRejected)`. It returns a new promise and is strongest when the code is already promise-chain shaped: returned helper chains, small adapters, compact recovery, or framework/API boundaries that expect a promise.

The professional review question is not "Which syntax is modern?" It is "Where should this failure be handled, and what happens after it is handled?" A catch block that only hides the error is worse than no catch because it destroys observability. Good recovery either returns a valid fallback, logs context, rethrows, converts to a domain error, or marks the result as partial/degraded.

## Syntax

```js
try {
  riskySynchronousWork();
} catch (error) {
  handleError(error);
}
```

```js
try {
  const value = await riskyAsyncWork();
  return value;
} catch (error) {
  handleError(error);
}
```

```js
return riskyAsyncWork().catch((error) => {
  handleError(error);
  return fallbackValue;
});
```

## Decision Guide

Ask these questions in order:

1. Can the code throw synchronously inside this block?
   Use `try/catch`.
2. Is the promise awaited inside an `async` function?
   Use `try/catch` when local handling is clearer.
3. Is the function returning a short promise chain?
   Use `.catch()` when chain-level handling is clearer.
4. Do you need cleanup regardless of success or failure?
   Use `try/catch/finally` or `Promise.prototype.finally()`.
5. Do you need both local logging and caller-level failure handling?
   Catch, add context, then rethrow.
6. Are several independent promises involved?
   Choose `Promise.all()` or `Promise.allSettled()` failure semantics first.
7. Are you tempted to write an empty catch?
   Stop. Decide whether to log, recover, rethrow, or remove the catch.

## Comparison Table

| Choice | Catches | Best For | Trade-Off |
| --- | --- | --- | --- |
| `try/catch` | Synchronous throws inside the block | Parsing, validation, ordinary throwing code | Does not catch future promise rejections unless awaited |
| `try/catch` + `await` | Rejections from awaited promises | Multi-step async workflows and local recovery | Can become too broad if the block is too large |
| `.catch()` | Rejection on a promise chain | Returned chains, adapters, compact fallback | Can hide recovery far from the operation |
| `finally` | Cleanup after success or failure | Loading states, resource cleanup | Does not receive the fulfillment value or rejection reason |
| Rethrow | Preserving failure for caller | Logging with context, domain conversion | Caller must still handle the failure |

## When To Use The Primary Option

Use `try/catch` when:

- Code can throw synchronously.
- You are using `await` and need local error handling.
- Several awaited steps share one user-facing failure boundary.
- You need `finally` for cleanup, loading state, or locks.
- Local variable names and branches make the flow easier to read.

```js
async function loadAccountPage(accountId) {
  try {
    const account = await fetchAccount(accountId);
    const invoices = await fetchInvoices(account.id);

    return { account, invoices, status: "ready" };
  } catch (error) {
    logError("account-page-load-failed", error);
    return { account: null, invoices: [], status: "failed" };
  }
}
```

## When To Use The Alternative

Use `.catch()` when:

- You are returning a promise chain directly.
- A small adapter needs a fallback value.
- A promise-oriented API expects returned chain behavior.
- The rejection handling belongs at the end of a compact pipeline.

```js
function loadCachedAccount(accountId) {
  return fetchAccount(accountId)
    .then(normalizeAccount)
    .catch((error) => {
      logError("account-cache-fallback", error);
      return getCachedAccount(accountId);
    });
}
```

## When To Use Both Carefully

Use both only when each boundary has a different job.

```js
async function loadProfileWithContext(userId) {
  try {
    return await fetchProfile(userId).catch((error) => {
      throw new Error(`Profile request failed for ${userId}: ${error.message}`);
    });
  } catch (error) {
    logError("profile-load-failed", error);
    throw error;
  }
}
```

This pattern is acceptable when `.catch()` converts low-level context and outer `try/catch` handles logging or cleanup. It is not a default style.

## When Not To Use This Decision

Do not use `try/catch` or `.catch()` to hide failures.

Avoid both when:

- The error should fail fast and be handled by a higher-level boundary.
- You cannot make a useful fallback.
- You would only write an empty catch block.
- You need retry, cancellation, timeout, validation, or observability design first.
- You are handling multiple independent promises and have not chosen fail-fast or partial-success semantics.
- You are using catch to hide a bug instead of fixing the cause.

## Alternatives

### Rethrow With Context

Use this when the current layer can add useful context but should not fully recover.

```js
try {
  return await saveInvoice(invoice);
} catch (error) {
  throw new Error(`Could not save invoice ${invoice.id}: ${error.message}`);
}
```

### Promise.all()

Use it when all independent async tasks must succeed.

```js
const [user, permissions] = await Promise.all([
  fetchUser(id),
  fetchPermissions(id)
]);
```

### Promise.allSettled()

Use it when partial success is acceptable and every result should be inspected.

```js
const results = await Promise.allSettled(tasks.map(runTask));
```

## Production Examples

### Parse And Validate API Configuration

```js
function parseConfig(rawConfig) {
  try {
    const parsed = JSON.parse(rawConfig);

    if (!parsed || typeof parsed.apiBaseUrl !== "string") {
      throw new Error("Missing apiBaseUrl");
    }

    return parsed;
  } catch (error) {
    throw new Error(`Invalid configuration: ${error.message}`);
  }
}
```

### Fetch With Local Async Boundary

```js
async function loadDashboard(userId) {
  try {
    const [profile, notifications] = await Promise.all([
      fetchProfile(userId),
      fetchNotifications(userId)
    ]);

    return { profile, notifications, degraded: false };
  } catch (error) {
    logError("dashboard-load-failed", error);
    return { profile: null, notifications: [], degraded: true };
  }
}
```

### Promise Chain Adapter

```js
function loadUserDisplayName(userId) {
  return fetchUser(userId)
    .then((user) => user.displayName)
    .catch((error) => {
      logError("display-name-fallback", error);
      return "Unknown user";
    });
}
```

### Do Not Swallow Operational Errors

```js
async function saveSettings(settings) {
  try {
    await persistSettings(settings);
  } catch (error) {
    logError("settings-save-failed", error);
    throw error;
  }
}
```

## Common Mistakes

- Expecting `try/catch` to catch an unawaited promise rejection.
- Catching an error and returning nothing, turning failure into `undefined`.
- Logging without enough context to debug the operation.
- Catching too broadly and hiding which step failed.
- Adding `.catch()` in the middle of a chain and accidentally converting failure into success.
- Mixing `.catch()` and outer `try/catch` without separate responsibilities.
- Swallowing errors in event handlers, background tasks, or fire-and-forget work.
- Using `.catch(console.error)` and assuming the caller still knows the operation failed.

## Debugging Checklist

- Is the failing promise awaited, returned, or left floating?
- Is the catch block actually reached? Add a temporary assertion or log with operation context.
- Does the catch handler return a valid fallback, rethrow, or mark the result as degraded?
- Is an error swallowed before the caller can observe it?
- Is the catch block too wide, making it unclear which operation failed?
- Should independent promises use `Promise.all()` or `Promise.allSettled()` first?
- Does cleanup belong in `finally`?
- Does the log include enough identifiers to reproduce the failure?

## Mechanical Verification

Runnable examples live in `canon/examples/CANON-016/`.

Run:

```bash
npm run canon:verify:016
```

Verified examples:

- `try/catch` catches a synchronous error.
- `try/catch` catches an awaited rejection.
- `Promise.catch()` handles a promise-chain rejection.
- Swallowing errors without logging or rethrowing hides failure.

## Performance Notes

This decision is primarily about correctness, reliability, and observability. The performance question is usually not `try/catch` versus `.catch()`. It is whether async work runs sequentially, concurrently, retried, cancelled, or repeated unnecessarily.

Avoid using error handling as normal control flow in hot paths. For expected states, prefer explicit checks. For exceptional or boundary failures, use clear error boundaries.

## AI Coding Guidance

- Ask whether the failing work is synchronous, awaited, returned, or floating.
- Generate `try/catch` for synchronous throwing code and multi-step `async`/`await` workflows.
- Generate `.catch()` for compact returned promise chains.
- Do not generate empty catch blocks.
- Do not swallow errors unless the fallback is explicit and logged or marked degraded.
- Add `finally` for loading state or cleanup when needed.
- Use `Promise.all()` or `Promise.allSettled()` before choosing local catch style for independent tasks.
- Warn when `try/catch` wraps a promise that is not awaited or returned.

## Teaching Notes

Teach the boundary before syntax:

```text
throw inside block -> try/catch
rejection at await -> try/catch
rejection in chain -> .catch()
```

Then show the dangerous case:

```js
try {
  failsLater();
} catch {
  // This will not catch a rejection if failsLater() returns a promise and is not awaited.
}
```

For juniors, emphasize that catching an error is not automatically good. The handler must recover, log, rethrow, or intentionally mark the result as degraded.

## Interview Questions

1. What does `try/catch` catch in synchronous code?
2. Why does `try/catch` catch an awaited rejection?
3. Why does `try/catch` not catch a floating promise rejection?
4. When is `.catch()` clearer than `try/catch`?
5. What is wrong with an empty catch block?
6. When should a catch handler rethrow?

## Exercises

### Beginner

Wrap invalid `JSON.parse()` input in `try/catch` and return a safe default.

### Intermediate

Refactor a fetch helper to use either `try/catch` or `.catch()` based on whether it uses `await` or a returned chain.

### Advanced

Audit an async module for swallowed errors, floating promises, and missing operation context in logs.

## Related Atlas Nodes

- `CANON-008`
- `CANON-011`
- `CANON-017`

## Evidence And Sources

- MDN try...catch: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/try...catch
- MDN Promise.prototype.catch(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/catch
- MDN async function: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function
- ECMAScript Try Statement: https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-try-statement
- ECMAScript Promise.prototype.catch: https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.prototype.catch

## Proof Of Superiority Summary

Official references explain syntax and promise mechanics. Atlas adds the practical reliability layer: identify the real error boundary, choose the syntax that matches that boundary, preserve observability, and avoid catch handlers that silently convert failure into confusion.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 15 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 10 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 2 |
| readability | 2 | 1 |
| Total | 100 | 95 |
