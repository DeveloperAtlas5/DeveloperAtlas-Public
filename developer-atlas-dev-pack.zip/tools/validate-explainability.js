const fs = require("fs");
const path = require("path");
const { readGoals } = require("./goal-utils");
const {
  explainabilityDir,
  readExplanations
} = require("./explainability-utils");

const schemaFiles = [
  "recommendation-explanation.schema.json",
  "skip-impact.schema.json",
  "dependency-justification.schema.json"
];

const requiredFields = [
  "explanation_id",
  "recommendation",
  "recommendation_type",
  "related_goals",
  "importance",
  "why_recommended",
  "what_depends_on_it",
  "skip_impact",
  "can_learn_later",
  "shortest_acceptable_path",
  "beginner_explanation",
  "professional_explanation",
  "ai_context_note",
  "evidence_level",
  "confidence"
];

const recommendationTypes = new Set(["knowledge", "tool", "hardware", "project", "setup", "practice"]);
const importanceLevels = new Set(["essential", "recommended", "optional", "defer"]);

function main() {
  const errors = [];
  const warnings = [];

  validateSchemas(errors);
  const explanations = readExplanations();
  validateExplanations(explanations, errors, warnings);

  console.log("Atlas Explainability validation");
  console.log(`Explanations: ${explanations.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemas(errors) {
  for (const fileName of schemaFiles) {
    const file = path.join(explainabilityDir, fileName);
    if (!fs.existsSync(file)) {
      errors.push(`explainability/${fileName}: missing schema file`);
      continue;
    }
    try {
      JSON.parse(fs.readFileSync(file, "utf8"));
    } catch (error) {
      errors.push(`explainability/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateExplanations(records, errors, warnings) {
  const knownGoals = new Set(readGoals().map((record) => record.goal.goal_id));
  const seen = new Set();

  for (const { explanation, relativePath } of records) {
    for (const field of requiredFields) {
      if (explanation[field] === undefined || explanation[field] === null || explanation[field] === "") {
        errors.push(`${relativePath}: missing ${field}`);
      }
    }

    if (seen.has(explanation.explanation_id)) errors.push(`${relativePath}: duplicate explanation_id ${explanation.explanation_id}`);
    seen.add(explanation.explanation_id);

    if (!recommendationTypes.has(explanation.recommendation_type)) {
      errors.push(`${relativePath}: unsupported recommendation_type ${explanation.recommendation_type}`);
    }
    if (!importanceLevels.has(explanation.importance)) {
      errors.push(`${relativePath}: unsupported importance ${explanation.importance}`);
    }
    if (!Array.isArray(explanation.related_goals) || explanation.related_goals.length === 0) {
      errors.push(`${relativePath}: related_goals should be a non-empty array`);
    }
    if (!Array.isArray(explanation.what_depends_on_it) || explanation.what_depends_on_it.length === 0) {
      errors.push(`${relativePath}: what_depends_on_it should be a non-empty array`);
    }
    if (typeof explanation.can_learn_later !== "boolean") {
      errors.push(`${relativePath}: can_learn_later should be boolean`);
    }
    if (typeof explanation.confidence !== "number" || explanation.confidence < 0 || explanation.confidence > 1) {
      errors.push(`${relativePath}: confidence should be a number from 0 to 1`);
    }

    for (const goal of explanation.related_goals || []) {
      if (!knownGoals.has(goal)) warnings.push(`${relativePath}: related_goals references unknown goal ${goal}`);
    }
  }
}

main();
