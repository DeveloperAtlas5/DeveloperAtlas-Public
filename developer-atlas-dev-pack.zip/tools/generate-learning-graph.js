const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  buildLearningGraph
} = require("./learning-utils");

function main() {
  const index = readCanonIndex();
  const graph = buildLearningGraph(index.entries || []);

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "dependency-graph.json"), `${JSON.stringify(graph, null, 2)}\n`);

  console.log(`Generated output/learning/dependency-graph.json with ${graph.nodes.length} nodes and ${graph.edges.length} edges.`);
  if (graph.cycles_detected.length) console.log(`Cycles detected: ${graph.cycles_detected.length}`);
}

main();

