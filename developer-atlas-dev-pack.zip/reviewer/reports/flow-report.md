# Atlas Flow Report

Flows generated: 3
Average flow quality score: 97
First recommended flow: rookie-vue-todo-flow

## Flow Scores

- career-switcher-fullstack-flow: 97/100 (0 warnings)
- jefry-ai-game-fullstack-flow: 97/100 (0 warnings)
- rookie-vue-todo-flow: 97/100 (0 warnings)

## Generated Files

- output/flow/career-switcher-fullstack-flow.md
- output/flow/career-switcher-fullstack-flow.json
- output/flow/jefry-ai-game-fullstack-flow.md
- output/flow/jefry-ai-game-fullstack-flow.json
- output/flow/rookie-vue-todo-flow.md
- output/flow/rookie-vue-todo-flow.json
- output/flow/flow-report.md
- output/flow/flow-report.json
