# CANON-015 Proof Of Superiority

Canon ID: CANON-015
Node ID: canon.sql.command.where-vs-having
Title: SQL WHERE vs HAVING

## What Official Docs Explain Well

PostgreSQL, MySQL, and SQLite documentation explain SELECT syntax, table-expression processing, `WHERE`, `GROUP BY`, and `HAVING` behavior.

## What Developers Still Struggle With

Developers commonly know both clauses filter but miss the timing:

- They put aggregate conditions in `WHERE`.
- They put row conditions in `HAVING`.
- They aggregate too much data before filtering.
- They confuse grouped results with detail rows.
- They filter in application code after fetching oversized result sets.

## How Atlas Improves The Explanation

Atlas turns the syntax distinction into a query-stage mental model: `WHERE` filters rows before grouping; `HAVING` filters groups after aggregation.

## What Decision Support Atlas Adds

The node gives practical routing:

- Use `WHERE` for row-level predicates.
- Use `HAVING` for aggregate predicates.
- Use both for reports with row constraints and group thresholds.
- Use CTEs, subqueries, or window functions when grouped filters must produce detail rows.

## What Production Guidance Atlas Adds

The node includes reporting examples, tenant/filter placement warnings, performance notes, debugging checks, and deterministic verification of row filtering, group filtering, combined filtering, and invalid aggregate placement.

## What AI-Readable Structure Atlas Adds

The node tells AI assistants to place row predicates in `WHERE`, aggregate predicates in `HAVING`, avoid `WHERE COUNT(*)`, explain logical query order, and recommend CTEs or window functions when the user asks for detail rows by aggregate facts.

## Why This Deserves Gold Candidate Status

CANON-015 deserves Gold Candidate status because it converts a high-frequency SQL confusion into a clear production decision model with official evidence, deterministic examples, debugging guidance, and AI-safe SQL generation rules. It still needs named reviewer sign-off before final Gold approval.
