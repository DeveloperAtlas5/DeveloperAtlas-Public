function relativeOffset({ normalTop, height, offsetTop = 0 }) {
  return {
    flowTop: normalTop,
    flowBottom: normalTop + height,
    visualTop: normalTop + offsetTop,
    visualBottom: normalTop + offsetTop + height,
    keepsLayoutSpace: true
  };
}

function absolutePosition({ ancestors, top = 0, left = 0 }) {
  const containingBlock = [...ancestors].reverse().find((ancestor) => ancestor.position !== "static");
  const anchor = containingBlock || { id: "initial-containing-block", x: 0, y: 0 };

  return {
    containingBlockId: anchor.id,
    visualTop: anchor.y + top,
    visualLeft: anchor.x + left,
    keepsLayoutSpace: false
  };
}

function fixedPosition({ viewport, top, right, width }) {
  return {
    visualTop: top,
    visualLeft: viewport.width - right - width,
    anchor: "viewport",
    keepsLayoutSpace: false
  };
}

function stickyPosition({ normalTop, scrollTop, thresholdTop, scrollContainerHeight, contentHeight }) {
  const hasScrollRange = contentHeight > scrollContainerHeight;
  const hasThreshold = Number.isFinite(thresholdTop);
  const stuck = hasScrollRange && hasThreshold && scrollTop + thresholdTop >= normalTop;

  return {
    stuck,
    visualTop: stuck ? thresholdTop : normalTop - scrollTop,
    requiresScrollContainer: true,
    requiresThreshold: true,
    keepsLayoutSpace: true
  };
}

module.exports = {
  relativeOffset,
  absolutePosition,
  fixedPosition,
  stickyPosition
};
