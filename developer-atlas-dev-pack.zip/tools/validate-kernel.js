const fs = require("fs");
const path = require("path");
const { readEntries, rootDir } = require("./content-utils");

const kernelDir = path.join(rootDir, "kernel");
const examplesDir = path.join(kernelDir, "examples");
const outputDir = path.join(rootDir, "output", "kernel");

function main() {
  const errors = [];
  const nodeIds = new Set(readEntries().map((entry) => entry.frontMatter.id));

  for (const file of findJsonFiles(kernelDir)) {
    try {
      JSON.parse(fs.readFileSync(file, "utf8"));
    } catch (error) {
      errors.push(`${path.relative(rootDir, file)}: invalid JSON (${error.message})`);
    }
  }

  for (const file of findJsonFiles(examplesDir).filter((file) => file.endsWith(".mission.json"))) {
    const mission = JSON.parse(fs.readFileSync(file, "utf8"));
    for (const nodeId of mission.required_node_ids || []) {
      if (!nodeIds.has(nodeId)) errors.push(`${path.relative(rootDir, file)}: required node missing: ${nodeId}`);
    }
    for (const nodeId of mission.optional_node_ids || []) {
      if (!nodeIds.has(nodeId)) errors.push(`${path.relative(rootDir, file)}: optional node missing: ${nodeId}`);
    }
  }

  if (fs.existsSync(outputDir)) {
    for (const file of findJsonFiles(outputDir)) {
      try {
        const output = JSON.parse(fs.readFileSync(file, "utf8"));
        if (file.endsWith(".json") && !output.decision_record && path.basename(file) !== "kernel-report.json") {
          errors.push(`${path.relative(rootDir, file)}: generated kernel output missing decision_record`);
        }
      } catch (error) {
        errors.push(`${path.relative(rootDir, file)}: invalid generated JSON (${error.message})`);
      }
    }
  }

  console.log("Atlas Kernel validation");
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  if (errors.length) process.exitCode = 1;
}

function findJsonFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) return findJsonFiles(fullPath);
    return entry.isFile() && entry.name.endsWith(".json") ? [fullPath] : [];
  });
}

main();
