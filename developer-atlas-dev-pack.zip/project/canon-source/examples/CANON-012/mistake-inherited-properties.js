const assert = require("assert");

function run() {
  const inheritedSettings = {
    inheritedTheme: "dark"
  };
  const userSettings = Object.create(inheritedSettings);
  userSettings.locale = "en-US";
  userSettings.timezone = "UTC";

  assert.deepStrictEqual(Object.keys(userSettings), ["locale", "timezone"]);
  assert.deepStrictEqual(Object.values(userSettings), ["en-US", "UTC"]);
  assert.deepStrictEqual(Object.entries(userSettings), [
    ["locale", "en-US"],
    ["timezone", "UTC"]
  ]);
  assert.strictEqual("inheritedTheme" in userSettings, true);
  assert.strictEqual(Object.keys(userSettings).includes("inheritedTheme"), false);
}

module.exports = run;

