# localStorage vs sessionStorage

## Status Metadata

- Canon ID: CANON-022
- Node ID: canon.javascript.storage.localstorage-vs-sessionstorage
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Batch: 05
- Level: rookie/junior
- Source family: JavaScript browser storage
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use `localStorage` when small browser data should persist after the tab and browser close. Use `sessionStorage` when small browser data should last only for the current tab session.

The everyday rule:

- `localStorage` answers: "Should this still be here tomorrow?"
- `sessionStorage` answers: "Should this disappear when this tab session ends?"
- Both store strings, so objects and arrays usually need `JSON.stringify()` and `JSON.parse()`.

## What Problem This Solves

Beginner web developers often need one practical next feature after a working todo app: persistence. Browser storage feels simple, but the wrong choice creates bugs and risk:

- Todos disappear because they were saved in `sessionStorage`.
- Temporary drafts leak between visits because they were saved in `localStorage`.
- Objects become `[object Object]` because they were stored without `JSON.stringify()`.
- App code crashes because invalid stored JSON was parsed without a fallback.
- Sensitive tokens, passwords, or personal data are stored in browser-accessible storage.

This node turns Web Storage into a decision: persistence lifetime first, security second, JSON boundary third.

## Mental Model

Think of browser storage as two small labeled drawers in the browser.

`localStorage` is the desk drawer. If you close the browser and come back later, the note is still there.

```js
localStorage.setItem("theme", "dark");
```

`sessionStorage` is the sticky note for the current tab session. It is useful while that tab is open, but it is not meant to become a long-term record.

```js
sessionStorage.setItem("checkoutDraft", "step-2");
```

Both drawers only store strings. If you want to save an array or object, pack it into JSON text with `JSON.stringify()` and unpack it with `JSON.parse()`.

```text
JavaScript value -- JSON.stringify() --> storage string
storage string   -- JSON.parse()     --> JavaScript value
```

## Beginner Explanation

Use `localStorage` for small things the user expects to keep:

```js
localStorage.setItem("todo-filter", "active");
```

Use `sessionStorage` for small things that should go away after the current tab session:

```js
sessionStorage.setItem("signup-draft-email", "ada@example.com");
```

If you save a todo list, remember that storage stores text:

```js
const todos = [{ id: 1, text: "Learn storage", done: false }];
localStorage.setItem("todos", JSON.stringify(todos));
```

To read it back:

```js
const saved = localStorage.getItem("todos");
const todos = saved ? JSON.parse(saved) : [];
```

Beginner rule:

1. Need it after closing the browser? `localStorage`.
2. Need it only for this tab session? `sessionStorage`.
3. Saving arrays or objects? `JSON.stringify()` before saving, `JSON.parse()` after reading.
4. Sensitive data? Do not store it in either one.

## Professional Explanation

`localStorage` and `sessionStorage` are synchronous Web Storage APIs exposed on `window`. They provide origin-scoped key-value storage where keys and values are strings. They are useful for small client-side preferences, drafts, UI state, and lightweight persistence, but they are not databases, secure secret stores, or state management systems.

`localStorage` persists across browser sessions for the same origin until cleared by the user, browser policy, or application code. `sessionStorage` is partitioned by origin and browser tab/top-level browsing context, and it lasts for the page session. That makes it better for tab-scoped drafts or wizard progress where long-term persistence would surprise the user.

Production review should check:

- Storage lifetime matches user expectations.
- Data is non-sensitive and safe to expose to JavaScript.
- Stored data is validated after parsing.
- Quota and unavailable-storage cases do not break the app.
- Synchronous storage calls are not placed in hot loops.
- Cross-tab behavior is understood before relying on it.

For larger, queryable, structured, or offline-first data, use IndexedDB or a higher-level persistence layer instead.

## Syntax

```js
localStorage.setItem("key", "value");
const value = localStorage.getItem("key");
localStorage.removeItem("key");
localStorage.clear();
```

```js
sessionStorage.setItem("draft", "hello");
const draft = sessionStorage.getItem("draft");
sessionStorage.removeItem("draft");
```

With JSON:

```js
localStorage.setItem("todos", JSON.stringify(todos));
const todos = JSON.parse(localStorage.getItem("todos") || "[]");
```

## Decision Guide

Ask these questions in order:

1. Is the data sensitive, secret, regulated, or dangerous if read by injected JavaScript?
   Use neither.
2. Should the data survive closing the tab or browser?
   Use `localStorage`.
3. Should the data disappear when the current tab session ends?
   Use `sessionStorage`.
4. Is the data an object or array?
   Use `JSON.stringify()` when saving and `JSON.parse()` when loading.
5. Is the data large, queryable, relational, or offline-first?
   Use IndexedDB or a backend instead.
6. Does the app need server trust, authentication, or authorization?
   Do not rely on browser storage as proof of trust.
7. Could stored data be missing, corrupt, or from an older app version?
   Add parsing fallback and shape validation.

## Comparison Table

| Feature | `localStorage` | `sessionStorage` |
| --- | --- | --- |
| Lifetime | Persists across browser sessions | Lasts for the current tab/page session |
| Scope | Same origin | Same origin and tab session |
| Best for | Preferences, small todo persistence, last selected filter | Tab-scoped drafts, wizard progress, temporary UI state |
| Value type | Strings only | Strings only |
| JSON needed for objects | Yes | Yes |
| Sensitive data | No | No |
| Main risk | Stale or privacy-sensitive data sticks around | Data disappears sooner than expected |
| Review question | "Should this survive tomorrow?" | "Should this belong only to this tab?" |

## When To Use The Primary Option

Use `localStorage` when:

- The user expects small data to remain after closing the browser.
- You are saving non-sensitive preferences such as theme, density, or dismissed tips.
- A beginner todo app needs simple persistence before a backend exists.
- You need a small cache that can be rebuilt safely.
- Losing the data would be annoying but not catastrophic.

```js
function saveTodos(todos) {
  localStorage.setItem("todos", JSON.stringify(todos));
}
```

## When To Use The Alternative

Use `sessionStorage` when:

- Data should be isolated to the current tab session.
- A multi-step form or checkout wizard needs temporary progress.
- A draft should not surprise the user by returning days later.
- Refreshing the page should keep the value, but opening a later browser session should not.

```js
function saveSignupDraft(draft) {
  sessionStorage.setItem("signup-draft", JSON.stringify(draft));
}
```

## When Not To Use This Decision

Use neither `localStorage` nor `sessionStorage` when:

- The value is a password, API token, refresh token, private key, or sensitive personal data.
- The data is large, needs indexing, or needs query-like access.
- The data must be trusted by the server.
- The value must be shared safely between users or devices.
- The app needs conflict resolution, transactions, or offline-first sync.
- The browser environment may block storage and the app has no fallback.
- You need secure authentication persistence. Use secure, HTTP-only cookie patterns or the platform's established auth approach.

## Alternatives

### IndexedDB

Use IndexedDB for larger structured browser data, offline-first data, or data that needs indexes.

### Backend Persistence

Use a backend database when data must follow the user across devices or be trusted by the server.

### In-Memory State

Use `ref()`, `reactive()`, or ordinary variables when the value does not need to survive refresh.

### Cookies

Use cookies only when HTTP request behavior is needed, and prefer secure, HTTP-only cookies for sensitive auth flows.

## Production Examples

### Persist A Rookie Vue Todo List

This is a practical next feature after a one-component Vue todo app works.

```js
const TODOS_KEY = "rookie-vue.todos";

function saveTodos(todos) {
  localStorage.setItem(TODOS_KEY, JSON.stringify(todos));
}

function loadTodos() {
  const raw = localStorage.getItem(TODOS_KEY);
  if (!raw) return [];

  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
```

This is safe beginner persistence because the todo list is small, non-sensitive, and recoverable.

### Store A Tab-Scoped Form Draft

Use `sessionStorage` when the draft should survive refresh but not become a long-term browser memory.

```js
const DRAFT_KEY = "signup.current-tab-draft";

function saveDraft(draft) {
  sessionStorage.setItem(DRAFT_KEY, JSON.stringify({
    email: draft.email,
    step: draft.step
  }));
}

function loadDraft() {
  return JSON.parse(sessionStorage.getItem(DRAFT_KEY) || "{\"email\":\"\",\"step\":1}");
}
```

### Avoid Sensitive Browser Storage

Do not store passwords, long-lived tokens, private keys, or sensitive personal data in Web Storage.

```js
// Avoid: readable by JavaScript and risky if the page has an XSS bug.
localStorage.setItem("accessToken", token);
```

Prefer a project-approved authentication pattern, often involving secure cookies and server-side controls.

## Common Mistakes

- Storing objects directly and getting `[object Object]`.
- Forgetting `JSON.parse()` when loading stored JSON.
- Assuming `sessionStorage` survives browser restarts.
- Assuming `localStorage` is secure because it is "local".
- Storing tokens or sensitive data in Web Storage.
- Parsing stored data without a fallback for missing or invalid JSON.
- Using browser storage as a database.
- Forgetting storage APIs are synchronous.
- Using one generic key like `"data"` and overwriting unrelated values.
- Trusting browser-stored values on the server.

## Debugging Checklist

- Check the key name in DevTools Application/Storage panel.
- Confirm whether the value is in `localStorage` or `sessionStorage`.
- Check whether the value is a string, JSON text, or accidental `[object Object]`.
- Wrap `JSON.parse()` in a fallback for corrupted or old data.
- Verify the data is not sensitive.
- Confirm the app uses the same origin where the value was saved.
- Check whether private browsing, browser settings, or quota limits affect storage.
- Remove the key and reload to test the empty-state path.
- Test closing and reopening the tab/browser to confirm lifetime behavior.

## Mechanical Verification

Deterministic examples live in `canon/examples/CANON-022/`.

Run:

```bash
npm run canon:verify:022
```

The examples verify:

- Saving a todo list to `localStorage` with `JSON.stringify()`.
- Loading a todo list from `localStorage` with `JSON.parse()`.
- Saving a tab-scoped draft in `sessionStorage`.
- Rejecting sensitive data as a browser-storage mistake.

## Performance Notes

Web Storage is synchronous. That is fine for small values and occasional preference or draft writes, but it should not be used for large payloads, hot loops, or frequent high-volume writes.

Practical performance guidance:

- Keep values small.
- Debounce frequent draft saves if needed.
- Avoid storing large API responses.
- Use IndexedDB for larger structured data.
- Do not block rendering with repeated JSON parsing in render paths.

## AI Coding Guidance

- Ask what lifetime the user expects before choosing storage.
- Use `localStorage` for small, non-sensitive persistence like a beginner todo list.
- Use `sessionStorage` for tab-scoped drafts and temporary progress.
- Always stringify arrays and objects before saving.
- Always parse with a missing/corrupt data fallback.
- Warn clearly against storing passwords, tokens, private keys, or sensitive personal data.
- Do not use browser storage as proof of authentication or authorization.
- For larger or offline-first data, recommend IndexedDB or backend persistence.

## Teaching Notes

Teach this after `JSON.parse()` vs `JSON.stringify()` and before backend persistence. It is a friendly next feature for the Rookie Vue Todo path because learners can see persistence immediately after refresh.

A calm teaching sequence:

1. Save one string with `localStorage`.
2. Load it after refresh.
3. Save an array with `JSON.stringify()`.
4. Load it with `JSON.parse()` and a fallback.
5. Compare that with `sessionStorage`.
6. Stop and explain security: not secrets, not tokens, not sensitive data.

## Interview Questions

1. What is the main lifetime difference between `localStorage` and `sessionStorage`?
2. Why do arrays and objects need `JSON.stringify()` before storage?
3. Why should sensitive tokens not be stored in Web Storage?
4. What would you use instead of Web Storage for large offline data?
5. How would you make loading stored JSON safer?

## Exercises

### Beginner

Persist a todo list in `localStorage`, refresh the page, and confirm the list returns.

### Intermediate

Add safe parsing: if the stored value is missing, invalid JSON, or the wrong shape, return a clean default.

### Advanced

Review an app that stores tokens and large API responses in browser storage. Write a short migration plan with safer alternatives.

## Related Atlas Nodes

- `CANON-017`
- `CANON-025`
- `javascript.browser.storage`
- `javascript.json.parse-vs-stringify`
- `vue.directive.v-model`

## Evidence And Sources

- MDN, `Window.localStorage`: https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
- MDN, `Window.sessionStorage`: https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage
- MDN, Web Storage API: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API
- MDN, Storage interface: https://developer.mozilla.org/en-US/docs/Web/API/Storage

## Proof Of Superiority Summary

Official docs explain the Web Storage APIs. Atlas improves the beginner path by turning the APIs into a practical persistence decision: expected lifetime, security risk, JSON conversion, fallback parsing, and the Rookie Vue Todo next feature. That makes it useful for rookies, reviewers, and AI assistants generating browser persistence code.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
