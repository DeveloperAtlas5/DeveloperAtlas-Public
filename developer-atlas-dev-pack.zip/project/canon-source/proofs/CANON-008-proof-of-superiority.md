# CANON-008 Proof Of Superiority

## What Official Docs Explain Well

MDN and the ECMAScript specification explain fulfillment behavior, rejection behavior, result ordering, and the settled-result shape for `Promise.all()` and `Promise.allSettled()`.

## What Developers Still Struggle With

Developers still struggle with practical failure semantics: when fail-fast is correct, when partial success should be preserved, whether `Promise.all()` cancels other work, how to inspect `allSettled()` results, and when concurrency limits require a different pattern.

## How Atlas Improves The Explanation

Atlas frames the choice around the question "What should happen when one task fails?" This turns promise aggregation into an engineering decision instead of a syntax choice.

## What Decision Support Atlas Adds

The Canon node gives a decision guide, comparison table, when-to-use sections, alternatives, and debugging checklist that route developers to `Promise.all()`, `Promise.allSettled()`, sequential `await`, promise pools, job queues, `Promise.race()`, or `Promise.any()`.

## What Production Guidance Atlas Adds

The node includes required account data loading, bulk notification reports, optional dashboard widgets, retry planning, result-to-input mapping, and concurrency cautions.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants explicit generation rules: use `Promise.all()` for required parallel work, use `Promise.allSettled()` for partial success, inspect `status`, preserve input identity, avoid `forEach(async ...)`, and never claim fail-fast means cancellation.

## Why This Deserves Gold Status

This node deserves Gold-candidate status because it turns a high-impact async behavior choice into a practical production decision model with official evidence, deterministic examples, debugging guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.
