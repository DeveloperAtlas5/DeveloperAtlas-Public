# Vue Router

Technology: Vue

## Simple meaning

Vue Router handles browser-side routing for a Vue app.

## Why it exists

It lets a single-page app show different views for different URLs without a full page reload.

## Where you use it

In router configuration and route-aware components.

## When to use it

Use Vue Router when a Vue app needs multiple pages or URL-based views.

## Tiny example

`{ path: '/todos', component: TodoPage }`

## Common beginner confusion

Vue Router changes what the browser shows. It does not replace Laravel routes that handle server requests or API endpoints.

## Related concepts

- Component
- Route params
- Navigation guard

## Similar idea in another technology

Laravel routes handle requests on the server; Vue Router handles view changes in the browser.
