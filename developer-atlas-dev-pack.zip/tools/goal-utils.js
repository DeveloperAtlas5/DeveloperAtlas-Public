const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const goalsDir = path.join(rootDir, "goals");
const goalExamplesDir = path.join(goalsDir, "examples");
const goalProfilesDir = path.join(goalsDir, "profiles");
const goalsOutputDir = path.join(rootDir, "output", "goals");
const personalRoadmapsOutputDir = path.join(goalsOutputDir, "personal-roadmaps");

function ensureGoalsOutputDirs() {
  fs.mkdirSync(personalRoadmapsOutputDir, { recursive: true });
}

function readJsonFiles(dir, dataKey) {
  if (!fs.existsSync(dir)) return [];

  return fs.readdirSync(dir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(dir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        [dataKey]: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function readGoals() {
  return readJsonFiles(goalExamplesDir, "goal");
}

function readGoalProfiles() {
  return readJsonFiles(goalProfilesDir, "profile");
}

function countValues(values) {
  const counts = new Map();

  for (const value of values) {
    counts.set(value, (counts.get(value) || 0) + 1);
  }

  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([value, count]) => ({ value, count }));
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

module.exports = {
  goalsDir,
  goalExamplesDir,
  goalProfilesDir,
  goalsOutputDir,
  personalRoadmapsOutputDir,
  ensureGoalsOutputDirs,
  readGoals,
  readGoalProfiles,
  countValues,
  unique
};

