# v-model in components

## Status Metadata

- Canon ID: CANON-CANDIDATE-VUE-007
- Node ID: canon.vue.components.v-model-in-components
- Status: candidate
- Score: 55
- Version: 2026.1
- Source family: Vue
- Level: rookie/junior
- Audience: future Rookie-to-Junior frontend path
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Component v-model is a convenient way for parent and child to share an editable value through a standard prop-and-event pattern. This candidate supports future Rookie-to-Junior frontend coverage and is not part of the current public alpha mission.

## What Problem This Solves

This reduces beginner confusion around v-model in components by turning the topic into a small decision with practical recovery guidance.

## Mental Model

Component v-model is a convenient way for parent and child to share an editable value through a standard prop-and-event pattern.

## Beginner Explanation

Component v-model is a convenient way for parent and child to share an editable value through a standard prop-and-event pattern. The goal is not to memorize a rule; the goal is to choose the option that matches what the code is trying to do.

## Professional Explanation

Use this decision to make intent visible in reviews, keep generated code scoped, and reduce hidden maintenance costs. The production signal is code that another developer can explain without reverse-engineering the author's guess.

## Syntax

```text
<TodoInput v-model="newTodo" />
```

## Decision Guide

1. Name the task in plain language.
2. Choose component v-model when: Use component v-model for form-like child components where two-way editing is the main point.
3. Choose props and emits when it communicates the intent better.
4. If neither fits, pause and look for a prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| component v-model | Use component v-model for form-like child components where two-way editing is the main point. | Can confuse beginners when used by habit. |
| props and emits | A clearer fit when the primary option does not match the task | Can add noise if the project does not need it. |

## When To Use The Primary Option

- Use component v-model for form-like child components where two-way editing is the main point.
- Use it when it makes the code easier to explain.
- Use it when it matches the surrounding project convention.

## When To Use The Alternative

- Use it when component v-model would hide the real intent.
- Use it when the alternative gives the learner or reviewer a clearer signal.
- Use it when existing project code already follows that pattern.

## When Not To Use This Decision

- Do not use v-model to hide many unrelated updates behind one binding.
- Do not expand the current Rookie Vue alpha mission just to use this candidate.
- Do not treat this candidate as fully reviewed evidence.

## Alternatives

- Use an existing Gold Candidate node when this topic overlaps one.
- Use a smaller prerequisite concept when the learner is blocked earlier.

## Production Examples

### Beginner Example

```text
<SearchBox v-model="searchText" />
```

### Review Example

```text
Before accepting the code, explain why component v-model or props and emits matches the task.
```

## Common Mistakes

- Using v-model when separate named events would make intent clearer.
- Copying generated code without checking whether it matches the task.
- Treating the candidate as final before examples and sources are hardened.

## Debugging Checklist

- If parent state does not update, check the model prop and update event names.
- Compare the current behavior with the intended choice.
- Ask whether a smaller prerequisite concept would unblock the learner faster.

## Mechanical Verification

Runnable or deterministic examples should be added during a future hardening sprint. This candidate intentionally has no runnable example folder yet.

## Performance Notes

No performance claim is finalized for this candidate. Future hardening should separate real runtime concerns from readability and learning concerns.

## AI Coding Guidance

- Ask AI to use v-model only for a focused editable value.
- Ask for a small, scoped change.
- Ask the assistant to explain the trade-off before producing code.

## Teaching Notes

Start with the plain-language model, show the beginner example, then ask the learner to explain the choice back in one sentence. Keep this candidate optional until a mission needs it.

## Interview Questions

1. When would you choose component v-model?
2. What mistake would make props and emits or another concept clearer?

## Exercises

### Beginner

Create a small SearchBox component controlled by parent state through v-model.

### Junior

Find one example in a small project and explain whether it uses the clearer option.

## Related Atlas Nodes

- CANON-025

## Evidence And Sources

- Candidate backlog entry only. Official source links must be added during hardening.
- Evidence level: candidate draft.
- Confidence: medium.

## Proof Of Superiority Summary

This candidate has a draft improvement hypothesis only. It should not be treated as reviewed or publication-ready.

## Scorecard Placeholder

- Current score: 55
- Status: candidate
- Needs official sources, stronger examples, verification, editorial review, and reviewer sign-off before any Gold consideration.
