const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const {
  createKernelContext,
  runIntentEngine,
  runConstraintEngine,
  runKnowledgeEngine,
  runPatternEngine,
  runDecisionEngine,
  runRecommendationEngine,
  runLearningEngine,
  createKernelOutput
} = require("./kernel-engines");

const missionArg = process.argv[2] || "all";
const examplesDir = path.join(rootDir, "kernel", "examples");
const outputDir = path.join(rootDir, "output", "kernel");

function readJson(relativePath, fallback = null) {
  const file = path.join(rootDir, relativePath);
  if (!fs.existsSync(file)) return fallback;
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function main() {
  const brain = readJson("output/brain/atlas-brain-pack.json");
  const atlasContext = readJson("output/ai/atlas-context-pack.json");
  const graph = readJson("output/graph/knowledge-graph.json");
  const models = {
    intentOntology: readJson("intent/ontology.json", {}),
    intentDetection: readJson("intent/intent-detection-model.json", {}),
    constraints: readJson("kernel/constraint-engine.json", {}),
    patternCatalog: readJson("patterns/pattern-catalog.json", { patterns: [] })
  };
  const missions = loadMissions();
  const report = [];

  fs.mkdirSync(outputDir, { recursive: true });

  for (const mission of missions) {
    const result = runMission(mission, brain, atlasContext, graph, models);
    const jsonPath = path.join(outputDir, `${mission.mission_id}.json`);
    const mdPath = path.join(outputDir, `${mission.mission_id}.md`);
    fs.writeFileSync(jsonPath, `${JSON.stringify(result, null, 2)}\n`);
    fs.writeFileSync(mdPath, toMarkdown(result));
    report.push({
      mission_id: mission.mission_id,
      confidence: result.decision_record.confidence,
      warnings: result.warnings,
      json: path.relative(rootDir, jsonPath),
      markdown: path.relative(rootDir, mdPath)
    });
  }

  writeReport(report);
  console.log(`Processed ${report.length} kernel mission(s).`);
}

function loadMissions() {
  const files = fs.readdirSync(examplesDir)
    .filter((file) => file.endsWith(".mission.json"))
    .sort();
  const selected = missionArg === "all"
    ? files
    : files.filter((file) => file === `${missionArg}.mission.json` || file.startsWith(`${missionArg}.`));

  if (selected.length === 0) throw new Error(`No mission found for "${missionArg}".`);
  return selected.map((file) => JSON.parse(fs.readFileSync(path.join(examplesDir, file), "utf8")));
}

function runMission(mission, brain, atlasContext, graph, models) {
  return createKernelOutput(
    runLearningEngine(
      runRecommendationEngine(
        runDecisionEngine(
          runPatternEngine(
            runKnowledgeEngine(
              runConstraintEngine(
                runIntentEngine(
                  createKernelContext(mission, brain, atlasContext, graph, models)
                )
              )
            )
          )
        )
      )
    )
  );
}

function toMarkdown(result) {
  const record = result.decision_record;
  const lines = [
    `# Atlas Kernel Decision: ${result.mission.mission_id}`,
    "",
    "## User Goal",
    "",
    record.user_goal,
    "",
    "## Detected Intent",
    "",
    record.detected_intent,
    "",
    "## Recommendation",
    "",
    `- Node: \`${record.recommendation.node_id}\``,
    `- Decision: ${record.recommendation.title}`,
    `- Reason: ${record.recommendation.reason}`,
    "",
    "## Confidence",
    "",
    `- Confidence: ${record.confidence}/5`,
    `- Evidence level: ${record.evidence_level}`,
    "",
    "## Ranked Solutions",
    ""
  ];
  for (const item of result.ranked_solutions || []) {
    lines.push(`- \`${item.node_id}\`: confidence ${item.confidence}/5, maintenance ${item.maintenance_impact}, performance ${item.performance_impact}`);
  }
  lines.push("", "## Trade-Offs", "");
  for (const item of record.tradeoffs) lines.push(`- ${item}`);
  lines.push("", "## Rejected Alternatives", "");
  for (const item of record.rejected_alternatives) lines.push(`- \`${item.node_id}\`: ${item.reason}`);
  lines.push("", "## Beginner Explanation", "", record.beginner_explanation);
  lines.push("", "## Professional Summary", "", record.professional_summary);
  lines.push("", "## Verification Steps", "");
  for (const step of record.verification_steps) lines.push(`- ${step}`);
  lines.push("", "## Related Knowledge Nodes", "");
  for (const nodeId of record.supporting_nodes) lines.push(`- \`${nodeId}\``);
  lines.push("", "## What To Learn Next", "");
  for (const nodeId of record.next_learning_nodes) lines.push(`- \`${nodeId}\``);
  lines.push("", "## AI Coding Guidance", "", record.ai_coding_guidance, "");
  if (result.warnings.length) {
    lines.push("## Warnings", "");
    for (const warning of result.warnings) lines.push(`- ${warning}`);
  }
  return `${lines.join("\n")}\n`;
}

function writeReport(report) {
  const average = report.length
    ? (report.reduce((sum, item) => sum + item.confidence, 0) / report.length).toFixed(1)
    : "0.0";
  const warnings = report.flatMap((item) => item.warnings.map((warning) => `${item.mission_id}: ${warning}`));
  const lines = [
    "# Atlas Kernel Report",
    "",
    `Missions processed: ${report.length}`,
    `Generated decision records: ${report.length}`,
    `Average confidence: ${average}`,
    "",
    "## Generated Files",
    ""
  ];
  for (const item of report) {
    lines.push(`- ${item.mission_id}: \`${item.markdown}\`, \`${item.json}\``);
  }
  lines.push("", "## Missing Nodes", "");
  const missing = warnings.filter((warning) => warning.includes("node not found"));
  if (missing.length) for (const warning of missing) lines.push(`- ${warning}`);
  else lines.push("- None");
  lines.push("", "## Warnings", "");
  if (warnings.length) for (const warning of warnings) lines.push(`- ${warning}`);
  else lines.push("- None");
  fs.writeFileSync(path.join(outputDir, "kernel-report.md"), `${lines.join("\n")}\n`);
}

main();
