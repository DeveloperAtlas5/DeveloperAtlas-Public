# CANON-015 Review

Canon ID: CANON-015
Node ID: canon.sql.command.where-vs-having
Title: SQL WHERE vs HAVING
Status: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Correctly explains `WHERE` row filtering before grouping and `HAVING` group filtering after aggregation.
- Edge cases: Covers combined use, aggregate placement mistakes, row predicates in `HAVING`, CTEs for detail rows, and tenant scoping.
- Evidence: Uses official PostgreSQL, MySQL, and SQLite documentation.
- Verification: Four deterministic examples pass.

## Educational Review

- Mental model: Strong before-count / after-count framing.
- Beginner clarity: Clear rules for row conditions, aggregate conditions, and using both.
- Professional depth: Includes performance, CTE/window alternatives, and production report review signals.
- Exercises: Covers beginner, intermediate, and advanced report-building practice.

## AI Readiness Review

- Code generation guidance: Strong rules for row predicates, aggregate predicates, invalid `WHERE COUNT(*)`, and staged aggregate queries.
- Machine readability: Stable Canon headings and scorecard structure.
- Relationship quality: Connects to SQL SELECT, WHERE, JOIN, and CANON-005.

## Engineering Review

- Production examples: Includes active paid orders, repeat customers, monthly revenue, and detail rows by aggregate facts.
- Debugging support: Checklist maps directly to common SQL report bugs.
- Trade-offs: Clear distinction between correctness, performance, and query complexity.

## Remaining Gold Gaps

- Named human reviewer sign-off is still required before final Gold status.
