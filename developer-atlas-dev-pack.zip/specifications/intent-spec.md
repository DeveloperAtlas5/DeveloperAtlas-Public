# Intent Specification

Intent describes what the user is trying to accomplish.

## Purpose

The Intent Engine helps Atlas choose the right reasoning path before recommending a solution.

## Initial Intent Types

- `syntax_reference`: User needs syntax or API shape.
- `engineering_decision`: User needs to choose between options.
- `troubleshooting_decision`: User has broken behavior or an error.
- `learning_guidance`: User wants to understand or study.
- `implementation_plan`: User wants steps for building something.
- `architecture_guidance`: User needs system-level trade-offs.

## Inputs

- `user_goal`
- `expected_output`
- `context`
- `persona`
- `technologies`
- `constraints`

## Outputs

- `detected_intent`
- `intent_confidence`
- `reason`
- `required_reasoning_modules`

## Rule

Do not answer a syntax question like a troubleshooting question, and do not answer a decision question like a documentation lookup.
