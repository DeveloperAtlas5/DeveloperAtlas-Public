const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const readinessDir = path.join(rootDir, "readiness");
const readinessExamplesDir = path.join(readinessDir, "examples");
const readinessDeltasDir = path.join(readinessDir, "deltas");
const readinessOutputDir = path.join(rootDir, "output", "readiness");

function ensureReadinessOutputDir() {
  fs.mkdirSync(readinessOutputDir, { recursive: true });
}

function readReadinessProfiles() {
  return readJsonFiles(readinessExamplesDir, "profile");
}

function readReadinessDeltas() {
  return readJsonFiles(readinessDeltasDir, "delta");
}

function readJsonFiles(dir, dataKey) {
  if (!fs.existsSync(dir)) return [];

  return fs.readdirSync(dir)
    .filter((fileName) => fileName.endsWith(".json"))
    .sort()
    .map((fileName) => {
      const file = path.join(dir, fileName);
      return {
        file,
        relativePath: path.relative(rootDir, file).replace(/\\/g, "/"),
        [dataKey]: JSON.parse(fs.readFileSync(file, "utf8"))
      };
    });
}

function average(values) {
  return values.length ? values.reduce((total, value) => total + value, 0) / values.length : 0;
}

function round(value) {
  return Number(value.toFixed(2));
}

function unique(values) {
  return [...new Set(values)].filter(Boolean);
}

module.exports = {
  readinessDir,
  readinessExamplesDir,
  readinessDeltasDir,
  readinessOutputDir,
  ensureReadinessOutputDir,
  readReadinessProfiles,
  readReadinessDeltas,
  average,
  round,
  unique
};
