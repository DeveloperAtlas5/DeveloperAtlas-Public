const assert = require("assert");

function run() {
  const accountSummary = {
    plan: "Pro",
    seats: 12,
    status: "Active"
  };
  const labels = {
    plan: "Plan",
    seats: "Seats",
    status: "Status"
  };

  const rows = Object.entries(accountSummary).map(([key, value]) => ({
    label: labels[key],
    value: String(value)
  }));

  assert.deepStrictEqual(rows, [
    { label: "Plan", value: "Pro" },
    { label: "Seats", value: "12" },
    { label: "Status", value: "Active" }
  ]);
}

module.exports = run;

