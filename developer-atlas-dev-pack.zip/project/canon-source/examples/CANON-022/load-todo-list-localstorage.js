const assert = require("assert");
const { MemoryStorage } = require("./storage-fake");

function loadTodos(storage) {
  const raw = storage.getItem("todos");
  if (!raw) return [];

  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

module.exports = function loadTodoListFromLocalStorage() {
  const localStorage = new MemoryStorage("localStorage");

  localStorage.setItem("todos", JSON.stringify([{ id: 1, text: "Load me", done: false }]));
  assert.deepStrictEqual(loadTodos(localStorage), [{ id: 1, text: "Load me", done: false }]);

  localStorage.setItem("todos", "not valid json");
  assert.deepStrictEqual(loadTodos(localStorage), []);
};
