# Laravel Controller vs Form Request vs Service

## Status Metadata

- Canon ID: CANON-018
- Node ID: canon.laravel.architecture.controller-vs-form-request-vs-service
- Status: gold_candidate
- Score: 95
- Version: 2026.1
- Source family: Laravel architecture
- Level: intermediate/professional
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use a controller to coordinate the HTTP request and response. Use a Form Request when validation, authorization, messages, or input preparation deserve a named request boundary. Extract a service when reusable business workflow has grown beyond simple controller coordination.

This is an ownership decision:

- Controller = HTTP coordinator.
- Form Request = validation and authorization boundary.
- Service = reusable business workflow.
- Not every endpoint needs all three.

## What Problem This Solves

Laravel apps often start clean and then quietly collect too many responsibilities in controllers:

- Validation rules duplicated across actions.
- Authorization mixed into persistence logic.
- Business workflows hidden inside long controller methods.
- Services created for one-line Eloquent calls.
- AI-generated Laravel code inventing generic `Manager` or `Service` classes without a real boundary.

This node helps developers decide where code belongs without turning every small endpoint into ceremony.

## Mental Model

Think of a Laravel request as a handoff.

The controller receives the request and decides the high-level HTTP flow.

The Form Request checks whether the request is allowed and shaped correctly.

The service owns a reusable business operation when the workflow deserves a name outside HTTP.

```text
Route -> Controller -> Form Request boundary -> Service workflow -> Response
```

Good Laravel architecture is not "thin controllers at any cost." It is clear responsibility:

- Keep simple coordination in the controller.
- Move request contracts into Form Requests when they grow.
- Move business workflow into services when it is reused, testable, or conceptually important.

## Beginner Explanation

A controller is the front door for a route.

```php
public function store(Request $request)
{
    // receive request
    // validate input
    // do the work
    // return response
}
```

That is fine when the action is tiny.

When validation gets longer, move it to a Form Request:

```php
public function store(StoreProductRequest $request)
{
    Product::create($request->validated());
}
```

When the work becomes a named business process, move that process into a service:

```php
public function store(StoreOrderRequest $request, CreateOrderService $orders)
{
    $order = $orders->create($request->user(), $request->validated());

    return new OrderResource($order);
}
```

Beginner rule:

1. Controller coordinates the request.
2. Form Request protects the input boundary.
3. Service owns reusable business work.
4. Do not create a service just because someone said controllers must be thin.

## Professional Explanation

Controllers, Form Requests, and services are not hierarchy levels that every feature must pass through. They are ownership tools.

A controller should express route intent: accept dependencies, call validation through the request contract, coordinate application work, and return a response. It may contain small local logic when that logic is HTTP-specific and readable.

A Form Request is a request boundary. It centralizes validation, authorization, custom messages, attributes, and input preparation. It is especially useful for stable API contracts, forms with many rules, route-aware validation, and policy-like request checks.

A service is useful when a business workflow needs a name, reuse, tests, transactions, multi-model coordination, integration calls, or invocation from multiple entry points such as controllers, commands, jobs, or listeners. A service should not know too much about HTTP details. It should receive validated data or typed inputs and return domain/application results.

The professional review question is: does this boundary reduce duplication, clarify responsibility, and make behavior easier to test? If not, the abstraction may be premature.

## Syntax

Controller with Form Request:

```php
public function store(StoreProductRequest $request)
{
    $product = Product::create($request->validated());

    return new ProductResource($product);
}
```

Controller with Form Request and service:

```php
public function store(StoreOrderRequest $request, CreateOrderService $orders)
{
    $order = $orders->create(
        user: $request->user(),
        data: $request->validated()
    );

    return new OrderResource($order);
}
```

Service shape:

```php
final class CreateOrderService
{
    public function create(User $user, array $data): Order
    {
        return DB::transaction(function () use ($user, $data) {
            return $user->orders()->create($data);
        });
    }
}
```

## Decision Guide

Ask these questions in order:

1. Is the logic just receiving a route request and returning a response?
   Keep it in the controller.
2. Are validation or authorization rules longer, reused, customized, route-aware, or worth testing separately?
   Use a Form Request.
3. Is the logic a business workflow rather than HTTP coordination?
   Consider a service.
4. Is the workflow reused by controllers, jobs, commands, listeners, or tests?
   Extract a service.
5. Does the operation need transactions, multi-model updates, integration calls, or named business language?
   Extract a service.
6. Is the service only wrapping one obvious Eloquent line?
   Do not create it yet.
7. Would an action, job, policy, model method, or custom validation rule be a better boundary?
   Use the more specific tool.

## Comparison Table

| Choice | Owns | Best For | Main Risk |
| --- | --- | --- | --- |
| Controller | HTTP coordination | Small actions, response shape, dependency handoff | Bloated methods if it owns every responsibility |
| Form Request | Validation and authorization boundary | Named request contracts, route-aware validation, custom messages | Business workflow leaking into request class |
| Service | Reusable business workflow | Multi-step operations, transactions, cross-entry-point reuse | Vague abstraction if it wraps trivial code |
| Policy/Gate | Authorization decisions | User permission checks | Mixing permission rules into validation or services |
| Job | Background work | Slow or asynchronous operations | Hiding synchronous result requirements |

## When To Use The Primary Option

Keep logic in the controller when:

- The action is small and readable.
- Validation is tiny and local.
- The behavior is HTTP-specific.
- The action does not contain reusable business workflow.
- Extracting a class would only rename one obvious line.

```php
public function updateDisplayName(Request $request)
{
    $validated = $request->validate([
        'display_name' => ['required', 'string', 'max:60'],
    ]);

    $request->user()->update($validated);

    return back()->with('status', 'Display name updated.');
}
```

Why controller-only fits: the request contract is short, the action is local, and a service would add ceremony without reducing confusion.

## When To Use The Alternative

Use a Form Request when:

- Rules are long or repeated.
- Authorization belongs with the request contract.
- Custom messages or attributes matter.
- Input must be prepared before validation.
- Route parameters affect validation.
- Tests should target the request contract directly.

```php
public function store(StoreProjectMemberRequest $request)
{
    ProjectMember::create($request->validated());

    return redirect()->route('project-members.index');
}
```

Use a service when:

- The workflow is reused.
- Multiple models are coordinated.
- A transaction is needed.
- The operation has domain language.
- The same operation may run from a controller, job, command, or listener.

```php
public function store(StoreInvoiceRequest $request, CreateInvoiceService $invoices)
{
    $invoice = $invoices->create($request->user(), $request->validated());

    return new InvoiceResource($invoice);
}
```

## When Not To Use This Decision

Do not force every feature into controller, Form Request, and service layers.

Avoid these patterns:

- A `UserService` with one method that only calls `User::create($data)`.
- A Form Request that sends emails, creates records, or runs business workflow.
- A controller that validates, authorizes, charges payment, sends emails, and returns a response in one long method.
- A service that depends on raw `Request` when it should receive validated data.
- A service created only to satisfy a vague "thin controller" rule.
- Moving logic out of a controller without making ownership clearer.

## Alternatives

- Policy or gate for authorization decisions.
- Custom validation rule for reusable field validation.
- Action class for a single named command.
- Job for asynchronous or slow workflow.
- Model method for behavior that truly belongs to one model.
- Event/listener for decoupled side effects.
- Database constraint for integrity guarantees.

## Production Examples

### Simple Controller Stays Simple

```php
public function archive(Project $project)
{
    $this->authorize('archive', $project);

    $project->update(['archived_at' => now()]);

    return back()->with('status', 'Project archived.');
}
```

Why controller-only fits: the operation is short, HTTP-specific, and does not justify a new service yet.

### Form Request Extracts Validation And Authorization

```php
class StoreProjectMemberRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('manageMembers', $this->route('project'));
    }

    public function rules(): array
    {
        return [
            'email' => ['required', 'email'],
            'role' => ['required', Rule::in(['viewer', 'editor', 'admin'])],
        ];
    }
}
```

```php
public function store(StoreProjectMemberRequest $request, Project $project)
{
    $project->members()->create($request->validated());

    return redirect()->route('projects.members.index', $project);
}
```

Why a Form Request fits: validation and authorization are a named request contract.

### Service Extracts Reusable Business Workflow

```php
final class InviteProjectMemberService
{
    public function invite(Project $project, User $inviter, array $data): ProjectMember
    {
        return DB::transaction(function () use ($project, $inviter, $data) {
            $member = $project->members()->create($data + [
                'invited_by' => $inviter->id,
            ]);

            Mail::to($data['email'])->queue(new ProjectInvitationMail($project));

            return $member;
        });
    }
}
```

```php
public function store(
    StoreProjectMemberRequest $request,
    Project $project,
    InviteProjectMemberService $members
) {
    $member = $members->invite($project, $request->user(), $request->validated());

    return new ProjectMemberResource($member);
}
```

Why a service fits: the workflow coordinates persistence, invitation metadata, email, and reuse outside one controller.

### Mistake: Service For One Line

```php
// Usually unnecessary.
final class UpdateDisplayNameService
{
    public function update(User $user, array $data): void
    {
        $user->update($data);
    }
}
```

This service does not yet reduce complexity. Keep the simple update in the controller until the workflow gains real behavior.

## Common Mistakes

- Treating "thin controller" as "every action must call a service."
- Putting long validation rules in controllers after the request contract deserves a name.
- Putting business workflow into a Form Request.
- Passing raw `Request` objects into services.
- Creating generic `Manager`, `Handler`, or `Service` classes with unclear ownership.
- Duplicating the same validation rules across store/update actions without extracting.
- Hiding authorization in a service when a policy or Form Request `authorize()` would be clearer.
- Moving code to a service without adding tests or clearer language.

## Debugging Checklist

- Can the controller action be understood in one scan?
- Are validation and authorization happening before business work trusts input?
- Does the Form Request only own request validation/authorization concerns?
- Does the service avoid HTTP response, redirect, session, and raw request details?
- Is the service reused or meaningfully named?
- Is a transaction needed for multi-step persistence?
- Are side effects like mail, jobs, events, or integrations visible and testable?
- Would a policy, job, action, custom rule, or model method be a better boundary?
- Did the refactor reduce confusion, or only add files?

## Mechanical Verification

Deterministic examples live in `canon/examples/CANON-018/`.

Run:

```bash
npm run canon:verify:018
```

Verified examples:

- Simple controller stays simple.
- Form Request extracts validation and authorization.
- Service extracts reusable business workflow.
- Creating a service for one line of code is identified as unnecessary.

## Performance Notes

This decision is about maintainability, testability, and clarity. It rarely affects runtime performance directly.

Performance-related concerns usually come from the work inside the boundary:

- N+1 database queries.
- Missing transactions.
- Slow external API calls.
- Synchronous email or notification work.
- Repeated validation or duplicated queries.

Use services or jobs when they make expensive workflows explicit and testable, not because indirection is automatically faster.

## AI Coding Guidance

- Do not generate service classes by default.
- Ask whether the code is HTTP coordination, request validation/authorization, or reusable business workflow.
- Use Form Requests for meaningful request contracts.
- Keep simple controller actions simple.
- Extract a service only when it owns named workflow, reuse, transactions, integrations, or multi-model coordination.
- Do not pass raw `Request` objects into services unless there is a strong framework-specific reason.
- Name services by business operation, such as `InviteProjectMemberService`, not vague nouns like `ProjectManager`.
- Suggest policies, jobs, custom rules, or actions when those are the better boundary.

## Teaching Notes

Teach this after Laravel validation and basic controllers.

Use a three-column responsibility exercise:

| Line of code | Responsibility | Better home |
| --- | --- | --- |
| validate email and role | Request contract | Form Request |
| call authorization policy | Permission boundary | Policy/Form Request |
| create member and send invite | Business workflow | Service |
| return redirect/resource | HTTP response | Controller |

The teaching goal is not "make controllers tiny." The goal is "make ownership obvious."

## Interview Questions

1. What should a Laravel controller own?
2. When should validation move into a Form Request?
3. What makes a service useful instead of unnecessary ceremony?
4. Why should services usually receive validated data instead of raw requests?
5. Where should authorization live?
6. How would you refactor a bloated controller action?

## Exercises

### Beginner

Label each line of a controller action as HTTP coordination, validation, authorization, business workflow, or response.

### Intermediate

Move a repeated validation contract into a Form Request with an `authorize()` method.

### Advanced

Extract a reusable invitation workflow into a service while keeping HTTP response logic in the controller.

## Related Atlas Nodes

- `CANON-014`
- `laravel.controllers.controller`
- `laravel.validation.validation`
- `laravel.routing.route-post`
- `laravel.eloquent.model`

## Evidence And Sources

- Laravel controllers: https://laravel.com/docs/controllers
- Laravel validation: https://laravel.com/docs/validation
- Laravel Form Request validation: https://laravel.com/docs/validation#form-request-validation
- Laravel authorization: https://laravel.com/docs/authorization
- Laravel service container: https://laravel.com/docs/container

## Proof Of Superiority Summary

Official Laravel documentation explains controllers, validation, authorization, Form Requests, and the service container. Atlas adds the architectural decision layer: keep simple actions simple, move request contracts to Form Requests, extract services only for real business workflow, and guide AI assistants away from boilerplate service classes that do not reduce confusion.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 15 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 10 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 2 |
| readability | 2 | 1 |
| Total | 100 | 95 |
