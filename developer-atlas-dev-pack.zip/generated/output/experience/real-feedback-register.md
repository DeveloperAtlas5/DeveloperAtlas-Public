# Real Feedback Register

This register records real tester feedback only.

Do not add simulated feedback here.

Use simulated feedback only for internal red-team thinking, not as evidence of traction.

Real tester feedback should be clearly separated from simulated or internal feedback.

## Real Feedback 1 - Rookie Pack first test

Source type: real tester
Date: unknown
Pack tested: Rookie

### What they said

- Starting was easy enough.
- No clutter.
- The dashboard/index worked.
- After that, mission text was too dense and small on laptop.
- Knowledge was interesting but not what tester wanted right now.
- AI/vibe coding sounded interesting later.
- Would not pay now, but might return if Atlas became a larger menu of missions.

### What this means

The Rookie Pack entry was close, but the reading experience needed to be calmer and easier on a laptop.

### Change made because of it

Phase 120 improved mission readability and dashboard typography.

### Still open

Keep testing whether a larger mission menu becomes useful after the first mission works.

## Real Feedback 2 - Beginner wording feedback

Source type: real beginner
Date: unknown
Pack tested: Rookie

### What they said

- Use `to-do` / `to-do's` in learner text.
- Do not say `Welcome back` in Mission 1.
- Clarify unclear phrases.
- Explain Vue state simply.
- Replace `Where this work happens`.
- Explain or remove `Difficulty: guided`.
- Clarify AI should explain/help, not take over.
- Replace `blocker`.

### What this means

Rookie text should be understandable before the learner knows programming words.

### Change made because of it

Phase 122 completed the Rookie plain-language pass.

### Still open

Keep checking new learner-facing words against real beginner reactions.

## Real Feedback 3 - Entry boundary feedback

Source type: real owner observation
Date: unknown
Pack tested: Rookie

### What they said

- The mission is understandable for a rookie with a project.
- It does not work for complete beginners who do not know how to start a Vue project.
- The dashboard HTML can open in VS Code instead of the browser.
- Suggested flow: Goal -> Build or Learn -> Solo or AI Help -> Concept Library / Mission Path.

### What this means

Atlas reduces confusion inside a mission, but it also needs a place for the step before the mission.

### Change made because of it

Phase 123 clarified the Vue project prerequisite and browser-opening instructions.

Phase 124 adds Project Start Guides.

### Still open

Decide later whether Project Start Guides should appear in the Rookie Pack or a future goal flow.

## Real Feedback 4 - To fill from owner notes

Status: waiting for owner summary.

## Real Feedback 5 - To fill from owner notes

Status: waiting for owner summary.
