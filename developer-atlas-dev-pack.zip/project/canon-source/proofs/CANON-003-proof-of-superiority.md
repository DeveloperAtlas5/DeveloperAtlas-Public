# CANON-003 Proof Of Superiority

## What Official Docs Explain Well

Vue's official documentation explains that `ref()` returns an object with a `.value` property, that `reactive()` returns a reactive proxy for objects, and that refs are unwrapped in templates.

## What Developers Still Struggle With

Developers still struggle with when `.value` is required, why reactive destructuring can produce stale values, when object replacement is risky, and how to return state safely from composables.

## How Atlas Improves The Explanation

Atlas frames the choice around state shape and boundary behavior: `ref()` for values, replacement, and composable returns; `reactive()` for cohesive local object state.

## What Decision Support Atlas Adds

The Canon node gives a decision guide, comparison table, when-to-use sections, alternatives, and debugging checklist that route developers to `ref()`, `reactive()`, `computed()`, `watch()`, props, emits, or store state.

## What Production Guidance Atlas Adds

The node includes fetch state, form state, composable return patterns, safe `toRefs()` usage, and debugging checks for `.value`, destructuring, and object replacement.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants explicit generation rules: use `.value` in script, avoid direct reactive destructuring, use `computed()` for derived values, and avoid replacing reactive proxies.

## Why This Deserves Gold Status

This node deserves Gold-candidate status because it turns a common Vue confusion into a practical decision model with evidence, examples, verification, production guidance, and AI-specific guardrails. It still needs named reviewer sign-off before final Gold approval.
