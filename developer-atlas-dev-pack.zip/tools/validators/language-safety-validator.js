const {
  fs,
  path,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionThreeSurfacePath,
  vibeMissionThreeSurfacePath,
  missionDashboardPath,
  startHerePath,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedFirstTimeQuickStartPath,
  packagedMissionDashboardPath,
  packagedAiPromptPackPath,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  packagedMissionThreeSurfacePath,
  packagedVibeMissionThreeSurfacePath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange
} = require("./shared-validator-utils");

function validateLearnerFacingPackageLanguage(errors) {
  if (!fs.existsSync(packagedDemoDir)) return;

  const learnerFacingFiles = [
    ["START_HERE.md", packagedStartHerePath],
    ["first-time-quick-start.md", packagedFirstTimeQuickStartPath],
    ["mission-dashboard.html", packagedMissionDashboardPath],
    ["ai-prompt-pack.md", packagedAiPromptPackPath],
    ["help/beginner-orientation.md", packagedBeginnerOrientationPath],
    ["help/vue-concept-cards.md", packagedVueConceptCardsPath],
    ["help/terminal-confidence-guide.md", packagedTerminalConfidenceGuidePath],
    ["mission/today-mission-surface.md", path.join(packagedDemoDir, "mission", "today-mission-surface.md")],
    ["mission/today-mission-surface.vibe.md", path.join(packagedDemoDir, "mission", "today-mission-surface.vibe.md")],
    ["mission/mission-02-todoitem-surface.md", path.join(packagedDemoDir, "mission", "mission-02-todoitem-surface.md")],
    ["mission/mission-02-todoitem-surface.vibe.md", path.join(packagedDemoDir, "mission", "mission-02-todoitem-surface.vibe.md")],
    ["mission/mission-03-todostats-surface.md", packagedMissionThreeSurfacePath],
    ["mission/mission-03-todostats-surface.vibe.md", packagedVibeMissionThreeSurfacePath],
    ["mission/mission-feedback-template.md", path.join(packagedDemoDir, "mission", "mission-feedback-template.md")]
  ];

  for (const [label, filePath] of learnerFacingFiles) {
    const fullLabel = `output/share/developer-atlas-mvp-demo/${label}`;
    if (!fs.existsSync(filePath)) {
      errors.push(`${fullLabel}: missing learner-facing package file`);
      continue;
    }
    const text = fs.readFileSync(filePath, "utf8");
    validateForbiddenTerms(text, fullLabel, errors);
    validateNoHypeLanguage(text, fullLabel, errors);
    validateNoShameLanguage(text, fullLabel, errors);
  }
}

module.exports = {
  validateLearnerFacingPackageLanguage
};
