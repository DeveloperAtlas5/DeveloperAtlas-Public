function fetchCustomer(customerId) {
  return Promise.resolve({
    id: customerId,
    firstName: "Ada",
    lastName: "Lovelace"
  });
}

function toCustomerSummary(customer) {
  return {
    id: customer.id,
    label: `${customer.firstName} ${customer.lastName}`
  };
}

function addDisplayLabels(summary) {
  return {
    ...summary,
    display: `${summary.label} (#${summary.id})`
  };
}

module.exports = async function runPromiseThenTransformationChain() {
  const summary = await fetchCustomer(7)
    .then(toCustomerSummary)
    .then(addDisplayLabels);

  if (summary.display !== "Ada Lovelace (#7)") {
    throw new Error("Promise.then() chain did not transform the customer summary.");
  }

  return summary;
};
