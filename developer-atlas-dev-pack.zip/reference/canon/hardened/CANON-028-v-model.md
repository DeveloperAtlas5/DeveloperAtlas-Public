# CANON-028 - v-model

Status: Hardened

## Core idea

v-model connects form input to state.

It is useful for todo input text.

## Use this when

Use this when an input should update a reactive value.

## Basic pattern

Bind the input to a ref.

## Common friction

Clear the input after adding the todo if the mission expects a fresh field.

## Small example

```vue
<input v-model="newTodo" />
```

## Check yourself

- Does typing update state?
- Does the add action use that state?

## Related Canon nodes

- CANON-024
