# CANON-031 - avoid prop mutation

Status: Hardened

## Core idea

Do not directly change props in a child component.

Emit an event and let the parent update the state.

## Use this when

Use this in Mission 2 when TodoItem needs to toggle or remove a todo.

## Basic pattern

Child emits. Parent updates.

## Common friction

Changing parent-owned data inside a child can create confusing state flow.

## Small example

```js
const emit = defineEmits(["toggle"]);
emit("toggle", props.todo.id);
```

## Check yourself

- Does the child avoid changing props directly?
- Does the parent handle the update?

## Related Canon nodes

- CANON-030
