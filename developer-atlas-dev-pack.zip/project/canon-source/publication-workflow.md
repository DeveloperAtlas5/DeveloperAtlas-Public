# Canon Publication Workflow

## Stages

1. Candidate
2. Draft
3. Technical Review
4. Educational Review
5. AI Review
6. Engineering Review
7. Proof of Superiority
8. Gold Approved
9. Canon Published

## Gold Requirements

A node cannot become Gold without:

- Score of 95 or higher.
- Proof of superiority.
- Evidence references.
- Working examples.
- Decision guidance.
- AI notes.
- Related graph links.

## Publication Rule

Canon is published from structured source files. Write once, generate everywhere.

