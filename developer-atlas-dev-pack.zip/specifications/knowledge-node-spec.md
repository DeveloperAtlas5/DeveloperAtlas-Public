# Knowledge Node Specification

Knowledge Nodes are the canonical source of Developer Atlas knowledge.

## Purpose

A Knowledge Node captures one reusable unit of developer knowledge for human learning, AI reasoning, AI teaching, code generation, troubleshooting, recommendations, graph traversal, and future product surfaces.

## Required Identity

- `id`: Stable dotted id.
- `slug`: Stable path-like slug.
- `title`: Human-readable label.
- `technology`: Primary technology.
- `category`: Primary category.
- `type`: Node type.

## Required Learning Metadata

- `difficulty`
- `importance`
- `frequency`
- `summary`
- `syntax`
- `examples`
- `related`
- `tags`
- `last_reviewed`
- `atlas_version`

## Recommendation Metadata

Every node should support future recommendation systems:

- `recommended_for`
- `avoid_for`
- `best_alternative`
- `tradeoffs`
- `industry_usage`
- `beginner_score`
- `professional_score`
- `interview_score`
- `production_score`
- `learning_priority`

## Evidence Metadata

- `confidence`
- `evidence_level`
- `sources`

Evidence levels: `official`, `specification`, `industry_standard`, `context_dependent`, `opinion`, `deprecated`.

## Enrichment Metadata

Important enrichment fields include:

- `problem`
- `solution`
- `when_to_use`
- `when_not_to_use`
- `common_mistakes`
- `best_practices`
- `alternatives`
- `ai_notes`
- `teaching_notes`
- `code_generation_notes`
- `troubleshooting_notes`

## Rule

Knowledge exists once in canonical nodes. Generated outputs, Brain packs, Kernel outputs, reports, and future products reference nodes instead of duplicating node knowledge.
