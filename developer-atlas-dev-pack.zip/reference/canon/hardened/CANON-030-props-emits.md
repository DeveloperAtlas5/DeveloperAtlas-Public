# CANON-030 - props + emits

Status: Hardened

## Core idea

Props go down. Events go up.

Parent owns shared state. Child asks for changes.

## Use this when

Use this in Mission 2 when TodoItem displays one todo and asks App.vue to update it.

## Basic pattern

Pass data as props. Emit events for changes.

## Common friction

Keep shared state in the parent for the current Rookie path.

## Small example

```vue
<TodoItem :todo="todo" @toggle="toggleTodo(todo.id)" />
```

## Check yourself

- Does the parent own the todo list?
- Does the child emit instead of updating shared state?

## Related Canon nodes

- CANON-031
- CANON-029
