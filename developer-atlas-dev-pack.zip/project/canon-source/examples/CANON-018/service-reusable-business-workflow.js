const assert = require("node:assert/strict");
const { classifyEndpoint, shouldAvoidService } = require("./architecture-rules");

module.exports = function runServiceReusableBusinessWorkflowExample() {
  const endpoint = {
    validationRules: 5,
    hasAuthorization: true,
    hasCustomMessages: false,
    routeAwareValidation: true,
    reusedWorkflow: true,
    modelOperations: 3,
    needsTransaction: true,
    hasExternalSideEffects: true,
    usedOutsideHttp: true
  };

  assert.deepEqual(classifyEndpoint(endpoint), ["controller", "form_request", "service"]);
  assert.equal(shouldAvoidService(endpoint), false);
};
