const { applyVIf, applyVShow, createElement } = require("./directive-sim");

module.exports = function runMistakeVShowExpensiveInitialRender() {
  const hiddenChartWithVShow = createElement("RevenueForecastChart", 100);
  const hiddenChartWithVIf = createElement("RevenueForecastChart", 100);

  applyVShow(hiddenChartWithVShow, false);
  applyVIf(hiddenChartWithVIf, false);

  const vShowInitialCost = hiddenChartWithVShow.mounted ? hiddenChartWithVShow.cost : 0;
  const vIfInitialCost = hiddenChartWithVIf.mounted ? hiddenChartWithVIf.cost : 0;

  if (vShowInitialCost !== 100) {
    throw new Error(`Expected v-show hidden expensive chart to pay cost 100, got ${vShowInitialCost}`);
  }

  if (vIfInitialCost !== 0) {
    throw new Error(`Expected v-if hidden expensive chart to pay cost 0, got ${vIfInitialCost}`);
  }
};
