# CANON-019 Proof Of Superiority

Canon ID: CANON-019
Node ID: canon.sql.command.inner-join-vs-left-join
Title: SQL INNER JOIN vs LEFT JOIN

## What Official Docs Explain Well

PostgreSQL, MySQL, and SQLite documentation explain joined tables, join syntax, join constraints, and SQL query behavior.

## What Developers Still Struggle With

Developers often remember the keywords but fail to predict result shape:

- `INNER JOIN` removes unmatched rows.
- `LEFT JOIN` preserves left-side rows with `NULL` right-side columns.
- A right-table filter in `WHERE` after `LEFT JOIN` can remove preserved rows.
- One-to-many joins create duplicate-looking parent rows.
- AI-generated SQL can pick a join type without knowing whether missing related rows should remain.

These mistakes create missing reports, inflated counts, misleading dashboards, and hard-to-debug data issues.

## How Atlas Improves The Explanation

Atlas frames the topic as a row-preservation decision:

- Use `INNER JOIN` when only matches belong in the answer.
- Use `LEFT JOIN` when every left-side row must remain visible.
- Debug missing rows by checking join type and right-table filters.
- Debug duplicate rows by checking relationship cardinality.

## What Decision Support Atlas Adds

The node asks which table defines the main list, whether unmatched rows should survive, whether one-to-many relationships can multiply rows, and whether filters belong in `ON`, `WHERE`, or an aggregate/subquery.

## What Production Guidance Atlas Adds

The node includes practical users/orders examples, zero-activity reports, missing-relationship queries, optional paid-order filters, row-count debugging, duplicate-row debugging, and performance notes around indexes and cardinality.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants direct SQL generation rules:

- Ask whether unmatched left rows should remain.
- Generate `INNER JOIN` only when missing related rows should be excluded.
- Generate `LEFT JOIN` for preserve-left reports.
- Put optional right-table filters in `ON` when left rows must survive.
- Warn about one-to-many duplication and suggest aggregation or `EXISTS`.

## Why This Deserves Gold Candidate Status

CANON-019 deserves Gold Candidate status because it turns a common SQL syntax choice into a practical row-preservation model with official evidence, deterministic examples, missing-row debugging, duplicate-row debugging, and AI generation guardrails. It still needs named reviewer sign-off before final Gold approval.
