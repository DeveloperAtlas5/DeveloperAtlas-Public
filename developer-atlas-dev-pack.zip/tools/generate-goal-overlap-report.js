const fs = require("fs");
const path = require("path");
const {
  goalsOutputDir,
  ensureGoalsOutputDirs,
  readGoals,
  countValues
} = require("./goal-utils");

function main() {
  const goals = readGoals().map((record) => record.goal);
  const report = buildReport(goals);

  ensureGoalsOutputDirs();
  fs.writeFileSync(
    path.join(goalsOutputDir, "goal-overlap-report.json"),
    `${JSON.stringify(report, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(goalsOutputDir, "goal-overlap-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/goals/goal-overlap-report.json for ${goals.length} goal(s).`);
  console.log("Generated output/goals/goal-overlap-report.md.");
}

function buildReport(goals) {
  const overlappingKnowledge = countField(goals, "required_knowledge_nodes");
  const overlappingCanon = countField(goals, "recommended_canon_nodes");
  const overlappingTools = countField(goals, "required_tools", "recommended_tools");
  const overlappingFriction = countField(goals, "common_friction_nodes");
  const hardwareConsiderations = countField(goals, "hardware_considerations");
  const strongest = strongestOverlap([
    ...tagItems(overlappingKnowledge, "knowledge"),
    ...tagItems(overlappingCanon, "canon"),
    ...tagItems(overlappingTools, "tool"),
    ...tagItems(overlappingFriction, "friction"),
    ...tagItems(hardwareConsiderations, "hardware")
  ]);

  return {
    goals_processed: goals.length,
    strongest_overlap: strongest,
    overlapping_knowledge_nodes: overlappingKnowledge,
    overlapping_canon_nodes: overlappingCanon,
    overlapping_tools: overlappingTools,
    overlapping_friction_nodes: overlappingFriction,
    hardware_considerations: hardwareConsiderations
  };
}

function countField(goals, ...fields) {
  const values = goals.flatMap((goal) => fields.flatMap((field) => goal[field] || []));
  return countValues(values).filter((item) => item.count > 1);
}

function tagItems(items, type) {
  return items.map((item) => ({ ...item, type }));
}

function strongestOverlap(items) {
  return items.sort((a, b) => b.count - a.count || a.value.localeCompare(b.value))[0] || null;
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Goal Overlap Report",
    "",
    `Goals processed: ${report.goals_processed}`,
    "",
    "## Strongest Overlap",
    "",
    report.strongest_overlap
      ? `- ${report.strongest_overlap.value} (${report.strongest_overlap.type}): ${report.strongest_overlap.count} goals`
      : "- None",
    "",
    "## Overlapping Knowledge Nodes",
    "",
    ...formatCounts(report.overlapping_knowledge_nodes),
    "",
    "## Overlapping Canon Nodes",
    "",
    ...formatCounts(report.overlapping_canon_nodes),
    "",
    "## Overlapping Tools",
    "",
    ...formatCounts(report.overlapping_tools),
    "",
    "## Overlapping Friction Nodes",
    "",
    ...formatCounts(report.overlapping_friction_nodes),
    "",
    "## Hardware Considerations",
    "",
    ...formatCounts(report.hardware_considerations)
  ];

  return `${lines.join("\n")}\n`;
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

main();

