const { validate } = require("./validation-simulator");

class StoreProductRequest {
  constructor(user, payload) {
    this.user = user;
    this.payload = payload;
  }

  authorize() {
    return this.user.permissions.includes("products:create");
  }

  rules() {
    return {
      name: ["required"],
      sku: ["required"],
      status: ["required", { in: ["draft", "active"] }]
    };
  }

  validated() {
    if (!this.authorize()) {
      throw new Error("unauthorized");
    }

    const result = validate(this.payload, this.rules());

    if (!result.passes) {
      throw new Error("validation failed");
    }

    return result.validated;
  }
}

module.exports = function runFormRequestStyleValidationStructure() {
  const request = new StoreProductRequest(
    { permissions: ["products:create"] },
    { name: "Keyboard", sku: "KB-01", status: "active", ignored: "raw input" }
  );

  const validated = request.validated();

  if (validated.ignored !== undefined || validated.status !== "active") {
    throw new Error("Form Request-style validation should return only validated fields.");
  }

  const unauthorized = new StoreProductRequest(
    { permissions: [] },
    { name: "Keyboard", sku: "KB-01", status: "active" }
  );

  let blocked = false;

  try {
    unauthorized.validated();
  } catch (error) {
    blocked = error.message === "unauthorized";
  }

  if (!blocked) {
    throw new Error("Form Request-style authorize() should block unauthorized users.");
  }

  return validated;
};
