const fs = require("fs");
const path = require("path");
const {
  readCanonIndex,
  ensureLearningOutputDir,
  learningOutputDir,
  getSkillArea,
  getLearning,
  unique
} = require("./learning-utils");

const skillOrder = [
  "JavaScript Arrays",
  "JavaScript Async",
  "Vue Reactivity",
  "Vue Directives",
  "CSS Layout",
  "SQL Fundamentals"
];

function main() {
  const entries = readCanonIndex().entries || [];
  const grouped = new Map(skillOrder.map((skill) => [skill, []]));
  for (const entry of entries) {
    const skill = getSkillArea(entry);
    if (!grouped.has(skill)) grouped.set(skill, []);
    grouped.get(skill).push(entry);
  }

  const skills = [...grouped.entries()]
    .filter(([, items]) => items.length)
    .map(([skill_area, items]) => ({
      skill_area,
      nodes: items.map((entry) => entry.canon_id),
      prerequisites: unique(items.flatMap((entry) => getLearning(entry).prerequisites || [])),
      unlocks: unique(items.flatMap((entry) => getLearning(entry).unlocks || [])),
      estimated_learning_minutes: items.reduce((sum, entry) => sum + Number(getLearning(entry).estimated_learning_minutes || 0), 0),
      estimated_practice_minutes: items.reduce((sum, entry) => sum + Number(getLearning(entry).estimated_practice_minutes || 0), 0),
      mastery_criteria: unique(items.flatMap((entry) => getLearning(entry).mastery_criteria || []))
    }));

  const output = {
    generated_at: new Date().toISOString(),
    skills
  };

  ensureLearningOutputDir();
  fs.writeFileSync(path.join(learningOutputDir, "skill-tree.json"), `${JSON.stringify(output, null, 2)}\n`);
  console.log(`Generated output/learning/skill-tree.json with ${skills.length} skill areas.`);
}

main();

