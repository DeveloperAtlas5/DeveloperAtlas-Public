const fs = require("fs");
const path = require("path");
const {
  readEntries,
  compareEntries,
  escapeTableCell,
  slugifyHeading,
  rootDir
} = require("./content-utils");

const outputDir = path.join(rootDir, "output", "cheatsheets");
const outputPath = path.join(outputDir, "pocket-guide.md");

function addCompactTable(lines, entries) {
  lines.push("| Technology | Category | Title | Summary | Syntax |");
  lines.push("|---|---|---|---|---|");

  for (const entry of entries) {
    const data = entry.frontMatter;
    lines.push(
      `| ${escapeTableCell(data.technology)} | ${escapeTableCell(data.category)} | ${escapeTableCell(data.title)} | ${escapeTableCell(data.summary)} | \`${escapeTableCell(data.syntax)}\` |`
    );
  }
}

function main() {
  const entries = readEntries().sort(compareEntries);
  const technologies = [...new Set(entries.map((entry) => entry.frontMatter.technology))].sort();
  const mostUsed = entries.filter((entry) => entry.frontMatter.frequency === 5).sort(compareEntries);

  const lines = [
    "# Developer Atlas Pocket Guide",
    "",
    "## Table of Contents"
  ];

  for (const technology of technologies) {
    lines.push(`- [${technology}](#${slugifyHeading(technology)})`);
  }

  lines.push("", "## Most Used Daily", "");
  addCompactTable(lines, mostUsed);

  for (const technology of technologies) {
    const technologyEntries = entries.filter((entry) => entry.frontMatter.technology === technology);
    lines.push("", `## ${technology}`, "");
    addCompactTable(lines, technologyEntries);
  }

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${lines.join("\n")}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)} with ${entries.length} entries.`);
}

main();
