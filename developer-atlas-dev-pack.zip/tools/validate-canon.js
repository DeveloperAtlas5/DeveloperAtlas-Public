const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const indexPath = path.join(rootDir, "canon", "canon-index.json");
const requiredSections = [
  "Status Metadata",
  "Summary",
  "What Problem This Solves",
  "Mental Model",
  "Beginner Explanation",
  "Professional Explanation",
  "Syntax",
  "Decision Guide",
  "Comparison Table",
  "Alternatives",
  "Production Examples",
  "Common Mistakes",
  "Debugging Checklist",
  "Mechanical Verification",
  "Performance Notes",
  "AI Coding Guidance",
  "Teaching Notes",
  "Interview Questions",
  "Exercises",
  "Related Atlas Nodes",
  "Evidence And Sources",
  "Proof Of Superiority Summary",
  "Scorecard Placeholder"
];
const sectionGroups = [
  ["When To Use map()", "When To Use The Primary Option"],
  ["When To Use forEach()", "When To Use The Alternative"],
  ["When Not To Use Either", "When Not To Use This Decision"]
];
const phase93CandidateIds = [
  "CANON-CANDIDATE-JS-001",
  "CANON-CANDIDATE-JS-002",
  "CANON-CANDIDATE-JS-003",
  "CANON-CANDIDATE-JS-004",
  "CANON-CANDIDATE-JS-005",
  "CANON-CANDIDATE-VUE-001",
  "CANON-CANDIDATE-VUE-002",
  "CANON-CANDIDATE-VUE-003",
  "CANON-CANDIDATE-VUE-004",
  "CANON-CANDIDATE-VUE-005",
  "CANON-CANDIDATE-VUE-006",
  "CANON-CANDIDATE-VUE-007",
  "CANON-CANDIDATE-BROWSER-001",
  "CANON-CANDIDATE-BROWSER-002",
  "CANON-CANDIDATE-BROWSER-003",
  "CANON-CANDIDATE-TOOLING-001",
  "CANON-CANDIDATE-TOOLING-002",
  "CANON-CANDIDATE-TOOLING-003",
  "CANON-CANDIDATE-AI-001",
  "CANON-CANDIDATE-AI-002"
];

function main() {
  const errors = [];
  const warnings = [];
  const index = readIndex(errors);
  const entries = index?.entries || [];
  const canonIds = new Set();
  const nodeIds = new Set();
  const statusCounts = {};

  for (const entry of entries) {
    statusCounts[entry.status] = (statusCounts[entry.status] || 0) + 1;
    validateUnique(entry.canon_id, canonIds, "Canon ID", errors);
    validateUnique(entry.node_id, nodeIds, "node ID", errors);
    validateScore(entry, errors);
    validateScorecard(entry, errors);
    validateNodeFile(entry, errors);
    validateGoldRules(entry, errors);
    validateCandidateSignals(entry, warnings);
  }

  validatePhase93CandidateBacklog(entries, statusCounts, errors);

  console.log("Atlas Canon validation");
  console.log(`Canon entries: ${entries.length}`);
  console.log("Canon status counts:");
  for (const [status, count] of Object.entries(statusCounts).sort()) {
    console.log(`  - ${status}: ${count}`);
  }
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validatePhase93CandidateBacklog(entries, statusCounts, errors) {
  const byId = new Map(entries.map((entry) => [entry.canon_id, entry]));
  const expectedGoldCandidates = 22;
  const expectedCandidates = 28;

  if (statusCounts.gold_candidate !== expectedGoldCandidates) {
    errors.push(`Phase 93: expected ${expectedGoldCandidates} existing gold_candidate entries, got ${statusCounts.gold_candidate || 0}`);
  }
  if (statusCounts.candidate !== expectedCandidates) {
    errors.push(`Phase 93: expected ${expectedCandidates} candidate entries after backlog expansion, got ${statusCounts.candidate || 0}`);
  }

  for (const canonId of phase93CandidateIds) {
    const entry = byId.get(canonId);
    if (!entry) {
      errors.push(`Phase 93: missing candidate backlog entry ${canonId}`);
      continue;
    }
    if (entry.status !== "candidate") {
      errors.push(`Phase 93: ${canonId} must remain status candidate, got ${entry.status}`);
    }
    if (entry.status === "gold_candidate" || entry.status === "gold") {
      errors.push(`Phase 93: ${canonId} must not be marked ${entry.status}`);
    }
    if (entry.score > 60) {
      errors.push(`Phase 93: ${canonId} candidate score must stay <= 60`);
    }
    if (!entry.source_node_path) {
      errors.push(`Phase 93: ${canonId} missing source_node_path`);
      continue;
    }
    validatePhase93CandidateContent(entry, errors);
  }
}

function validatePhase93CandidateContent(entry, errors) {
  const sourcePath = path.join(rootDir, entry.source_node_path);
  if (!fs.existsSync(sourcePath)) return;

  const markdown = fs.readFileSync(sourcePath, "utf8");
  const requiredSignals = [
    [/^# .+/m, "title"],
    [/Status: candidate/i, "candidate status"],
    [/## Beginner Explanation[\s\S]+?## Professional Explanation/i, "plain-language explanation"],
    [/## When To Use The Primary Option[\s\S]+?## When To Use The Alternative/i, "when to use"],
    [/## When Not To Use This Decision[\s\S]+?## Alternatives/i, "when not to use"],
    [/## Common Mistakes[\s\S]+?## Debugging Checklist/i, "common mistakes"],
    [/### Beginner Example[\s\S]+?### Review Example/i, "beginner example"],
    [/## AI Coding Guidance[\s\S]+?## Teaching Notes/i, "AI collaboration note"],
    [/## Debugging Checklist[\s\S]+?## Mechanical Verification/i, "recovery/debugging note"],
    [/## Exercises[\s\S]+?### Beginner[\s\S]+?### Junior/i, "practice task"],
    [/## Related Atlas Nodes[\s\S]+?## Evidence And Sources/i, "related concepts"]
  ];

  for (const [pattern, label] of requiredSignals) {
    if (!pattern.test(markdown)) {
      errors.push(`Phase 93: ${entry.canon_id} missing ${label}`);
    }
  }
}

function readIndex(errors) {
  try {
    return JSON.parse(fs.readFileSync(indexPath, "utf8"));
  } catch (error) {
    errors.push(`canon/canon-index.json: invalid JSON (${error.message})`);
    return null;
  }
}

function validateUnique(value, seen, label, errors) {
  if (!value) {
    errors.push(`missing ${label}`);
    return;
  }
  if (seen.has(value)) errors.push(`duplicate ${label}: ${value}`);
  seen.add(value);
}

function validateScore(entry, errors) {
  if (!Number.isInteger(entry.score) || entry.score < 0 || entry.score > 100) {
    errors.push(`${entry.canon_id}: score must be an integer from 0 to 100`);
  }
}

function validateScorecard(entry, errors) {
  const scorecardPath = path.join(rootDir, "canon", "scorecards", `${entry.canon_id}-scorecard.json`);
  if (!fs.existsSync(scorecardPath)) {
    errors.push(`${entry.canon_id}: scorecard file is missing`);
    return;
  }

  let scorecard;
  try {
    scorecard = JSON.parse(fs.readFileSync(scorecardPath, "utf8"));
  } catch (error) {
    errors.push(`${entry.canon_id}: invalid scorecard JSON (${error.message})`);
    return;
  }

  const weightTotal = sumObjectValues(scorecard.weights);
  if (weightTotal !== 100) errors.push(`${entry.canon_id}: scorecard weights must total 100, got ${weightTotal}`);

  const categoryScoreTotal = scorecard.category_scores
    ? sumObjectValues(scorecard.category_scores)
    : scorecard.score;
  if (categoryScoreTotal !== scorecard.score) {
    errors.push(`${entry.canon_id}: scorecard score ${scorecard.score} does not match category total ${categoryScoreTotal}`);
  }
  if (entry.score !== scorecard.score) {
    errors.push(`${entry.canon_id}: indexed score ${entry.score} does not match scorecard total ${scorecard.score}`);
  }

  if (scorecard.canon_id !== entry.canon_id) errors.push(`${entry.canon_id}: scorecard canon_id mismatch`);
  if (scorecard.node_id !== entry.node_id) errors.push(`${entry.canon_id}: scorecard node_id mismatch`);
}

function validateNodeFile(entry, errors) {
  if (!entry.source_node_path) {
    errors.push(`${entry.canon_id}: missing source_node_path`);
    return;
  }

  const sourcePath = path.join(rootDir, entry.source_node_path);
  if (!fs.existsSync(sourcePath)) {
    errors.push(`${entry.canon_id}: missing Canon node file ${entry.source_node_path}`);
    return;
  }

  const markdown = fs.readFileSync(sourcePath, "utf8");
  for (const section of requiredSections) {
    const pattern = new RegExp(`^## ${escapeRegExp(section)}\\s*$`, "m");
    if (!pattern.test(markdown)) errors.push(`${entry.canon_id}: missing required section "${section}"`);
  }
  for (const group of sectionGroups) {
    if (!group.some((section) => new RegExp(`^## ${escapeRegExp(section)}\\s*$`, "m").test(markdown))) {
      errors.push(`${entry.canon_id}: missing one required section from group "${group.join(" | ")}"`);
    }
  }
}

function validateGoldRules(entry, errors) {
  const goldCandidateStatuses = new Set(["gold_candidate", "gold", "gold_approved", "canon_published"]);
  const goldStatuses = new Set(["gold", "gold_approved", "canon_published"]);
  if (goldCandidateStatuses.has(entry.status) && entry.score < 95) {
    errors.push(`${entry.canon_id}: ${entry.status} status requires score >= 95`);
  }
  if (!goldStatuses.has(entry.status)) return;

  if (entry.score < 95) errors.push(`${entry.canon_id}: Gold status requires score >= 95`);
  if (!entry.proof_of_superiority_path || !fs.existsSync(path.join(rootDir, entry.proof_of_superiority_path))) {
    errors.push(`${entry.canon_id}: Gold status requires proof of superiority file`);
  }
}

function validateCandidateSignals(entry, warnings) {
  if (!entry.proof_of_superiority_path || !fs.existsSync(path.join(rootDir, entry.proof_of_superiority_path))) {
    warnings.push(`${entry.canon_id}: proof of superiority file is missing`);
  }
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function sumObjectValues(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return 0;
  return Object.values(value).reduce((sum, item) => sum + Number(item || 0), 0);
}

main();
