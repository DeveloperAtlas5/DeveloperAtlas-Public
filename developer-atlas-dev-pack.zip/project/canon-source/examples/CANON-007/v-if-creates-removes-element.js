const { applyVIf, createElement } = require("./directive-sim");

module.exports = function runVIfCreatesRemovesElement() {
  const panel = createElement("AdminPanel");

  applyVIf(panel, false);
  if (panel.mounted) throw new Error("Expected v-if false to leave panel unmounted");

  applyVIf(panel, true);
  if (!panel.mounted || panel.mountCount !== 1) {
    throw new Error("Expected v-if true to create panel once");
  }

  applyVIf(panel, false);
  if (panel.mounted || panel.destroyCount !== 1) {
    throw new Error("Expected v-if false to remove panel once");
  }
};
