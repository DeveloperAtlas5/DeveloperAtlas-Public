# Start a Vue Project

## What this is for

Use this when you want to start or open a Vue app.

## What you need first

You need Node.js installed before creating or running most Vue projects.

## Required tools

- Node.js
- npm
- A browser
- VS Code or another text editor

## Recommended extensions

- Vue - Official

## Start from zero

- Create a Vite Vue project with `npm create vite@latest`.
- Choose Vue when the tool asks for a framework.
- Open the new project folder in VS Code.
- Run `npm install`.
- Run `npm run dev`.

## Open an existing project

- Open the Vue project folder in VS Code.
- Look for `package.json` to confirm you opened the project root.
- Run `npm install` if dependencies are not installed yet.

## Run or preview the project

- Run `npm run dev` in the project folder.
- Open the local browser link shown in the terminal.
- Keep the terminal running while you work.

## Where you usually code

- Start with `src/App.vue` in a small Vue project.
- Components usually live in `src/components/`.
- Styles may live inside `.vue` files or separate CSS files.

## Common first problems

- `npm` is not recognized: install Node.js and reopen the terminal.
- `npm run dev` cannot find a script: check that the terminal is in the project folder.
- The browser link does not open: copy the local URL from the terminal into your browser.

## Next Atlas step

After the Vue app runs, continue with Mission 1 or use the Concept Library for Vue words.
