const assert = require("node:assert/strict");
const { leftJoinUsersOrders } = require("./data");

module.exports = function runMistakeLeftJoinFilteredInWhereExample() {
  const leftJoinThenWherePaid = leftJoinUsersOrders().filter((row) => row.order && row.order.status === "paid");
  const leftJoinWithPaidFilterInOn = leftJoinUsersOrders((order) => order.status === "paid");

  const whereEmails = [...new Set(leftJoinThenWherePaid.map((row) => row.user.email))];
  const onEmails = [...new Set(leftJoinWithPaidFilterInOn.map((row) => row.user.email))];
  const linusRow = leftJoinWithPaidFilterInOn.find((row) => row.user.email === "linus@example.com");

  assert.deepEqual(whereEmails, ["ada@example.com", "grace@example.com"]);
  assert.deepEqual(onEmails, ["ada@example.com", "grace@example.com", "linus@example.com"]);
  assert.equal(linusRow.order, null);
};
