const fs = require("fs");
const path = require("path");
const { readFrictionNodes } = require("./friction-utils");
const { readTools, readSetupProfiles } = require("./toolkit-utils");
const {
  recoveryAdvisorOutputDir,
  ensureRecoveryAdvisorOutputDir,
  readRecoveryRequests
} = require("./recovery-advisor-utils");

function main() {
  const requests = readRecoveryRequests().map((record) => record.request);
  const frictionNodes = readFrictionNodes().map((record) => record.node);
  const tools = readTools().map((record) => record.data);
  const setupProfiles = readSetupProfiles().map((record) => record.data);
  const adviceRecords = [];

  ensureRecoveryAdvisorOutputDir();

  for (const request of requests) {
    const advice = buildAdvice(request, frictionNodes, tools, setupProfiles);
    adviceRecords.push(advice);

    fs.writeFileSync(
      path.join(recoveryAdvisorOutputDir, `${request.request_id}.json`),
      `${JSON.stringify(advice, null, 2)}\n`
    );
    fs.writeFileSync(
      path.join(recoveryAdvisorOutputDir, `${request.request_id}.md`),
      toAdviceMarkdown(advice)
    );
  }

  fs.writeFileSync(
    path.join(recoveryAdvisorOutputDir, "recovery-advisor-report.md"),
    toReport(adviceRecords)
  );

  console.log(`Generated recovery advice for ${adviceRecords.length} request(s).`);
  console.log("Generated output/recovery-advisor/recovery-advisor-report.md.");
}

function buildAdvice(request, frictionNodes, tools, setupProfiles) {
  const matched = chooseFrictionNode(request, frictionNodes);
  const relatedTools = tools
    .filter((tool) => tool.related_friction_nodes.includes(matched.id))
    .sort((a, b) => b.friction_reduction_score - a.friction_reduction_score || a.name.localeCompare(b.name))
    .map((tool) => ({
      id: tool.id,
      name: tool.name,
      category: tool.category,
      friction_reduction_score: tool.friction_reduction_score,
      verification_steps: tool.verification_steps
    }));
  const relatedSetupProfile = chooseSetupProfile(request, matched, setupProfiles);

  return {
    request_id: request.request_id,
    symptom: request.symptom,
    matched_friction_node: {
      id: matched.id,
      title: matched.title,
      category: matched.category,
      friction_score: matched.friction_score
    },
    likely_causes_ranked: rankCauses(request, matched),
    diagnostic_steps: matched.diagnostic_steps,
    safest_first_fix: matched.fixes[0],
    alternative_fixes: matched.fixes.slice(1),
    verification_steps: matched.verification_steps,
    prevention_notes: matched.prevention,
    related_tools: relatedTools,
    related_setup_profile: relatedSetupProfile,
    estimated_recovery_time: estimateRecoveryTime(request, matched),
    beginner_reassurance: beginnerReassurance(request, matched),
    professional_shortcut: professionalShortcut(request, matched),
    when_to_stop_and_ask_for_help: stopRules(request, matched)
  };
}

function chooseFrictionNode(request, frictionNodes) {
  return [...frictionNodes]
    .map((node) => ({ node, score: scoreFrictionNode(request, node) }))
    .sort((a, b) => b.score - a.score || a.node.id.localeCompare(b.node.id))[0].node;
}

function scoreFrictionNode(request, node) {
  const haystack = [
    node.title,
    node.category,
    ...node.symptoms,
    ...node.likely_causes,
    ...node.affected_tools
  ].join(" ").toLowerCase();
  const requestText = [
    request.symptom,
    request.error_message,
    request.current_step,
    ...request.stack,
    ...request.known_tools,
    ...request.recent_changes
  ].join(" ").toLowerCase();

  let score = 0;
  if (requestText.includes("npm install") && node.id.includes("npm.install_fails")) score += 60;
  if (requestText.includes("npm run dev") && node.id.includes("vite.not_starting")) score += 60;
  if (requestText.includes("composer") && requestText.includes("not recognized") && node.id.includes("composer.not_recognized")) score += 60;
  if (requestText.includes("artisan") && node.id.includes("artisan_missing")) score += 60;

  for (const token of importantTokens(requestText)) {
    if (haystack.includes(token)) score += token.length > 5 ? 8 : 4;
  }

  if (node.affected_os.some((os) => os.toLowerCase() === request.operating_system.toLowerCase())) score += 20;
  for (const item of request.stack) {
    if (node.affected_tools.some((tool) => tool.toLowerCase().includes(item.toLowerCase()))) score += 10;
  }

  return score;
}

function rankCauses(request, node) {
  const requestText = [
    request.symptom,
    request.error_message,
    request.current_step,
    ...request.recent_changes
  ].join(" ").toLowerCase();

  return node.likely_causes
    .map((cause) => ({
      cause,
      rank_score: importantTokens(cause.toLowerCase()).reduce((sum, token) => sum + (requestText.includes(token) ? 1 : 0), 0)
    }))
    .sort((a, b) => b.rank_score - a.rank_score || a.cause.localeCompare(b.cause))
    .map((item, index) => ({
      rank: index + 1,
      cause: item.cause
    }));
}

function chooseSetupProfile(request, matched, setupProfiles) {
  const scored = setupProfiles
    .map((profile) => {
      let score = 0;
      if (profile.operating_system.toLowerCase().includes(request.operating_system.toLowerCase())) score += 20;
      for (const item of request.stack) {
        if (profile.stack.some((profileItem) => profileItem.toLowerCase() === item.toLowerCase())) score += 8;
      }
      if (profile.common_friction_nodes.includes(matched.id)) score += 30;
      return { profile, score };
    })
    .sort((a, b) => b.score - a.score || a.profile.profile_id.localeCompare(b.profile.profile_id));

  return scored[0]?.profile.profile_id || "none";
}

function estimateRecoveryTime(request, node) {
  const availablePressure = request.available_minutes < node.estimated_recovery_time ? 5 : 0;
  return Math.max(5, node.estimated_recovery_time + availablePressure);
}

function beginnerReassurance(request, node) {
  const notes = [
    "This is a setup or toolchain blocker, not a sign that you cannot code.",
    "Follow the diagnostic steps in order and verify after each fix."
  ];

  if (/beginner/i.test(request.learner_level)) {
    notes.push(`The matched blocker is common: ${node.title}.`);
  }

  return notes;
}

function professionalShortcut(request, node) {
  return [
    `Jump to: ${node.diagnostic_steps[0]}`,
    `Then apply: ${node.fixes[0]}`,
    "If verification fails, move to the next likely cause rather than repeating the same fix."
  ];
}

function stopRules(request, node) {
  return [
    `Stop after ${Math.max(request.available_minutes, node.estimated_recovery_time)} minutes if no verification step passes.`,
    "Ask for help if the error message changes into a new unknown error.",
    "Ask for help before deleting project files, changing global permissions, or reinstalling major toolchains."
  ];
}

function importantTokens(text) {
  return [...new Set(String(text)
    .toLowerCase()
    .split(/[^a-z0-9._-]+/)
    .filter((token) => token.length >= 3)
    .filter((token) => !["the", "and", "for", "with", "from", "this", "that", "run", "running"].includes(token)))];
}

function toAdviceMarkdown(advice) {
  const lines = [
    `# Recovery Advice: ${advice.request_id}`,
    "",
    `Symptom: ${advice.symptom}`,
    `Matched friction node: ${advice.matched_friction_node.id} (${advice.matched_friction_node.title})`,
    `Estimated recovery time: ${advice.estimated_recovery_time} minutes`,
    `Related setup profile: ${advice.related_setup_profile}`,
    "",
    "## Likely Causes Ranked",
    "",
    ...advice.likely_causes_ranked.map((item) => `${item.rank}. ${item.cause}`),
    "",
    "## Diagnostic Steps",
    "",
    ...advice.diagnostic_steps.map((step, index) => `${index + 1}. ${step}`),
    "",
    "## Safest First Fix",
    "",
    `- ${advice.safest_first_fix}`,
    "",
    "## Alternative Fixes",
    "",
    ...formatList(advice.alternative_fixes),
    "",
    "## Verification Steps",
    "",
    ...advice.verification_steps.map((step) => `- [ ] ${step}`),
    "",
    "## Prevention Notes",
    "",
    ...formatList(advice.prevention_notes),
    "",
    "## Related Tools",
    "",
    ...advice.related_tools.map((tool) => `- ${tool.name} (${tool.id})`),
    "",
    "## Beginner Reassurance",
    "",
    ...formatList(advice.beginner_reassurance),
    "",
    "## Professional Shortcut",
    "",
    ...formatList(advice.professional_shortcut),
    "",
    "## When To Stop And Ask For Help",
    "",
    ...formatList(advice.when_to_stop_and_ask_for_help)
  ];

  return `${lines.join("\n")}\n`;
}

function toReport(adviceRecords) {
  const matchedCounts = countBy(adviceRecords.map((advice) => advice.matched_friction_node.id));
  const causeCounts = countBy(adviceRecords.flatMap((advice) => advice.likely_causes_ranked.slice(0, 2).map((item) => item.cause)));
  const averageRecoveryTime = adviceRecords.length
    ? adviceRecords.reduce((sum, advice) => sum + advice.estimated_recovery_time, 0) / adviceRecords.length
    : 0;

  const lines = [
    "# Recovery Advisor Report",
    "",
    `Requests processed: ${adviceRecords.length}`,
    `Average recovery time: ${averageRecoveryTime.toFixed(1)} minutes`,
    "",
    "## Matched Friction Nodes",
    "",
    ...matchedCounts.map(([id, count]) => `- ${id}: ${count}`),
    "",
    "## Top Recurring Causes",
    "",
    ...causeCounts.map(([cause, count]) => `- ${cause}: ${count}`),
    "",
    "## Generated Advice Files",
    "",
    ...adviceRecords.map((advice) => `- output/recovery-advisor/${advice.request_id}.md`)
  ];

  return `${lines.join("\n")}\n`;
}

function countBy(values) {
  const counts = new Map();
  for (const value of values) counts.set(value, (counts.get(value) || 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])));
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();
