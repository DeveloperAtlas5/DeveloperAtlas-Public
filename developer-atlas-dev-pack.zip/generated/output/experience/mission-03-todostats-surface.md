# Mission 3 - Create a TodoStats Component

## Today's Mission

Create a `TodoStats` component that shows total, completed, and remaining todos.

## Why this matters

Mission 1 made the app remember todos.

Mission 2 extracted one todo row into `TodoItem.vue`.

Mission 3 adds a focused display component. This helps the app show progress without moving state.

Components can display useful information without owning the whole app. This mission reinforces props: the parent owns the data, and the child receives the values it needs.

## Where this work happens

Work in the same Vue todo project from Missions 1 and 2.

Use this mission file as the guide.

Do not edit the Atlas package files.

## Quick Start

1. Open your Vue project.
2. Create `src/components/TodoStats.vue`.
3. Keep the todo list state in `App.vue`.
4. Calculate total, completed, and remaining todos in `App.vue`.
5. Pass those values into `TodoStats` as props.
6. Show the stats above or near the todo list.
7. Confirm the numbers update when todos change.

## Estimated time

35-50 minutes

## Difficulty

Guided

## Start here

1. Find where your todo list state lives in `App.vue`.
2. Create `src/components/TodoStats.vue`.
3. Decide which numbers to show:

   - total todos
   - completed todos
   - remaining todos

4. Calculate those numbers in `App.vue`.
5. Import `TodoStats` in `App.vue`.
6. Pass the numbers as props.
7. Check the numbers change when you add, complete, or remove todos.

## Where this change belongs

Create `src/components/TodoStats.vue` inside your Vue todo project, not inside the Atlas package.

### Tiny file map

- `src/App.vue` keeps the todo list state and calculates the stats.
- `src/components/TodoStats.vue` displays the stats it receives.

### Data flow

`App.vue` owns the todos.

`App.vue` calculates:

- total todos
- completed todos
- remaining todos

`TodoStats.vue` receives those values as props and displays them.

Remember: stats go down as props. `TodoStats.vue` does not need to change the todo list.

### Shape only example

`App.vue` can pass values into `TodoStats` like this:

```vue
<TodoStats
  :total="totalTodos"
  :completed="completedTodos"
  :remaining="remainingTodos"
/>
```

`TodoStats.vue` can receive those values like this:

```vue
<script setup>
defineProps({
  total: Number,
  completed: Number,
  remaining: Number
})
</script>
```

This is only the shape of the connection. Keep your own app names if they are different.

### Important State Boundary

The todo array/list stays in `App.vue`.

localStorage loading and saving stay in `App.vue`.

`TodoStats.vue` should not own or change the todo list.

`TodoStats.vue` should not write to localStorage.

## Check your result

You are done when:

- `TodoStats.vue` exists.
- `App.vue` imports and uses `TodoStats`.
- The app shows total todos.
- The app shows completed todos.
- The app shows remaining todos.
- The numbers update when todos change.
- Mission 1 persistence still works if it was added.
- Mission 2 `TodoItem.vue` still works if it was added.
- No browser console errors appear.

Visible win: the todo app shows total, completed, and remaining todo counts through a TodoStats component.

## Completion checklist

- [ ] I created `src/components/TodoStats.vue`.
- [ ] `App.vue` imports and uses `TodoStats`.
- [ ] `App.vue` still owns the todo list.
- [ ] `TodoStats.vue` receives numbers as props.
- [ ] Total todos display correctly.
- [ ] Completed todos display correctly.
- [ ] Remaining todos display correctly.
- [ ] The numbers update when I add, complete, or remove todos.
- [ ] Refresh persistence still works if Mission 1 added it.
- [ ] `TodoItem.vue` still works if Mission 2 added it.
- [ ] I did not add backend, routing, Pinia, database, auth, deployment, or a new architecture.

## If you get stuck

- Stats not updating: check whether the numbers are calculated from the current todo list in `App.vue`.
- Completed count looks off: check which field marks a todo as complete in your app.
- Remaining count looks off: check that remaining means total minus completed.
- Prop name mismatch: make sure the prop names in `TodoStats.vue` match the names passed from `App.vue`.
- Component not showing: confirm `TodoStats.vue` is imported and used in `App.vue`.
- Import path mismatch: check whether the path looks like `./components/TodoStats.vue` for your project.
- State moved too far: move the todo list state back to `App.vue`.
- localStorage no longer saves: confirm Mission 1 loading and saving still happen in `App.vue`.
- Mission 2 component stopped working: confirm `TodoItem.vue` still receives the todo data and emits actions as before.

### If stats do not update

Check whether the numbers are calculated from the current todo list in `App.vue`.

If the todo list changes but the numbers do not, the stats may be copied once instead of calculated from the current todos.

### If TodoStats tries to change todos

For this mission, `TodoStats.vue` only displays numbers.

Keep todo changes in `App.vue` and `TodoItem.vue`.

## Ask AI for help

Copy and paste this prompt:

```txt
I am building a Vue 3 todo app. Mission 3 is to create a TodoStats component that displays total, completed, and remaining todos. Keep the todo list state and localStorage behavior in App.vue. TodoStats.vue should receive numbers as props and only display them. Do not add Pinia, routing, backend, auth, database, deployment, a store, a composable, or a new architecture. Help me one step at a time and explain each changed file.
```

## Skip today

- Pinia
- Routing
- Backend
- Auth/login
- Database
- Deployment
- Global store
- Composable `for later`
- Chart library
- Complex analytics
- Styling overhaul
- Moving todo state into `TodoStats.vue`
- Rewriting Mission 1 or Mission 2

## Next mission preview

Next, you can practice parent-child communication more deeply by letting a child component ask the parent to update data.

## After the mission

Before you started, how confident did you feel?

1 2 3 4 5

After finishing or stopping, how confident do you feel now?

1 2 3 4 5

Did you complete the visible win?

- Yes
- Partly
- Not yet

Did recovery help?

- Yes
- I did not need recovery
- Not yet

What still feels unclear?

Write one sentence.

Would you continue to the next mission?

- Yes
- Maybe
- Not yet
