const assert = require("node:assert/strict");
const { classifyEndpoint, shouldAvoidService } = require("./architecture-rules");

module.exports = function runMistakeServiceForOneLineExample() {
  const endpoint = {
    validationRules: 2,
    hasAuthorization: false,
    hasCustomMessages: false,
    routeAwareValidation: false,
    reusedWorkflow: false,
    modelOperations: 1,
    needsTransaction: false,
    hasExternalSideEffects: false,
    usedOutsideHttp: false
  };

  const recommendations = classifyEndpoint(endpoint);

  assert.deepEqual(recommendations, ["controller"]);
  assert.equal(recommendations.includes("service"), false);
  assert.equal(shouldAvoidService(endpoint), true);
};
