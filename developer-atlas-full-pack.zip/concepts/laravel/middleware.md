# Laravel Middleware

Technology: Laravel

## Simple meaning

Middleware runs before or after a request reaches the main route action.

## Why it exists

It handles cross-cutting checks such as authentication, permissions, or request cleanup.

## Where you use it

In middleware classes and route definitions.

## When to use it

Use middleware when many routes need the same gate or request behavior.

## Tiny example

`Route::middleware('auth')->group(function () { ... });`

## Common beginner confusion

Middleware is not the page logic. It is a layer around the page or API logic.

## Related concepts

- Route
- Request
- Controller

## Similar idea in another technology

Vue navigation guards can protect frontend routes, while Laravel middleware protects server requests.
