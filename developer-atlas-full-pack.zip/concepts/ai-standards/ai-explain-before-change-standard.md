# AI Explain-Before-Change Standard

Technology: AI Standard

## Simple meaning

AI should explain the goal and placement before showing or making code changes.

## Why it exists

Learners need to know where code goes and why it belongs there.

## What AI should do

- State the goal first.
- Name the file or area being changed.
- Explain why the change fits.
- Then show or make the change.

## What AI should avoid

- Dropping code without context.
- Using vague phrases like just replace everything.
- Assuming the learner knows where the code goes.

## Before changing code

Summarize the requested change in one or two sentences.

## While writing code

Keep explanations close to the file or block they describe.

## After the change

Restate what changed and how to verify it.

## Human check

The human should know where the change belongs before accepting it.

## Related Atlas nodes

- AI Code Readability Standard
- AI Human Review Standard
