const assert = require("node:assert/strict");
const { hasDeclaration } = require("./css-rule-utils");

const badCss = `
.dashboard-cards {
  display: flex;
  flex-wrap: wrap;
}
`;

const betterCss = `
.dashboard-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(18rem, 1fr));
  gap: 1rem;
}
`;

function run() {
  assert.equal(hasDeclaration(badCss, ".dashboard-cards", "display: flex"), true);
  assert.equal(hasDeclaration(betterCss, ".dashboard-cards", "display: grid"), true);
  assert.equal(hasDeclaration(betterCss, ".dashboard-cards", "grid-template-columns: repeat(auto-fit, minmax(18rem, 1fr))"), true);

  return { badCss, betterCss };
}

module.exports = run;

if (require.main === module) run();
