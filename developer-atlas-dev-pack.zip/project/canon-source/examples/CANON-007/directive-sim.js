function createElement(name, cost = 1) {
  return {
    name,
    cost,
    mounted: false,
    mountCount: 0,
    destroyCount: 0,
    style: {
      display: ""
    },
    localState: {
      toggles: 0
    }
  };
}

function applyVIf(element, condition) {
  if (condition && !element.mounted) {
    element.mounted = true;
    element.mountCount += 1;
    element.localState = { toggles: 0 };
  }

  if (!condition && element.mounted) {
    element.mounted = false;
    element.destroyCount += 1;
    element.localState = { toggles: 0 };
  }
}

function applyVShow(element, condition) {
  if (!element.mounted) {
    element.mounted = true;
    element.mountCount += 1;
  }

  element.style.display = condition ? "" : "none";
}

module.exports = {
  createElement,
  applyVIf,
  applyVShow
};
