# Laravel Seeder

Technology: Laravel

## Simple meaning

A seeder fills the database with starting or test data.

## Why it exists

Seeders help developers create known data for local testing, demos, and repeatable setup.

## Where you use it

In `database/seeders`.

## When to use it

Use a seeder when a fresh app needs example users, roles, settings, or other starting data.

## Tiny example

`$this->call(UserSeeder::class);`

## Common beginner confusion

A seeder inserts data. A migration changes structure. A factory can help the seeder create fake records.

## Related concepts

- Factory
- Migration
- Model

## Similar idea in another technology

A frontend demo fixture can fill a page with sample data, but a Laravel seeder fills the database.
