const examples = [
  ["stable id key preserves identity", require("./stable-id-key-preserves-identity")],
  ["index key breaks identity after reorder", require("./index-key-breaks-identity-after-reorder")],
  ["acceptable index key for static list", require("./acceptable-index-key-static-list")],
  ["mistake: duplicate keys", require("./mistake-duplicate-keys")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-013 example(s).`);
