module.exports = function runMistakeFilterZeroInsteadOfFind() {
  const products = [
    { id: "p1", slug: "black-t-shirt" },
    { id: "p2", slug: "white-mug" },
    { id: "p3", slug: "white-mug" }
  ];

  const filterResult = products.filter((product) => product.slug === "white-mug")[0];
  const findResult = products.find((product) => product.slug === "white-mug");

  if (filterResult !== findResult) {
    throw new Error("Expected filter()[0] and find() to return the same first matching item");
  }

  if (findResult.id !== "p2") {
    throw new Error("Expected find() to return first matching product p2");
  }
};
