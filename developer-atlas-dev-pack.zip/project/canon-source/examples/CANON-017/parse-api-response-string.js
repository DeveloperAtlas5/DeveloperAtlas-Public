const assert = require("node:assert/strict");

module.exports = function runParseApiResponseStringExample() {
  const apiResponseText = '{"id":42,"name":"Ada","roles":["admin","editor"]}';
  const user = JSON.parse(apiResponseText);

  assert.equal(typeof apiResponseText, "string");
  assert.equal(typeof user, "object");
  assert.equal(user.name, "Ada");
  assert.deepEqual(user.roles, ["admin", "editor"]);
};
