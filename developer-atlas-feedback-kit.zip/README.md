# Developer Atlas Feedback Kit

This folder contains lightweight Markdown forms for early MVP feedback.

Use these with the shareable demo package:

- `output/share/developer-atlas-mvp-demo/`
- `output/share/developer-atlas-mvp-demo.zip`

## Suggested Review Order

1. Open the demo package landing page: `site/index.html`.
2. Read `demo/mvp-demo-pack.md`.
3. Skim `demo/demo-walkthrough.md`.
4. Review one advisor example and one context report.
5. Fill out the most relevant feedback form.

## Forms

- `tester-feedback-form.md`: general early tester feedback.
- `mentor-review-form.md`: product, positioning, and learning-value review.
- `developer-review-form.md`: practical developer usefulness review.
- `ai-context-test-form.md`: AI prompt/context usefulness review.
- `feedback-analysis-template.md`: template for summarizing responses.

The goal is structured signal, not polished prose. Short, specific answers are best.
