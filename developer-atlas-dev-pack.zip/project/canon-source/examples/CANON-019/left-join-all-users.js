const assert = require("node:assert/strict");
const { leftJoinUsersOrders } = require("./data");

module.exports = function runLeftJoinAllUsersExample() {
  const rows = leftJoinUsersOrders();
  const emails = [...new Set(rows.map((row) => row.user.email))];
  const linusRow = rows.find((row) => row.user.email === "linus@example.com");

  assert.equal(rows.length, 4);
  assert.deepEqual(emails, ["ada@example.com", "grace@example.com", "linus@example.com"]);
  assert.equal(linusRow.order, null);
};
