# Laravel validation

## Status Metadata

- Canon ID: CANON-014
- Node ID: canon.laravel.validation.validation
- Status: Gold Candidate
- Score: 95
- Version: 2026.1
- Source family: Laravel
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Use Laravel validation as the request boundary before controller logic trusts incoming data. Inline controller validation is good for small, local rules. Form Request validation is better when rules, authorization, messages, or normalization deserve a named class.

## What Problem This Solves

Laravel applications often start with scattered request checks in controllers, duplicated frontend rules, or database errors standing in for request validation. That makes behavior inconsistent and hard to test.

This node explains:

- Validation as a boundary around untrusted input.
- When `$request->validate()` is enough.
- When a Form Request is the better production shape.
- Why frontend validation, database constraints, and authorization are related but not replacements.

## Mental Model

Think of validation as the front desk for a request.

The controller should not have to guess whether `email`, `name`, or `password` are present and shaped correctly. Validation checks the request at the door and returns a trusted validated payload.

Small request, small front desk:

```php
$validated = $request->validate([
    'email' => ['required', 'email'],
]);
```

Bigger request, named front desk:

```php
public function store(StoreUserRequest $request)
{
    User::create($request->validated());
}
```

## Beginner Explanation

Laravel validation checks request data before your application uses it.

```php
$validated = $request->validate([
    'name' => ['required', 'string', 'max:255'],
    'email' => ['required', 'email'],
]);
```

If validation passes, `$validated` contains the data that matched the rules. If validation fails, Laravel handles the failure response. For normal web requests it redirects back with errors. For JSON/API-style requests, Laravel returns validation errors with a `422` response.

Beginner rule:

1. Do not trust request input directly.
2. Validate before saving.
3. Use inline validation for simple controller-local rules.
4. Use a Form Request when the rules deserve a name.

## Professional Explanation

Laravel validation is part of the request contract. It defines which fields are accepted, which shapes are valid, and what error behavior clients should expect.

Inline validation keeps small endpoints readable because the rules sit next to the action. Form Requests move validation and authorization into dedicated classes, which improves reuse, testability, custom messages, input preparation, and controller focus.

In production, validation should work with, not replace:

- Authorization policies and permissions.
- Database constraints and indexes.
- Domain invariants.
- Sanitization or normalization.
- API error response contracts.
- Tests that assert valid and invalid paths.

Good Laravel validation makes invalid input fail early and consistently. It does not prove the user is allowed to perform the action, and it does not replace uniqueness constraints at the database layer.

## Syntax

Inline controller validation:

```php
public function store(Request $request)
{
    $validated = $request->validate([
        'title' => ['required', 'string', 'max:120'],
        'body' => ['required', 'string'],
    ]);

    return Post::create($validated);
}
```

Form Request validation:

```php
class StorePostRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', Post::class);
    }

    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:120'],
            'body' => ['required', 'string'],
        ];
    }
}
```

## Decision Guide

1. Are the rules small, local, and unlikely to be reused?
   Use inline controller validation.
2. Are the rules long, reused, authorized, customized, or tested separately?
   Use a Form Request.
3. Does validation depend on route parameters or the current model?
   Prefer a Form Request or a clearly named rule object.
4. Does the field need uniqueness scoped to a tenant, account, or ignored current model?
   Write the scope explicitly.
5. Is the rule trying to enforce authorization or domain state transitions?
   Use policy/domain logic in addition to validation.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| Inline `$request->validate()` | Small controller-local request contracts | Controllers can get noisy as rules grow. |
| Form Request | Larger production forms, APIs, authorization, custom messages | Adds a class, but gives the request a reusable name. |
| Custom rule object | Complex reusable field logic | More structure than simple rules need. |
| Database constraint | Final integrity guarantee | Produces lower-level failure unless paired with validation. |
| Frontend validation | Fast user feedback | Cannot be trusted as the backend boundary. |

## When To Use The Primary Option

Use inline controller validation when the rule set is small and local.

- A simple contact form.
- A small settings update.
- A one-off endpoint with two or three fields.
- A prototype endpoint that still needs backend validation.
- A controller action where the request contract is clearer inline.

## When To Use Inline Validation

```php
public function updateDisplayName(Request $request)
{
    $validated = $request->validate([
        'display_name' => ['required', 'string', 'max:60'],
    ]);

    $request->user()->update($validated);

    return back()->with('status', 'Display name updated.');
}
```

Why inline validation fits: the rule is short, local, and easy to review in the action.

## When To Use The Alternative

Use a Form Request when validation is important enough to name.

- Create/update forms with many fields.
- API endpoints with stable contracts.
- Rules reused by multiple controller actions.
- Custom validation messages or attributes.
- Authorization tied to the request.
- Input preparation before validation.
- Tests that should target the request contract directly.

## When To Use Form Request Validation

```php
public function store(StoreProductRequest $request)
{
    Product::create($request->validated());

    return redirect()->route('products.index');
}
```

Why a Form Request fits: product creation has a named request contract that should stay out of the controller.

## When Not To Use This Decision

Do not treat validation as the only application boundary. Laravel validation checks input shape, but other layers still handle permission, persistence integrity, business rules, and output safety.

## When Not To Rely Only On Validation

Laravel validation is necessary, but it is not the whole safety model.

- Do not rely only on validation for authorization. Use policies, gates, middleware, or Form Request `authorize()`.
- Do not rely only on validation for uniqueness. Use database unique indexes too.
- Do not rely only on frontend validation. Clients can bypass it.
- Do not rely only on `nullable` when business logic requires conditional presence.
- Do not use validation to hide domain invariants that belong in models, services, or actions.
- Do not assume validation sanitizes all input for every output context.

## Alternatives

- Authorization policies for "may this user do this?"
- Database constraints for final integrity.
- Custom validation rules for reusable complex checks.
- Form Request `prepareForValidation()` for request normalization.
- DTOs or action classes for application-level command shape.
- Frontend validation for user experience, backed by server validation.

## Production Examples

### Controller Inline Validation

```php
public function store(Request $request)
{
    $validated = $request->validate([
        'name' => ['required', 'string', 'max:255'],
        'email' => ['required', 'email', 'max:255'],
    ]);

    Subscriber::create($validated);

    return response()->json(['status' => 'subscribed'], 201);
}
```

Why inline validation fits: the endpoint has a small request contract and no special authorization or custom messages.

### Form Request With Authorization And Scoped Unique Rule

```php
class StoreProjectMemberRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('manageMembers', $this->route('project'));
    }

    public function rules(): array
    {
        $projectId = $this->route('project')->id;

        return [
            'email' => [
                'required',
                'email',
                Rule::unique('project_members', 'email')
                    ->where('project_id', $projectId),
            ],
            'role' => ['required', Rule::in(['viewer', 'editor', 'admin'])],
        ];
    }
}
```

Why a Form Request fits: authorization, route-aware uniqueness, and a named request contract make the controller simpler and safer.

### API JSON Validation Behavior

```php
Route::post('/api/products', function (Request $request) {
    $validated = $request->validate([
        'sku' => ['required', 'string'],
        'price' => ['required', 'numeric', 'min:0'],
    ]);

    return Product::create($validated);
});
```

When JSON validation fails, Laravel returns validation errors with HTTP `422`, which API clients can handle predictably.

### Frontend Validation Is Not Enough

```php
// Bad: trusting a disabled button or JavaScript check is enough.
Order::create($request->all());

// Better: validate again on the server boundary.
$validated = $request->validate([
    'quantity' => ['required', 'integer', 'min:1'],
    'shipping_method' => ['required', Rule::in(['standard', 'express'])],
]);
```

Why this matters: any client can send a request that bypasses frontend checks.

## Common Mistakes

- Trusting frontend validation and saving `$request->all()`.
- Treating validation as authorization.
- Forgetting to use `$request->validated()` or the validated array.
- Using `nullable` when the field should be required in a specific scenario.
- Using `required` when `sometimes` or conditional rules are intended.
- Writing a global `unique` rule when uniqueness must be scoped to a tenant, account, or project.
- Forgetting to ignore the current model when updating unique fields.
- Duplicating large validation arrays across controllers.
- Letting controllers become unreadable instead of extracting Form Requests.

## Debugging Checklist

- Is the controller using validated data or raw `$request->all()`?
- Does the failing request expect redirect errors or JSON `422` errors?
- Is the request sending the right `Accept` header for API behavior?
- Are nullable and required rules describing the real contract?
- Does the unique rule need tenant/account/project scope?
- Does an update route need to ignore the current model in a unique rule?
- Is authorization happening separately from validation?
- Would a Form Request make the contract easier to test?

## Mechanical Verification

Runnable deterministic examples live in `canon/examples/CANON-014/`.

Run:

```bash
npm run canon:verify:014
```

The examples verify:

- Inline controller validation accepts valid payloads and rejects invalid payloads.
- A Form Request-style object separates authorization, rules, and validated data.
- Frontend validation alone is not a backend boundary.
- Scoped uniqueness and nullable/required rules avoid common production mistakes.

## Performance Notes

Validation cost is usually small compared with I/O, database work, and rendering. Optimize for a clear request contract first.

Practical performance concerns:

- Avoid expensive database validation rules in loops.
- Scope uniqueness queries correctly.
- Prefer Form Requests or rule objects when rule logic becomes complex.
- Let database constraints remain the final integrity guard for race conditions.

## AI Coding Guidance

When generating Laravel validation code:

- Validate server-side before saving.
- Use `$validated = $request->validate([...])` for small local rules.
- Use a Form Request for larger contracts, authorization, custom messages, or route-aware rules.
- Use `$request->validated()` in Form Request controllers.
- Do not generate `$request->all()` for mass assignment.
- Do not treat frontend validation as sufficient.
- Add scoped `Rule::unique()` when uniqueness belongs to a tenant, project, account, or current model.
- Explain redirect versus JSON `422` behavior when relevant.

## Teaching Notes

Teach validation as a boundary before teaching rule memorization. A rookie does not need every rule first; they need to understand that request input is untrusted until the backend validates it.

Progression:

1. Validate a two-field form inline.
2. Use the returned validated data.
3. Move a larger rule set into a Form Request.
4. Add authorization to the Form Request.
5. Add a scoped unique rule and explain why the database still needs an index.

Useful teaching phrase:

> Frontend validation helps the user; Laravel validation protects the application boundary.

## Interview Questions

1. Why should backend validation exist even when the frontend validates a form?
2. When would you use `$request->validate()` instead of a Form Request?
3. What does a Form Request add besides rules?
4. What response should an API client expect when Laravel validation fails?
5. Why is validation not a replacement for authorization?
6. Why can a `unique` rule need tenant or project scope?
7. Why should you use validated data instead of `$request->all()`?

## Exercises

### Beginner

Write inline validation for a contact form with `name`, `email`, and `message`, then save only the validated data.

### Intermediate

Move a product creation rule set into a Form Request with custom messages and an `authorize()` method.

### Advanced

Design validation for adding a member to a project where email must be unique within that project, role must be limited, and the user must be authorized to manage members.

## Related Atlas Nodes

- `laravel.validation.validation`
- `laravel.routing.route_post`
- `laravel.controllers.controller`
- `laravel.database.migration`
- `php.function.isset`

## Evidence And Sources

- Official Laravel Validation docs - https://laravel.com/docs/13.x/validation
- Official Laravel Form Request validation docs - https://laravel.com/docs/13.x/validation#form-request-validation
- Official Laravel validation JSON response behavior - https://laravel.com/docs/13.x/validation#quick-displaying-the-validation-errors
- Official Laravel unique rule docs - https://laravel.com/docs/13.x/validation#rule-unique

## Proof Of Superiority Summary

Official Laravel docs explain validation syntax and available rules. This Canon node explains how to choose between inline validation and Form Requests in practical production code, why validation is a request boundary, where validation stops, how API error behavior affects clients, how scoped uniqueness prevents data bugs, and how AI should generate safer Laravel controllers.

## Scorecard Placeholder

| Category | Weight | Score |
| --- | ---: | ---: |
| technical_accuracy | 20 | 19 |
| beginner_teaching | 15 | 14 |
| professional_depth | 15 | 14 |
| decision_guidance | 15 | 15 |
| production_examples | 10 | 10 |
| ai_readiness | 10 | 9 |
| evidence | 5 | 5 |
| relationships | 5 | 4 |
| exercises | 3 | 3 |
| readability | 2 | 2 |
| Total | 100 | 95 |
