# Start a PHP Project

## What this is for

Use this when you want to run a small PHP file locally.

## What you need first

You need PHP installed before running PHP files from the terminal.

## Required tools

- PHP
- A browser
- VS Code or another text editor

## Recommended extensions

- PHP Intelephense

## Start from zero

- Create a project folder.
- Create a file such as `index.php`.
- Add a small PHP example.
- Run `php -S localhost:8000` from the project folder.

## Open an existing project

- Open the project folder in VS Code.
- Find an `.php` file.
- Check whether the project has special instructions in a README file.

## Run or preview the project

- Run `php -S localhost:8000` in the project folder.
- Open `http://localhost:8000` in your browser.
- Refresh the browser after changes.

## Where you usually code

- Small PHP projects often start in `index.php`.
- Larger PHP projects may separate pages, includes, classes, and templates.

## Common first problems

- `php` is not recognized: install PHP and reopen the terminal.
- The browser downloads the file: use the local PHP server instead of opening the file directly.
- The page is not found: check the folder where the server command is running.

## Next Atlas step

After PHP runs locally, continue with the mission or look up backend concepts.
