module.exports = async function runPromiseAllSettledMixedResults() {
  const results = await Promise.allSettled([
    Promise.resolve("sent:user_1"),
    Promise.reject(new Error("user_2 bounced")),
    Promise.resolve("sent:user_3")
  ]);

  const statuses = results.map((result) => result.status).join("|");

  if (statuses !== "fulfilled|rejected|fulfilled") {
    throw new Error(`Expected mixed statuses, got ${statuses}`);
  }

  if (results[1].reason.message !== "user_2 bounced") {
    throw new Error("Expected rejected result to preserve the reason");
  }
};
