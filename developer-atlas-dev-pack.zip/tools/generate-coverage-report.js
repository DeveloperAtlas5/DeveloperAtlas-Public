const fs = require("fs");
const path = require("path");
const { analyzeContent } = require("./quality-utils");
const { rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "reports");
const outputPath = path.join(outputDir, "coverage-report.md");

function main() {
  const { results } = analyzeContent();
  const groups = new Map();

  for (const result of results) {
    const data = result.entry.frontMatter;
    const tech = data.technology;
    const category = data.category;
    if (!groups.has(tech)) groups.set(tech, new Map());
    if (!groups.get(tech).has(category)) groups.get(tech).set(category, []);
    groups.get(tech).get(category).push(result);
  }

  const lines = [
    "# Developer Atlas Coverage Report",
    "",
    "Coverage is calculated from current node quality scores because no external curriculum target list exists yet.",
    "",
    "| Technology | Category | Entries | Avg Quality | Enriched |",
    "|---|---|---:|---:|---:|"
  ];

  for (const [technology, categories] of [...groups.entries()].sort()) {
    for (const [category, entries] of [...categories.entries()].sort()) {
      const average = Math.round(entries.reduce((sum, entry) => sum + entry.score, 0) / entries.length);
      const enriched = Math.round((entries.filter((entry) => entry.score === 100).length / entries.length) * 100);
      lines.push(`| ${technology} | ${category} | ${entries.length} | ${average}% | ${enriched}% |`);
    }
  }

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${lines.join("\n")}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)}.`);
}

main();
