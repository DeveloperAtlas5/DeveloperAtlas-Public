# CANON-022 - localStorage + Vue state

Status: Hardened

## Core idea

localStorage saves strings. Vue state drives the screen.

Use JSON.stringify before saving arrays or objects. Use JSON.parse when loading arrays or objects.

Keep persistence in App.vue for the current Rookie path.

localStorage is for persistence, not app logic.

## Use this when

Use this when Mission 1 needs todos to survive refresh.

## Basic pattern

Load saved todos when the app starts, then save todos when they change.

## Common friction

Saved text must be parsed before it behaves like an array again.

## Small example

```js
const saved = localStorage.getItem("todos");
const todos = saved ? JSON.parse(saved) : [];
localStorage.setItem("todos", JSON.stringify(todos));
```

## Check yourself

- Did the screen still use Vue state?
- Did localStorage only save and load data?

## Related Canon nodes

- CANON-023
- CANON-027
