function normalizeCss(css) {
  return css.replace(/\s+/g, " ").trim();
}

function hasDeclaration(css, selector, declaration) {
  const normalized = normalizeCss(css);
  const escapedSelector = selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const blockPattern = new RegExp(`${escapedSelector}\\s*\\{([^}]*)\\}`);
  const match = normalized.match(blockPattern);
  if (!match) return false;
  return match[1].includes(declaration);
}

module.exports = { hasDeclaration };
