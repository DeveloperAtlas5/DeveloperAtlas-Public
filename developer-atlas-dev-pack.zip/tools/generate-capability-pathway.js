const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");
const {
  capabilityOutputDir,
  ensureCapabilityOutputDir,
  readCapabilities,
  unique
} = require("./capability-utils");

function main() {
  const context = readContext();
  const pathway = buildPathway(context);

  ensureCapabilityOutputDir();
  fs.writeFileSync(
    path.join(capabilityOutputDir, "capability-pathway.json"),
    `${JSON.stringify(pathway, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(capabilityOutputDir, "capability-pathway.md"),
    toMarkdown(pathway)
  );

  console.log("Generated output/capability/capability-pathway.json.");
  console.log("Generated output/capability/capability-pathway.md.");
}

function readContext() {
  const projectFitPath = path.join(capabilityOutputDir, "project-fit-report.json");
  if (!fs.existsSync(projectFitPath)) {
    throw new Error("Run npm run capability or node tools/generate-project-fit.js before generating a pathway.");
  }

  return {
    projectFit: JSON.parse(fs.readFileSync(projectFitPath, "utf8")),
    capabilitiesById: new Map(readCapabilities().map((record) => [record.capability.capability_id, record.capability])),
    readinessDetails: readReadinessDetails(),
    canonLearningById: readCanonLearningById(),
    practicePack: readJsonIfExists(path.join(rootDir, "output", "learning", "practice-pack.json"), { levels: {} }),
    toolkitIndex: readJsonIfExists(path.join(rootDir, "output", "toolkit", "toolkit-index.json"), { tools: [] }),
    frictionNodesById: readFrictionNodesById()
  };
}

function readReadinessDetails() {
  const dir = path.join(rootDir, "output", "readiness");
  const details = new Map();
  if (!fs.existsSync(dir)) return details;

  for (const fileName of fs.readdirSync(dir).filter((name) => name.endsWith(".json") && !name.includes("report"))) {
    const file = path.join(dir, fileName);
    const report = JSON.parse(fs.readFileSync(file, "utf8"));
    if (report.profile_summary?.readiness_id) details.set(report.profile_summary.readiness_id, report);
  }
  return details;
}

function readCanonLearningById() {
  const canonIndex = readJsonIfExists(path.join(rootDir, "canon", "canon-index.json"), { entries: [] });
  return new Map(canonIndex.entries.map((entry) => [entry.canon_id, entry.learning || {}]));
}

function readFrictionNodesById() {
  const dir = path.join(rootDir, "friction", "examples");
  const nodes = new Map();
  if (!fs.existsSync(dir)) return nodes;

  for (const fileName of fs.readdirSync(dir).filter((name) => name.endsWith(".json"))) {
    const node = JSON.parse(fs.readFileSync(path.join(dir, fileName), "utf8"));
    nodes.set(node.id, node);
  }
  return nodes;
}

function buildPathway(context) {
  const orderedFits = [...context.projectFit.project_fits].sort((a, b) => b.fit_score - a.fit_score || a.estimated_hours - b.estimated_hours);
  const weekFits = selectWeekFits(context.projectFit);
  const primaryDetail = context.readinessDetails.get(weekFits[0]?.best_readiness_match) || firstReadinessDetail(context);

  return {
    generated_at: new Date().toISOString(),
    pathway_id: "capability.pathway.4_week_project_ladder",
    profile_summary: profileSummary(primaryDetail, weekFits[0]),
    weeks: weekFits.map((fit, index) => buildWeek(index + 1, fit, context)),
    deferred_items: (context.projectFit.defer || []).map((fit) => ({
      capability_id: fit.capability_id,
      title: fit.title,
      fit_score: fit.fit_score,
      blockers: fit.blockers
    })),
    what_to_avoid_for_now: whatToAvoidForNow(orderedFits, primaryDetail),
    source_reports: [
      "output/capability/project-fit-report.json",
      "output/readiness/readiness-report.json",
      "output/learning/practice-pack.json",
      "canon/canon-index.json"
    ]
  };
}

function selectWeekFits(projectFit) {
  const ready = [...(projectFit.ready_today || [])].sort(byFitThenSmall);
  const mostly = [...(projectFit.mostly_ready || [])].sort(byFitThenSmall);
  const deferred = [...(projectFit.defer || [])].sort(byFitThenSmall);
  const selected = [];

  selected.push(ready[0] || mostly[0] || deferred[0]);
  selected.push(mostly[0] || ready[1] || deferred[0] || selected[0]);
  selected.push(mostly.find((fit) => fit.capability_id !== selected[1]?.capability_id) || deferred[0] || selected[1]);
  selected.push(deferred[0] || mostly.find((fit) => !selected.some((item) => item?.capability_id === fit.capability_id)) || selected[2]);

  return selected.filter(Boolean).slice(0, 4);
}

function buildWeek(weekNumber, fit, context) {
  const capability = context.capabilitiesById.get(fit.capability_id) || {};
  const readiness = context.readinessDetails.get(fit.best_readiness_match);
  const canonIds = capability.required_canon_nodes || [];
  const practiceTasks = selectPracticeTasks(canonIds, readiness?.profile_summary?.learner_level, context.practicePack);

  return {
    week: weekNumber,
    focus: weekFocus(weekNumber, fit),
    project: {
      capability_id: fit.capability_id,
      title: fit.title,
      estimated_hours: fit.estimated_hours,
      output_artifact: capability.output_artifact || ""
    },
    fit_level: fit.fit_level,
    prep_tasks: prepTasksFor(fit, capability, readiness),
    required_knowledge: unique([...(capability.required_canon_nodes || []), ...(fit.missing_knowledge || []).slice(0, 6)]),
    recommended_next_knowledge: capability.recommended_next_canon_nodes || [],
    optional_knowledge_note: capability.optional_canon_note || "",
    required_tools: requiredToolsFor(capability, readiness, context.toolkitIndex),
    friction_risks: frictionRisksFor(capability, fit, context),
    hardware_notes: fit.hardware_concerns.length ? fit.hardware_concerns : ["No major hardware concern detected for this week."],
    practice_tasks: practiceTasks,
    mastery_checkpoints: masteryCheckpointsFor(canonIds, capability, context),
    ai_ready_weekly_prompt: weeklyPrompt(weekNumber, fit, capability, practiceTasks)
  };
}

function profileSummary(readiness, fallbackFit) {
  const summary = readiness?.profile_summary || {};
  return {
    readiness_profile: summary.readiness_id || fallbackFit?.best_readiness_match || "unknown",
    readiness_status: readiness?.readiness_status || "unknown",
    readiness_score: readiness?.readiness_score || 0,
    available_hours_per_week: summary.available_hours_per_week || 0,
    desired_output: summary.desired_output || "Build the smallest realistic project first."
  };
}

function prepTasksFor(fit, capability, readiness) {
  const tasks = [];
  if (fit.fit_level !== "ready_today") tasks.push("Complete the smallest missing foundation before starting the project.");
  for (const node of (fit.missing_knowledge || []).slice(0, 3)) tasks.push(`Review ${node}.`);
  for (const tool of (fit.missing_tools || []).slice(0, 2)) tasks.push(`Install or verify ${tool}.`);
  for (const step of (readiness?.recommended_next_3_steps || []).slice(0, 2)) tasks.push(step);
  if (capability.avoid_if?.length) tasks.push(`Do not start if: ${capability.avoid_if[0]}`);
  return unique(tasks).slice(0, 7);
}

function requiredToolsFor(capability, readiness, toolkitIndex) {
  const toolNames = new Map((toolkitIndex.tools || []).map((tool) => [tool.id, tool.name || tool.id]));
  const tools = unique([...(capability.required_tools || []), ...(readiness?.tooling_gaps || []).slice(0, 3)]);
  return tools.map((tool) => toolNames.get(tool) || tool);
}

function frictionRisksFor(capability, fit, context) {
  const risks = unique([...(capability.common_friction_nodes || []), ...(fit.blockers || [])
    .filter((blocker) => blocker.includes("friction."))
    .map((blocker) => blocker.match(/friction\.[\w.]+/)?.[0])]);

  return risks.map((risk) => {
    const node = context.frictionNodesById.get(risk);
    return node ? `${risk}: ${node.title}` : risk;
  });
}

function selectPracticeTasks(canonIds, learnerLevel, practicePack) {
  const level = learnerLevel === "professional" ? "professional" : learnerLevel === "junior" ? "junior" : "rookie";
  const tasks = practicePack.levels?.[level] || [];
  const matching = tasks.filter((task) => canonIds.includes(task.canon_id)).slice(0, 4);
  return matching.length ? matching : tasks.slice(0, 2);
}

function masteryCheckpointsFor(canonIds, capability, context) {
  const checkpoints = [];
  for (const canonId of canonIds) {
    const learning = context.canonLearningById.get(canonId);
    checkpoints.push(...(learning?.mastery_criteria || []).slice(0, 2));
  }
  checkpoints.push(...(capability.success_criteria || []));
  return unique(checkpoints).slice(0, 8);
}

function weeklyPrompt(weekNumber, fit, capability, practiceTasks) {
  const practice = practiceTasks[0] ? `Practice first: ${practiceTasks[0].task_title}.` : "Start with the smallest missing practice task.";
  return [
    `Week ${weekNumber}: help me build ${fit.title}.`,
    capability.ai_context_prompt || "Keep the scope small and finishable.",
    `Current fit is ${fit.fit_level.replace(/_/g, " ")}.`,
    practice,
    "Keep the plan deterministic, beginner-safe, and focused on a finished artifact."
  ].join(" ");
}

function whatToAvoidForNow(fits, readiness) {
  const avoid = [];
  for (const fit of fits.filter((item) => item.fit_level === "defer")) avoid.push(`Avoid ${fit.title} until blockers are reduced.`);
  avoid.push(...(readiness?.what_to_skip_for_now || []));
  return unique(avoid).slice(0, 8);
}

function weekFocus(weekNumber, fit) {
  if (weekNumber === 1) return "Finish one ready-today project and protect momentum.";
  if (weekNumber === 2) return "Add one mostly-ready project after targeted prep.";
  if (weekNumber === 3) return "Take on a harder project while watching scope.";
  return fit.fit_level === "defer" ? "Prepare the deferred stretch project without overcommitting." : "Stretch the strongest remaining capability.";
}

function firstReadinessDetail(context) {
  return context.readinessDetails.values().next().value;
}

function byFitThenSmall(a, b) {
  return b.fit_score - a.fit_score || a.estimated_hours - b.estimated_hours;
}

function readJsonIfExists(file, fallback) {
  return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, "utf8")) : fallback;
}

function toMarkdown(pathway) {
  const lines = [
    "# Atlas Capability Pathway",
    "",
    `Pathway: ${pathway.pathway_id}`,
    `Readiness profile: ${pathway.profile_summary.readiness_profile}`,
    `Readiness score: ${pathway.profile_summary.readiness_score}/100`,
    `Available hours per week: ${pathway.profile_summary.available_hours_per_week}`,
    `Desired output: ${pathway.profile_summary.desired_output}`,
    ""
  ];

  for (const week of pathway.weeks) {
    lines.push(
      `## Week ${week.week}: ${week.project.title}`,
      "",
      `Focus: ${week.focus}`,
      `Fit: ${week.fit_level}`,
      `Estimated hours: ${week.project.estimated_hours}`,
      `Output artifact: ${week.project.output_artifact}`,
      "",
      "Prep tasks:",
      ...formatList(week.prep_tasks),
      "",
      "Required knowledge:",
      ...formatList(week.required_knowledge.map(displayKnowledge)),
      "",
      "Recommended next knowledge:",
      ...formatList(week.recommended_next_knowledge.map(displayKnowledge)),
      week.optional_knowledge_note ? `Note: ${week.optional_knowledge_note}` : "Note: None",
      "",
      "Required tools:",
      ...formatList(week.required_tools),
      "",
      "Friction risks:",
      ...formatList(week.friction_risks),
      "",
      "Hardware notes:",
      ...formatList(week.hardware_notes),
      "",
      "Practice tasks:",
      ...formatPractice(week.practice_tasks),
      "",
      "Mastery checkpoints:",
      ...formatList(week.mastery_checkpoints),
      "",
      "AI-ready weekly prompt:",
      week.ai_ready_weekly_prompt,
      ""
    );
  }

  lines.push(
    "## What to Avoid For Now",
    "",
    ...formatList(pathway.what_to_avoid_for_now),
    "",
    "## Deferred Items",
    "",
    ...formatDeferred(pathway.deferred_items)
  );

  return `${lines.join("\n")}\n`;
}

function formatList(items) {
  return items?.length ? items.map((item) => `- ${item}`) : ["- None"];
}

function formatPractice(tasks) {
  return tasks?.length
    ? tasks.map((task) => `- ${task.task_title}: ${task.task} (${task.estimated_minutes} min)`)
    : ["- None"];
}

function formatDeferred(items) {
  return items?.length
    ? items.map((item) => `- ${item.title}: ${item.fit_score}/100`)
    : ["- None"];
}

function displayKnowledge(id) {
  const labels = {
    "CANON-003": "Vue reactivity: choosing simple state",
    "CANON-005": "SQL joins: combining related rows",
    "CANON-007": "Vue conditional display",
    "CANON-008": "Promise coordination: all vs allSettled",
    "CANON-009": "Filtering visible items",
    "CANON-011": "Async JavaScript: async, await, and then",
    "CANON-012": "Object iteration: keys, values, and entries",
    "CANON-013": "Stable keys for list rows",
    "CANON-014": "Laravel validation boundaries",
    "CANON-015": "SQL filtering: WHERE vs HAVING",
    "CANON-022": "Browser storage: localStorage vs sessionStorage",
    "CANON-025": "Component communication: props, emits, and model"
  };
  return labels[id] || id;
}

main();
