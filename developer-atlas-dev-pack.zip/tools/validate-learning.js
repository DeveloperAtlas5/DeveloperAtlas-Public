const { readCanonIndex, getKnownReferences, getLearning } = require("./learning-utils");

function main() {
  const errors = [];
  const warnings = [];
  let index;

  try {
    index = readCanonIndex();
  } catch (error) {
    errors.push(`canon/canon-index.json: invalid JSON (${error.message})`);
  }

  const entries = index?.entries || [];
  const knownRefs = getKnownReferences(entries);
  const withLearning = entries.filter((entry) => entry.learning);

  for (const entry of withLearning) {
    validateEntryLearning(entry, knownRefs, warnings);
  }

  console.log("Atlas Learning validation");
  console.log(`Canon nodes with learning metadata: ${withLearning.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateEntryLearning(entry, knownRefs, warnings) {
  const learning = getLearning(entry);
  validateRefList(entry, "prerequisites", learning.prerequisites, knownRefs, warnings);
  validateRefList(entry, "unlocks", learning.unlocks, knownRefs, warnings);
  validatePositiveNumber(entry, "estimated_learning_minutes", learning.estimated_learning_minutes, warnings);
  validatePositiveNumber(entry, "estimated_practice_minutes", learning.estimated_practice_minutes, warnings);
  validateNonEmptyArray(entry, "mastery_criteria", learning.mastery_criteria, warnings);
  validateStringArray(entry, "misconceptions", learning.misconceptions, warnings);
  validateStringArray(entry, "recommended_projects", learning.recommended_projects, warnings);
  validateMisconceptionCorrections(entry, learning.misconception_corrections, warnings);
  validatePracticeTasks(entry, "rookie_practice", learning.rookie_practice, warnings);
  validatePracticeTasks(entry, "junior_practice", learning.junior_practice, warnings);
  validatePracticeTasks(entry, "professional_practice", learning.professional_practice, warnings);
  validateMasteryProof(entry, learning.mastery_proof, warnings);
  validateStringArray(entry, "ai_tutor_guidance", learning.ai_tutor_guidance, warnings);

  if (typeof learning.interview_readiness !== "string" || !learning.interview_readiness.trim()) {
    warnings.push(`${entry.canon_id}: interview_readiness should be a non-empty string`);
  }
  if (typeof learning.confidence_threshold !== "number" || learning.confidence_threshold <= 0 || learning.confidence_threshold > 1) {
    warnings.push(`${entry.canon_id}: confidence_threshold should be a number from 0 to 1`);
  }
}

function validateRefList(entry, field, values, knownRefs, warnings) {
  if (!Array.isArray(values)) {
    warnings.push(`${entry.canon_id}: learning.${field} should be an array`);
    return;
  }
  const seen = new Set();
  for (const value of values) {
    if (typeof value !== "string" || !value.trim()) {
      warnings.push(`${entry.canon_id}: learning.${field} contains a non-string reference`);
      continue;
    }
    if (seen.has(value)) warnings.push(`${entry.canon_id}: duplicate learning.${field} reference ${value}`);
    seen.add(value);
    if (!knownRefs.has(value)) warnings.push(`${entry.canon_id}: learning.${field} reference does not exist: ${value}`);
  }
}

function validatePositiveNumber(entry, field, value, warnings) {
  if (typeof value !== "number" || value <= 0) {
    warnings.push(`${entry.canon_id}: learning.${field} should be a positive number`);
  }
}

function validateNonEmptyArray(entry, field, values, warnings) {
  if (!Array.isArray(values) || !values.length) {
    warnings.push(`${entry.canon_id}: learning.${field} should be a non-empty array`);
    return;
  }
  validateStringArray(entry, field, values, warnings);
}

function validateStringArray(entry, field, values, warnings) {
  if (!Array.isArray(values)) {
    warnings.push(`${entry.canon_id}: learning.${field} should be an array`);
    return;
  }
  for (const value of values) {
    if (typeof value !== "string" || !value.trim()) {
      warnings.push(`${entry.canon_id}: learning.${field} contains a non-string entry`);
    }
  }
}

function validateMisconceptionCorrections(entry, values, warnings) {
  if (values === undefined) return;
  if (!Array.isArray(values)) {
    warnings.push(`${entry.canon_id}: learning.misconception_corrections should be an array`);
    return;
  }
  for (const [index, value] of values.entries()) {
    validateObjectStringField(entry, `misconception_corrections[${index}].misconception`, value, warnings);
    validateObjectStringField(entry, `misconception_corrections[${index}].correction`, value, warnings);
    validateObjectStringField(entry, `misconception_corrections[${index}].explanation`, value, warnings);
    validateObjectStringField(entry, `misconception_corrections[${index}].practice_task`, value, warnings);
  }
}

function validatePracticeTasks(entry, field, values, warnings) {
  if (values === undefined) return;
  if (!Array.isArray(values)) {
    warnings.push(`${entry.canon_id}: learning.${field} should be an array`);
    return;
  }
  for (const [index, value] of values.entries()) {
    validateObjectStringField(entry, `${field}[${index}].title`, value, warnings);
    validateObjectStringField(entry, `${field}[${index}].task`, value, warnings);
    validateObjectStringField(entry, `${field}[${index}].success_criteria`, value, warnings);
    if (!value || typeof value.estimated_minutes !== "number" || value.estimated_minutes <= 0) {
      warnings.push(`${entry.canon_id}: learning.${field}[${index}].estimated_minutes should be a positive number`);
    }
  }
}

function validateMasteryProof(entry, value, warnings) {
  if (value === undefined) return;
  validateObjectStringField(entry, "mastery_proof.proof", value, warnings);
  validateObjectStringField(entry, "mastery_proof.evidence", value, warnings);
  if (!value || !Array.isArray(value.rubric) || !value.rubric.length) {
    warnings.push(`${entry.canon_id}: learning.mastery_proof.rubric should be a non-empty array`);
    return;
  }
  for (const item of value.rubric) {
    if (typeof item !== "string" || !item.trim()) {
      warnings.push(`${entry.canon_id}: learning.mastery_proof.rubric contains a non-string entry`);
    }
  }
}

function validateObjectStringField(entry, field, value, warnings) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    warnings.push(`${entry.canon_id}: learning.${field} parent should be an object`);
    return;
  }
  const key = field.split(".").pop();
  if (typeof value[key] !== "string" || !value[key].trim()) {
    warnings.push(`${entry.canon_id}: learning.${field} should be a non-empty string`);
  }
}

main();
