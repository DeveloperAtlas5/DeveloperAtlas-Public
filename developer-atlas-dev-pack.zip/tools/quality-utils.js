const fs = require("fs");
const path = require("path");
const { readEntries, rootDir } = require("./content-utils");

const schemaPath = path.join(rootDir, "schemas", "entry.schema.json");
const MIN_SUMMARY_LENGTH = 30;

const QUALITY_FIELDS = [
  "when_to_use",
  "when_not_to_use",
  "common_mistakes",
  "best_practices",
  "sources",
  "confidence",
  "evidence_level"
];

const ENRICHMENT_FIELDS = [
  "problem",
  "solution",
  "alternatives",
  "ai_notes",
  "human_notes",
  "teaching_notes",
  "code_generation_notes",
  "troubleshooting_notes"
];

const FUTURE_FIELDS = [
  "subcategory",
  "interview",
  "performance",
  "parameters",
  "returns",
  "recipes",
  "projects",
  "decision_tree",
  "interview_questions",
  "exercises",
  "language_versions"
];

function hasValue(value) {
  return value !== undefined && value !== null && value !== "" && (!Array.isArray(value) || value.length > 0);
}

function validateTypes(entry, schema) {
  const errors = [];

  for (const [field, definition] of Object.entries(schema.properties || {})) {
    const value = entry[field];
    if (value === undefined) continue;

    if (definition.enum && !definition.enum.includes(value)) {
      errors.push(`${field} must be one of: ${definition.enum.join(", ")}`);
    }

    if (definition.type === "string" && typeof value !== "string") {
      errors.push(`${field} must be a string`);
    }

    if (definition.type === "integer" && !Number.isInteger(value)) {
      errors.push(`${field} must be an integer`);
    }

    if (definition.type === "array" && !Array.isArray(value)) {
      errors.push(`${field} must be an array`);
    }

    if (definition.minimum !== undefined && typeof value === "number" && value < definition.minimum) {
      errors.push(`${field} must be at least ${definition.minimum}`);
    }

    if (definition.maximum !== undefined && typeof value === "number" && value > definition.maximum) {
      errors.push(`${field} must be at most ${definition.maximum}`);
    }
  }

  return errors;
}

function findDuplicates(entries, field) {
  const seen = new Map();
  const duplicates = new Map();

  for (const entry of entries) {
    const value = entry.frontMatter[field];
    if (!value) continue;
    if (!seen.has(value)) {
      seen.set(value, entry.relativePath);
      continue;
    }
    duplicates.set(value, [seen.get(value), entry.relativePath]);
  }

  return duplicates;
}

function addWarning(warnings, level, field, message) {
  warnings.push({ level, field, message });
}

function scoreEntry(frontMatter, requiredFields, relatedLinksValid) {
  let score = 0;
  const requiredComplete = requiredFields.every((field) => hasValue(frontMatter[field]));
  if (requiredComplete) score += 40;
  if (hasValue(frontMatter.examples)) score += 10;
  if (hasValue(frontMatter.when_to_use)) score += 8;
  if (hasValue(frontMatter.when_not_to_use)) score += 8;
  if (hasValue(frontMatter.common_mistakes)) score += 8;
  if (hasValue(frontMatter.best_practices)) score += 8;
  if (hasValue(frontMatter.confidence) && hasValue(frontMatter.evidence_level)) score += 8;
  if (hasValue(frontMatter.sources)) score += 5;
  if (relatedLinksValid) score += 5;
  return score;
}

function analyzeContent() {
  const schema = JSON.parse(fs.readFileSync(schemaPath, "utf8"));
  const entries = readEntries();
  const ids = new Set(entries.map((entry) => entry.frontMatter.id).filter(Boolean));
  const duplicateIds = findDuplicates(entries, "id");
  const duplicateSlugs = findDuplicates(entries, "slug");
  const results = [];

  for (const entry of entries) {
    const frontMatter = entry.frontMatter;
    const errors = [];
    const warnings = [];
    let relatedLinksValid = true;

    for (const field of schema.required || []) {
      if (!hasValue(frontMatter[field])) errors.push(`missing required field: ${field}`);
    }

    errors.push(...validateTypes(frontMatter, schema));

    if (duplicateIds.has(frontMatter.id)) errors.push(`duplicate id: ${frontMatter.id}`);
    if (duplicateSlugs.has(frontMatter.slug)) errors.push(`duplicate slug: ${frontMatter.slug}`);

    if (typeof frontMatter.summary === "string" && frontMatter.summary.length < MIN_SUMMARY_LENGTH) {
      addWarning(warnings, "quality", "summary", `summary is short (${frontMatter.summary.length} chars)`);
    }

    if (!hasValue(frontMatter.examples)) {
      addWarning(warnings, "critical", "examples", "examples are empty");
    }

    for (const field of QUALITY_FIELDS) {
      if (!hasValue(frontMatter[field])) addWarning(warnings, "quality", field, `${field} is missing`);
    }

    for (const field of ENRICHMENT_FIELDS) {
      if (!hasValue(frontMatter[field])) {
        addWarning(warnings, "enrichment", field, `missing enrichment field: ${field}`);
      }
    }

    for (const field of FUTURE_FIELDS) {
      if (!hasValue(frontMatter[field])) {
        addWarning(warnings, "future", field, `future field not yet filled: ${field}`);
      }
    }

    if (Array.isArray(frontMatter.related)) {
      for (const relatedId of frontMatter.related) {
        if (!ids.has(relatedId)) {
          relatedLinksValid = false;
          addWarning(warnings, "critical", "related", `related id does not exist: ${relatedId}`);
        }
      }
    }

    for (const referenceField of ["recipes", "projects"]) {
      if (!Array.isArray(frontMatter[referenceField])) continue;
      for (const referencedId of frontMatter[referenceField]) {
        if (!ids.has(referencedId)) {
          addWarning(warnings, "critical", referenceField, `${referenceField} reference does not exist: ${referencedId}`);
        }
      }
    }

    results.push({
      file: entry.relativePath,
      entry,
      errors,
      warnings,
      score: scoreEntry(frontMatter, schema.required || [], relatedLinksValid)
    });
  }

  return {
    entries,
    results,
    counts: summarize(entries, results)
  };
}

function summarize(entries, results) {
  const warningLevels = { critical: 0, quality: 0, enrichment: 0, future: 0 };
  const missingFields = new Map();

  for (const result of results) {
    for (const warning of result.warnings) {
      warningLevels[warning.level] += 1;
      missingFields.set(warning.field, (missingFields.get(warning.field) || 0) + 1);
    }
  }

  const errorCount = results.reduce((count, result) => count + result.errors.length, 0);
  const warningCount = Object.values(warningLevels).reduce((sum, count) => sum + count, 0);
  const averageScore = results.length
    ? Math.round(results.reduce((sum, result) => sum + result.score, 0) / results.length)
    : 0;

  return {
    totalEntries: results.length,
    errorCount,
    warningCount,
    warningLevels,
    averageScore,
    byTechnology: countBy(entries, "technology"),
    byType: countBy(entries, "type"),
    missingFields: [...missingFields.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
  };
}

function countBy(entries, field) {
  const counts = new Map();
  for (const entry of entries) {
    const value = entry.frontMatter[field] || "unknown";
    counts.set(value, (counts.get(value) || 0) + 1);
  }
  return [...counts.entries()].sort((a, b) => a[0].localeCompare(b[0]));
}

module.exports = {
  analyzeContent,
  hasValue
};
