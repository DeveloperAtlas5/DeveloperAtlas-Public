module.exports = function runFilterActiveUsers() {
  const users = [
    { id: 1, name: "Ada", active: true },
    { id: 2, name: "Grace", active: false },
    { id: 3, name: "Lin", active: true }
  ];

  const activeUsers = users.filter((user) => user.active);
  const names = activeUsers.map((user) => user.name).join(",");

  if (names !== "Ada,Lin") {
    throw new Error(`Expected active users Ada,Lin, got ${names}`);
  }

  if (activeUsers[0] !== users[0]) {
    throw new Error("Expected filter() to keep original item references");
  }
};
