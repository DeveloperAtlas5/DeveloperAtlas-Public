const {
  fs,
  path,
  rootDir,
  missionDir,
  outputDir,
  missionSurfacePath,
  vibeMissionSurfacePath,
  missionTwoSurfacePath,
  vibeMissionTwoSurfacePath,
  missionDashboardPath,
  startHerePath,
  beginnerOrientationPath,
  vueConceptCardsPath,
  terminalConfidenceGuidePath,
  testerFeedbackReportPath,
  testerHandoffMessagesPath,
  publicAlphaReadinessReportPath,
  alphaFocusLockPath,
  canonCandidateBacklogReportPath,
  alphaPackageFinalQaPath,
  humanAiReadabilityAuditPath,
  maintainerMapPath,
  aiEditingRulesPath,
  accessibilityPrinciplePath,
  templateDir,
  validatorsDir,
  startHereTemplatePath,
  dashboardTemplatePath,
  missionTemplatesPath,
  reportTemplatesPath,
  quickStartTemplatePath,
  aiPromptPackTemplatePath,
  canonTemplatesPath,
  missionExperienceGeneratorPath,
  packagedDemoDir,
  packagedStartHerePath,
  packagedMissionDashboardPath,
  packagedBeginnerOrientationPath,
  packagedVueConceptCardsPath,
  packagedTerminalConfidenceGuidePath,
  packagedTesterFeedbackReportPath,
  packagedTesterHandoffMessagesPath,
  packagedPublicAlphaReadinessReportPath,
  packagedAlphaFocusLockPath,
  packagedCanonCandidateBacklogReportPath,
  packagedAlphaPackageFinalQaPath,
  packagedHumanAiReadabilityAuditPath,
  phase93CandidateIdPattern,
  requiredFiles,
  requiredMissionFields,
  validateSectionsInOrder,
  requireText,
  requirePattern,
  validateForbiddenTerms,
  validateNoShameLanguage,
  validateNoHypeLanguage,
  parseJson,
  validateRange
} = require("./shared-validator-utils");
const { validateHumanAiReadabilityAudit } = require("./report-validator");

function validateTemplateSplit(errors) {
  const requiredTemplateFiles = [
    ["tools/templates/start-here-template.js", startHereTemplatePath],
    ["tools/templates/dashboard-template.js", dashboardTemplatePath],
    ["tools/templates/mission-templates.js", missionTemplatesPath],
    ["tools/templates/report-templates.js", reportTemplatesPath],
    ["tools/templates/quick-start-template.js", quickStartTemplatePath],
    ["tools/templates/ai-prompt-pack-template.js", aiPromptPackTemplatePath],
    ["tools/templates/canon-templates.js", canonTemplatesPath]
  ];

  if (!fs.existsSync(templateDir)) {
    errors.push("tools/templates/: missing template directory");
  }

  for (const [label, filePath] of requiredTemplateFiles) {
    if (!fs.existsSync(filePath)) {
      errors.push(`${label}: missing template module`);
      continue;
    }
    const text = fs.readFileSync(filePath, "utf8");
    if (!/Template source for generated Developer Atlas outputs/.test(text)) {
      errors.push(`${label}: missing template source comment`);
    }
    if (!/module\.exports/.test(text)) {
      errors.push(`${label}: missing CommonJS exports`);
    }
  }

  if (!fs.existsSync(missionExperienceGeneratorPath)) {
    errors.push("tools/generate-mission-experience-report.js: missing generator");
    return;
  }

  const generatorText = fs.readFileSync(missionExperienceGeneratorPath, "utf8");
  const requiredGeneratorSignals = [
    [/Orchestrates generation\. Template text lives in tools\/templates\//, "orchestrator comment"],
    [/require\("\.\/templates\/mission-templates"\)/, "mission templates import"],
    [/require\("\.\/templates\/dashboard-template"\)/, "dashboard template import"],
    [/require\("\.\/templates\/start-here-template"\)/, "start here template import"],
    [/require\("\.\/templates\/quick-start-template"\)/, "quick start template import"],
    [/require\("\.\/templates\/ai-prompt-pack-template"\)/, "AI prompt pack template import"],
    [/require\("\.\/templates\/canon-templates"\)/, "hardened Canon template import"],
    [/require\("\.\/templates\/report-templates"\)/, "report templates import"],
    [/renderMissionSurface\(mission\)/, "mission render call"],
    [/renderMissionThreeSurface\(\)/, "Mission 3 default render call"],
    [/renderVibeMissionThreeSurface\(\)/, "Mission 3 vibe render call"],
    [/renderMissionDashboard\(\)/, "dashboard render call"],
    [/renderStartHere\(\)/, "START_HERE render call"],
    [/renderFirstTimeQuickStart\(\)/, "first-time quick start render call"],
    [/renderAiPromptPack\(\)/, "AI prompt pack render call"],
    [/renderHardenedCanonFiles\(\)/, "hardened Canon render call"],
    [/renderHumanAiReadabilityAudit\(\)/, "human-AI audit render call"],
    [/renderInheritedWarningBurnDownReport\(contentWarningCounts\)/, "inherited warning burn-down report render call"]
  ];

  for (const [pattern, meaning] of requiredGeneratorSignals) {
    if (!pattern.test(generatorText)) {
      errors.push(`tools/generate-mission-experience-report.js: missing ${meaning}`);
    }
  }
}

function validateValidatorSplit(errors) {
  const requiredValidatorFiles = [
    "shared-validator-utils.js",
    "package-structure-validator.js",
    "dashboard-accessibility-validator.js",
    "mission-content-validator.js",
    "report-validator.js",
    "hardened-canon-validator.js",
    "maintainer-docs-validator.js",
    "language-safety-validator.js",
    "file-growth-validator.js"
  ];

  if (!fs.existsSync(validatorsDir)) {
    errors.push("tools/validators/: missing validator module directory");
    return;
  }

  for (const fileName of requiredValidatorFiles) {
    const filePath = path.join(validatorsDir, fileName);
    if (!fs.existsSync(filePath)) {
      errors.push(`tools/validators/${fileName}: missing validator module`);
      continue;
    }
    const text = fs.readFileSync(filePath, "utf8");
    if (!/module\.exports/.test(text)) {
      errors.push(`tools/validators/${fileName}: missing CommonJS exports`);
    }
  }

  const orchestratorPath = path.join(rootDir, "tools", "validate-mission.js");
  if (!fs.existsSync(orchestratorPath)) {
    errors.push("tools/validate-mission.js: missing mission validation orchestrator");
    return;
  }

  const orchestratorText = fs.readFileSync(orchestratorPath, "utf8");
  const orchestratorLines = orchestratorText.split(/\r?\n/).length;
  const requiredSignals = [
    [/Orchestrates mission\/package validation\. Concern-specific checks live in tools\/validators\/\./, "orchestrator comment"],
    [/require\("\.\/validators\/shared-validator-utils"\)/, "shared validator import"],
    [/require\("\.\/validators\/mission-content-validator"\)/, "mission content validator import"],
    [/require\("\.\/validators\/dashboard-accessibility-validator"\)/, "dashboard accessibility validator import"],
    [/require\("\.\/validators\/package-structure-validator"\)/, "package structure validator import"],
    [/require\("\.\/validators\/report-validator"\)/, "report validator import"],
    [/require\("\.\/validators\/hardened-canon-validator"\)/, "hardened Canon validator import"],
    [/require\("\.\/validators\/maintainer-docs-validator"\)/, "maintainer docs validator import"],
    [/require\("\.\/validators\/language-safety-validator"\)/, "language safety validator import"],
    [/require\("\.\/validators\/file-growth-validator"\)/, "file growth validator import"],
    [/validateMissionSurface\(errors, warnings\)/, "mission content validator call"],
    [/validateMissionThreeSurface\(errors, warnings\)/, "Mission 3 validator call"],
    [/validateVibeMissionThreeSurface\(errors, warnings\)/, "Mission 3 vibe validator call"],
    [/validateMissionDashboard\(errors, warnings\)/, "dashboard validator call"],
    [/validateHardenedCanon\(errors, warnings\)/, "hardened Canon validator call"],
    [/validatePackagedDemoStructure\(errors, warnings\)/, "package validator call"],
    [/validateLearnerFacingPackageLanguage\(errors\)/, "language safety validator call"],
    [/validateMaintainerFileGrowth\(warnings\)/, "file growth validator call"]
  ];

  for (const [pattern, meaning] of requiredSignals) {
    if (!pattern.test(orchestratorText)) {
      errors.push(`tools/validate-mission.js: missing ${meaning}`);
    }
  }

  if (orchestratorLines > 500) {
    errors.push(`tools/validate-mission.js: orchestrator is too large (${orchestratorLines} lines); keep concern-specific checks in tools/validators/`);
  }
}

function validatePhase97MaintainerGuardrails(errors, warnings) {
  validateMaintainerMap(errors);
  validateAiEditingRules(errors);
  validateHumanAiReadabilityAudit(
    humanAiReadabilityAuditPath,
    "output/experience/human-ai-readability-audit.md",
    errors,
    warnings,
    false
  );

  if (fs.existsSync(packagedDemoDir)) {
    validateHumanAiReadabilityAudit(
      packagedHumanAiReadabilityAuditPath,
      "output/share/developer-atlas-mvp-demo/reviewer/human-ai-readability-audit.md",
      errors,
      warnings,
      true
    );

    if (fs.existsSync(path.join(packagedDemoDir, "docs", "maintainer-map.md"))) {
      errors.push("output/share/developer-atlas-mvp-demo/docs/maintainer-map.md: maintainer docs should not be packaged");
    }
    if (fs.existsSync(path.join(packagedDemoDir, "docs", "ai-editing-rules.md"))) {
      errors.push("output/share/developer-atlas-mvp-demo/docs/ai-editing-rules.md: maintainer docs should not be packaged");
    }
    if (fs.existsSync(path.join(packagedDemoDir, "tools", "validators"))) {
      errors.push("output/share/developer-atlas-mvp-demo/tools/validators: validator modules should not be packaged");
    }
  }
}

function validateMaintainerMap(errors) {
  const label = "docs/maintainer-map.md";
  if (!fs.existsSync(maintainerMapPath)) {
    errors.push(`${label}: missing maintainer map`);
    return;
  }

  const text = fs.readFileSync(maintainerMapPath, "utf8");
  const requiredSections = [
    "# Developer Atlas Maintainer Map",
    "## Purpose",
    "## Source of Truth",
    "## Generated Outputs",
    "## Package Outputs",
    "## Common Change Requests",
    "## Validation Map",
    "## Do Not Edit Directly",
    "## File Growth Watchlist",
    "## Safe Editing Workflow",
    "## AI Assistant Notes"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  const requiredMeanings = [
    [/helps maintainers and AI assistants understand where to edit/i, "purpose"],
    [/tools\/generate-mission-experience-report\.js[\s\S]*tools\/templates\/[\s\S]*tools\/validators\/[\s\S]*tools\/package-mvp-demo\.js[\s\S]*tools\/validate-mission\.js[\s\S]*tools\/validate-canon\.js[\s\S]*docs\/accessibility-principle\.md[\s\S]*canon\/canon-index\.json[\s\S]*canon\/nodes\/[\s\S]*canon\/scorecards\/[\s\S]*canon\/proofs\/[\s\S]*site\/README\.md[\s\S]*package\.json/i, "source-of-truth guidance"],
    [/output\/experience\/\*\.md[\s\S]*output\/experience\/\*\.html[\s\S]*output\/share\/developer-atlas-mvp-demo\/[\s\S]*output\/share\/developer-atlas-mvp-demo\.zip[\s\S]*Generated outputs should normally be refreshed by scripts/i, "generated outputs guidance"],
    [/START_HERE\.md[\s\S]*mission-dashboard\.html[\s\S]*mission\/[\s\S]*help\/[\s\S]*ai\/[\s\S]*reference\/[\s\S]*reviewer\//i, "package output structure"],
    [/\| Change request \| Edit here first \| Then validate with \|[\s\S]*Change START_HERE text[\s\S]*tools\/templates\/start-here-template\.js[\s\S]*Change first-time quick start[\s\S]*tools\/templates\/quick-start-template\.js[\s\S]*Change dashboard[\s\S]*tools\/templates\/dashboard-template\.js[\s\S]*Change dashboard accessibility or read-aloud support[\s\S]*docs\/accessibility-principle\.md[\s\S]*Change goal-based dashboard panels[\s\S]*tools\/templates\/dashboard-template\.js[\s\S]*tools\/validators\/dashboard-accessibility-validator\.js[\s\S]*Change dashboard simplification or goal visibility[\s\S]*tools\/templates\/dashboard-template\.js[\s\S]*tools\/validators\/dashboard-accessibility-validator\.js[\s\S]*Change hardened Canon files[\s\S]*tools\/templates\/canon-templates\.js[\s\S]*tools\/validators\/hardened-canon-validator\.js[\s\S]*Change workspace clarity wording[\s\S]*quick start, dashboard, START_HERE, mission templates, and related validators[\s\S]*Change AI-assisted path[\s\S]*vibe mission templates, dashboard AI panel, optional AI prompt pack, and related validators[\s\S]*Change learner-first package structure[\s\S]*package script, dashboard links, START_HERE, package validators[\s\S]*Change Mission 1 or Mission 2 text[\s\S]*tools\/templates\/mission-templates\.js[\s\S]*Add or change a mission[\s\S]*tools\/validators\/mission-content-validator\.js[\s\S]*tools\/package-mvp-demo\.js[\s\S]*Change owner\/reviewer reports[\s\S]*tools\/templates\/report-templates\.js[\s\S]*Change package file list[\s\S]*Change mission validation[\s\S]*tools\/validators\/mission-content-validator\.js[\s\S]*Change dashboard\/accessibility validation[\s\S]*tools\/validators\/dashboard-accessibility-validator\.js[\s\S]*Change report validation[\s\S]*tools\/validators\/report-validator\.js[\s\S]*Change language safety scan[\s\S]*tools\/validators\/language-safety-validator\.js[\s\S]*Change validation rules[\s\S]*tools\/validators\/[\s\S]*Add Canon candidate[\s\S]*Add mission to package/i, "common change request table"],
    [/npm run validate[\s\S]*npm run build[\s\S]*npm run package:demo[\s\S]*npm run mission[\s\S]*npm run validate:mission[\s\S]*tools\/validators\/[\s\S]*npm run canon[\s\S]*npm run flow[\s\S]*npm run walkthrough[\s\S]*npm run ai-context[\s\S]*npm run site:preview/i, "validation map"],
    [/Mission 3 content checks belong in `tools\/validators\/mission-content-validator\.js`/i, "Mission 3 validator guidance"],
    [/Do not treat `output\/experience` files as long-term source-of-truth[\s\S]*Do not patch packaged files directly[\s\S]*Do not update package zip manually/i, "do-not-edit guidance"],
    [/tools\/generate-mission-experience-report\.js[\s\S]*tools\/templates\/mission-templates\.js[\s\S]*tools\/templates\/report-templates\.js[\s\S]*tools\/validate-mission\.js[\s\S]*tools\/validators\/[\s\S]*tools\/package-mvp-demo\.js[\s\S]*concern-specific validator grows past its warning threshold/i, "file growth watchlist"],
    [/Identify source-of-truth file[\s\S]*Make the smallest change[\s\S]*Regenerate outputs[\s\S]*Run targeted validator[\s\S]*Run full validation[\s\S]*Confirm package file exists[\s\S]*learner-facing language scan/i, "safe editing workflow"],
    [/tools\/validate-mission\.js`? should stay an orchestrator/i, "validator orchestrator note"],
    [/Prefer source-of-truth edits[\s\S]*Avoid direct output-only edits[\s\S]*Update generator, validator, and package together[\s\S]*Report exact files changed[\s\S]*Avoid broad rewrites[\s\S]*Preserve focus lock[\s\S]*Preserve the Atlas accessibility principle[\s\S]*Preserve progressive visibility[\s\S]*recommended first action[\s\S]*Validate accessibility changes in generated dashboard output and the packaged copy[\s\S]*Do not add product scope/i, "AI assistant notes"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateAiEditingRules(errors) {
  const label = "docs/ai-editing-rules.md";
  if (!fs.existsSync(aiEditingRulesPath)) {
    errors.push(`${label}: missing AI editing rules`);
    return;
  }

  const text = fs.readFileSync(aiEditingRulesPath, "utf8");
  const requiredSections = [
    "# AI Editing Rules for Developer Atlas",
    "## Purpose",
    "## Golden Rule",
    "## Editing Layers",
    "## Before Changing Anything",
    "## When Adding or Changing a Mission",
    "## When Changing Package Contents",
    "## When Changing Learner-Facing HTML",
    "## When Changing Validators",
    "## When Adding Canon Content",
    "## Forbidden AI Behaviors",
    "## Required Final Report"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  const requiredMeanings = [
    [/Edit the source-of-truth first, then regenerate outputs and validate the result/i, "golden rule"],
    [/Template text lives in `tools\/templates\/`[\s\S]*Do not edit `output\/experience` files as source-of-truth/i, "template source-of-truth guidance"],
    [/1\. Source files[\s\S]*2\. Generated output files[\s\S]*3\. Packaged demo files[\s\S]*4\. Zip artifact/i, "editing layers"],
    [/change type[\s\S]*source file[\s\S]*generated outputs affected[\s\S]*package files affected[\s\S]*validator affected[\s\S]*commands to run/i, "before-changing checklist"],
    [/Identify the correct template module first[\s\S]*Update the generator[\s\S]*Update the validator[\s\S]*Update the package script[\s\S]*dashboard and `START_HERE\.md`[\s\S]*feedback, readiness, or focus reports[\s\S]*When adding a new mission, update the mission template, package script, dashboard\/START_HERE references, report templates, and mission-content validator together[\s\S]*Do not add a mission output file without adding validator coverage[\s\S]*mission validation/i, "mission change rules"],
    [/Update the package script[\s\S]*package manifest[\s\S]*Validate source and destination paths[\s\S]*Refresh the package directory and zip artifact[\s\S]*Do not put optional AI, reference, or reviewer material back into the package root[\s\S]*Reviewer-facing files should not appear required for normal learners/i, "package change rules"],
    [/Preserve semantic structure[\s\S]*keyboard access[\s\S]*clear link labels[\s\S]*visible focus states[\s\S]*read-aloud features optional and user-triggered[\s\S]*do not autoplay speech[\s\S]*readable, listenable, keyboard-friendly, screen-reader-aware, calm, recoverable, AI-assistable, and broken into small wins[\s\S]*recommended first action visible before optional paths[\s\S]*progressive visibility[\s\S]*current goal[\s\S]*all paths look equally important[\s\S]*choice pressure[\s\S]*clear user goal[\s\S]*Reviewer\/owner files should not appear required[\s\S]*quick start into a full tutorial[\s\S]*first visible win[\s\S]*hardened Canon references feel required[\s\S]*current Rookie Vue path[\s\S]*Do not add external accessibility dependencies[\s\S]*docs\/accessibility-principle\.md/i, "learner-facing HTML accessibility rules"],
    [/Do not tell learners or AI to edit the Atlas package[\s\S]*learner's Vue project/i, "Atlas package workspace boundary"],
    [/For Rookie Vue missions, code changes belong in the learner's Vue todo project/i, "Rookie Vue workspace boundary"],
    [/AI-assisted mission prompts must keep AI inside one mission at a time[\s\S]*AI prompts should ask for small, scoped, explainable changes[\s\S]*AI prompts must include what not to change, not only what to build[\s\S]*AI prompts should ask for an explain-it-back response before the learner accepts the change/i, "AI-assisted prompt rules"],
    [/Do not reduce warning counts by weakening learner-facing language validation[\s\S]*Fix warning terms at the source template when generated files contain repeated warnings[\s\S]*Only exclude files from scans when they are clearly archived, vendor files, generated build artifacts, or not learner\/package-facing/i, "warning burn-down rules"],
    [/Mission validation is split by concern under `tools\/validators\/`[\s\S]*specific validator module[\s\S]*instead of adding all checks to `tools\/validate-mission\.js`[\s\S]*Keep `tools\/validate-mission\.js` as an orchestrator[\s\S]*actionable[\s\S]*clear file paths[\s\S]*Avoid vague failures[\s\S]*Avoid shame language/i, "validator change rules"],
    [/candidate status[\s\S]*Update the index[\s\S]*scorecard and proof consistency[\s\S]*Canon validation/i, "Canon change rules"],
    [/Do not edit packaged files only[\s\S]*Do not edit generated outputs only[\s\S]*Do not claim validation proves something unless a validator actually checks it[\s\S]*Do not add new product scope[\s\S]*Do not rewrite large files[\s\S]*Do not hide inherited warnings[\s\S]*Do not remove focus-lock protections/i, "forbidden AI behaviors"],
    [/files added[\s\S]*files changed[\s\S]*source-of-truth updated[\s\S]*outputs regenerated[\s\S]*package refreshed[\s\S]*validation commands run[\s\S]*error count[\s\S]*inherited warnings[\s\S]*learner-facing scan result[\s\S]*known limitations/i, "required final report"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

function validateAccessibilityPrinciple(errors) {
  const label = "docs/accessibility-principle.md";
  if (!fs.existsSync(accessibilityPrinciplePath)) {
    errors.push(`${label}: missing Atlas accessibility principle`);
    return;
  }

  const text = fs.readFileSync(accessibilityPrinciplePath, "utf8");
  const requiredSections = [
    "# Atlas Accessibility Principle"
  ];

  validateSectionsInOrder(text, requiredSections, label, errors);

  const requiredMeanings = [
    [/Developer Atlas exists to help people turn ideas into working progress/i, "Atlas purpose"],
    [/Some people come to coding through school[\s\S]*Some come through curiosity[\s\S]*life changed[\s\S]*body changed[\s\S]*work options changed[\s\S]*new way forward/i, "many learner paths"],
    [/learner's idea is not less valuable[\s\S]*type slowly[\s\S]*read with difficulty[\s\S]*text-to-speech[\s\S]*larger text[\s\S]*AI assistance[\s\S]*pain or fatigue[\s\S]*traditional tutorials/i, "access needs are valid"],
    [/Atlas should support the person behind the idea/i, "person behind the idea"],
    [/readable[\s\S]*listenable[\s\S]*keyboard-friendly[\s\S]*screen-reader-aware[\s\S]*calm[\s\S]*recoverable[\s\S]*AI-assistable[\s\S]*broken into small wins/i, "accessibility aims"],
    [/Progressive visibility: show only what helps the user's current goal/i, "progressive visibility principle"],
    [/The first screen should show the next useful action, not the whole product/i, "first screen next action principle"],
    [/Small entry points are part of accessibility because they reduce first-read fatigue/i, "small entry points accessibility principle"],
    [/Clear workspace boundaries reduce cognitive load for first-time learners/i, "workspace boundaries accessibility principle"],
    [/A calm folder structure is part of accessibility because it reduces first-impression cognitive load/i, "calm folder structure accessibility principle"],
    [/Scoped AI prompts reduce cognitive load because the learner does not have to judge a large, unexpected rewrite/i, "scoped AI prompts accessibility principle"],
    [/reduce friction[\s\S]*fewer people give up[\s\S]*larger text[\s\S]*read-aloud[\s\S]*keyboard navigation[\s\S]*AI assistance[\s\S]*slower pacing[\s\S]*recovery guidance/i, "friction reduction accessibility guidance"],
    [/Accessibility is not separate from the Atlas mission/i, "accessibility part of mission"],
    [/Accessibility is how Atlas protects momentum for more people/i, "accessibility protects momentum"]
  ];

  for (const [pattern, meaning] of requiredMeanings) {
    if (!pattern.test(text)) {
      errors.push(`${label}: missing ${meaning}`);
    }
  }
}

module.exports = {
  validateTemplateSplit,
  validateValidatorSplit,
  validatePhase97MaintainerGuardrails,
  validateMaintainerMap,
  validateAiEditingRules,
  validateAccessibilityPrinciple
};
