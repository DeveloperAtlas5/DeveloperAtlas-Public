# Developer Atlas MVP Demo Pack

**Developer Atlas**  
**Learn with confidence. Build with purpose. Grow without getting lost.**

Developer Atlas is an Engineering Progress Platform. It helps developers learn, build, fix, improve, and grow with structured knowledge, personal roadmaps, setup and recovery support, and AI-ready context.

This demo pack is generated from local Atlas data. It does not require a website, chatbot, external API, or LLM call.

## Executive Snapshot

- Canon nodes: 50
- Review-ready Canon nodes: 22
- Canon average score: 72.6
- Readiness profiles processed: 3
- Average readiness score: 51.65
- Ready-today projects: 1
- Momentum sessions: 3
- Estimated minutes saved: 220
- AI context quality average: 98.89
- Team context quality average: 99.2
- Atlas flows generated: 3
- Average flow quality score: 97

## What The Demo Proves

1. Atlas can turn knowledge into reviewable decision guides.
2. Atlas can detect when someone is not ready yet without shaming them or stopping momentum.
3. Atlas can recommend a realistic project for this week.
4. Atlas can identify setup and recovery risks before they waste time.
5. Atlas can produce concise AI context packs without locking users into a model.
6. Atlas can help teams share consistent context with explicit AI safety rules.
7. Atlas can make progress feel visible instead of overwhelming.

## Featured User Story

Start the demo after the landing page with the first recommended flow: **rookie-vue-todo-flow**.

A rookie learner wants to build something real. Atlas checks readiness, detects that the learner still needs foundations, and still finds a realistic project: **Build Vue Todo App**.

Week 1 recommendation: **Build Vue Todo App**.
Estimated time: 6 hours.
Output artifact: Small Vue todo app with add, complete, filter, and delete behavior.

Atlas does not simply say the learner is behind. It shows the smallest useful project, the missing knowledge, the likely blockers, and the next practice tasks.

## Readiness And Capability

Average readiness score is 51.65. The weakest category is knowledge at 23.19.

Project fit summary:
- Build Full-Stack Inventory System: defer (55.28)
- Build Laravel CRUD API: mostly ready (63.68)
- Build Unity 2D Prototype: mostly ready (58.05)
- Build Vue Todo App: ready today (68.63)
- Run Local LLM Learning Experiment: mostly ready (60.45)

## Momentum And Friction

Across 3 momentum sessions, Atlas estimates 220 minutes saved and a confidence improvement of 0.34.

Most common blockers:
- friction.javascript.npm.install_fails: 2
- friction.php.composer.not_recognized: 2
- friction.javascript.vite.not_starting: 1
- friction.laravel.artisan_missing: 1
- friction.php.php_not_in_path: 1

## Goal Overlap

Strongest overlap: tool.git (tool, 5 goals).

Top overlapping knowledge:
- javascript.array.filter: 4
- javascript.array.map: 4
- javascript.function.fetch: 3
- css.property.flex: 2
- css.property.grid-template-columns: 2

## AI And Team Context

AI context packs scored: 4. Average score: 98.89.
Best AI context pack: jefry-fullstack-ai-game-dev.

Team contexts scored: 3. Average score: 99.2.
Best team context: project.junior_vue_laravel_onboarding.

## Inspectable Evidence

- output/canon/canon-report.md
- output/readiness/readiness-report.md
- output/capability/project-fit-report.md
- output/capability/capability-pathway.md
- output/friction/friction-report.md
- output/setup-advisor/setup-advisor-report.md
- output/recovery-advisor/recovery-advisor-report.md
- output/momentum/momentum-report.md
- output/explainability/why-this-roadmap.md
- output/ai-context/ai-context-quality-report.md
- output/team-context/team-context-quality-report.md
- output/flow/flow-report.md
