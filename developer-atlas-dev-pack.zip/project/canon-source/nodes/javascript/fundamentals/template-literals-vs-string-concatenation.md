# template literals vs string concatenation

## Status Metadata

- Canon ID: CANON-CANDIDATE-JS-005
- Node ID: canon.javascript.fundamentals.template-literals-vs-string-concatenation
- Status: candidate
- Score: 55
- Version: 2026.1
- Source family: JavaScript
- Level: rookie/junior
- Audience: future Rookie-to-Junior frontend path
- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Summary

Template literals make strings with variables easier to read. Concatenation is still useful for very simple or legacy code. This candidate supports future Rookie-to-Junior frontend coverage and is not part of the current public alpha mission.

## What Problem This Solves

This reduces beginner confusion around template literals vs string concatenation by turning the topic into a small decision with practical recovery guidance.

## Mental Model

Template literals make strings with variables easier to read. Concatenation is still useful for very simple or legacy code.

## Beginner Explanation

Template literals make strings with variables easier to read. Concatenation is still useful for very simple or legacy code. The goal is not to memorize a rule; the goal is to choose the option that matches what the code is trying to do.

## Professional Explanation

Use this decision to make intent visible in reviews, keep generated code scoped, and reduce hidden maintenance costs. The production signal is code that another developer can explain without reverse-engineering the author's guess.

## Syntax

```text
`Hello ${name}`
"Hello " + name
```

## Decision Guide

1. Name the task in plain language.
2. Choose template literals when: Use template literals when a string contains variables, multiple values, or line breaks.
3. Choose string concatenation when it communicates the intent better.
4. If neither fits, pause and look for a prerequisite concept.

## Comparison Table

| Choice | Best For | Trade-Off |
| --- | --- | --- |
| template literals | Use template literals when a string contains variables, multiple values, or line breaks. | Can confuse beginners when used by habit. |
| string concatenation | A clearer fit when the primary option does not match the task | Can add noise if the project does not need it. |

## When To Use The Primary Option

- Use template literals when a string contains variables, multiple values, or line breaks.
- Use it when it makes the code easier to explain.
- Use it when it matches the surrounding project convention.

## When To Use The Alternative

- Use it when template literals would hide the real intent.
- Use it when the alternative gives the learner or reviewer a clearer signal.
- Use it when existing project code already follows that pattern.

## When Not To Use This Decision

- Do not use template literals to hide complex formatting logic inside one long string.
- Do not expand the current Rookie Vue alpha mission just to use this candidate.
- Do not treat this candidate as fully reviewed evidence.

## Alternatives

- Use an existing Gold Candidate node when this topic overlaps one.
- Use a smaller prerequisite concept when the learner is blocked earlier.

## Production Examples

### Beginner Example

```text
const message = `Saved ${todos.length} todos`;
```

### Review Example

```text
Before accepting the code, explain why template literals or string concatenation matches the task.
```

## Common Mistakes

- Forgetting backticks and expecting ${value} to work inside normal quotes.
- Copying generated code without checking whether it matches the task.
- Treating the candidate as final before examples and sources are hardened.

## Debugging Checklist

- If ${name} appears on screen, check whether the string uses backticks.
- Compare the current behavior with the intended choice.
- Ask whether a smaller prerequisite concept would unblock the learner faster.

## Mechanical Verification

Runnable or deterministic examples should be added during a future hardening sprint. This candidate intentionally has no runnable example folder yet.

## Performance Notes

No performance claim is finalized for this candidate. Future hardening should separate real runtime concerns from readability and learning concerns.

## AI Coding Guidance

- Ask AI to keep generated strings readable and avoid mixing many concatenation pieces.
- Ask for a small, scoped change.
- Ask the assistant to explain the trade-off before producing code.

## Teaching Notes

Start with the plain-language model, show the beginner example, then ask the learner to explain the choice back in one sentence. Keep this candidate optional until a mission needs it.

## Interview Questions

1. When would you choose template literals?
2. What mistake would make string concatenation or another concept clearer?

## Exercises

### Beginner

Convert three concatenated strings into template literals.

### Junior

Find one example in a small project and explain whether it uses the clearer option.

## Related Atlas Nodes

- CANON-CANDIDATE-BROWSER-002

## Evidence And Sources

- Candidate backlog entry only. Official source links must be added during hardening.
- Evidence level: candidate draft.
- Confidence: medium.

## Proof Of Superiority Summary

This candidate has a draft improvement hypothesis only. It should not be treated as reviewed or publication-ready.

## Scorecard Placeholder

- Current score: 55
- Status: candidate
- Needs official sources, stronger examples, verification, editorial review, and reviewer sign-off before any Gold consideration.
