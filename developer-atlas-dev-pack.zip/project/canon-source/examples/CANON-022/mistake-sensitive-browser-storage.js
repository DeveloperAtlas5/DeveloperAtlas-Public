const assert = require("assert");

function shouldStoreInBrowserStorage(record) {
  const sensitiveKinds = new Set(["password", "access_token", "refresh_token", "private_key", "secret"]);
  return !sensitiveKinds.has(record.kind);
}

module.exports = function mistakeSensitiveBrowserStorage() {
  assert.strictEqual(shouldStoreInBrowserStorage({ kind: "todo_list" }), true);
  assert.strictEqual(shouldStoreInBrowserStorage({ kind: "access_token" }), false);
  assert.strictEqual(shouldStoreInBrowserStorage({ kind: "password" }), false);
};
