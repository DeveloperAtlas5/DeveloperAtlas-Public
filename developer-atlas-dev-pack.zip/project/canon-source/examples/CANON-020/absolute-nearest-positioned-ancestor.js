const assert = require("node:assert/strict");
const { absolutePosition } = require("./layout-simulator");

module.exports = function runAbsoluteNearestPositionedAncestorExample() {
  const result = absolutePosition({
    ancestors: [
      { id: "page", position: "static", x: 0, y: 0 },
      { id: "card", position: "relative", x: 200, y: 120 },
      { id: "content", position: "static", x: 220, y: 150 }
    ],
    top: 12,
    left: 16
  });

  assert.equal(result.containingBlockId, "card");
  assert.equal(result.keepsLayoutSpace, false);
  assert.equal(result.visualTop, 132);
  assert.equal(result.visualLeft, 216);
};
