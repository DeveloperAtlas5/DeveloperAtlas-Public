const assert = require("node:assert/strict");
const { innerJoinUsersOrders, users } = require("./data");

module.exports = function runMistakeInnerJoinUnmatchedUsersExample() {
  const rows = innerJoinUsersOrders();
  const returnedUserIds = new Set(rows.map((row) => row.user.id));
  const missingUsers = users.filter((user) => !returnedUserIds.has(user.id));

  assert.deepEqual(missingUsers.map((user) => user.email), ["linus@example.com"]);
};
