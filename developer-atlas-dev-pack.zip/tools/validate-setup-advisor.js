const fs = require("fs");
const path = require("path");
const {
  setupAdvisorDir,
  readSetupRequests
} = require("./setup-advisor-utils");

const requiredSchemaFiles = [
  "setup-request.schema.json",
  "setup-advice.schema.json"
];

const requiredRequestFields = [
  "request_id",
  "learner_level",
  "operating_system",
  "stack",
  "goal",
  "known_tools",
  "constraints",
  "preferred_editor",
  "available_minutes"
];

function main() {
  const errors = [];
  const warnings = [];

  validateSchemaFiles(errors);

  let records = [];
  try {
    records = readSetupRequests();
  } catch (error) {
    errors.push(`setup-advisor/examples: unable to read requests (${error.message})`);
  }

  const seenIds = new Set();
  for (const record of records) {
    validateRequest(record, seenIds, errors, warnings);
  }

  console.log("Atlas Setup Advisor validation");
  console.log(`Setup requests: ${records.length}`);
  console.log(`Errors: ${errors.length}`);
  for (const error of errors) console.log(`  - ${error}`);
  console.log(`Warnings: ${warnings.length}`);
  for (const warning of warnings) console.log(`  - ${warning}`);

  if (errors.length) process.exitCode = 1;
}

function validateSchemaFiles(errors) {
  for (const fileName of requiredSchemaFiles) {
    const schemaPath = path.join(setupAdvisorDir, fileName);
    if (!fs.existsSync(schemaPath)) {
      errors.push(`setup-advisor/${fileName}: missing schema file`);
      continue;
    }

    try {
      JSON.parse(fs.readFileSync(schemaPath, "utf8"));
    } catch (error) {
      errors.push(`setup-advisor/${fileName}: invalid JSON (${error.message})`);
    }
  }
}

function validateRequest(record, seenIds, errors, warnings) {
  const { request, relativePath } = record;

  for (const field of requiredRequestFields) {
    if (request[field] === undefined || request[field] === null || request[field] === "") {
      errors.push(`${relativePath}: missing ${field}`);
    }
  }

  if (typeof request.request_id === "string") {
    if (seenIds.has(request.request_id)) errors.push(`${relativePath}: duplicate request_id ${request.request_id}`);
    seenIds.add(request.request_id);
  }

  validateStringArray(relativePath, request, "stack", errors);
  validateStringArray(relativePath, request, "known_tools", errors);
  validateStringArray(relativePath, request, "constraints", errors);

  if (typeof request.available_minutes !== "number" || request.available_minutes <= 0) {
    errors.push(`${relativePath}: available_minutes should be a positive number`);
  }

  if (request.available_minutes < 30) {
    warnings.push(`${relativePath}: available_minutes may be too low for environment setup`);
  }
}

function validateStringArray(relativePath, data, field, errors) {
  if (!Array.isArray(data[field])) {
    errors.push(`${relativePath}: ${field} should be an array`);
    return;
  }

  for (const value of data[field]) {
    if (typeof value !== "string" || !value.trim()) {
      errors.push(`${relativePath}: ${field} contains a non-string entry`);
    }
  }
}

main();
