const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const outputDir = path.join(rootDir, "output", "editorial");

const CHECKS = [
  { key: "missing analogy", section: "Mental Model", patterns: [/think of|imagine|model|analogy|phrase|box|map|shape|relationship/i] },
  { key: "missing decision guide", section: "Decision Guide", patterns: [/## Decision Guide/i] },
  { key: "missing production example", section: "Production Examples", patterns: [/## Production Examples/i] },
  { key: "missing troubleshooting", section: "Debugging Checklist", patterns: [/## Debugging Checklist/i] },
  { key: "missing exercises", section: "Exercises", patterns: [/## Exercises/i] },
  { key: "missing AI notes", section: "AI Coding Guidance", patterns: [/## AI Coding Guidance/i] },
  { key: "missing evidence", section: "Evidence And Sources", patterns: [/## Evidence And Sources/i, /https?:\/\//i] },
  { key: "missing graph links", section: "Related Atlas Nodes", patterns: [/## Related Atlas Nodes/i, /`[a-z]+[.\w-]+`/] },
  { key: "missing verification", section: "Mechanical Verification", patterns: [/## Mechanical Verification/i] },
  { key: "missing interview section", section: "Interview Questions", patterns: [/## Interview Questions/i] }
];

const DIMENSIONS = [
  ["technical_accuracy", 12],
  ["teaching_quality", 12],
  ["decision_support", 12],
  ["production_readiness", 10],
  ["evidence", 10],
  ["ai_readiness", 10],
  ["relationships", 8],
  ["exercises", 6],
  ["examples", 8],
  ["readability", 4],
  ["maintainability", 4],
  ["future_proofing", 4]
];

function loadCanonEntries() {
  const index = JSON.parse(fs.readFileSync(path.join(rootDir, "canon", "canon-index.json"), "utf8"));
  return index.entries.map((entry) => {
    const markdown = fs.readFileSync(path.join(rootDir, entry.source_node_path), "utf8");
    return { ...entry, markdown };
  });
}

function reviewEntry(entry) {
  const warnings = [];
  const missingSections = [];
  for (const check of CHECKS) {
    if (!check.patterns.every((pattern) => pattern.test(entry.markdown))) {
      warnings.push(check.key);
      missingSections.push(check.section);
    }
  }

  const dimensions = scoreDimensions(entry.markdown, warnings);
  const score = Object.values(dimensions).reduce((sum, value) => sum + value, 0);
  return {
    canon_id: entry.canon_id,
    node_id: entry.node_id,
    title: entry.title,
    score,
    canon_score: entry.score,
    publication_status: publicationStatus(score, entry.status),
    warnings,
    dimensions,
    missing_sections: [...new Set(missingSections)]
  };
}

function scoreDimensions(markdown, warnings) {
  const score = {};
  for (const [key, max] of DIMENSIONS) score[key] = max;

  if (warnings.includes("missing evidence")) score.evidence = Math.min(score.evidence, 3);
  if (warnings.includes("missing graph links")) score.relationships = Math.min(score.relationships, 2);
  if (warnings.includes("missing exercises")) score.exercises = Math.min(score.exercises, 1);
  if (warnings.includes("missing production example")) score.production_readiness = Math.min(score.production_readiness, 4);
  if (warnings.includes("missing AI notes")) score.ai_readiness = Math.min(score.ai_readiness, 3);
  if (warnings.includes("missing verification")) score.examples = Math.min(score.examples, 4);
  if (warnings.includes("missing decision guide")) score.decision_support = Math.min(score.decision_support, 4);
  if (warnings.includes("missing analogy")) score.teaching_quality = Math.min(score.teaching_quality, 7);
  if (warnings.includes("missing troubleshooting")) score.maintainability = Math.min(score.maintainability, 2);

  if (!/official|MDN|Vue|PostgreSQL|W3C|ECMAScript|MySQL|SQLite/i.test(markdown)) score.technical_accuracy = Math.min(score.technical_accuracy, 8);
  if (!/When Not To Use|Alternatives/i.test(markdown)) score.future_proofing = Math.min(score.future_proofing, 2);
  if (markdown.length < 6000) score.readability = Math.min(score.readability, 3);
  if (!/Trade-Off|trade-off|Tradeoff|cost|risk/i.test(markdown)) score.decision_support = Math.min(score.decision_support, 9);

  return score;
}

function publicationStatus(score, canonStatus) {
  if (canonStatus === "gold") return "Gold";
  if (canonStatus === "candidate") return "Candidate";
  if (score >= 95) return "Gold Candidate";
  if (score >= 85) return "Review";
  if (score >= 70) return "Draft";
  return "Candidate";
}

function average(items, selector) {
  if (!items.length) return 0;
  return items.reduce((sum, item) => sum + selector(item), 0) / items.length;
}

function ensureEditorialOutputDir() {
  fs.mkdirSync(outputDir, { recursive: true });
}

function weakestSections(reviews) {
  const counts = {};
  for (const review of reviews) {
    for (const section of review.missing_sections) counts[section] = (counts[section] || 0) + 1;
  }
  return Object.entries(counts).sort((a, b) => b[1] - a[1]);
}

function strongestSections(reviews) {
  const sections = CHECKS.map((check) => check.section);
  const weak = new Map(weakestSections(reviews));
  return sections
    .map((section) => [section, reviews.length - (weak.get(section) || 0)])
    .sort((a, b) => b[1] - a[1]);
}

module.exports = {
  CHECKS,
  DIMENSIONS,
  outputDir,
  rootDir,
  loadCanonEntries,
  reviewEntry,
  average,
  ensureEditorialOutputDir,
  weakestSections,
  strongestSections
};
