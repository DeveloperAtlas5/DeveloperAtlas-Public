# Atlas Brain Pack Specification

The Brain Pack is the generated reasoning context for Atlas Brain.

## Purpose

The Brain Pack packages the reasoning flow, personas, decision model, graph statistics, high-confidence nodes, high-importance nodes, recommendation-ready nodes, and relationship summary into one machine-readable artifact.

## Inputs

- `output/ai/atlas-context-pack.json`
- `output/graph/knowledge-graph.json`
- `brain/reasoning-flow.json`
- `brain/personas.json`
- `brain/decision-model.json`

## Output

- `output/brain/atlas-brain-pack.json`

## Required Sections

- `metadata`
- `reasoning_flow`
- `personas`
- `decision_model`
- `node_count`
- `edge_count`
- `high_confidence_nodes`
- `high_importance_nodes`
- `recommendation_ready_nodes`
- `relationship_summary`

## Rule

The Brain Pack is generated. Do not hand-edit generated Brain outputs.
