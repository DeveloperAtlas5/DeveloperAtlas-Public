const assert = require("node:assert/strict");

module.exports = function runStringifyForStorageAndApiExample() {
  const settings = {
    theme: "dark",
    density: "compact",
    notifications: true
  };

  const storedText = JSON.stringify(settings);
  const request = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(settings)
  };

  assert.equal(typeof storedText, "string");
  assert.equal(request.headers["Content-Type"], "application/json");
  assert.equal(request.body, storedText);
  assert.deepEqual(JSON.parse(storedText), settings);
};
