function ref(initialValue) {
  return { value: initialValue };
}

function computed(getter) {
  return {
    get value() {
      return getter();
    }
  };
}

function createWatchedRef(initialValue) {
  const subscribers = [];
  let currentValue = initialValue;

  return {
    get value() {
      return currentValue;
    },
    set value(nextValue) {
      const previousValue = currentValue;
      currentValue = nextValue;
      for (const subscriber of subscribers) subscriber(nextValue, previousValue);
    },
    watch(callback) {
      subscribers.push(callback);
    }
  };
}

function watch(source, callback) {
  source.watch(callback);
}

module.exports = {
  ref,
  computed,
  createWatchedRef,
  watch
};
