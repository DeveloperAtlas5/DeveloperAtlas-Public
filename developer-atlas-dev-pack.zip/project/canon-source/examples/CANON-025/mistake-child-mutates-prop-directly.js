const assert = require("assert");

module.exports = function mistakeChildMutatesPropDirectly() {
  const warnings = [];
  const parentTodo = { id: 1, text: "Do not mutate props", done: false };

  function createReadonlyProp(value) {
    return new Proxy(value, {
      set() {
        warnings.push("Child attempted to mutate a parent-owned prop.");
        return false;
      }
    });
  }

  function TodoItem(props) {
    try {
      props.todo.done = true;
    } catch {
      warnings.push("Mutation was blocked by readonly prop boundary.");
    }
  }

  TodoItem({ todo: createReadonlyProp(parentTodo) });

  assert.strictEqual(parentTodo.done, false);
  assert.ok(warnings.length >= 1);
};
