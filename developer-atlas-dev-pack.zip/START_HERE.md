# Developer Atlas Public Alpha Demo

## Start here

Open `mission-dashboard.html`.

Start Mission 1.

You do not need to browse the folders.

If you feel nervous, open `first-time-quick-start.md`.

## What the folders mean

- `mission/` is where the learner missions live.
- `help/` is optional support.
- `ai/` is optional AI-assisted material.
- `reference/` is optional concept reference.
- `reviewer/` is for testers, mentors, or project reviewers.

## Simplest path

Open `mission-dashboard.html`.

Start Mission 1.

You do not need to browse the folders.

## Read here, code there

This package guides you.

Your Vue todo project is where you write code.

Do not edit files inside this Atlas package unless a mission explicitly tells you to.

## Fastest path

1. Open `mission-dashboard.html`.
2. Start Mission 1: `mission/today-mission-surface.md`.
3. Use `help/` only if you get stuck.
4. Answer the reflection questions at the end.

## Accessibility note

Use the dashboard if a visual overview helps. The dashboard also includes an optional read-aloud button.

You can zoom your browser, use your own screen reader or text-to-speech tools, and move through dashboard links with a keyboard.

## Mission path

Mission 1 is the primary path:

```text
mission/today-mission-surface.md
```

After Mission 1, continue only if you want the next step:

Mission 2 is the next mission after Mission 1.

```text
mission/mission-02-todoitem-surface.md
mission/mission-03-todostats-surface.md
```

`mission/mission-02-todoitem-surface.md` is the next mission after Mission 1.

After Mission 2, open `mission/mission-03-todostats-surface.md`. Mission 3 adds a small stats component.

If you build with AI, use the matching `.vibe.md` mission files.

## Using AI?

Use the AI mission files or `ai/ai-prompt-pack.md`.

Give AI one mission at a time.

## Optional help

- `help/beginner-orientation.md` for folders, `App.vue`, terminal commands, and `package.json`.
- `help/terminal-confidence-guide.md` for `npm install`, `npm run dev`, and project folders.
- `help/vue-concept-cards.md` for `ref()`, `reactive()`, `v-for`, `:key`, and Vue state.

## Optional reference

`reference/canon/hardened/` contains short Canon notes for concepts used in Missions 1-3.

These notes are optional. You do not need them to start Mission 1.

## Give feedback

After testing, answer the reflection questions at the end of the mission. You can also use `mission/mission-feedback-template.md`.

Project owners and reviewers can use `reviewer/tester-feedback-report.md`, `reviewer/alpha-package-final-qa.md`, and `reviewer/alpha-focus-lock.md` after learner testing.

## What to ignore for now

Normal testers can ignore reports, package metadata, source code, build scripts, and reviewer files unless they are specifically reviewing the project.
