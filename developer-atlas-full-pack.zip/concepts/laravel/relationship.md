# Laravel Relationship

Technology: Laravel

## Simple meaning

A relationship describes how models connect, such as one user having many posts.

## Why it exists

Relationships let Laravel load connected records with clear method names.

## Where you use it

Inside model classes in `app/Models`.

## When to use it

Use relationships when database records belong together, such as posts and comments or users and orders.

## Tiny example

`User` can `hasMany(Post::class)`, and `Post` can `belongsTo(User::class)`.

## Common beginner confusion

A relationship method describes a database connection. It is not just an array nested inside another object.

## Related concepts

- Model
- Eloquent
- Migration

## Similar idea in another technology

Frontend data can nest related items, but database relationships define how stored records connect.
