const examples = [
  ["find user by id", require("./find-user-by-id")],
  ["find product by slug", require("./find-product-by-slug")],
  ["mistake: using filter()[0] instead of find()", require("./mistake-filter-zero-instead-of-find")],
  ["mistake: expecting find() to return all matches", require("./mistake-expecting-find-all-matches")]
];

for (const [name, run] of examples) {
  run();
  console.log(`PASS ${name}`);
}

console.log(`Verified ${examples.length} CANON-010 example(s).`);
