# CANON-005 Proof Of Superiority

## What Official Docs Explain Well

PostgreSQL, MySQL, and SQLite documentation explain SQL join syntax, join clauses, and joined table behavior.

## What Developers Still Struggle With

Developers still struggle with result shape: why rows disappear with `INNER JOIN`, why rows multiply in one-to-many joins, why `LEFT JOIN` introduces nulls, and how filters can accidentally change outer join behavior.

## How Atlas Improves The Explanation

Atlas frames joins around the driving table, relationship key, unmatched-row behavior, and cardinality before showing syntax.

## What Decision Support Atlas Adds

The Canon node gives a decision guide for choosing `INNER JOIN`, `LEFT JOIN`, `EXISTS`, aggregation, or staged queries based on the question being asked.

## What Production Guidance Atlas Adds

The node covers key production risks: wrong keys, row multiplication, missing rows, right-table filters in `WHERE`, ambiguous columns, indexes, query plans, and avoiding `SELECT *`.

## What AI-Readable Structure Atlas Adds

The node gives AI assistants explicit generation rules: identify the main table, choose join type by unmatched-row behavior, include `ON`, qualify columns, avoid `SELECT *`, and warn about cardinality.

## Why This Deserves Gold Status

This node deserves Gold-candidate status because it turns SQL joins from syntax memorization into result-shape reasoning, with official sources, deterministic examples, debugging guidance, production trade-offs, and AI coding guardrails. It still needs named reviewer sign-off before final Gold approval.
