const fs = require("fs");
const path = require("path");
const {
  hardwareOutputDir,
  ensureHardwareOutputDir,
  readHardwareNodes,
  readWorkloadProfiles,
  countValues,
  average,
  round
} = require("./hardware-utils");

function main() {
  const nodes = readHardwareNodes().map((record) => record.node);
  const workloads = readWorkloadProfiles().map((record) => record.workload);
  const report = buildReport(nodes, workloads);

  ensureHardwareOutputDir();
  fs.writeFileSync(
    path.join(hardwareOutputDir, "hardware-index.json"),
    `${JSON.stringify({ hardware_nodes: nodes, workload_profiles: workloads }, null, 2)}\n`
  );
  fs.writeFileSync(
    path.join(hardwareOutputDir, "hardware-report.md"),
    toMarkdown(report)
  );

  console.log(`Generated output/hardware/hardware-index.json for ${nodes.length} hardware node(s).`);
  console.log("Generated output/hardware/hardware-report.md.");
}

function buildReport(nodes, workloads) {
  const highestRiskWorkloads = [...workloads]
    .sort((a, b) => b.estimated_risk_of_wrong_purchase - a.estimated_risk_of_wrong_purchase)
    .slice(0, 5);

  return {
    total_hardware_nodes: nodes.length,
    workload_profiles: workloads.length,
    average_future_proofing_score: round(average(nodes.map((node) => node.future_proofing_score))),
    highest_cost_risk_workloads: highestRiskWorkloads.map((workload) => ({
      workload_id: workload.workload_id,
      goal: workload.goal,
      estimated_risk_of_wrong_purchase: workload.estimated_risk_of_wrong_purchase
    })),
    most_common_specs: countValues(nodes.flatMap((node) => node.important_specs)),
    most_important_specs_by_workload: workloads.map((workload) => ({
      workload_id: workload.workload_id,
      priority_order: workload.priority_order
    })),
    local_vs_cloud_guidance: workloads.map((workload) => ({
      workload_id: workload.workload_id,
      guidance: workload.local_vs_cloud_guidance
    })),
    recommended_next_hardware_nodes: recommendedNextHardwareNodes(nodes, workloads)
  };
}

function recommendedNextHardwareNodes(nodes, workloads) {
  const nodeIds = new Set(nodes.map((node) => node.id));
  const recommendations = [];

  if (!nodeIds.has("hardware.display.external_monitor")) {
    recommendations.push("Add external monitor and ergonomics guidance for long learning sessions.");
  }
  if (!nodeIds.has("hardware.network.reliability")) {
    recommendations.push("Add network reliability guidance for cloud, package installs, and remote development.");
  }
  if (workloads.some((workload) => workload.workload_id.includes("llm"))) {
    recommendations.push("Add a model sizing worksheet for local AI workload planning.");
  }
  recommendations.push("Add budget-band neutral upgrade paths that avoid store or price recommendations.");

  return recommendations;
}

function toMarkdown(report) {
  const lines = [
    "# Atlas Hardware Report",
    "",
    `Total hardware nodes: ${report.total_hardware_nodes}`,
    `Workload profiles: ${report.workload_profiles}`,
    `Average future-proofing score: ${report.average_future_proofing_score}`,
    "",
    "## Highest Cost-Risk Workloads",
    "",
    ...report.highest_cost_risk_workloads.map((workload) => {
      return `- ${workload.workload_id}: ${workload.estimated_risk_of_wrong_purchase}/100 - ${workload.goal}`;
    }),
    "",
    "## Most Common Important Specs",
    "",
    ...formatCounts(report.most_common_specs.slice(0, 12)),
    "",
    "## Most Important Specs by Workload",
    "",
    ...report.most_important_specs_by_workload.map((workload) => {
      return `- ${workload.workload_id}: ${workload.priority_order.join(", ")}`;
    }),
    "",
    "## Local vs Cloud Guidance",
    "",
    ...report.local_vs_cloud_guidance.map((item) => `- ${item.workload_id}: ${item.guidance}`),
    "",
    "## Recommended Next Hardware Nodes",
    "",
    ...formatList(report.recommended_next_hardware_nodes)
  ];

  return `${lines.join("\n")}\n`;
}

function formatCounts(items) {
  return items.length ? items.map((item) => `- ${item.value}: ${item.count}`) : ["- None"];
}

function formatList(items) {
  return items.length ? items.map((item) => `- ${item}`) : ["- None"];
}

main();

