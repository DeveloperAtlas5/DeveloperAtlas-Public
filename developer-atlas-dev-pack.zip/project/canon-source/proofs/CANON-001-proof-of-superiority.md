# CANON-001 Proof Of Superiority

## What Official Docs Explain Well

MDN explains that `map()` creates a new array from callback results and that `forEach()` executes a callback for each element and returns `undefined`.

## What Developers Still Struggle With

Developers often choose by habit instead of intent. Beginners use `forEach()` to build transformed arrays manually, use `map()` for side effects, forget that `map()` should return a value for every item, or assume `forEach(async () => ...)` is awaited by the caller.

## How Atlas Improves The Explanation

Atlas frames the decision around output shape: new array means `map()`, side effect means `forEach()`, filtered array means `filter()`, single value means `reduce()`, one item means `find()`, yes/no checks mean `some()` or `every()`, and imperative async or early-exit control means `for...of`.

## What Decision Support Atlas Adds

The node gives a direct comparison table, when-to-use sections, alternatives, async decision guidance, and a debugging checklist so a developer can choose rather than memorize.

## What Production Guidance Atlas Adds

The node includes API transformation, Vue computed list preparation, logging side effects, async control flow examples, performance notes, and code review guidance.

## What AI-Readable Structure Atlas Adds

The node separates decision guidance, alternatives, production examples, common mistakes, debugging checks, AI coding guidance, related nodes, and evidence so assistants can retrieve the right reasoning for a task.

## Why This Deserves Gold Status

This node is a strong Gold candidate because it teaches a daily JavaScript decision better than syntax-only docs. It now has direct source links, runnable verification examples, improved production examples, and a realistic Gold-candidate score. It still needs named reviewer sign-off before Gold approval.
