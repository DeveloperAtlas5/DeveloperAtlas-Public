const fs = require("fs");
const path = require("path");
const { rootDir } = require("./content-utils");

const examplePath = path.join(rootDir, "brain", "examples", "choose-array-loop-method.json");
const brainPackPath = path.join(rootDir, "output", "brain", "atlas-brain-pack.json");
const contextPackPath = path.join(rootDir, "output", "ai", "atlas-context-pack.json");
const graphPath = path.join(rootDir, "output", "graph", "knowledge-graph.json");
const outputDir = path.join(rootDir, "output", "advisor");
const outputPath = path.join(outputDir, "array-loop-advice.md");

function readJson(file) {
  if (!fs.existsSync(file)) {
    throw new Error(`Missing required input: ${path.relative(rootDir, file)}. Run npm run build first.`);
  }
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function main() {
  const example = readJson(examplePath);
  const brainPack = readJson(brainPackPath);
  const contextPack = readJson(contextPackPath);
  const graph = readJson(graphPath);
  const nodeById = new Map(contextPack.knowledge.map((node) => [node.id, node]));

  const supportingNodes = example.supporting_nodes
    .map((nodeId) => nodeById.get(nodeId))
    .filter(Boolean);
  const relatedEdges = graph.edges.filter(
    (edge) => example.supporting_nodes.includes(edge.source) || example.supporting_nodes.includes(edge.target)
  );

  const confidence = Math.min(...supportingNodes.map((node) => Number(node.confidence || 3)));
  const evidenceLevels = [...new Set(supportingNodes.map((node) => node.evidence_level).filter(Boolean))];
  const learningNext = chooseLearningNext(example.supporting_nodes, relatedEdges);

  const lines = [
    "# Atlas Advisor Demo: Choosing an Array Loop Method",
    "",
    "This is a deterministic Atlas Brain simulation. It uses Brain examples, the AI context pack, and the knowledge graph. It does not call an LLM or API.",
    "",
    "## User Goal",
    "",
    example.user_goal,
    "",
    "## Detected Intent",
    "",
    "- Intent: engineering decision",
    "- Persona assumption: junior developer unless specified",
    "- Reasoning flow: detect intent -> identify problem -> compare options -> evaluate trade-offs -> recommend -> suggest next learning",
    "",
    "## Recommendation",
    "",
    "Choose the array method by the shape of the result you need:",
    "",
    "- New transformed array: `map()`",
    "- Smaller filtered array: `filter()`",
    "- First matching item: `find()`",
    "- One accumulated value: `reduce()`",
    "- Any item matches: `some()`",
    "- Every item matches: `every()`",
    "- Side effects only: `forEach()`",
    "",
    "## Confidence",
    "",
    `- Confidence: ${confidence}/5`,
    `- Evidence level: ${evidenceLevels.join(", ") || "context_dependent"}`,
    `- Supporting high-confidence nodes in Brain pack: ${brainPack.high_confidence_nodes.length}`,
    "",
    "## Trade-Offs",
    ""
  ];

  for (const tradeoff of example.tradeoffs) lines.push(`- ${tradeoff}`);

  lines.push("", "## Alternatives", "");
  for (const recommendation of example.recommendations) {
    const node = nodeById.get(recommendation.node_id);
    lines.push(`- \`${recommendation.node_id}\` (${node?.title || recommendation.node_id}): ${recommendation.use_when} Avoid when: ${recommendation.avoid_when}`);
  }

  lines.push(
    "",
    "## Beginner Explanation",
    "",
    example.beginner_explanation,
    "",
    "## Professional Summary",
    "",
    example.professional_summary,
    "",
    "## Related Knowledge Nodes",
    ""
  );

  for (const node of supportingNodes) {
    lines.push(`- \`${node.id}\` - ${node.summary}`);
  }

  lines.push("", "## What To Learn Next", "");
  for (const nodeId of learningNext) {
    const node = nodeById.get(nodeId);
    lines.push(`- \`${nodeId}\`${node ? ` - ${node.title}` : ""}`);
  }

  lines.push(
    "",
    "## AI Coding Guidance",
    "",
    example.ai_coding_guidance,
    ""
  );

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${lines.join("\n")}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)}.`);
}

function chooseLearningNext(supportingNodeIds, edges) {
  const next = [];
  for (const edge of edges) {
    const candidate = supportingNodeIds.includes(edge.source) ? edge.target : edge.source;
    if (!supportingNodeIds.includes(candidate) && !next.includes(candidate)) next.push(candidate);
    if (next.length >= 5) break;
  }
  return next.length > 0 ? next : supportingNodeIds.slice(0, 3);
}

main();
