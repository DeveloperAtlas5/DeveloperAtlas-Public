# Demo Package Instructions

This feedback kit is designed to be used with the Developer Atlas MVP demo package.

Expected demo package locations:

- Folder: `output/share/developer-atlas-mvp-demo/`
- Zip: `output/share/developer-atlas-mvp-demo.zip`

If both packages are side by side after sharing, open:

```text
../developer-atlas-mvp-demo/site/index.html
```

Then read:

1. `../developer-atlas-mvp-demo/demo/mvp-demo-pack.md`
2. `../developer-atlas-mvp-demo/demo/demo-walkthrough.md`
3. `../developer-atlas-mvp-demo/advisors/recovery-npm-install-fails.md`
4. `../developer-atlas-mvp-demo/reports/team-context-quality-report.md`
