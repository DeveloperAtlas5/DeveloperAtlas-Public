const fs = require("fs");
const path = require("path");
const { readEntries, compareEntries, rootDir } = require("./content-utils");
const { buildGraph } = require("./graph-utils");

const outputDir = path.join(rootDir, "output", "graph");
const outputPath = path.join(outputDir, "knowledge-graph.json");

function main() {
  const entries = readEntries().sort(compareEntries);
  const graph = buildGraph(entries);

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(outputPath, `${JSON.stringify(graph, null, 2)}\n`);
  console.log(`Generated ${path.relative(rootDir, outputPath)} with ${graph.nodes.length} nodes and ${graph.edges.length} edges.`);
}

main();
