const fs = require("fs");
const path = require("path");
const { rootDir, readEntries } = require("./content-utils");

const canonIndexPath = path.join(rootDir, "canon", "canon-index.json");
const learningOutputDir = path.join(rootDir, "output", "learning");

const skillAreaByCanonId = {
  "CANON-001": "JavaScript Arrays",
  "CANON-002": "JavaScript Arrays",
  "CANON-003": "Vue Reactivity",
  "CANON-004": "CSS Layout",
  "CANON-005": "SQL Fundamentals",
  "CANON-006": "Vue Reactivity",
  "CANON-007": "Vue Directives",
  "CANON-008": "JavaScript Async",
  "CANON-009": "JavaScript Arrays",
  "CANON-010": "JavaScript Arrays"
};

function readCanonIndex() {
  return JSON.parse(fs.readFileSync(canonIndexPath, "utf8"));
}

function ensureLearningOutputDir() {
  fs.mkdirSync(learningOutputDir, { recursive: true });
}

function getKnownReferences(entries = readCanonIndex().entries) {
  const refs = new Set();
  for (const entry of entries) {
    refs.add(entry.canon_id);
    refs.add(entry.node_id);
  }
  for (const entry of readEntries()) {
    if (entry.frontMatter.id) refs.add(entry.frontMatter.id);
  }
  return refs;
}

function getSkillArea(entry) {
  if (skillAreaByCanonId[entry.canon_id]) return skillAreaByCanonId[entry.canon_id];
  if (entry.node_id.includes(".vue.")) return "Vue";
  if (entry.node_id.includes(".css.")) return "CSS";
  if (entry.node_id.includes(".sql.")) return "SQL";
  if (entry.node_id.includes(".javascript.")) return "JavaScript";
  return "General";
}

function unique(values) {
  return [...new Set((values || []).filter(Boolean))];
}

function getLearning(entry) {
  return entry.learning || {};
}

function buildLearningGraph(entries) {
  const knownRefs = getKnownReferences(entries);
  const canonIds = new Set(entries.map((entry) => entry.canon_id));
  const nodes = entries.map((entry) => ({
    id: entry.canon_id,
    canon_id: entry.canon_id,
    node_id: entry.node_id,
    title: entry.title,
    skill_area: getSkillArea(entry)
  }));
  const edges = [];
  const missing = new Set();
  const inbound = new Map(entries.map((entry) => [entry.canon_id, 0]));
  const outbound = new Map(entries.map((entry) => [entry.canon_id, 0]));

  for (const entry of entries) {
    const learning = getLearning(entry);
    for (const ref of unique(learning.prerequisites)) {
      if (!knownRefs.has(ref)) missing.add(`${entry.canon_id}: prerequisite ${ref}`);
      edges.push({ from: ref, to: entry.canon_id, type: "prerequisite" });
      if (canonIds.has(ref)) inbound.set(entry.canon_id, (inbound.get(entry.canon_id) || 0) + 1);
    }
    for (const ref of unique(learning.unlocks)) {
      if (!knownRefs.has(ref)) missing.add(`${entry.canon_id}: unlock ${ref}`);
      edges.push({ from: entry.canon_id, to: ref, type: "unlock" });
      if (canonIds.has(ref)) outbound.set(entry.canon_id, (outbound.get(entry.canon_id) || 0) + 1);
    }
  }

  return {
    nodes,
    edges,
    missing_references: [...missing].sort(),
    root_nodes: [...inbound.entries()].filter(([, count]) => count === 0).map(([id]) => id),
    terminal_nodes: [...outbound.entries()].filter(([, count]) => count === 0).map(([id]) => id),
    cycles_detected: detectCanonCycles(entries)
  };
}

function detectCanonCycles(entries) {
  const canonIds = new Set(entries.map((entry) => entry.canon_id));
  const adjacency = new Map(entries.map((entry) => [entry.canon_id, []]));
  for (const entry of entries) {
    const refs = [...unique(getLearning(entry).unlocks)];
    for (const ref of refs) {
      if (canonIds.has(ref)) adjacency.get(entry.canon_id).push(ref);
    }
  }

  const cycles = [];
  const visiting = new Set();
  const visited = new Set();

  function visit(node, stack) {
    if (visiting.has(node)) {
      cycles.push(stack.slice(stack.indexOf(node)).concat(node));
      return;
    }
    if (visited.has(node)) return;
    visiting.add(node);
    for (const next of adjacency.get(node) || []) visit(next, stack.concat(next));
    visiting.delete(node);
    visited.add(node);
  }

  for (const entry of entries) visit(entry.canon_id, [entry.canon_id]);
  return cycles;
}

function sumLearning(entries, field) {
  return entries.reduce((sum, entry) => sum + Number(getLearning(entry)[field] || 0), 0);
}

module.exports = {
  canonIndexPath,
  learningOutputDir,
  readCanonIndex,
  ensureLearningOutputDir,
  getKnownReferences,
  getSkillArea,
  getLearning,
  buildLearningGraph,
  sumLearning,
  unique
};

