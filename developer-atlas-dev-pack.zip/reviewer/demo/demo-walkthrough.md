# Developer Atlas Demo Walkthrough

Use this walkthrough when showing the MVP from files only.

## 1. Open The Demo Pack

Start with `output/demo/mvp-demo-pack.md`. Explain that this is generated from structured Atlas data, not handwritten marketing copy.

## 2. Show Atlas Flow

Open `output/flow/rookie-vue-todo-flow.md` first. Show how Atlas turns separate reports into one calm journey from goal to next step.

## 3. Show Canon Quality

Open `output/canon/canon-report.md`. Point to the Canon node count, average score, and release batches.

## 4. Show The Project Recommendation

Open `output/capability/project-fit-report.md`. Show the ready-today project and the deferred project. This proves Atlas can say both yes and not yet.

## 5. Show The Four-Week Ladder

Open `output/capability/capability-pathway.md`. The ladder moves from a small Vue app toward larger full-stack work.

Weeks in the generated pathway:
- Week 1: Build Vue Todo App (ready today)
- Week 2: Build Laravel CRUD API (mostly ready)
- Week 3: Run Local LLM Learning Experiment (mostly ready)
- Week 4: Build Full-Stack Inventory System (defer)

## 6. Show Friction Recovery

Open `output/recovery-advisor/recovery-advisor-report.md`. Show that Atlas can respond to common blockers like npm install failures, Vite startup issues, Composer PATH problems, and missing Laravel artisan files.

## 7. Show AI Context

Open `output/ai-context/rookie-vue-next-step.md` and `output/ai-context/ai-context-quality-report.md`. The point is portability: Atlas gives the user better context for any AI assistant.

## 8. Show Team Context

Open `output/team-context/team-context-quality-report.md`. This shows Atlas can evaluate shared team context for alignment, onboarding clarity, AI safety, and drift risk.

## Closing Line

Developer Atlas is not just a knowledge base. It is a deterministic progress layer that helps developers decide what to learn, what to build, what to fix, and what context to give humans or AI next.

Generated at: 2026-07-06T13:29:42.465Z
