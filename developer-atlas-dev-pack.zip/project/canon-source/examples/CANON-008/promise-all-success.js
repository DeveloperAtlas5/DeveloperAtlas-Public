module.exports = async function runPromiseAllSuccess() {
  const values = await Promise.all([
    Promise.resolve("user"),
    Promise.resolve("permissions"),
    Promise.resolve("settings")
  ]);

  const actual = values.join("|");
  const expected = "user|permissions|settings";

  if (actual !== expected) {
    throw new Error(`Expected ${expected}, got ${actual}`);
  }
};
