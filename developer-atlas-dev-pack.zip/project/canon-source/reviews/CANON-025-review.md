# Canon Review Template

Canon ID: CANON-025
Node ID: canon.vue.components.props-vs-emits-vs-model
Reviewer: Pending Gold Review Panel
Date: 2026-07-04
Stage: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Gold-candidate draft aligns with Vue documentation for props, component events, component `v-model`, `defineProps()`, `defineEmits()`, and `defineModel()`.
- Edge cases: Covers prop mutation, parent-owned state, input-like controlled components, named model bindings, and when stores or composables are better.
- Version concerns: `defineModel()` depends on modern Vue support, so the node names the classic `modelValue` and `update:modelValue` fallback.
- Evidence quality: Direct official Vue source URLs are included.

## Educational Review

- Beginner clarity: Strong "props down, events up, controlled editing" model.
- Mental model: Ownership is introduced before syntax.
- Exercise quality: Beginner, intermediate, and advanced exercises are present.
- Common mistake coverage: Covers child prop mutation, vague events, duplicate local state, overusing `v-model`, and prop drilling.

## AI Review

- Structured enough for retrieval: Yes.
- Code generation guidance: Strong and specific.
- Ambiguity risks: AI should ask who owns the value before generating component communication code.
- Related node quality: Related Canon and Vue content graph IDs are included.

## Engineering Review

- Decision support: Strong.
- Production realism: Todo item, search input, and domain action examples reflect common Vue application code.
- Trade-offs: Good coverage of explicit emits, controlled inputs, prop boundaries, stores, composables, and reviewability.
- Anti-pattern coverage: Strong enough for Gold-candidate review.

## Decision

- Approved stage: Gold Candidate
- Required changes: Add named reviewer sign-off before Gold approval.
- Score: 95
