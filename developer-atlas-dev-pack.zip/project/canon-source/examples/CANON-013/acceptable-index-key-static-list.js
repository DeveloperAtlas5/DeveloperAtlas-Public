const { renderRows } = require("./keyed-patch-simulator");

module.exports = function runAcceptableIndexKeyStaticList() {
  const passwordRules = [
    { id: "rule-0", label: "At least 12 characters" },
    { id: "rule-1", label: "Includes a number" },
    { id: "rule-2", label: "Includes a symbol" }
  ];

  const firstRender = renderRows(passwordRules, (_item, index) => index);
  const secondRender = renderRows(passwordRules, (_item, index) => index, firstRender.stateByKey);

  const sameIdentity = secondRender.rows.every((row, index) => {
    return row.itemId === passwordRules[index].id && row.state.createdFor === passwordRules[index].id;
  });

  if (!sameIdentity) {
    throw new Error("Static index-keyed list should keep position and item identity aligned.");
  }

  return secondRender.rows;
};
