# CANON-011 Review

Canon ID: CANON-011
Node ID: canon.javascript.promise.async-await-vs-promise-then
Title: async vs await vs Promise.then()
Status: Gold Candidate

## Reviewer Placeholders

- Technical reviewer: TBD Technical Reviewer
- Educational reviewer: TBD Educational Reviewer
- AI-readiness reviewer: TBD AI Reviewer
- Engineering reviewer: TBD Engineering Reviewer

## Technical Review

- Accuracy: Explains `async` function promise returns, `await` rejection behavior, and `.then()` continuation behavior.
- Edge cases: Covers missing `.then()` returns, `try/catch` without `await`, accidental serialization, and `forEach(async ...)`.
- Evidence: Uses MDN and ECMAScript source URLs.
- Verification: Four deterministic Node examples pass.

## Educational Review

- Mental model: Frames async code as handoffs, with checklist-shaped `async`/`await` and pipeline-shaped `.then()`.
- Beginner clarity: Starts with plain function-return and wait-for-result language.
- Progression: Moves from syntax to sequencing, chains, error handling, and concurrency.
- Exercises: Covers beginner, intermediate, and advanced practice.

## AI Readiness Review

- Code generation guidance: Strong rules for defaulting to `async`/`await`, preserving returned chains, avoiding `forEach(async ...)`, and selecting concurrency tools.
- Machine readability: Stable headings match Canon template.
- Relationship quality: Links to array, reduce, Promise.all/allSettled, and fetch-related nodes.

## Engineering Review

- Production examples: Includes handler, transformation chain, dashboard concurrency, and sequential loop cases.
- Debugging support: Checklist maps directly to common production async failures.
- Trade-offs: Clear distinction between readability, promise composition, and concurrency.

## Remaining Gold Gaps

- Named human reviewer sign-off is still required before final Gold status.
