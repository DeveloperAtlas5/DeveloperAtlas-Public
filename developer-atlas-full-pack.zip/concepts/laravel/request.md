# Laravel Request

Technology: Laravel

## Simple meaning

A request represents incoming data from the browser or API client.

## Why it exists

It gives Laravel one object for reading form fields, query strings, files, headers, and user context.

## Where you use it

Controller methods and custom Form Request classes.

## When to use it

Use a request when you need data sent by the user or client.

## Tiny example

`$request->input('email')`

## Common beginner confusion

A request is what comes into the app. A response is what the app sends back.

## Related concepts

- Route
- Controller
- Validation

## Similar idea in another technology

In Express, `req` has a similar job.
