# Canon Selection Criteria

A node may enter the Canon candidate list when it meets at least one of these conditions:

- It explains a concept developers use daily.
- It prevents common beginner confusion.
- It improves production engineering decisions.
- It connects multiple Atlas nodes into a reusable mental model.
- It is commonly mishandled by AI coding assistants.
- It appears frequently in interviews, code reviews, debugging, or architecture discussions.

Canon candidates should be stable, broadly useful, and worth teaching carefully.

## Exclusions

- Narrow trivia.
- Version-specific edge cases unless they define a major migration.
- Content that only repeats official documentation.
- Nodes without meaningful decision guidance.

