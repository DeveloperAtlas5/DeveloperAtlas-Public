# Start a Java Project

## What this is for

Use this when you want to start or run a small Java program.

## What you need first

You need a JDK installed before compiling and running Java from the terminal.

## Required tools

- JDK
- A terminal
- VS Code or an IDE

## Recommended extensions

- Extension Pack for Java

## Start from zero

- Create a project folder.
- Create a file such as `Main.java`.
- Add a small `public class Main` example.
- Compile it with `javac Main.java`.
- Run it with `java Main`.

## Open an existing project

- Open the project folder in VS Code or an IDE.
- Find the main `.java` file or project instructions.
- Use the project's build tool if it has one.

## Run or preview the project

- For one file, run `javac Main.java` and then `java Main`.
- For larger projects, use the IDE run button or the project's build command.

## Where you usually code

- Java code usually lives in `.java` files.
- Larger projects often place code under a `src/` folder.

## Common first problems

- `javac` is not recognized: install a JDK and reopen the terminal.
- Class name error: the public class name should match the file name.
- Package errors appear: check the folder structure or use the IDE run option.

## Next Atlas step

After Java runs, continue with the mission or use a guide for the next concept.
