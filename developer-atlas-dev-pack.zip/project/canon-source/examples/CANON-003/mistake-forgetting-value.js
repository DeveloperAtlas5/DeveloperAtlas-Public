const assert = require("node:assert/strict");
const { ref } = require("./reactivity-sim");

function run() {
  const count = ref(0);

  const wrongResult = count + 1;
  const rightResult = count.value + 1;

  assert.equal(wrongResult, "[object Object]1");
  assert.equal(rightResult, 1);

  count.value = rightResult;
  assert.equal(count.value, 1);

  return { wrongResult, rightResult };
}

module.exports = run;

if (require.main === module) run();
