const assert = require("node:assert/strict");

function run() {
  const validationErrors = [
    { field: "email", code: "required" },
    { field: "password", code: "too_short" }
  ];
  const analyticsEvents = [];

  const result = validationErrors.forEach((error) => {
    analyticsEvents.push({
      event: "validation_error",
      field: error.field,
      code: error.code
    });
  });

  assert.equal(result, undefined);
  assert.deepEqual(analyticsEvents, [
    { event: "validation_error", field: "email", code: "required" },
    { event: "validation_error", field: "password", code: "too_short" }
  ]);

  return analyticsEvents;
}

module.exports = run;

if (require.main === module) run();
